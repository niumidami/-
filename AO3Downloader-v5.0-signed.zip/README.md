# obkk下载中 v4.6（原 AO3 下载器）

Android 原生客户端，用于把 Archive of Our Own（AO3）的作品下载为本地文件。
包名 `com.tabbit.aodl`，`versionCode = 10`，`versionName = 4.6`，最低支持 **Android 7.0（API 24）**。

---

## 0. v4.6 更新了什么（站点作品搜索 + 搜索页合并 + 收藏复制）

| # | 需求 | 落地方式 |
| --- | --- | --- |
| 1 | 新增功能：可以通过原网站搜索作品 | 接入 AO3 站点搜索 `GET /works/search?work_search[query]=<关键词>&commit=Search[&page=N]`（`net/Ao3Client.kt` 的 `searchWorks`）。结果页与作者作品列表**共用同一套作品条目结构**（`ol.work index group` + `li#work_<id>.work.blurb`），因此解析直接复用 `net/Ao3Parsers.kt` 的 `parseWorkList` / `parseWorkBlurb`；分页按 AO3 搜索页实际使用的 `will_paginate` 结构取下一页 |
| 2 | 搜索结果只显示前六，后面的被折叠 | 折叠逻辑下沉为纯函数 `data/SearchResultPlan.kt`（`COLLAPSED_LIMIT = 6`、`visibleCount` / `hiddenCount` / `collapsible` / `visible`）。**折叠只发生在渲染层**：状态里的结果集始终是完整的，全选与批量下载按完整集合算，收起再展开不会丢勾选；不足 6 条时不显示折叠条 |
| 3 | 搜索作者和搜索作品两个分页合在一起（但不是把两个搜索融在一起） | 底部导航的「作者」Tab 改为「搜索」Tab（`ui/SearchScreen.kt` 取代原 `AuthorScreen.kt`），页面顶部用一个分段控件在**「搜索作者」/「搜索作品」两个子页**之间切换。两套搜索**各自独立**：输入框、结果集、分页状态、勾选状态分别由 `AuthorUiState` 与 `WorkSearchUiState` 持有，切子页不会清空对方的结果 |
| 4 | 收藏书签里的作品可以复制作者名字和编号 | 「我的 → 我的收藏」每条作品新增三个复制动作：复制作者名 / 复制编号（带 `#` 前缀）/ 一次性复制成 `作者名 #编号`（`data/BookmarkCopy.kt` + `Components.BookmarkRow`），走系统剪贴板并在日志区回执 |

顺手修掉一处文案歧义：作者子页里那个按钮原来写的是「搜索作品」，语义其实是「搜索该作者的作品」，现改为**「搜索该作者」**（英文 `Search this author`），避免与新的作品搜索混淆。

版本随之升到 `versionCode = 10` / `versionName = 4.6`；包名 `com.tabbit.aodl` 未变，签名沿用同一份 `keystore/aodl.jks`。

## 0.1 v4.5 修好了什么（v4.3 / v4.4 打开即闪退）

| # | 问题 | 用户看到的现象 | 根因与修复 |
| --- | --- | --- | --- |
| 1 | v4.3 / v4.4 装上后打开就闪退 | 点图标黑一下就退出，界面进不去（**Android 8.0 及以上必现**，Android 7.x 不受影响） | v4.3 把应用图标换成了 `drawable-anydpi-v26/ic_launcher.xml`（`<adaptive-icon>` 自适应图标），而顶栏与底部导航的图标位用 Compose 的 `painterResource` 渲染它——该 API **只支持矢量图与位图**，碰到自适应图标会在**首帧**抛 `IllegalArgumentException: Only VectorDrawables and rasterized asset types are supported ex. PNG, JPG, WEBP`，进程当场退出 |
| 2 | 应用内图标位与桌面图标混用同一个资源 | —— | 拆成两个资源：桌面图标继续用 `ic_launcher`（自适应图标，由系统渲染，不经 Compose）；应用内图标位改用新增的 `AppIcon.logoRes`——默认款指向纯位图 `drawable-*/ic_logo_sakura.png`，另外三套仍用各自矢量图 |
| 3 | 渲染逻辑对资源类型过于敏感 | —— | `ui/Components.kt` 的 `AppLogo` 不再用 `painterResource`，改为 `ContextCompat.getDrawable` + `Canvas` 栅格化成 `ImageBitmap`，位图 / 矢量 / 自适应图标都能画；解码失败用 `runCatching` 兜底退回 `Icons.Filled.Image` 占位图标，任何情况下都不会崩 |

一句话：**崩的不是下载功能，而是首帧那个 26 dp 的应用图标。** v4.3 之前该资源是矢量图所以没事，v4.3 换成自适应图标后 Compose 不支持才炸；v4.5 把「应用内渲染」与「桌面图标」两个用途拆成两个资源，并去掉对资源类型的隐式假设。

版本随之升到 `versionCode = 9` / `versionName = 4.5`；包名 `com.tabbit.aodl` 未变，签名沿用同一份 `keystore/aodl.jks`。

## 0.2 v4.4 更新了什么（设置页折叠整理 + HTML 美化默认主题）

| # | 变更 | 落地方式 |
| --- | --- | --- |
| 1 | 设置页按主题折叠分组 | 新增 `ui/Components.kt` 的 `GroupCard`（点击标题栏展开/收起、`rememberSaveable` 记住状态、标题栏右侧显示当前取值摘要）。`ui/SettingsScreen.kt` 的 8 个分区全部改为折叠卡片，默认只展开第一组，长页面不再一次性铺开 |
| 2 | HTML 美化的最终呈现与导出文档一致 | 新增 `data/DocBeautifier.kt`：不再只往 `<head>` 注入一段 CSS，而是按 AO3 官方下载模板的结构**解析后重建**整篇——扉页（标题 + by 作者）→ 版权页（来源、标签、统计行逐条）→ 前言（Summary / Notes）→ 目录 → 逐章正文（含章末注）→ THE END → 关于页 |
| 3 | 把随包提供的第二段美化代码设为默认主题 | 该段 CSS（「暗夜樱粉」：`#17161a` 背景、`#f7a8c6` 樱粉标题、`.content-wrapper` 容器、分页线与移动端适配）原文不改动，作为内置常量 `DocBeautifier.THEME_CSS` 写入 `style#aodl-doc-theme` |
| 4 | 美化风格可切换 | 新增 `BeautifyStyle`：`DOCUMENT`（书籍文档，新默认）与 `CLASSIC`（v3.0 起的注入式美化，保留）；自定义 CSS 追加与「保留原文件」对两种风格都生效 |

解析一律**按结构定位**（`#preface` / `dl.tags` 的 `dt-dd` 对 / `blockquote.userstuff` / `#chapters` 的 `.meta.group` 与 `div[id^=endnotes]` / `#afterword`），不依赖英文标签文本，因此中文界面或 AO3 改了文案都不会解析失败。美化结果会写入 `<meta name="generator" content="obkk-doc-beautifier">`，重复美化同一文件时只刷新样式块、不会二次重建结构。

版本随之升到 `versionCode = 8` / `versionName = 4.4`；包名 `com.tabbit.aodl` 未变，签名沿用同一份 `keystore/aodl.jks`。

## 0.3 上一版（v4.3）：应用图标与应用名称

| # | 变更 | 落地方式 |
| --- | --- | --- |
| 1 | 应用图标换成本次随包提供的图片 | `drawable-mdpi`~`drawable-xxxhdpi/ic_launcher.png`（各密度位图）+ `drawable-anydpi-v26/ic_launcher.xml`（自适应图标，前景为同一图片、背景为纯白 `@color/ic_launcher_background`）。API 24/25 走位图，API 26+ 走自适应图标（圆形、方形等形状由系统裁切） |
| 2 | 应用名称改为「obkk下载中」 | `values/strings.xml` 与 `values-en/strings.xml` 的 `app_name`；`AndroidManifest` 的 `application` 与 4 个 `activity-alias` 都引用 `@string/app_name`，桌面名称随之变化 |

## 0.4 v4.2 修好了什么

| # | 问题 | 用户看到的现象 | 根因与修复 |
| --- | --- | --- | --- |
| 1 | PDF 每下载一次就多出一个文件夹 | 同一作者目录下同时出现 `onee1e` 与 `onee1e (1)`，内容各占一半 | 并发任务同时判定「目录不存在」→ 各自调 `createDirectory`，第二份被 SAF 自动改名成 `onee1e (1)`。目录的查建改为**串行化**，并在建完之后复核 provider 实际给出的名字：名字被改写就说明已有同名目录，立即复用它并回收自己刚建的空目录（`data/SubDirPlanner.kt`） |
| 2 | 下载下来的 PDF 打开是坏的 | 目录里 `xxx.pdf` 与 `xxx.pdf.part.pdf` 并存，其中一个打不开 | 写入侧原先只把流拷进文件，**不校验内容**。现在加了两道校验：头部魔数（PDF 必须 `%PDF`、EPUB 必须 `PK`、MOBI/AZW3 第 60 字节起必须 `BOOKMOBI`、HTML 必须以 `<` 开头）与响应声明的总长；判定顺序为**先比总长、后验头部**——不完整判 `INCOMPLETE`（残片有续传价值，保留并重试），字节数对得上但内容不对判 `INVALID_CONTENT`（多半是登录页或被拦截的响应，**一个字节都不落盘**、删残片、不重试） |
| 3 | `.part` 残片越积越多、断点续传失效 | 盘上出现 `xxx.pdf.part.pdf`、`xxx (1).pdf.part` 等多种写法 | 旧实现处处用「按请求名精确查找」定位 `.part`，一旦 provider 改名就全部落空：探测不到断点、删不掉残片、续传还会**再建一份新的**。改为按**名字模式**识别（`data/PartCleanup.kt`），与 provider 实际写法无关 |

中间文件的清理策略见 6.1.1，分格式目录的四种开关组合见 6.2。

### 0.4.1 v4.1 修好了什么（已保留）

| # | 问题 | 根因与修复 |
| --- | --- | --- |
| 1 | 五种格式的文件全部落进同一个文件夹 | 「已解析目录」的缓存键只用了「根目录 + 作者名」，**漏了格式这一维**。缓存键改为「根目录 + 作者名 + 格式」（`DirPlan.cacheKey`） |
| 2 | 关闭「按作者分类保存」后完全没有格式目录 | 格式层判定改为「根目录是否已经按格式分开」：只要多种格式共用同一个根目录，就一定补一层格式目录（`DirPlan.needsFormatLevel`） |

---

## 1. v4.0 功能一览（v4.1 / v4.2 / v4.3 / v4.4 / v4.5 / v4.6 全部保留）

| # | 功能 | 落地位置 |
| --- | --- | --- |
| 1 | 文件名自动改为「作品名 by 作者名.后缀」，取不到时回退作品 ID | `data/FileNameBuilder.kt` |
| 2 | 按格式分目录保存，自动创建「作者名 / HTML·PDF·MOBI·EPUB·AZW3」两级目录，已存在则复用追加 | `data/DirPlan.kt` + `data/SafStore.kt` |
| 3 | 底部第 4 个标签页「管理」：下载记录列表、实时进度条、已传/总大小、完成/失败状态、刷新与清空 | `ui/ManageScreen.kt` + `data/DownloadHistory.kt` |
| 4 | 自定义图标：4 套内置图标一键切换，也可上传图片作为图标 | `model/AppIcon.kt`、`data/IconPlan.kt`、`data/IconManager.kt`、`ui/SettingsScreen.kt` |
| 5 | 自动跳转官网、由用户自行登录后提取 Cookie | `ui/LoginWebScreen.kt`、`net/Ao3WebProxy.kt`、`data/WebLoginPlan.kt` |
| 6 | 下载优化：断点续传、失败自动重试、并发队列、精确进度、DoH 端点轮换 | `data/ResumePlan.kt`、`vm/RetryPolicy.kt`、`vm/AppViewModel.kt`、`net/DohDns.kt` |

v3.0 的全部功能（安全 DNS、SAF 保存、HTML 美化与预览、作者检索批量下载、收藏列表、双语界面、三套主题）均保留。

---

## 2. 技术栈

| 层次 | 选型 |
| --- | --- |
| 语言 / UI | Kotlin 2.0.20 + Jetpack Compose（BOM 2024.09.00，Material3，material-icons-extended 1.7.0） |
| 构建 | AGP 8.5.2 / Gradle 8.7 / JDK 17 / Android SDK 34（build-tools 34.0.0） |
| 网络 | OkHttp 4.12.0，自定义 `okhttp3.Dns` 实现 DNS-over-HTTPS |
| HTML 解析 | Jsoup 1.18.1 |
| 文件读写 | SAF（`DocumentsContract` + `DocumentFile` + `takePersistableUriPermission`），全程流式写入，落盘前后各有一道完整性校验 |
| 网页 | `androidx.webkit` 1.11.0 + 系统 WebView（预览页 / 官网登录页） |
| 桌面图标 | `activity-alias` + `PackageManager.setComponentEnabledSetting`；快捷方式走 `ShortcutManagerCompat` |
| 持久化 | SharedPreferences：主设置沿用 `aodl_v3_prefs`（**升级保留登录态与全部设置**），下载记录新增 `aodl_v4_history` |
| 测试 | JUnit 4.13.2，`./gradlew testReleaseUnitTest` 共 **231** 个用例 |
| 架构 | 单 Activity + Compose，`AndroidViewModel` + `StateFlow` |

**不使用任何镜像站**：所有请求直连 `https://archiveofourown.org`，被污染或阻断时由安全 DNS（DoH）解析真实 IP。

---

## 3. 构建

```bash
export JAVA_HOME=<JDK 17>
export ANDROID_HOME=<Android SDK，需含 platforms;android-34 与 build-tools;34.0.0>

# local.properties 中写入 sdk.dir=<Android SDK 绝对路径>
./gradlew testReleaseUnitTest   # 231 个用例
./gradlew assembleRelease
```

产物：`app/build/outputs/apk/release/app-release.apk`

首次构建需要联网拉取依赖。若官方仓库缓慢，可在 `settings.gradle.kts` 的
`dependencyResolutionManagement.repositories` 中替换为镜像仓库（本次构建实测 `maven.aliyun.com` 可用）。

---

## 4. 签名

- 方案：**APK Signature Scheme v2 + v3**（`v1 = false`、`v3.1 = false`、`v4 = false`，单签名者）。
- 密钥库：`keystore/aodl.jks`，别名 `aodl`，口令见 `keystore.properties`。
- 证书 DN：`CN=AO3 Downloader, OU=App, O=Tabbit, L=CN, ST=CN, C=CN`
  （`SHA256withRSA`，**2048-bit RSA**，有效期 2026-10-22 → 2056-10-14）。
- 证书 SHA-256：`c6be6a6793d70ccadc958b79eee8efa0c2dad9c4807c685b5e96bf51a63fb730`

> **升级提示**
> - **v3.0 / v4.0 / v4.1 / v4.2 / v4.3 / v4.4 / v4.5 → v4.6：可直接覆盖安装，数据保留。** 已实测比对：从 v3.0 交付包中取出的
>   `AO3Downloader-v3.0.apk`（`versionCode = 3`）、v4.0 与 v4.1 交付包里的 APK，与本次 v4.6 APK
>   的签名者证书 SHA-256 **完全一致**（均为上表 `c6be6a67…fb730`），也都与
>   `keystore/aodl.jks` 内证书指纹一致，v4.6 用的仍是同一份密钥库。
>   主设置的 SharedPreferences 文件名仍为 `aodl_v3_prefs`，因此登录 Cookie、保存目录授权、
>   DoH 配置、排版与主题设置在升级后原样可用（下载记录是新文件 `aodl_v4_history`，v3.0 没有该数据）。
> - **v2.0 → v4.6：本次无法代为比对，请按下面的命令自查。** v2.0 的 APK 已不在本构建环境中
>   （uploads 目录不可访问），因此**没有做证书指纹比对**，不能断言两者签名是否相同。
>   请用 `apksigner verify --print-certs AO3Downloader-v2.0.apk` 取出证书 SHA-256：
>   与上表一致 → 可直接覆盖安装；不一致 → 必须先卸载 v2.0 再安装 v4.6，
>   否则会提示「应用未安装」或签名冲突。
> - 卸载会清除应用私有数据，包括登录 Cookie、下载记录与上传的自定义图标；
>   已下载到 SAF 目录的文件不受影响。
>
> `keystore.properties` 含明文口令，仅用于本地复现构建。正式分发前请替换为自己的密钥库，
> 并把 `keystore.properties`、`keystore/` 加入版本控制忽略列表。

---

## 5. 目录结构

```
app/src/main/java/com/tabbit/aodl/
├── MainActivity.kt            入口：语言 Context 包装、分享/深链接收、语言切换后重建
├── model/
│   ├── Models.kt              纯 JVM 数据模型（格式、日志、作品条目、DoH 状态、账号、设置、
│   │                          下载记录 DownloadRecord / 状态 DownloadStatus / WebLoginState…）
│   ├── AppIcon.kt             4 套内置图标枚举，与 Manifest 的 activity-alias 一一对应
│   └── IconUiState.kt         图标设置页的 UI 状态
├── data/
│   ├── Prefs.kt               SharedPreferences 全量持久化（沿用 aodl_v3_prefs）；Cookie 存取；密码不落盘
│   ├── SafStore.kt            SAF 目录/文件创建、子目录复用、流式写入、持久化授权、文本读写、
│   │                          中间文件清理（决策全部下沉到 PartCleanup，本文件只做 SAF 适配）
│   ├── HtmlBeautifier.kt      按排版设置生成 CSS 并注入 </head> 前
│   ├── FileNameBuilder.kt     【需求 1】文件名生成与非法字符清洗、长度截断、作品 ID 回退
│   ├── DirPlan.kt             【需求 2】目录规划的纯决策：是否建格式层、作者层与格式层怎么拼、
│   │                          已解析目录的缓存键（建目录由 SafStore 执行）
│   ├── SubDirPlanner.kt       【v4.2】子目录查建的纯决策：先查后建、建完复核、同名一律复用，
│   │                          消除并发任务各自 createDirectory 导致 `作者 (1)` 的竞态
│   ├── PartCleanup.kt         【v4.2】`.part` 中间文件的识别与收敛决策（纯函数）：按名字模式
│   │                          认出 provider 改名后的各种变体，决定留哪份/删哪些/要不要改回规范名
│   ├── StreamCopy.kt          【v4.2】流式落盘与完整性收尾：先比总长、后验头部魔数，
│   │                          区分 INCOMPLETE（可续传）与 INVALID_CONTENT（不落盘、不重试）
│   ├── FormatSignature.kt     【v4.2】五种格式的头部特征校验（PDF `%PDF`、EPUB `PK`、
│   │                          MOBI/AZW3 第 60 字节起 `BOOKMOBI`、HTML 以 `<` 开头）
│   ├── DownloadHistory.kt     【需求 3】下载记录持久化（独立 prefs，上限 300 条）
│   ├── IconPlan.kt            【需求 4】图标选择的纯决策：alias 启用组合、裁剪取样框
│   ├── IconManager.kt         【需求 4】alias 启停、上传图片落盘、桌面快捷方式
│   ├── ResumePlan.kt          【需求 6】断点续传的纯决策（206 + Content-Range 起点校验）
│   ├── SearchResultPlan.kt    【v4.6】搜索结果「只显示前六、其余折叠」的纯决策：可见条数、
│   │                          隐藏条数、要不要出折叠条、折叠/展开各返回哪一段
│   ├── BookmarkCopy.kt        【v4.6】收藏条目复制内容的纯决策：作者名 / 编号（带 # 前缀）/
│   │                          两者拼成一行，以及内容缺失时该动作是否可用
│   └── WebLoginPlan.kt        【需求 5】官网登录的纯逻辑：主机白名单、Cookie 归一化、
│                              重定向策略、请求/响应头清洗、表单捕获 JS、replaceState JS
├── net/
│   ├── DohDns.kt              DNS wireformat 编解码、DoH GET/POST、TTL 缓存、端点轮换与回退
│   ├── Ao3Client.kt           登录、会话校验、下载、作者作品列表、收藏列表、
│   │                          【v4.6】站点作品搜索（/works/search）、当前登录用户名
│   ├── Ao3Parsers.kt          页面解析与重试判定（独立成文件以便离线断言）；
│   │                          【v4.6】作品列表 / 作品条目 / 搜索请求构造的纯函数集中在这里
│   └── Ao3WebProxy.kt         【需求 5】WebView 请求经 DoH 转发的本地代理，自行跟随重定向
├── util/Format.kt             与语言无关的大小 / 速度 / 剩余时间格式化
├── vm/
│   ├── AppViewModel.kt        全部业务编排与 StateFlow 状态（`resolveDir` 负责把 DirPlan 的
│   │                          判定结果落到 SAF 上，目录缓存键带格式维度）
│   └── RetryPolicy.kt         【需求 6】线性退避（2s/4s/6s…上限 15s）与总尝试次数
└── ui/
    ├── theme/Theme.kt         暗樱花粉 / 午夜蓝 / 樱花亮色三套配色
    ├── Components.kt          卡片、按钮、开关行、分段选择、滑杆、进度、日志控制台等
    ├── AppRoot.kt             底部 **4** Tab 导航 + 设置页 + 预览层 + 官网登录层
    ├── DownloadScreen.kt      下载主页
    ├── SearchScreen.kt        【v4.6】搜索页：「搜索作者」与「搜索作品」两个可切换子页，
    │                          作品结果默认只显示前六条、其余折叠（取代原 AuthorScreen.kt）
    ├── AccountScreen.kt       底部「我的」Tab：登录状态 / 收藏列表 / 官网登录入口
    ├── ManageScreen.kt        【需求 3】下载管理页
    ├── LoginWebScreen.kt      【需求 5】官网登录 WebView 层
    ├── SettingsScreen.kt      设置页（含下载优化、图标、安全 DNS 分区）
    └── PreviewScreen.kt       WebView HTML 预览
```

测试：`app/src/test/java/com/tabbit/aodl/` 下 **15** 个测试类，共 **231** 个用例：
`AppIconTest`(5)、`BookmarkCopyTest`(16)、`DocBeautifierTest`(10)、`DirPlanTest`(17)、
`FileNameBuilderTest`(15)、`FormatSignatureTest`(15)、`IconPlanTest`(20)、`PartCleanupTest`(22)、
`ResumePlanTest`(8)、`SearchResultPlanTest`(15)、`StreamCopyTest`(15)、`SubDirPlannerTest`(8)、
`WebLoginPlanTest`(29)、`Ao3ParsersTest`(32)、`RetryPolicyTest`(4)。

资源：`res/values/strings.xml`（中文，默认，451 键）、`res/values-en/strings.xml`（英文，451 键）、
`res/drawable/ic_launcher{,_night,_mono,_ao3}.xml`（夜读 / 素白 / AO3 红三套矢量图标）、
`res/drawable-*/ic_launcher.png` 与 `res/drawable-anydpi-v26/ic_launcher.xml`（v4.3 起的桌面图标）、
`res/drawable-*/ic_logo_sakura.png`（**v4.5 新增**，应用内图标位用的纯位图，5 个密度）。

---

## 6. 功能说明

### 6.0 设置页的折叠分组（v4.4）

设置项多且杂，v4.4 起整页改为折叠分组：

- 8 个分区各是一张可点击展开/收起的卡片（`GroupCard`），默认只展开第一组，其余收成一行。
- 收起状态下标题栏右侧显示该组的当前取值摘要（例如美化组显示「书籍文档 · 下载后自动美化」），不展开也能看到关键设置。
- 展开/收起状态用 `rememberSaveable` 记住，切到别的页面再回来不会复位。
- 分组只是呈现方式的变化：设置项本身、默认值、以及写入 `SharedPreferences` 的键都没有改动，覆盖安装后原有设置全部保留。

### 6.1 下载与文件命名（需求 1、6）

- 输入作品编号、作品链接或整段文本，自动提取全部作品编号（支持一次多个）。
- 支持系统「分享到 obkk下载中」与 `https://archiveofourown.org/works/<id>` 深链。
- 走 AO3 官方接口：`GET /downloads/<作品编号>/work.<html|pdf|mobi|epub|azw3>`。
- 下载前**预解析作品页**取得标题、作者、章节数与更新时间；预解析失败会提前报错，不产生半截文件。
- 文件名规则（可在「设置 → 下载优化」里关闭，关闭时用服务端 `Content-Disposition` 建议名）：
  1. 标题与作者都拿到 → `作品名 by 作者名.<后缀>`（多作者以 `, ` 连接）；
  2. 只拿到标题 → `作品名.<后缀>`；
  3. 都拿不到 → 回退 **作品 ID** 命名 `<workId>.<后缀>`；
  4. 作品 ID 也为空 → 兜底 `AO3-work.<后缀>`。
  - 清洗：替换文件系统非法字符与控制字符、折叠连续空白、去首尾点与空格；
    标题段截断 80 字符、作者段 40 字符、整名（含扩展名）120 字符，保证 FAT32/ext4/FUSE 均可写。
- **断点续传**：写入 `<文件名>.part` 临时文件，带 `Range: bytes=<已有大小>-` 请求；
  仅当服务端确实以 `206` 返回、且 `Content-Range` 确认的起点等于本地 `.part` 大小时才续写，
  其余情况（含 `416`、起点不一致）一律丢弃 `.part` 重新下载，绝不出现错位拼接。
  **v4.2 起断点按名字模式探测**，不再依赖「请求时那个名字」：SAF provider 把中间文件
  改名成 `xxx.pdf.part.pdf` 或 `xxx (1).pdf.part` 之后，旧版探测不到断点、删不掉残片、
  续传还会再建一份新的，残片于是越积越多——这一串问题的根源已一并消除。
- **落盘完整性校验（v4.2 新增）**：写完先比**响应声明的总长**，再验**头部特征**
  （`%PDF` / `PK` / `BOOKMOBI` / `<`）。字节数不够判 `INCOMPLETE`，保留残片并重试；
  字节数够但内容不对判 `INVALID_CONTENT`——通常是拿到了登录页或被拦截的响应——
  此时**一个字节都不落盘**、删除残片、不再重试，并在日志里写明期望与实收。
- **失败自动重试**：额外重试次数可设 0–5（默认 2），线性退避 2s、4s、6s…上限 15s；
  总尝试次数 = 1 次首发 + 额外重试次数。
- **并发队列**：多作品 × 多格式的任务进队列，同时运行的任务数可设 1–4（默认 2）。
- **精确进度**：`已传 / 总大小 / 速度 / 剩余时间` 全部来自写入流的真实回调；
  服务端未给 `Content-Length` 时界面显示不确定进度条，不编造百分比。
- **DoH 端点轮换**：主端点解析失败时自动依次尝试 `https://dns.google/dns-query`、
  `https://cloudflare-dns.com/dns-query`，仍失败可回退系统 DNS 并在设置页提示。
- 受限作品自动携带会话 Cookie；成人内容需登录后按设置追加 `?view_adult=true`。

#### 6.1.1 中间文件（`.part`）的清理策略

判定规则集中在纯函数 `PartCleanup`（22 条单测），SAF 侧只负责执行，因此规则可离线核对：

| 盘上名字 | 本次下载的正式名 | 判定 |
| --- | --- | --- |
| `x.pdf.part` | `x.pdf` | 中间文件 |
| `x.pdf.part.pdf` | `x.pdf` | 中间文件（provider 按 MIME 追加了扩展名） |
| `x (1).pdf.part` | `x.pdf` | 中间文件（provider 改了重名） |
| `x.pdf.part (1)` | `x.pdf` | 中间文件（重名序号加在 `.part` 之后） |
| `x.pdf` | `x.pdf` | **成品，绝不动** |
| `x.pdf.partition` | `x.pdf` | **成品，绝不动**（`.part` 只是词的一部分） |
| `x2.pdf.part` | `x.pdf` | 不属于本次目标，不动 |

作品名自身含 `.part` 时（正式名 `x.part.pdf`）按**最后一个** `.part` 切分，中间文件
`x.part.pdf.part` 仍能被正确识别。

收尾动作随任务终态而定：

- **下载成功** → 该正式名下的中间文件清零，目录里只剩成品；
- **断点作废**（`416` / `Content-Range` 起点不符 / 内容非法）→ 全部删除，下次从空文件开始；
- **任务终态 FAILED**（重试耗尽或不可重试）→ 全部删除，用户目录里不留 `.part`；
- **任务终态 CANCELLED**（用户取消）→ 收敛为**唯一一份**规范命名的 `x.pdf.part`
  （保留续传入口），同时删掉 `x.pdf.part.pdf`、`x (1).pdf.part` 等重复变体；
- **进程被强杀** → 不走收尾路径，但残片在写入时就已被规范化命名，下次下载仍能续传。

每次实际删除都会在日志区如实报出「已清理 N 个残留临时文件：…」，可对着文件管理器逐条核对。

**一条硬护栏**：若 provider 不支持重命名，成品只能继续叫 `x.pdf.part`（日志区会用
「重命名失败，文件保留为 …」告知）。此时「成品」与「残片」是同一个名字，
按名字模式的删除会直接删掉用户刚下完的文件，因此收尾**整体跳过清理**——
宁可留一个名字不好看的成品，也绝不冒险删数据。这条护栏同样有单测钉死。

### 6.2 保存位置与分格式目录（需求 2）

两个开关：**「统一保存位置」**（`dirFor(format)`：开 = 全部格式共用 `unifiedDir`，关 = 每个格式用自己的目录）
与 **「按作者分类保存」**（默认开启）。两者组合出的目录层级如下（v4.1 / v4.2 修正后的最终行为）：

| 按作者分类 | 统一保存位置 | 实际落盘目录 | 说明 |
| --- | --- | --- | --- |
| 开 | 开 | 所选目录 / **作者名 / 格式名** | 一次建齐五个格式目录 |
| 开 | 关 | 该格式目录 / **作者名 / 格式名** | 每个根目录只建当前格式那一个，不留空目录 |
| 关 | 开 | 所选目录 / **格式名** | v4.0 这里不建任何格式目录，五种格式混在一起（已修） |
| 关 | 关 | 该格式目录（不套子目录） | 用户为每种格式各选了一个目录，目录本身已完成格式隔离，与 v3.0 一致 |

- 判定逻辑集中在**纯函数** `DirPlan.needsFormatLevel` / `formatSegments` / `targetFormatDir`，
  四种组合全部有单测断言（`DirPlanTest`）。
- 格式目录名固定为 `HTML`、`PDF`、`MOBI`、`EPUB`、`AZW3`。
- **已存在同名目录时直接复用并向其中追加文件，绝不重复创建**（`SafStore.ensureSubDir`
  先查后建、建完复核）。
- **v4.2：目录查建串行化，彻底消除 `作者 (1)` 这类重复目录。** 并发队列里多个任务同时
  判定「目录不存在」→ 各自 `createDirectory`，第二份会被 SAF 自动改名成 `onee1e (1)`，
  于是同一作者凭空多出两个文件夹、内容各占一半。现在同一「父目录 + 名字」的查建走同一把锁；
  建完还会复核 provider 实际给出的名字，一旦发现被改写，就说明已有同名目录，
  立即复用它并**回收自己刚建的那个空目录**。决策部分是纯函数 `SubDirPlanner`（8 条单测）。
- **目录缓存键 = 根目录 + 作者名 + 格式**（`DirPlan.cacheKey`，三段以控制字符分隔）。
  同一作者的多个作品共用「同作者同格式」这一个键，避免反复重建目录；
  不同格式一定是不同的键，因此不会出现「某个格式的文件被写进另一个格式目录」。
  作者名与格式名都经过清洗（控制字符一律替换为 `_`），所以占位符不可能与真实名字撞键。
- 作者名同样经过非法字符清洗（比文件名更严格：不允许 `.` / `..`，不允许以空格或点结尾）；
  取不到作者名时一级目录回退为「未知作者」（英文界面为 `Unknown author`）。
- 目录创建失败（如授权被撤销）时退回**上一级目录**并在日志中如实告警，不让整批下载失败；
  格式目录创建失败时告警文案是「创建格式目录失败：…，改存到上一级目录」。
- 设置页会在开关下方直接标出最终路径：按作者分类开启显示
  「最终路径：所选目录 / 作者名 / 格式名（…）」，关闭但用统一目录时显示
  「最终路径：所选目录 / 格式名（…）」。
- 目录授权通过 `takePersistableUriPermission` 持久化，重启后无需重新选择。

### 6.3 下载管理页（需求 3）

- 底部导航第 4 个 Tab「管理」（清单图标 `Icons.Filled.Checklist`）；四个 Tab 依次为
  **下载 / 作者 / 我的 / 管理**（标签文案取自 `tab_download` / `tab_author` / `tab_account` / `tab_manage`）。
- 列表按时间倒序展示：作品名、作者、格式、状态、进度条、已传 / 总大小、速度、剩余时间、失败原因。
- 顶部「下载概况」区汇总统计，下载进行中实时刷新。
- 状态：排队中 / 下载中 / 已完成 / 失败 / 已取消；失败与「上次进程被杀留下的未完成任务」分别标记。
- 顶部三个操作：**刷新**、**清除已结束的记录**、**清空全部记录**；清空只删记录，**不删已下载的文件**。
- 记录持久化在应用私有的 `aodl_v4_history`（JSON 数组，上限 300 条，超限丢弃最旧），
  进程被杀或设备重启后仍可查询；载入时会把残留的 QUEUED/RUNNING 归一为失败，不显示假进度。
- 记录中只存作品编号、标题、作者、文件名、目录 Uri、状态与字节数，**不含 Cookie 或任何凭据**。

### 6.4 自定义图标（需求 4）

- 4 套内置图标：**樱花**（默认）、**夜读**、**素白**、**AO3 红**，在「设置 → 应用图标」一键切换。
- 实现方式：`AndroidManifest` 中 4 个 `<activity-alias>`，每个自带 `MAIN/LAUNCHER`
  意图过滤器和自己的 `android:icon`，全部 `targetActivity=".MainActivity"`；
  切换时用 `PackageManager.setComponentEnabledSetting` 打开目标 alias、关掉其余三个，
  **保证任意时刻有且仅有一个 alias 处于启用状态**，桌面图标真实换图，无需重装应用。
- 主 Activity 只承接 `ACTION_SEND` 与 `ACTION_VIEW`，不再持有 `MAIN/LAUNCHER`。
- 也可从相册上传一张图片作为图标：「设置 → 应用图标 → 上传的图片」分组下的
  **「上传图片作为图标」**；图片居中裁成正方形、缩放到 **256 px**（`IconManager.TARGET_PX`），
  存于应用私有的 `filesDir/icons/custom.png`（卸载即清除，不写共享存储）。
  - 导入成功后该分组会出现三行：**「使用上传的图片」**（已在用则行尾标「使用中」）、
    **「重新选择图片」**、**「用该图片创建桌面快捷方式」**，以及底部的**「删除已上传的图片」**。
  - 上传的图片无法写进 APK，因此**不参与桌面 alias**；应用内所有图标位（导航栏、
    设置页、关于页）会立即换成它，桌面则靠上面那行快捷方式实现（API 26+ 用
    `ShortcutManagerCompat.requestPinShortcut`，API 24–25 用 `ACTION_INSTALL_SHORTCUT`，
    需要 `com.android.launcher.permission.INSTALL_SHORTCUT`）；系统不支持时该行置灰并说明原因。
  - 无权限读取所选 Uri、所选文件不是图片、写入失败三种情况分别给出明确提示。

### 6.5 官网登录取 Cookie（需求 5）

- 底部「我的」Tab 里新增**「官网登录（推荐）」**分区（副标题：在官网页面里自行登录，
  验证码与两步验证都在官网完成），按钮为**「打开 AO3 官网登录」**，已登录时变为
  **「用官网重新登录」**。点击后应用内打开一个 WebView，直接加载
  `https://archiveofourown.org/users/login`，**由你自己在官网上输入账号密码登录**，
  应用不参与密码输入，也不保存密码。
- 登录完成后点「完成并提取 Cookie」：读取 WebView 的 Cookie，校验是否含
  `_otwarchive_session` 或 `remember_user_token`，归一化后落盘；
  随后用 `GET /` 反查当前登录用户名一并保存。反查失败时弹窗让你手动补一个用户名，
  **登录态不会因为取不到用户名而丢失**（Cookie 已先落盘）。
- 保存的 Cookie 复用既有的手动 Cookie 槽位，因此下载、收藏、作者检索链路无需任何改动。
- WebView 的 AO3 请求由 `Ao3WebProxy` 经本应用的安全 DNS（DoH）转发，与下载链路走同一套解析：
  - 只精确匹配 `archiveofourown.org` 与 `www.archiveofourown.org`，其余域名不代理；
  - 代理自行跟随重定向（`followRedirects(false)`），以便拿到 `302` 上的 `Set-Cookie` 原文
    并完整交回 `CookieManager`（保留 Domain / Path / Expires）；
  - 丢弃 hop-by-hop 头、`Accept-Encoding`（交给 OkHttp 透明解压）与响应中的
    `Set-Cookie` / `Location` / `Content-Length` / `Content-Encoding` / `Transfer-Encoding`；
  - 站外导航被拦下，作为登录页的防钓鱼措施；
  - 关闭 `allowFileAccess` / `allowContentAccess` / `allowFileAccessFromFileURLs` /
    `allowUniversalAccessFromFileURLs`，并设 `MIXED_CONTENT_NEVER_ALLOW`；
  - 代理请求失败时返回 `null`，交回 WebView 原生再试一次（未污染网络下反而更容易成功）。
- **POST 的处理方式与隐私权衡（请阅读）**：Android 没有公开 API 能读到 WebView 的 POST 请求体，
  因此登录表单由注入的 JS 在捕获阶段拦下，把字段序列化进查询串（带 `__aodl_post` 标记），
  再由代理还原成真实的 `POST /users/login`。这意味着**密码会短暂出现在 URL 中**。已做的缓解：
  不显示地址栏、URL 不写入任何日志、主框架加载完成后立即 `history.replaceState` 抹掉查询串
  并 `clearHistory()`。若你介意，可继续使用「密码登录」或「手动填入 Cookie」。
- 逃生开关：「设置 → 安全 DNS（DoH）→ 官网登录直连」，默认关闭（= 经安全 DNS 加载，推荐）。
  仅在网络未受污染、或你已配置系统级 Private DNS / 全局 VPN 而代理反而干扰页面加载时建议打开。

### 6.6 账号（沿用 v3.0）

- 密码登录：`GET /users/login` 取 `authenticity_token` → `POST /users/login`
  （`user_login[login]`、`user_login[password]`、`user_login[remember_me]`、`commit=Log In`）。
- 成功后仅保存 `_otwarchive_session` Cookie 与用户名；**密码只在一次请求内存活，绝不写入磁盘或日志**。
- 三种 Cookie 来源并存并在页面上标注，文案分别为「官网登录」「账号密码」「手动 Cookie」。
- 底部「我的」Tab 展示登录状态、登录时间、Session 校验结果、Cookie 预览（已脱敏），支持立即校验与退出。
- 收藏列表抓取 `/users/<用户名>/bookmarks`，区分作品 / 系列 / 外部链接 / 已删除，可直接下载作品。

### 6.7 安全 DNS（DoH，沿用 v3.0）

- 在 OkHttp 的 `Dns` 接口内实现，默认端点 `https://cs4x9fcgvq.cloudflare-gateway.com/dns-query`。
- **只对 `archiveofourown.org` 及其子域生效**，其余域名走系统 DNS。
- 支持 GET（`?dns=` Base64url wireformat + `Accept: application/dns-message`）与
  POST（`Content-Type: application/dns-message` + 原始查询字节）；`AUTO` 模式先 POST 再 GET。
- 解析 A / AAAA 记录并按 TTL 缓存；DoH 客户端自身强制 `Dns.SYSTEM`，避免递归解析。
- 设置页提供启用开关、请求方式、端点显示与自定义、连接测试与状态指示（已连接 / 连接失败 / 未启用）。

### 6.8 搜索页：搜索作者 / 搜索作品（v4.6 起合并为一页）

底部导航第 2 个 Tab 是「搜索」（原「作者」Tab）。页面顶部一个分段控件在两个子页之间切换，
**两套搜索各自独立**——不是把作者名和关键词塞进同一个搜索框：输入框、结果集、分页状态、
勾选状态分别由 `AuthorUiState` 与 `WorkSearchUiState` 持有，切子页不会清空对方的结果。

**搜索作者（沿用 v3.0 的能力）**

- 抓取 `/users/<用户名>/works`，按 `?page=N` 翻页加载。
- 列表展示标题、作者、字数、章节、语言、Fandom、标签、更新时间、受限标记。
- 支持单选、全选/取消全选、下载所选、一键下载全部（自动补齐后续分页再下载）。
- 该子页的按钮文案在 v4.6 由「搜索作品」改为**「搜索该作者」**（英文 `Search this author`），
  消除与新增的作品搜索之间的歧义。

**搜索作品（v4.6 新增）**

- 走 AO3 站点搜索：`GET /works/search?work_search[query]=<关键词>&commit=Search`，翻页追加 `&page=N`。
- 结果条目与作者作品列表**共用同一套解析**（`ol.work index group` 下的 `li#work_<id>.work.blurb`），
  因此标题、作者、字数、章节、语言、Fandom、标签、更新时间、受限标记的口径完全一致。
- 顶部显示命中条数，取自结果页的 `h3.heading`（AO3 原文形如 `N Found`）。
- **默认只显示前 6 条，其余折叠**：列表底部一行「展开全部（还有 N 条）」，展开后变成「收起」。
  折叠只作用于显示——状态里的 `works` 始终是完整结果集，因此全选与批量下载按**全部**结果计算，
  收起再展开不会丢掉已勾选的条目；发起新搜索时折叠状态自动复位为收起。
- 结果不足 6 条（含 0 条）时不显示折叠条。
- 支持「加载更多」：按结果页 `will_paginate` 的下一页链接判断是否还有更多。

### 6.9 HTML 美化与预览（v4.4 起默认重建为书籍文档版式）

美化有两种风格，在「设置 → HTML 美化 → 美化风格」里切换，**默认是「书籍文档」**：

**书籍文档（`DOCUMENT`，新默认）** —— 由 `data/DocBeautifier.kt` 完成，最终呈现与导出的文档一致：

- 结构：扉页（`h1` 标题 + 「by 作者」）→ 版权页（来源链接、Rating / Fandoms 等标签行、统计行拆成 Published / Updated / Words / Chapters 四条、导出时间）→ 前言页（Summary / Notes）→ 目录（「第 N 章」+ 章节标题）→ 逐章正文（章名、章摘要、章末注）→ `THE END` → 关于页。
- 主题：内置「暗夜樱粉」，`#17161a` 深色底、`#f7a8c6` 樱粉标题、`.content-wrapper` 圆角卡片与分页线，含 `max-width: 800px` 与移动端媒体查询。
- 解析不依赖文案：按 `#preface` / `dl.tags` 的 `dt-dd` 对 / `blockquote.userstuff` / `#chapters` 的 `.meta.group` / `div[id^=endnotes]` / `#afterword` 定位，AO3 换语言或改标签文案都不影响。
- 幂等：产物带 `<meta name="generator" content="obkk-doc-beautifier">`，重复美化只刷新 `style#aodl-doc-theme` 与自定义样式块，不会把结构套两层。

**经典注入（`CLASSIC`）** —— 沿用 v3.0 的做法，保留给习惯旧效果的用户：

- 可调字体（衬线 / 无衬线 / 等宽 / 自定义 font-family）、字号、行高、页边距、段间距、两端对齐。
- 三套阅读主题（暗樱花粉 / 午夜蓝 / 樱花亮色）与「保留原样式」开关。
- 生成 `<style id="aodl-beautify">` 注入到 `</head>` 之前。

两种风格共用：自定义 CSS 追加（写入独立样式块，排在主题之后，可覆盖主题规则）、「保留原文件」开关、设置页内置示例预览，以及已下载 HTML 文件的「美化版 / 原始版」对比预览。

### 6.10 应用内图标位与桌面图标分离（v4.5）

- 「桌面启动器图标」与「应用内图标位」是**两个不同资源**，不再共用：
  - 桌面图标 = `ic_launcher`（v4.3 起是 `drawable-anydpi-v26/ic_launcher.xml` 的自适应图标），由系统渲染，不经 Compose；
  - 应用内图标位 = `AppIcon.logoRes`，用于顶栏（`ScreenTitle`）、底部导航第 1 个 Tab、管理页与关于页。
- 四套内置图标的应用内资源：樱花（默认）→ `drawable-*/ic_logo_sakura.png`（纯位图，与同密度 `ic_launcher.png` 内容一致）；夜读 / 素白 / AO3 红 → 各自原有矢量 XML。
- 渲染改用 `ContextCompat.getDrawable` + `Canvas` 栅格化成 `ImageBitmap`（`Components.kt` 内的 `rememberResourceBitmap`），替代只支持矢量与位图的 `painterResource`；解码失败退回 `Icons.Filled.Image` 占位图标，绝不抛异常。上传自定义图片时仍走 `Image(bitmap = …)`，与本次改动无关。

### 6.11 外观与语言（沿用 v3.0）

- 三套应用主题；界面语言支持跟随系统 / 中文 / English，切换后立即重建生效。
- 中英文案各 451 键，键集完全一致，占位符与转义经脚本三向校验通过。

### 6.12 收藏条目复制（v4.6）

「我的 → 我的收藏」列表里每条作品都有三个复制动作：

| 动作 | 复制内容 | 形态 |
| --- | --- | --- |
| 复制作者名 | 作品条目的作者字段原文（多作者按原样保留，不拆分） | `作者名` |
| 复制编号 | 作品 ID，带 `#` 前缀 | `#编号` |
| 复制作者+编号 | 作者名 + 一个空格 + 带前缀的编号，拼成一行 | `作者名 #编号` |

- 复制走系统剪贴板（Compose 的 `LocalClipboardManager`），成功后在「下载」页日志区回执复制了什么。
- 内容取自条目**既有字段**，不为复制额外发任何请求。
- 某一侧为空时（例如外部链接类条目没有作者），对应动作直接不可用；
  **编号为空时不会复制出光秃秃的 `#`**。
- 复制出来的编号可以直接粘到「下载」页当作品编号用。

---

## 7. 权限

```
android.permission.INTERNET
android.permission.ACCESS_NETWORK_STATE
com.android.launcher.permission.INSTALL_SHORTCUT   # v4.0 起：自定义图标创建桌面快捷方式
```

不申请存储权限——所有文件写入均通过 SAF 由用户显式授权目录完成。
`AndroidManifest` 中 `usesCleartextTraffic="false"`，全程 HTTPS。

> 注：`aapt2 dump badging` 不会为挂在 `<activity-alias>` 上的 `MAIN/LAUNCHER` 输出
> `launchable-activity:` 行，这是 aapt2 只扫描 `<activity>` 的工具行为，不代表桌面入口缺失。
> 本项目改用「APK 内 Manifest 的 `xmltree` 结构校验」作为证据（见下节）。

---

## 8. 验证状态与已知边界（请如实阅读）

**已验证：**

- `./gradlew testReleaseUnitTest`：**231 tests，0 failures，0 errors，0 skipped**
  （`AppIconTest` 5 / `BookmarkCopyTest` 16 / `DirPlanTest` 17 / `DocBeautifierTest` 10 /
  `FileNameBuilderTest` 15 / `FormatSignatureTest` 15 / `IconPlanTest` 20 / `PartCleanupTest` 22 /
  `ResumePlanTest` 8 / `SearchResultPlanTest` 15 / `StreamCopyTest` 15 / `SubDirPlannerTest` 8 /
  `WebLoginPlanTest` 29 / `Ao3ParsersTest` 32 / `RetryPolicyTest` 4）。
  这些用例覆盖文件名生成与回退、**目录规划的四种开关组合**、
  **「多种格式共用根目录时各格式的目标相对路径互不相同」**与
  **「目录缓存键必须含格式、同作者同格式必须稳定、占位符不可能与真实名字撞键」**两组回归断言、
  断点续传的字节起点判定、重试退避与 32 位溢出边界、图标 alias 启用组合的唯一性、
  官网登录的主机白名单 / Cookie 归一化 / 重定向方法降级 / 请求响应头清洗 / JS 转义。
- **v4.2 三处修复各自的取证**：
  - `SubDirPlannerTest`（8 条）：同名目录已存在时一律复用；provider 把新建目录改名成
    `xxx (1)` 时，判定为「已有同名目录」并要求回收自己刚建的空目录；并发查建被串行化。
  - `StreamCopyTest`（15 条）：200 KB 与 69 字节两档响应体**逐字节**与落盘内容一致；
    进度单调且终值等于总长；截断 / 超长 / 空响应体判 `INCOMPLETE`；`Transfer-Encoding: chunked`
    无声明长度时免长度校验；HTML 冒充 PDF 时判 `INVALID_CONTENT` 且**零字节落盘**；
    续传跳过头部校验、落盘恰为缺失段；取消时上报字节数等于实际落盘数。
  - `PartCleanupTest`（22 条）：`x.pdf.part` / `x.pdf.part.pdf` / `x (1).pdf.part` /
    `x.pdf.part (1)` / `x.pdf.part (2).pdf` 全部命中，而成品 `x.pdf`、`x.pdf.partition`、
    `x.pdf.partial`、别的作品的残片、目录、zip 一律不命中；作品名自身含 `.part` 时按最后一个
    后缀切分；`planCleanup` 的七种收尾决策（无事可做 / 成功全清 / 失败全清 / 取消保留最大并改回
    规范名 / 已规范则不改名 / 单份原样保留 / 空正式名）逐条断言；
    **成品仍叫 `.part` 时整体拒绝清理**这条硬护栏也被钉死。
  - `FormatSignatureTest`（15 条）：五种格式的头部特征、MOBI 在第 60 字节的偏移、
    BOM 与前置空白、长度不足、以及 `expectation` 文案。
- `./gradlew assembleRelease`：**BUILD SUCCESSFUL**。
- **v4.5 闪退修复的取证**：
  - `AppIconTest`（5 条）：`AppIcon.SAKURA.logoRes` 既不等于 `drawableRes`、也不等于 `R.drawable.ic_launcher`；
    四套 `logoRes` 互不相同；`ic_logo_sakura` 在 5 个密度目录里都是 PNG（校验文件头 `89 50 4E 47`）；
    应用内 logo 资源名下不存在任何 XML（尤其是 `<adaptive-icon>`）；对照组断言桌面
    `drawable-anydpi-v26/ic_launcher.xml` 仍是 `<adaptive-icon>`。
  - APK 资源实测（`aapt2 dump resources`）：`drawable/ic_logo_sakura` = 5 个密度 **PNG**（mdpi 48 / hdpi 72 /
    xhdpi 96 / xxhdpi 144 / xxxhdpi 192），**没有** `anydpi-v26` 条目；`drawable/ic_launcher` 则同时有 5 个
    密度 PNG 与 `anydpi-v26` 的自适应图标 XML——前者给应用内渲染、后者给桌面，正是本次修复的分离点。
  - 代码层：`app/src/main/java/com/tabbit/aodl/` 下已无任何 `painterResource` 调用（`grep` 确认），
    应用内图标位全部走 `rememberResourceBitmap`。
- **v4.6 三项改动的取证**：
  - `SearchResultPlanTest`（15 条）：默认折叠阈值就是 **6**；空结果、少于 6 条、恰好 6 条时
    **不出折叠条**且隐藏数为 0；7 条与 20 条时可见 6、隐藏分别为 1 与 14；`collapsible` 只看总量、
    **不受展开状态影响**；折叠返回前六条且**保持原顺序**、展开返回全量；未截断时返回的是
    **同一个列表实例**（不做无谓拷贝）；`limit` 传负数按 0 处理、传 0 则全部隐藏、
    大于总量时等于总量；任意组合下「可见数 + 隐藏数 == 总数」恒成立。
  - `BookmarkCopyTest`（16 条）：`ID_PREFIX = "#"`、`SEPARATOR = " "`；作者名去首尾空白、容忍 null；
    多作者原样保留不拆分；编号加 `#` 前缀，**编号为空时返回空串而不是光秃秃的 `#`**；
    只有作者 / 只有编号 / 两者都有 / 两者都缺四种组合逐条断言；`payload` 按 `CopyTarget` 正确路由；
    `enabled` 与 `payload` **同口径**（内容为空即不可用）；三个 target 的产物互不相同；
    非数字编号原样保留。
  - `Ao3ParsersTest` 新增 10 条（22 → 32）：以 AO3 官方开源仓库 `otwcode/otwarchive` 的
    `works/search_results`、`works/_search_form`、`works/_work_blurb`、`works/_work_module`、
    `works/index`、`works/_stats` 模板还原出**搜索结果页**与**作者作品列表页**两种结构，
    断言 `searchRequest` 生成的 URL 与查询参数、结果条目的标题 / 作者 / 编号 / 字数 / 章节 /
    语言 / Fandom / 标签 / 更新时间 / 受限标记逐项正确、非 `work_` 前缀的条目被跳过，
    以及 `will_paginate`（搜索页）与 `pagy_nav`（作品列表页）两种分页结构都能正确判定「还有下一页」。
  - APK 实测（`aapt2 dump resources` / `aapt2 dump strings`）：`tab_search`、`screen_search_title`、
    `search_tab_author`、`search_tab_works`、`work_search_hint`、`work_search_expand`、
    `bookmark_copy_author`、`bookmark_copy_id`、`bookmark_copy_both`、`log_work_search_ok`、
    `author_search` 等新增/改动的字符串资源全部打进包里，取值为「搜索」「搜索作者」「搜索作品」
    「展开全部（还有 %1$d 条）」「复制作者名」「复制作者+编号」「搜索该作者」等预期文案。
  - 代码层：`grep -rn "AuthorScreen\|MainTab.AUTHOR"` 已**无任何残留**；`MainTab` 为
    `{ DOWNLOAD, SEARCH, ACCOUNT, MANAGE }`，`AppRoot.kt` 的分支是 `MainTab.SEARCH -> SearchScreen(vm = vm)`。
- **v4.4 两项改动的取证**：
  - `DocBeautifierTest`（10 条）：多章 fixture 逐项断言扉页 `h1`/`h2`（`by 作者`）、
    版权页的来源行与各标签行、**统计行被拆成 Published / Updated / Words / Chapters 四条**、
    前言两节（Summary / Notes）、目录两项文案（`第 1 章` / `第 2 章 档案 243-104-18-6`）、
    `#chapter-1`/`#chapter-2` 与正文保留、章末注与作品尾注、`THE END`、关于页含应用名、
    内置主题含 `#17161a`、`.content-wrapper` 与 `text-transform: none !important`；
    单章 fixture 只出「第 1 章」；无 `#preface`/`#chapters` 的普通网页回退成单章；
    自定义 CSS 追加在主题块之后、传空则移除；**重复美化只换样式块、结构不会重复**；
    `HtmlBeautifier` 按风格路由（默认 `DOCUMENT` 走文档重建、`CLASSIC` 走旧注入）。
  - 设置页折叠：`GroupCard` 只是呈现层组件，展开/收起状态由 `rememberSaveable` 保存；
    **设置项、默认值与偏好键一个都没改**（`Prefs.FILE_NAME` 仍是 `aodl_v3_prefs`），
    覆盖安装后原有设置全部保留。
- **v4.3 桌面图标、v4.5 应用内图标位分别取证**：release 构建会改名资源，故按 `aapt2 dump resources` 定位——
  `drawable/ic_launcher` 落到 `res/*.png`（mdpi 48 / hdpi 72 / xhdpi 96 / xxhdpi 144 / xxxhdpi 192）
  与 `res/vX.xml`（`anydpi-v26` 自适应图标），`drawable/ic_launcher_foreground` 落到各密度 PNG、
  `color/ic_launcher_background` 为 `#ffffffff`；`drawable/ic_logo_sakura` 落到 5 个密度的 PNG
  （与同密度 `ic_launcher.png` 字节相同，即同一张照片的全幅方形裁切，不含自适应图标那圈留白），
  **没有** `anydpi-v26` 条目。把 APK 内这些图片解出来与随包图片比对，内容一致。
- APK 经 `apksigner verify --verbose --print-certs`：
  `v1 = false`、**`v2 = true`、`v3 = true`**、`v3.1 = false`、`v4 = false`，单签名者，
  `SHA256withRSA` / 2048-bit RSA。
- **签名者证书与仓库内密钥库一致**：`keytool -list -v -keystore keystore/aodl.jks` 的
  SHA256 指纹与 `apksigner` 报出的签名者证书 SHA-256 逐位相同
  （`c6be6a67…fb730`），即交付的 APK 确实由本仓库的 `aodl.jks` 签名。
- **与 v3.0、v4.0、v4.1 的签名一致性已实测比对**：从三个历史交付包中分别取出
  `AO3Downloader-v3.0.apk`（`versionCode = 3`）、`AO3Downloader-v4.0.apk`（`versionCode = 4`）、
  `AO3Downloader-v4.1.apk`（`versionCode = 5`），连同本次 v4.6 的 APK 与
  `keystore/aodl.jks` 内的证书，**五个 SHA-256 指纹逐位相同**
  （均为 `c6be6a6793d70ccadc958b79eee8efa0c2dad9c4807c685b5e96bf51a63fb730`），
  因此 v3.0 / v4.0 / v4.1 / v4.2 / v4.3 / v4.4 / v4.5 → v4.6 可直接覆盖安装，登录态与设置全部保留。
- `aapt2 dump badging`：`package: name='com.tabbit.aodl' versionCode='10' versionName='4.6'`、
  `sdkVersion:'24'`、`targetSdkVersion:'34'`、`application-label:'obkk下载中'`、
  `application-label-en:'obkk下载中'`。
- **APK 内**（`aapt2 dump xmltree --file AndroidManifest.xml`）的 Manifest 结构校验：
  `<application>` 下 `activity` 1 个、`activity-alias` **4** 个；4 个 alias 全部
  `exported="true"`、`targetActivity="com.tabbit.aodl.MainActivity"`、各自持有 **1** 个
  `MAIN + LAUNCHER` 意图过滤器、`android:label` 均解析到 `string/app_name`、
  `android:icon` 分别解析到互不相同的 `drawable/ic_launcher`、`ic_launcher_night`、
  `ic_launcher_mono`、`ic_launcher_ao3`；**恰好 1 个 `enabled="true"`**（出厂为 `LauncherSakura`）；
  唯一的 `<activity>`（MainActivity）只持有 `ACTION_SEND` 与两个 `ACTION_VIEW`，
  **不持有任何 `MAIN/LAUNCHER`**——桌面入口唯一，不会重复出现图标。
- APK 大小 11,933,021 字节，SHA-256 `46dcafc3b0820024751bf4e849155746d6869763871bd3c0ffa80c67b3f180de`。
- 双语字符串三向校验（`R.string.X` 引用 vs 中英文 XML）：zh 451 / en 451，
  无缺失键、无重复键、无空值、无未转义裸引号、无占位符不匹配
  （v4.2 新增 `err_content_invalid`、`err_incomplete`、`log_part_cleaned` 三条；
  **v4.6 新增 24 条**：`tab_search`、`screen_search_title`、`search_tab_author`、`search_tab_works`、
  `work_search_*` 十条、`log_work_search_*` 四条、`log_copied_*` 三条、`bookmark_copy_*` 三条，
  并把 `author_search` 由「搜索作品」改为「搜索该作者」，全部中英同步）。
- 页面解析选择器经离线校验：以 AO3 官方开源仓库 `otwcode/otwarchive`（master 分支）的
  `works/index`、`works/search_results`、`works/_search_form`、`_work_blurb`、`_work_module`、
  `works/_stats`、`bookmarks/index`、`_bookmark_blurb`、`_bookmark_user_module`、
  `pagination_helper.rb`、`pagination_list_link_renderer.rb`
  等模板还原出页面结构做断言（**v4.6 的站点作品搜索同样按这套官方模板取证**）。

**未验证（构建环境的客观限制，非代码问题）：**

1. **无法访问真实 AO3 站点**：构建沙箱内直连 `archiveofourown.org` 返回连接失败，
   `dns.google`、`cloudflare-dns.com` 亦不可达。因此**登录、作品抓取、站点搜索、文件下载、
   官网 WebView 取 Cookie 五条链路均未在真实站点上端到端跑通**。
   请求路径、表单字段与解析规则以上述官方开源模板为依据；真机上仍可能因 AO3 改版、
   Cloudflare 质询或账号风控出现偏差。
2. **v4.6 的站点作品搜索没有在真实 AO3 上跑过**：沙箱直连 `archiveofourown.org` 失败，
   因此搜索请求的 URL 与查询参数、结果页的真实 DOM、`will_paginate` 分页、命中条数文案
   （结果页 `h3.heading`，AO3 原文形如 `N Found`）、受限作品在搜索结果里的表现，
   **全部只按 AO3 官方开源模板做了离线断言，没有对真实站点验证过**。AO3 若改版搜索结果页，
   选择器可能需要跟着调整。「默认只显示前六条、其余折叠」是纯本地渲染逻辑、与站点无关，
   已由 `SearchResultPlanTest` 钉住；收藏复制同理，只读条目既有字段。
3. **没有模拟器或真机**：桌面图标实际换图效果、桌面快捷方式能否被各家 Launcher 接受、
   WebView 登录页的真实渲染与交互、SAF 目录选择器的实际行为，**均只做了编译与结构层面的验证，
   未做实机验证**。
4. **v4.5 的闪退修复无法在本环境实机复现或验证**：沙箱里既没有 Android 运行时，也没有可安装
   APK 的设备，因此「装上 v4.5 能正常打开」这一步**没有在真机上跑过**。本次结论建立在三条证据上——
   ① 用 `javap -c` 反编译 compose-ui 1.7.0 的 `androidx/compose/ui/res/PainterResources_androidKt`，
   确认 `painterResource` 对非矢量 / 非位图资源会 `new IllegalArgumentException`，并附上原文
   「Only VectorDrawables and rasterized asset types are supported ex. PNG, JPG, WEBP」；
   ② `aapt2 dump resources` 确认 v4.3 起 `drawable/ic_launcher` 在 `anydpi-v26` 下是 XML、
   `aapt2 dump xmltree` 确认其根节点为 `<adaptive-icon>`；
   ③ 代码路径确认 `ui/AppRoot.kt` 底部导航与各屏 `ScreenTitle` **在首帧就渲染** `AppLogo`（即上述资源）。
   请装到真机后先确认应用能打开、顶栏与底部导航的图标显示正常（显示为那张照片），再继续用其他功能。
5. **v4.1 / v4.2 的分目录与落盘修复只做了纯逻辑取证，没有实机验证**：`DirPlan`、`SubDirPlanner`、
   `StreamCopy`、`FormatSignature`、`PartCleanup` 都是下载链路**实际调用**的那份判定逻辑
   （从 `AppViewModel` 与 `SafStore` 剥离出的纯函数），单测跑的就是它们本身，因此
   「四种开关组合的目录层级」「缓存键含格式」「同名目录一律复用、被改名则回收空目录」
   「落盘字节与响应体逐字节一致」「截断判 INCOMPLETE / 内容不符判 INVALID_CONTENT 且零字节落盘」
   「`.part` 各变体的识别与清理决策」「成品仍叫 `.part` 时拒绝清理」这些结论已被钉住；
   但沙箱内既没有可写的 SAF 目录、也没有真机，所以
   **SAF 侧真实的 `createDirectory` / `delete` / `renameTo` 动作、以及
   「装上手机点开始下载、文件确实分到各自文件夹且 PDF 能正常打开」这一步没有跑过**。
   请在真机上按「同一个作者 + 勾选多种格式」下载一次，用「下载」页日志区里的
   「保存目录：…」与「已清理 N 个残留临时文件：…」逐条核对。
6. **用户此前遇到的 `.part` 变体究竟由哪一步产生，仍是推断而非实证**：`xxx.pdf.part.pdf`
   最可能是 SAF provider 按 MIME 追加扩展名或重名改名所致（AOSP 的 `FileUtils.splitFileName`
   只在显示名不含点时才补扩展名，因此更可能是 OEM 存储提供者的行为）。
   沙箱无法访问 AO3、也没有真机，无法复现该 provider 行为。
   `PartCleanup` 采取的是**不依赖 provider 行为、只按名字模式识别**的防御性方案，
   因此即便真实成因与推断不同，清理与续传仍然成立。
7. **v2.0 的签名指纹未能比对**：v2.0 的 APK 已不在本构建环境中（原 uploads 路径不可访问），
   因此**没有**对 v2.0 做过证书指纹比对，无法断言它与 v4.6 是否同一密钥。
   文中关于 v2.0 的升级建议是保守处理（先自查指纹，不一致就卸载后重装），不是实测结论。
8. 首次安装后请在真机上依次确认：
   应用能正常打开（不闪退）、顶栏与底部导航的图标显示为那张照片 →
   「设置 → 安全 DNS（DoH）→ 测试连接」为已连接 → 「设置 → 应用图标」切一次图标看桌面是否变化 →
   到「搜索」Tab 切进「搜索作品」，用一个已知关键词搜一次，确认结果默认只有 6 条、
   点「展开全部（还有 N 条）」能看到其余条目、再点「收起」能收回去 →
   到「我的」Tab 的收藏列表试一次三个复制动作，粘贴出来核对内容 →
   用一个已知作品编号、勾选多种格式试下载并核对文件是否分到各自格式目录 →
   下载完成后到目录里确认**没有**残留 `.part`、且 PDF 能正常打开 →
   需要登录时优先用「我的」Tab 里的「官网登录（推荐）」。

**本次改动引入的结构守卫（防回归）：**
- `AppIconTest` 把「应用内 logo 资源不得是自适应图标」钉成断言：默认款 `logoRes` 必须是位图
  `ic_logo_sakura`、四套 `logoRes` 互不相同、5 个密度目录里同名资源必须是 PNG、
  应用内 logo 资源名下不得出现任何 XML；同时保留对照组断言桌面 `ic_launcher.xml` 仍为自适应图标。
- 仓库内已无 `painterResource` 调用（`ui/Components.kt` 换成 `rememberResourceBitmap`），
  即便将来有人把某个自适应图标挂到 `logoRes` 上，渲染也只会退回占位图标而不会崩。
- `SearchResultPlanTest` 把「折叠阈值就是 6」「折叠只影响可见段、不影响总数」
  「可见数 + 隐藏数恒等于总数」「未截断时不拷贝列表」钉成断言；
  `BookmarkCopyTest` 把「复制内容为空时该动作不可用」「编号为空时不会复制出光秃秃的 `#`」
  「三个 target 的产物互不相同」钉成断言。
- `Ao3ParsersTest` 用 AO3 官方模板还原的搜索结果页 fixture 钉住选择器：搜索页结构或字段一旦对不上，
  测试会先于用户发现。

**已知设计取舍：**

- 官网登录的 POST 采用「JS 序列化表单字段进查询串 + 代理还原真实 POST」方案，密码会短暂进入 URL；
  已用不显示地址栏、不写日志、`replaceState` + `clearHistory()` 缓解（详见 6.5）。
- `Ao3WebProxy` 的 OkHttp 客户端独立于 `Ao3Client.client`（共享同一个 `DohDns` 实例，
  但连接池独立，且必须 `followRedirects(false)` 才能拿到重定向上的 `Set-Cookie`）。
- **「按作者分类」与「按格式分目录」在 v4.1 被解耦**：作者层仍严格跟随该开关（关闭时不建作者目录，
  同 v3.0），但格式层只看「多格式是否共用一个根目录」——共用就一定要分级，否则文件必然混在一起。
  代价是「关闭作者分类 + 统一保存位置」这个组合不再与 v3.0 完全一致（v3.0 会全堆在根目录）。
- **v4.2：完整性校验的判定顺序是「先比总长、后验头部」，而非反过来。** 内容为空或被截断时
  优先判 `INCOMPLETE`，因为残片对续传有价值，上层会保留并重试；只有字节数对得上、内容却不对时
  才判 `INVALID_CONTENT`——这种残片没有任何价值，直接删掉且不再重试。反过来判会把
  「下载了一半的合法 PDF」误判成「内容非法」而丢弃，白白浪费已下载的流量。
- **v4.2：目录查建被串行化，牺牲了一点并发度。** 同一「父目录 + 名字」的查建走同一把锁，
  因此高并发下建目录不再是纯并行。相比「同一作者凭空多出 `onee1e (1)`、文件被拆到两个目录」，
  这个代价是值得的；锁只作用于目录解析，文件写入本身仍按设置的并发数（1–4）并行。
- **v4.2：宁可留一个名字难看的成品，也不冒险删数据。** provider 不支持重命名时成品会继续叫
  `xxx.pdf.part`，此时按名字模式无法区分成品与残片，收尾会**整体跳过清理**并在日志区如实说明。
- 自定义图标图片只存 `filesDir/icons/custom.png`，卸载应用即清除，不写共享存储。

---

## 9. 许可与声明

本项目为个人使用的第三方客户端，与 Archive of Our Own / Organization for Transformative Works 无关联。
请遵守 AO3 的服务条款与速率限制，仅下载自己有权访问的作品。