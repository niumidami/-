package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 中间文件（`.part`）识别规则的离线断言（v4.2 修复 #2）。
 *
 * 用户实测的两个缺陷都由「按请求名精确查找 `.part`」引起：
 * 1. provider 把 `x.pdf.part` 改名成 `x.pdf.part.pdf` / `x (1).pdf.part` 之后，
 *    旧代码既探测不到断点、也删不掉残片，续传还会再建一份新的 → 残片越积越多；
 * 2. 残缺内容被重命名成正式文件 → 打开是坏的。
 *
 * 这里断言识别规则**按名字模式**工作，且永远不会把成品判成中间文件。
 */
class PartCleanupTest {

    private val finalName = "作品 by onee1e.pdf"

    // ------------------------------------------------------------- 应判为中间文件

    @Test
    fun `recognises the plain part file`() {
        assertTrue(PartCleanup.isIntermediateOf("$finalName.part", finalName))
    }

    @Test
    fun `recognises the part file whose extension was appended by the provider`() {
        // 用户截图里的真实文件名：`【带卡】大蛇在旗木老宅 by onee1e.pdf.part.pdf`
        assertTrue(PartCleanup.isIntermediateOf("$finalName.part.pdf", finalName))
    }

    @Test
    fun `recognises the part file renamed on collision`() {
        val stem = finalName.substringBeforeLast('.')
        val ext = "." + finalName.substringAfterLast('.')
        assertTrue(PartCleanup.isIntermediateOf("$stem (1)$ext.part", finalName))
        assertTrue(PartCleanup.isIntermediateOf("$stem (1)$ext.part$ext", finalName))
        assertTrue(PartCleanup.isIntermediateOf("$finalName.part (1)", finalName))
        assertTrue(PartCleanup.isIntermediateOf("$finalName.part (2).pdf", finalName))
    }

    @Test
    fun `recognises the part file when the work title itself contains part`() {
        // 作品名叫 `x.part` 时正式名是 `x.part.pdf`，只有最后一个 `.part` 才是我们加的后缀
        val tricky = "x.part.pdf"
        assertTrue(PartCleanup.isIntermediateOf("$tricky.part", tricky))
        assertTrue(PartCleanup.isIntermediateOf("$tricky.part.pdf", tricky))
    }

    // ------------------------------------------------------------- 绝不能命中成品

    @Test
    fun `never matches the finished file`() {
        assertFalse(PartCleanup.isIntermediateOf(finalName, finalName))
    }

    @Test
    fun `never matches a word that merely starts with part`() {
        // `.partition` 里的 `.part` 只是词的一部分，这是成品，删掉就是数据丢失
        assertFalse(PartCleanup.isIntermediateOf("$finalName.partition", finalName))
        assertFalse(PartCleanup.isIntermediateOf("$finalName.partial", finalName))
    }

    @Test
    fun `never matches another work`() {
        assertFalse(PartCleanup.isIntermediateOf("别的作品 by someone.pdf.part", finalName))
        assertFalse(PartCleanup.isIntermediateOf("别的作品 by someone.pdf.part.pdf", finalName))
    }

    @Test
    fun `blank inputs are not intermediates`() {
        assertFalse(PartCleanup.isIntermediateOf("", finalName))
        assertFalse(PartCleanup.isIntermediateOf(finalName, ""))
        assertFalse(PartCleanup.isIntermediateOf("   ", "   "))
    }

    @Test
    fun `directories and unrelated files are ignored`() {
        assertFalse(PartCleanup.isIntermediateOf("onee1e", finalName))
        assertFalse(PartCleanup.isIntermediateOf("AO3Downloader-v4.1-APK.zip", finalName))
    }

    // ------------------------------------------------------------------ 批量筛选

    @Test
    fun `intermediatesOf picks only the variants of this download`() {
        val children = listOf(
            finalName,                       // 成品
            "$finalName.part",               // 中间文件
            "$finalName.part.pdf",           // provider 追加扩展名
            "作品 by onee1e (1).pdf.part",   // provider 改重名
            "别的作品 by onee1e.pdf.part",   // 另一个作品
            "onee1e"                         // 目录
        )

        val picked = PartCleanup.intermediatesOf(children, finalName)

        assertEquals(
            listOf("$finalName.part", "$finalName.part.pdf", "作品 by onee1e (1).pdf.part"),
            picked
        )
    }

    @Test
    fun `canonical name is the plain part name`() {
        assertEquals("$finalName.part", PartCleanup.canonicalName(finalName))
        assertEquals(FileNameBuilder.partName(finalName), PartCleanup.canonicalName(finalName))
    }

    // ------------------------------------------------------------------ 日志描述

    @Test
    fun `describe keeps short lists verbatim and truncates long ones`() {
        assertEquals("", PartCleanup.describe(emptyList()))
        assertEquals("a, b", PartCleanup.describe(listOf("a", "b")))
        assertEquals("a, b, c", PartCleanup.describe(listOf("a", "b", "c")))
        assertEquals("a, b, c …", PartCleanup.describe(listOf("a", "b", "c", "d")))
    }

    // ------------------------------------------------------------------ 收敛决策

    /** 用户截图里那个作者目录的真实构成：成品 + 两种写法的残片并存。 */
    private val messy = listOf(
        finalName,                       // 成品
        "$finalName.part",               // 规范中间文件
        "$finalName.part.pdf",           // provider 追加了扩展名
        "作品 by onee1e (1).pdf.part",   // provider 改了重名
        "别的作品 by onee1e.pdf.part",   // 另一个作品的中间文件
        "onee1e"                         // 作者目录
    )

    private fun plan(children: List<String>, keepForResume: Boolean, sizes: Map<String, Long> = emptyMap()) =
        PartCleanup.planCleanup(children, finalName, { sizes[it] ?: 0L }, keepForResume)

    @Test
    fun `nothing to do when the folder holds no intermediate of this download`() {
        val children = listOf(finalName, "onee1e", "别的作品 by onee1e.pdf.part")

        listOf(true, false).forEach { keepForResume ->
            val plan = plan(children, keepForResume)
            assertTrue("没有本次下载的残片时不该有任何动作", plan.isNothingToDo)
            assertEquals(emptyList<String>(), plan.delete)
        }
    }

    @Test
    fun `finished download removes every variant and keeps the finished file`() {
        val plan = plan(messy, keepForResume = false)

        assertEquals(
            listOf("$finalName.part", "$finalName.part.pdf", "作品 by onee1e (1).pdf.part"),
            plan.delete
        )
        assertNull("成功收尾不该保留任何断点", plan.keep)
        assertNull(plan.renameTo)
        assertFalse("成品绝不能出现在删除清单里", plan.delete.contains(finalName))
        assertFalse("别的作品的残片不该被误删", plan.delete.contains("别的作品 by onee1e.pdf.part"))
    }

    @Test
    fun `failed download removes every variant too`() {
        // 失败收尾与成功收尾一致：断点已无价值，用户目录里不留 .part
        assertEquals(plan(messy, keepForResume = false).delete, plan(messy, keepForResume = false).delete)
        assertEquals(3, plan(messy, keepForResume = false).delete.size)
    }

    @Test
    fun `cancelled download keeps the largest part and renames it back to the canonical name`() {
        val sizes = mapOf(
            "$finalName.part" to 1_000L,
            "$finalName.part.pdf" to 4_000L,
            "作品 by onee1e (1).pdf.part" to 2_000L
        )

        val plan = plan(messy, keepForResume = true, sizes)

        assertEquals("应保留最大（最值得续传）的那一份", "$finalName.part.pdf", plan.keep)
        assertEquals(listOf("$finalName.part", "作品 by onee1e (1).pdf.part"), plan.delete)
        assertEquals("留下的那份要改名回规范形式", "$finalName.part", plan.renameTo)
    }

    @Test
    fun `cancelled download leaves an already canonical part alone`() {
        val sizes = mapOf("$finalName.part" to 4_000L, "$finalName.part.pdf" to 1_000L)

        val plan = plan(messy, keepForResume = true, sizes)

        assertEquals("$finalName.part", plan.keep)
        assertEquals(listOf("$finalName.part.pdf", "作品 by onee1e (1).pdf.part"), plan.delete)
        assertNull("已经是规范名就不必改名", plan.renameTo)
    }

    @Test
    fun `a single canonical part survives cancellation untouched`() {
        val plan = plan(listOf(finalName, "$finalName.part"), keepForResume = true)

        assertEquals("$finalName.part", plan.keep)
        assertEquals(emptyList<String>(), plan.delete)
        assertNull(plan.renameTo)
    }

    @Test
    fun `blank final name produces no plan at all`() {
        val plan = PartCleanup.planCleanup(messy, "", { 0L }, keepForResume = false)
        assertTrue(plan.isNothingToDo)
    }

    // ------------------------------------------------- 护栏：成品仍叫 `.part` 时绝不清理

    /**
     * provider 不支持重命名时，成品只能继续叫 `xxx.pdf.part`。
     * 此时「成品」和「残片」是同一个名字，按名字模式的删除会直接删掉用户刚下完的文件，
     * 因此识别与决策都必须整体让路。
     */
    @Test
    fun `cleanup is unsafe whenever the stored name still carries the part suffix`() {
        assertTrue(PartCleanup.cleanupIsUnsafe("$finalName.part"))
        assertTrue(PartCleanup.cleanupIsUnsafe("$finalName.part.pdf"))
        assertTrue(PartCleanup.cleanupIsUnsafe("作品 by onee1e (1).pdf.part"))
        assertFalse("正常成品名可以安全清理", PartCleanup.cleanupIsUnsafe(finalName))
        assertFalse(PartCleanup.cleanupIsUnsafe(""))
    }

    @Test
    fun `plan refuses to touch anything when the final name itself is a part name`() {
        val storedAsPart = "$finalName.part"
        val children = messy + storedAsPart + "$storedAsPart.pdf"

        listOf(true, false).forEach { keepForResume ->
            val plan = PartCleanup.planCleanup(children, storedAsPart, { 9_999L }, keepForResume)
            assertTrue("成品仍叫 .part 时不该有任何清理动作", plan.isNothingToDo)
            assertNull(plan.keep)
            assertEquals(emptyList<String>(), plan.delete)
            assertNull(plan.renameTo)
        }
    }

    @Test
    fun `the finished file that still looks like a part is never selected for deletion`() {
        val storedAsPart = "$finalName.part"
        assertFalse(
            "成品与残片同名，识别规则必须判它不是中间文件",
            PartCleanup.isIntermediateOf(storedAsPart, storedAsPart)
        )
    }
}
