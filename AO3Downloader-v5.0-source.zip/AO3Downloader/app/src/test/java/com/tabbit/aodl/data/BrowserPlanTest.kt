package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * 浏览页地址规划的离线断言（纯函数，不依赖 Android 与网络）。
 *
 * 重点锁定「点作者名进作者作品页」的地址形态：卡片 byline 上的名字就是 pseud，
 * 站点把 `/users/<pseud>` 直接服务成该作者的用户页。
 */
class BrowserPlanTest {

    @Test
    fun `authorPath targets the user works index`() {
        assertEquals("/users/StarDust/works", BrowserPlan.authorPath("StarDust"))
    }

    @Test
    fun `authorPath percent encodes reserved characters`() {
        assertEquals("/users/A%20B/works", BrowserPlan.authorPath("A B"))
        assertEquals("/users/a%2Fb/works", BrowserPlan.authorPath("a/b"))
    }

    @Test
    fun `authorPath falls back to all works when the name is blank`() {
        assertEquals(BrowserPlan.PATH_ALL_WORKS, BrowserPlan.authorPath(""))
        assertEquals(BrowserPlan.PATH_ALL_WORKS, BrowserPlan.authorPath("   "))
    }

    @Test
    fun `tagPath turns spaces into underscores like the site does`() {
        assertEquals("/tags/Time_Travel/works", BrowserPlan.tagPath("Time Travel"))
        assertEquals("/tags/Hurt%2FComfort/works", BrowserPlan.tagPath("Hurt/Comfort"))
    }
}
