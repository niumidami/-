package com.tabbit.aodl.data

import com.tabbit.aodl.model.Chapter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** [ReaderPlan] 的离线规则测试：排版夹取、段落切分、目录、进度 LRU、缓存编解码。 */
class ReaderPlanTest {

    /* ------------------------------------------------ 排版夹取 */

    @Test
    fun `font size clamped to bounds`() {
        assertEquals(ReaderPlan.MIN_FONT_SIZE, ReaderPlan.clampFontSize(4))
        assertEquals(ReaderPlan.MAX_FONT_SIZE, ReaderPlan.clampFontSize(999))
        assertEquals(22, ReaderPlan.clampFontSize(22))
    }

    @Test
    fun `line height clamped and rounded to one decimal`() {
        assertEquals(1.2f, ReaderPlan.clampLineHeight(0.5f))
        assertEquals(2.4f, ReaderPlan.clampLineHeight(9f))
        assertEquals(1.7f, ReaderPlan.clampLineHeight(1.74f))
        assertEquals(1.8f, ReaderPlan.clampLineHeight(1.76f))
    }

    @Test
    fun `margin clamped to bounds`() {
        assertEquals(ReaderPlan.MIN_MARGIN, ReaderPlan.clampMargin(0))
        assertEquals(ReaderPlan.MAX_MARGIN, ReaderPlan.clampMargin(100))
        assertEquals(24, ReaderPlan.clampMargin(24))
    }

    /* ------------------------------------------------ 段落切分 */

    @Test
    fun `blank lines split paragraphs`() {
        val text = "p1 line1\np1 line2\n\np2\n\n\np3"
        assertEquals(listOf("p1 line1\np1 line2", "p2", "p3"), ReaderPlan.splitParagraphs(text))
    }

    @Test
    fun `single newlines fallback when no blank separator`() {
        assertEquals(listOf("a", "b", "c"), ReaderPlan.splitParagraphs("a\nb\nc"))
    }

    @Test
    fun `crlf normalized before splitting`() {
        assertEquals(listOf("a", "b"), ReaderPlan.splitParagraphs("a\r\n\r\nb"))
        assertEquals(listOf("a", "b"), ReaderPlan.splitParagraphs("a\r\rb"))
    }

    @Test
    fun `blank and whitespace segments dropped`() {
        assertEquals(listOf("a", "b"), ReaderPlan.splitParagraphs("  a  \n\n   \n\n b "))
    }

    /* ------------------------------------------------ 目录 */

    @Test
    fun `outline keeps index and trims title`() {
        val chapters = listOf(
            Chapter(index = 0, title = "  卷一  ", text = "x"),
            Chapter(index = 1, title = "", text = "y")
        )
        assertEquals(listOf(0 to "卷一", 1 to ""), ReaderPlan.outline(chapters))
    }

    /* ------------------------------------------------ 精细进度 */

    @Test
    fun `progress rows roundtrip`() {
        val rows = listOf(
            Triple("w1", 3, 0.25f),
            Triple("w2", 0, 1f),
            Triple("w3", 12, 0f)
        )
        val decoded = ReaderPlan.decodeProgressRows(ReaderPlan.encodeProgressRows(rows))
        assertEquals(rows, decoded)
    }

    @Test
    fun `progress decode skips bad rows`() {
        val bad1 = RecordCodec.encodeRow(listOf("onlywork"))
        val bad2 = RecordCodec.encodeRow(listOf("", "5", "0.5"))
        val bad3 = RecordCodec.encodeRow(listOf("w", "-1", "0.5"))
        val bad4 = RecordCodec.encodeRow(listOf("w", "5", "nan?"))
        val good = RecordCodec.encodeRow(listOf("keep", "2", "0.3333"))
        val raw = listOf(bad1, bad2, bad3, bad4, good).joinToString(RecordCodec.ROW.toString())
        assertEquals(listOf(Triple("keep", 2, 0.3333f)), ReaderPlan.decodeProgressRows(raw))
        assertTrue(ReaderPlan.decodeProgressRows(null).isEmpty())
        assertTrue(ReaderPlan.decodeProgressRows("   ").isEmpty())
    }

    @Test
    fun `progress decode clamps frac`() {
        val raw = RecordCodec.encodeRow(listOf("w", "1", "9.5"))
        assertEquals(listOf(Triple("w", 1, 1f)), ReaderPlan.decodeProgressRows(raw))
    }

    @Test
    fun `upsert moves existing work to end`() {
        val rows = listOf(
            Triple("a", 1, 0.1f),
            Triple("b", 2, 0.2f)
        )
        val next = ReaderPlan.upsertProgress(rows, "a", 5, 0.9f)
        assertEquals(listOf("b", "a"), next.map { it.first })
        assertEquals(Triple("a", 5, 0.9f), next.last())
    }

    @Test
    fun `upsert drops oldest over max`() {
        val rows = (1..5).map { Triple("w$it", it, 0.1f * it) }
        val next = ReaderPlan.upsertProgress(rows, "w6", 6, 0.6f, max = 3)
        assertEquals(listOf("w4", "w5", "w6"), next.map { it.first })
    }

    @Test
    fun `upsert ignores blank work id`() {
        val rows = listOf(Triple("a", 1, 0.1f))
        assertEquals(rows, ReaderPlan.upsertProgress(rows, "   ", 2, 0.2f))
    }

    /* ------------------------------------------------ 缓存 */

    @Test
    fun `cache file name filters unsafe chars with fallback`() {
        assertEquals("work12x.txt", ReaderPlan.cacheFileName("work/12?x"))
        assertEquals("w-1_2.txt", ReaderPlan.cacheFileName(" w-1_2 "))
        assertEquals("work.txt", ReaderPlan.cacheFileName("///"))
    }

    @Test
    fun `freshness boundary`() {
        assertTrue(ReaderPlan.isFresh(cachedAt = 1000L, now = 1000L, ttlMillis = 100L))
        assertTrue(ReaderPlan.isFresh(cachedAt = 950L, now = 1000L, ttlMillis = 100L))
        // 恰好到期即视为过期
        assertEquals(false, ReaderPlan.isFresh(cachedAt = 900L, now = 1000L, ttlMillis = 100L))
        assertEquals(false, ReaderPlan.isFresh(cachedAt = 0L, now = 1000L, ttlMillis = 100L))
    }

    @Test
    fun `prune keeps newest and drops rest`() {
        val files = listOf("a" to 100L, "b" to 300L, "c" to 200L)
        assertEquals(listOf("a"), ReaderPlan.pruneFiles(files, max = 2))
        assertTrue(ReaderPlan.pruneFiles(files, max = 5).isEmpty())
    }

    @Test
    fun `cache roundtrip preserves control chars and newlines`() {
        val ctrl = 1.toChar()
        val content = ReaderPlan.CachedContent(
            workId = "12345",
            title = "标题 \u00b7 Title",
            authors = "A, B",
            summary = "第一行\n第二行",
            chaptersLabel = "2/5",
            chapters = listOf(
                Chapter(index = 1, title = "Ch 2", text = "line1\nline2${ctrl}end"),
                Chapter(index = 0, title = "Ch 1", text = "hello")
            )
        )
        val decoded = ReaderPlan.decodeCache(ReaderPlan.encodeCache(content))
        assertEquals(content.workId, decoded?.workId)
        assertEquals(content.title, decoded?.title)
        assertEquals(content.summary, decoded?.summary)
        // 解码时按 index 升序
        assertEquals(listOf(0, 1), decoded?.chapters?.map { it.index })
        assertEquals("line1\nline2${ctrl}end", decoded?.chapters?.last()?.text)
    }

    @Test
    fun `decode cache rejects garbage`() {
        assertNull(ReaderPlan.decodeCache(""))
        assertNull(ReaderPlan.decodeCache("   "))
        assertNull(ReaderPlan.decodeCache("garbage"))
        // 只有元信息、没有章节
        val headerOnly = RecordCodec.encodeRow(listOf("w", "t", "a", "s", "1/1"))
        assertNull(ReaderPlan.decodeCache(headerOnly))
        // 元信息字段不足
        val shortHeader = RecordCodec.encodeRow(listOf("w", "t"))
        val chapterRow = RecordCodec.encodeRow(listOf("0", "c", "x"))
        assertNull(ReaderPlan.decodeCache("$shortHeader${RecordCodec.ROW}$chapterRow"))
    }
}