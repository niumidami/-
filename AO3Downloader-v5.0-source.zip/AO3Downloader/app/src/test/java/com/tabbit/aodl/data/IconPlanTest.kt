package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 需求 4「自定义图标」决策逻辑的离线断言。
 *
 * [IconPlan] 是 `AppViewModel.reloadIconState` / `IconManager` 里剥离出来的纯决策部分，
 * 这里逐条核对三件必须成立的事：
 * - **桌面 alias 有且仅有一个启用**：任何脏数据（旧版本遗留的图标名、空串、null、
 *   被裁剪的枚举）都不允许出现「零个可启动入口」或「多个入口」；
 * - **自定义图片不接管桌面 alias**：图片在应用私有目录、写不进 APK 的 `android:icon`，
 *   所以选择 `CUSTOM` 时 [IconDecision.builtin] 必须仍是最后一次选中的内置图标；
 * - **采样与裁剪可算**：`inSampleSize` 只能是 2 的幂且采样后两条边仍不小于目标边长，
 *   居中裁剪取最大内接正方形，非法尺寸直接拒绝而不是返回 0 边长。
 */
class IconPlanTest {

    private val known = listOf("SAKURA", "NIGHT", "MONO", "AO3")
    private val fallback = "SAKURA"

    private fun decide(
        choice: String?,
        builtin: String?,
        hasImage: Boolean,
        icons: List<String> = known
    ) = IconPlan.decide(choice, builtin, icons, fallback, hasImage)

    // ------------------------------------------------------------- 选择归一化

    @Test
    fun `first launch falls back to the default built-in icon`() {
        val decision = decide(null, null, hasImage = false)
        assertEquals("SAKURA", decision.choice)
        assertEquals("SAKURA", decision.builtin)
        assertFalse(decision.useCustom)
    }

    @Test
    fun `a stored built-in choice is kept as is`() {
        val decision = decide("NIGHT", "NIGHT", hasImage = false)
        assertEquals("NIGHT", decision.choice)
        assertEquals("NIGHT", decision.builtin)
        assertFalse(decision.useCustom)
    }

    @Test
    fun `unknown or blank values never leak into the decision`() {
        // 脏数据来源：枚举被裁剪后遗留的旧名字、空白串、null
        listOf("GONE", "  ", "", null).forEach { raw ->
            val decision = decide(raw, raw, hasImage = false)
            assertEquals("raw=$raw", fallback, decision.choice)
            assertEquals("raw=$raw", fallback, decision.builtin)
            assertFalse(decision.useCustom)
        }
    }

    @Test
    fun `matching ignores case and surrounding whitespace`() {
        val decision = decide("  mono ", "Mono", hasImage = false)
        assertEquals("MONO", decision.choice)
        assertEquals("MONO", decision.builtin)
    }

    @Test
    fun `blank entries in the known list are ignored`() {
        val decision = IconPlan.decide("MONO", "MONO", listOf("SAKURA", "", "MONO"), fallback, false)
        assertEquals("MONO", decision.choice)
        assertEquals("MONO", decision.builtin)
    }

    @Test
    fun `empty known list falls back to the default name`() {
        val decision = decide("NIGHT", "NIGHT", hasImage = false, icons = emptyList())
        assertEquals(fallback, decision.choice)
        assertEquals(fallback, decision.builtin)
    }

    @Test
    fun `fallback outside the known list uses the first known icon`() {
        // 出厂默认名已不在列表里时退到第一项，绝不返回一个未知名字
        val trimmed = listOf("NIGHT", "MONO")
        val decision = IconPlan.decide(null, null, trimmed, fallback, hasCustomImage = false)
        assertEquals("NIGHT", decision.choice)
        assertEquals("NIGHT", decision.builtin)
    }

    // ----------------------------------------------------------- 自定义图片

    @Test
    fun `custom choice wins only when the uploaded image really exists`() {
        val withImage = decide("CUSTOM", "NIGHT", hasImage = true)
        assertEquals(IconPlan.CUSTOM, withImage.choice)
        assertEquals("NIGHT", withImage.builtin)
        assertTrue(withImage.useCustom)

        // 图片文件被清掉（清缓存、卸载重装残留）时静默回退，不弹错也不留空图标
        val withoutImage = decide("CUSTOM", "NIGHT", hasImage = false)
        assertEquals("NIGHT", withoutImage.choice)
        assertEquals("NIGHT", withoutImage.builtin)
        assertFalse(withoutImage.useCustom)
    }

    @Test
    fun `custom keyword is matched ignoring case and whitespace`() {
        assertTrue(decide(" custom ", "MONO", hasImage = true).useCustom)
        assertEquals(IconPlan.CUSTOM, decide("Custom", "MONO", true).choice)
    }

    @Test
    fun `a broken remembered builtin still yields a usable custom decision`() {
        val decision = decide("CUSTOM", "GONE", hasImage = true)
        assertEquals(IconPlan.CUSTOM, decision.choice)
        assertEquals(fallback, decision.builtin)
        assertTrue(decision.useCustom)
    }

    // ------------------------------------------------------- 桌面 alias 开关表

    @Test
    fun `exactly one alias is enabled for every possible choice`() {
        (known + IconPlan.CUSTOM).forEach { picked ->
            val decision = decide(picked, picked, hasImage = picked == IconPlan.CUSTOM)
            val states = IconPlan.enabledStates(known, decision)
            assertEquals(known.size, states.size)
            assertEquals("picked=$picked", 1, states.count { it.second })
            assertEquals("picked=$picked", decision.builtin, states.single { it.second }.first)
        }
    }

    @Test
    fun `custom mode still enables a built-in alias so the app stays launchable`() {
        val decision = decide("CUSTOM", "AO3", hasImage = true)
        assertTrue(decision.useCustom)
        assertEquals(
            listOf("SAKURA" to false, "NIGHT" to false, "MONO" to false, "AO3" to true),
            IconPlan.enabledStates(known, decision)
        )
    }

    @Test
    fun `enabled states degrade safely on empty or mismatching known list`() {
        val decision = decide("NIGHT", "NIGHT", hasImage = false)
        assertEquals(listOf("NIGHT" to true), IconPlan.enabledStates(emptyList(), decision))

        val states = IconPlan.enabledStates(listOf("MONO", "AO3"), decision)
        assertEquals(1, states.count { it.second })
        assertEquals("MONO", states.single { it.second }.first)
    }

    // ----------------------------------------------------------- 点选后的记忆

    @Test
    fun `picking a built-in icon updates the remembered one`() {
        assertEquals("MONO", IconPlan.nextBuiltin("MONO", "SAKURA", known, fallback))
        assertEquals("AO3", IconPlan.nextBuiltin("ao3", "SAKURA", known, fallback))
    }

    @Test
    fun `picking custom keeps the remembered built-in icon`() {
        assertEquals("NIGHT", IconPlan.nextBuiltin("CUSTOM", "NIGHT", known, fallback))
        assertEquals("NIGHT", IconPlan.nextBuiltin(" custom ", "night", known, fallback))
    }

    @Test
    fun `picking an unknown name falls back to the default icon`() {
        assertEquals(fallback, IconPlan.nextBuiltin("GONE", "NIGHT", known, fallback))
        assertEquals(fallback, IconPlan.nextBuiltin(null, "NIGHT", known, fallback))
        assertEquals(fallback, IconPlan.nextBuiltin("  ", "NIGHT", known, fallback))
    }

    // ------------------------------------------------------------ 采样与裁剪

    @Test
    fun `sample size is a power of two and keeps both edges above the target`() {
        assertEquals(1, IconPlan.sampleSize(256, 256, 256))
        assertEquals(2, IconPlan.sampleSize(512, 512, 256))
        assertEquals(4, IconPlan.sampleSize(1024, 1024, 256))
        assertEquals(8, IconPlan.sampleSize(4000, 3000, 256))
        // 竖长图受短边限制，不能按长边算
        assertEquals(2, IconPlan.sampleSize(600, 1200, 256))
        // 比目标还小则不缩放（inSampleSize 不会放大图片）
        assertEquals(1, IconPlan.sampleSize(120, 80, 256))
    }

    @Test
    fun `sample size rejects non positive input instead of looping`() {
        assertEquals(1, IconPlan.sampleSize(0, 100, 256))
        assertEquals(1, IconPlan.sampleSize(100, -1, 256))
        assertEquals(1, IconPlan.sampleSize(100, 100, 0))
    }

    @Test
    fun `center crop returns the largest inscribed square`() {
        assertEquals(Triple(0, 150, 300), IconPlan.centerCrop(300, 600))
        assertEquals(Triple(150, 0, 300), IconPlan.centerCrop(600, 300))
        assertEquals(Triple(0, 0, 256), IconPlan.centerCrop(256, 256))
        // 极端长宽比：边长退到 1px，起点仍取另一条边的正中，不会越界
        assertEquals(Triple(0, 499, 1), IconPlan.centerCrop(1, 999))
        assertEquals(Triple(499, 0, 1), IconPlan.centerCrop(999, 1))
        // 奇数边长向下取整，偏移量不会越界
        assertEquals(Triple(0, 149, 301), IconPlan.centerCrop(301, 600))
    }

    @Test
    fun `center crop rejects non positive sizes`() {
        assertNull(IconPlan.centerCrop(0, 100))
        assertNull(IconPlan.centerCrop(100, -1))
    }
}
