package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 结果页筛选条件与分页口径的离线断言（v5.1 结果页筛选与分页）。
 *
 * `WorkSearchFilter` / `WorkSearchOptions` / `WorkSearchPaging` 都是纯数据 + 纯函数，
 * 不依赖 Android 与网络；参数名对齐 otwarchive `work_search_form.rb` 的 ATTRIBUTES，
 * 因此这里直接断言产出的 `work_search[...]` 键值序列与站点表单一致。
 */
class WorkSearchFilterTest {

    // ------------------------------------------------------------ 参数拼装

    @Test
    fun `empty filter produces no query pairs`() {
        assertTrue(WorkSearchFilter().isEmpty())
        assertTrue(WorkSearchFilter().toQueryPairs().isEmpty())
    }

    @Test
    fun `toQueryPairs emits site field names in form order`() {
        val filter = WorkSearchFilter(
            title = " 时间机器 ",
            creators = "someone",
            revisedAt = "> 2 weeks ago",
            dateFrom = "2024-01-01",
            dateTo = "2024-06-30",
            complete = true,
            crossover = false,
            singleChapter = true,
            wordCount = ">1000",
            language = "zh",
            fandomNames = "Harry Potter",
            ratingId = "12",
            warningIds = setOf("18", "14"),
            categoryIds = setOf("23", "21"),
            characterNames = "Hermione",
            relationshipNames = "Draco/Harry",
            freeformNames = "Fluff",
            hits = ">100",
            kudos = "50-500",
            comments = ">10",
            bookmarks = "<1000",
            sortColumn = "revised_at",
            sortDirection = "desc"
        )
        assertEquals(
            listOf(
                "work_search[title]" to "时间机器",
                "work_search[creators]" to "someone",
                "work_search[revised_at]" to "> 2 weeks ago",
                "work_search[date_from]" to "2024-01-01",
                "work_search[date_to]" to "2024-06-30",
                "work_search[complete]" to "T",
                "work_search[crossover]" to "F",
                "work_search[single_chapter]" to "1",
                "work_search[word_count]" to ">1000",
                "work_search[language_id]" to "zh",
                "work_search[fandom_names]" to "Harry Potter",
                "work_search[rating_ids]" to "12",
                "work_search[archive_warning_ids][]" to "14",
                "work_search[archive_warning_ids][]" to "18",
                "work_search[category_ids][]" to "21",
                "work_search[category_ids][]" to "23",
                "work_search[character_names]" to "Hermione",
                "work_search[relationship_names]" to "Draco/Harry",
                "work_search[freeform_names]" to "Fluff",
                "work_search[hits]" to ">100",
                "work_search[kudos_count]" to "50-500",
                "work_search[comments_count]" to ">10",
                "work_search[bookmarks_count]" to "<1000",
                "work_search[sort_column]" to "revised_at",
                "work_search[sort_direction]" to "desc"
            ),
            filter.toQueryPairs()
        )
    }

    @Test
    fun `blank values are trimmed and skipped`() {
        val filter = WorkSearchFilter(title = "   ", hits = "  42  ")
        assertEquals(listOf("work_search[hits]" to "42"), filter.toQueryPairs())
        assertFalse(filter.isEmpty())
    }

    @Test
    fun `multi select ids are emitted sorted for stable urls`() {
        val filter = WorkSearchFilter(
            warningIds = setOf("20", "14", "17"),
            categoryIds = setOf("2246", "21")
        )
        assertEquals(
            listOf(
                "work_search[archive_warning_ids][]" to "14",
                "work_search[archive_warning_ids][]" to "17",
                "work_search[archive_warning_ids][]" to "20",
                "work_search[category_ids][]" to "21",
                "work_search[category_ids][]" to "2246"
            ),
            filter.toQueryPairs()
        )
    }

    // ------------------------------------------------------------ 生效项计数

    @Test
    fun `activeCount counts filter fields but not sort`() {
        assertEquals(0, WorkSearchFilter().activeCount())
        assertEquals(
            0,
            WorkSearchFilter(sortColumn = "hits", sortDirection = "desc").activeCount()
        )
        assertEquals(
            1,
            WorkSearchFilter(dateFrom = "2024-01-01", dateTo = "2024-06-30").activeCount()
        )
        assertEquals(
            3,
            WorkSearchFilter(
                complete = false,
                warningIds = setOf("14", "18"),
                categoryIds = setOf("21")
            ).activeCount()
        )
    }

    // ------------------------------------------------------------ 候选项合并

    @Test
    fun `merge keeps builtin entries when online list is empty`() {
        val merged = WorkSearchOptions.merge(SearchFormOptions())
        assertEquals(WorkSearchOptions.RATINGS, merged.ratings)
        assertEquals(WorkSearchOptions.WARNINGS, merged.warnings)
        assertEquals(WorkSearchOptions.CATEGORIES, merged.categories)
        assertEquals(WorkSearchOptions.LANGUAGES, merged.languages)
        assertEquals(WorkSearchOptions.SORTS, merged.sorts)
    }

    @Test
    fun `merge prefers online entries and fills the rest from builtin`() {
        val online = SearchFormOptions(ratings = listOf(FilterOption("99", "Custom")))
        val merged = WorkSearchOptions.merge(online)
        assertEquals(listOf(FilterOption("99", "Custom")), merged.ratings)
        assertEquals(WorkSearchOptions.LANGUAGES, merged.languages)
        assertEquals(WorkSearchOptions.SORTS, merged.sorts)
    }

    // ------------------------------------------------------------ 分页口径

    @Test
    fun `parseFoundCount reads leading number with commas`() {
        assertEquals(1234, WorkSearchPaging.parseFoundCount("1,234 Found"))
        assertEquals(1234, WorkSearchPaging.parseFoundCount("Found 1,234 works"))
        assertEquals(1, WorkSearchPaging.parseFoundCount("1 Work Found"))
        assertEquals(0, WorkSearchPaging.parseFoundCount("没有找到"))
        assertEquals(0, WorkSearchPaging.parseFoundCount(""))
    }

    @Test
    fun `pageCount rounds up per twenty and caps at five hundred`() {
        assertEquals(0, WorkSearchPaging.pageCount(0))
        assertEquals(1, WorkSearchPaging.pageCount(1))
        assertEquals(1, WorkSearchPaging.pageCount(20))
        assertEquals(2, WorkSearchPaging.pageCount(21))
        assertEquals(500, WorkSearchPaging.pageCount(100_000))
    }

    @Test
    fun `pageWindow keeps first last and current neighborhood`() {
        assertEquals(
            listOf(1, 2, 3, 4, 5),
            WorkSearchPaging.pageWindow(current = 3, pages = 5)
        )
        assertEquals(
            listOf(1, null, 3, 4, 5, 6, 7, null, 10),
            WorkSearchPaging.pageWindow(current = 5, pages = 10)
        )
        assertEquals(
            listOf(1, 2, 3, null, 10),
            WorkSearchPaging.pageWindow(current = 1, pages = 10)
        )
        assertEquals(
            listOf(1, null, 8, 9, 10),
            WorkSearchPaging.pageWindow(current = 10, pages = 10)
        )
        assertTrue(WorkSearchPaging.pageWindow(current = 1, pages = 0).isEmpty())
    }
}
