package com.tabbit.aodl.vm

import com.tabbit.aodl.model.AppSettings
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * 重试退避策略的离线断言（需求 6）。
 *
 * `RetryPolicy` 是纯函数，不涉及 Android API，可直接在 JVM 上验证。
 */
class RetryPolicyTest {

    @Test
    fun `delay grows linearly from the base interval`() {
        assertEquals(2, RetryPolicy.delaySeconds(1))
        assertEquals(4, RetryPolicy.delaySeconds(2))
        assertEquals(6, RetryPolicy.delaySeconds(3))
        assertEquals(8, RetryPolicy.delaySeconds(4))
    }

    @Test
    fun `delay is capped and never below one second`() {
        assertEquals(RetryPolicy.MAX_DELAY_SECONDS, RetryPolicy.delaySeconds(10))
        assertEquals(RetryPolicy.MAX_DELAY_SECONDS, RetryPolicy.delaySeconds(Int.MAX_VALUE))
        // attempt 可能因异常路径传入 0 或负数，退避仍须是正数，否则 delay(0) 变成忙等。
        assertEquals(2, RetryPolicy.delaySeconds(0))
        assertEquals(2, RetryPolicy.delaySeconds(-3))
    }

    @Test
    fun `max attempts is one first try plus configured retries`() {
        assertEquals(1, RetryPolicy.maxAttempts(0))
        assertEquals(3, RetryPolicy.maxAttempts(2))
        assertEquals(1 + AppSettings.MAX_RETRY, RetryPolicy.maxAttempts(AppSettings.MAX_RETRY))
    }

    @Test
    fun `max attempts clamps out of range settings`() {
        // 设置被改写或历史值越界时，至少尝试 1 次，最多 1 + MAX_RETRY 次。
        assertEquals(1, RetryPolicy.maxAttempts(-5))
        assertEquals(1, RetryPolicy.maxAttempts(Int.MIN_VALUE))
        assertEquals(1 + AppSettings.MAX_RETRY, RetryPolicy.maxAttempts(99))
        assertEquals(1 + AppSettings.MAX_RETRY, RetryPolicy.maxAttempts(Int.MAX_VALUE))
    }
}
