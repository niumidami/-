package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 「我的标签」本地名单的离线断言（v5.1 快捷入口改造）。
 *
 * [MyTagsStore] 是纯对象：编解码往返、忽略大小写去重、上限截断与坏行清理都在这里验证。
 */
class MyTagsStoreTest {

    @Test
    fun `encode decode round trip keeps order and values`() {
        val tags = listOf("Time Travel", "Fluff", "Hurt_Comfort")
        val encoded = MyTagsStore.encode(tags)
        assertEquals(tags, MyTagsStore.decode(encoded))
    }

    @Test
    fun `decode of blank or null gives empty list`() {
        assertEquals(emptyList<String>(), MyTagsStore.decode(null))
        assertEquals(emptyList<String>(), MyTagsStore.decode(""))
        assertEquals(emptyList<String>(), MyTagsStore.decode("   "))
    }

    @Test
    fun `add ignores case duplicates and trims input`() {
        val base = listOf("Fluff")
        assertEquals(base, MyTagsStore.add(base, "fluff"))
        assertEquals(base, MyTagsStore.add(base, " FLUFF "))
        assertEquals(listOf("Fluff", "Angst"), MyTagsStore.add(base, " Angst "))
    }

    @Test
    fun `add empty value keeps list unchanged`() {
        val base = listOf("Fluff")
        assertEquals(base, MyTagsStore.add(base, ""))
        assertEquals(base, MyTagsStore.add(base, "   "))
    }

    @Test
    fun `remove ignores case and surrounding spaces`() {
        val base = listOf("Fluff", "Angst")
        assertEquals(listOf("Angst"), MyTagsStore.remove(base, "fluff"))
        assertEquals(listOf("Angst"), MyTagsStore.remove(base, " Fluff "))
        assertEquals(base, MyTagsStore.remove(base, "not-there"))
    }

    @Test
    fun `contains ignores case`() {
        val base = listOf("Fluff")
        assertTrue(MyTagsStore.contains(base, "fluff"))
        assertTrue(MyTagsStore.contains(base, "FLUFF"))
        assertFalse(MyTagsStore.contains(base, "angst"))
    }

    @Test
    fun `list is capped at MAX`() {
        val many = (1..(MyTagsStore.MAX + 20)).map { "tag-$it" }
        val encoded = MyTagsStore.encode(many)
        assertEquals(MyTagsStore.MAX, MyTagsStore.decode(encoded).size)
        val grown = many.fold(emptyList<String>()) { acc, tag -> MyTagsStore.add(acc, tag) }
        assertEquals(MyTagsStore.MAX, grown.size)
    }

    @Test
    fun `separator characters inside tag survive round trip`() {
        // 正文里混入分隔符（单元分隔/记录分隔）时转义应保证往返一致
        val tricky = listOf("a${RecordCodec.FIELD}b", "c${RecordCodec.ROW}d", "line\nbreak")
        val decoded = MyTagsStore.decode(MyTagsStore.encode(tricky))
        assertEquals(tricky, decoded)
    }

    @Test
    fun `decode drops blank rows and duplicates`() {
        val raw = listOf("Fluff", "", "fluff", "  ", "Angst")
            .joinToString(RecordCodec.ROW.toString()) { RecordCodec.escape(it) }
        assertEquals(listOf("Fluff", "Angst"), MyTagsStore.decode(raw))
    }
}
