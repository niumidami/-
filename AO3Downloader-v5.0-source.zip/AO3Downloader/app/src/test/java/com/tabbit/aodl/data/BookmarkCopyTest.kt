package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 收藏条目「复制作者名 / 复制编号」的取值与拼装规则断言（v4.6 需求）。
 *
 * 复制内容全部来自 `WorkItem` 已有字段，不再为复制发一次请求，因此这里的输入
 * 就是解析好的 byline 文本与作品 id。要钉住的是三件事：
 * 1. 编号统一带 `#` 前缀，与界面卡片上的显示口径一致；
 * 2. 缺字段时**退化**而不是产出 `#`、`null` 之类的半截内容；
 * 3. 非纯数字的 id（系列 `/series/<id>`、外部作品）原样保留——复制的目的就是
 *    让用户拿到能定位这条记录的东西，不做二次加工。
 */
class BookmarkCopyTest {

    @Test
    fun constants_matchTheUiDisplayConvention() {
        assertEquals("#", BookmarkCopy.ID_PREFIX)
        assertEquals(" ", BookmarkCopy.SEPARATOR)
    }

    @Test
    fun authorText_trimsAndToleratesNull() {
        assertEquals("onee1e", BookmarkCopy.authorText("  onee1e  "))
        assertEquals("", BookmarkCopy.authorText(null))
        assertEquals("", BookmarkCopy.authorText("   "))
    }

    /** 多作者的 byline 是逗号分隔原文，复制时不能改写或截断。 */
    @Test
    fun authorText_keepsMultipleAuthorsVerbatim() {
        val authors = "Alpha, Beta, Gamma"
        assertEquals(authors, BookmarkCopy.authorText(authors))
    }

    @Test
    fun idText_trimsAndToleratesNull() {
        assertEquals("12345678", BookmarkCopy.idText(" 12345678 "))
        assertEquals("", BookmarkCopy.idText(null))
    }

    @Test
    fun prefixedId_addsHashPrefix() {
        assertEquals("#12345678", BookmarkCopy.prefixedId("12345678"))
    }

    /** 编号为空时返回空串，而不是只剩一个孤零零的 `#`。 */
    @Test
    fun prefixedId_emptyIdYieldsEmptyString() {
        assertEquals("", BookmarkCopy.prefixedId(""))
        assertEquals("", BookmarkCopy.prefixedId("   "))
        assertEquals("", BookmarkCopy.prefixedId(null))
    }

    @Test
    fun combined_authorAndId() {
        assertEquals("onee1e #12345678", BookmarkCopy.combined("onee1e", "12345678"))
    }

    /** 缺作者名时退化成只剩编号，反之亦然。 */
    @Test
    fun combined_degradesWhenOneSideMissing() {
        assertEquals("#12345678", BookmarkCopy.combined("", "12345678"))
        assertEquals("#12345678", BookmarkCopy.combined("   ", "12345678"))
        assertEquals("#12345678", BookmarkCopy.combined(null, "12345678"))
        assertEquals("onee1e", BookmarkCopy.combined("onee1e", ""))
        assertEquals("onee1e", BookmarkCopy.combined("onee1e", null))
    }

    @Test
    fun combined_bothMissingYieldsEmptyString() {
        assertEquals("", BookmarkCopy.combined(null, null))
        assertEquals("", BookmarkCopy.combined("", ""))
        assertEquals("", BookmarkCopy.combined("  ", "  "))
    }

    @Test
    fun combined_trimsBothSides() {
        assertEquals("onee1e #12345678", BookmarkCopy.combined("  onee1e ", " 12345678 "))
    }

    @Test
    fun payload_routesByTarget() {
        val authors = "onee1e"
        val id = "12345678"
        assertEquals("onee1e", BookmarkCopy.payload(CopyTarget.AUTHOR, authors, id))
        assertEquals("#12345678", BookmarkCopy.payload(CopyTarget.ID, authors, id))
        assertEquals("onee1e #12345678", BookmarkCopy.payload(CopyTarget.BOTH, authors, id))
    }

    /** 无可复制内容时 payload 为空串，界面据此忽略这次点击、不写空剪贴板。 */
    @Test
    fun payload_emptyWhenNothingToCopy() {
        for (target in CopyTarget.values()) {
            assertEquals("", BookmarkCopy.payload(target, null, null))
            assertEquals("", BookmarkCopy.payload(target, "", ""))
        }
    }

    @Test
    fun enabled_isFalseOnlyWhenPayloadIsEmpty() {
        assertFalse(BookmarkCopy.enabled(CopyTarget.AUTHOR, "", "12345678"))
        assertFalse(BookmarkCopy.enabled(CopyTarget.ID, "onee1e", ""))
        assertFalse(BookmarkCopy.enabled(CopyTarget.BOTH, null, null))

        assertTrue(BookmarkCopy.enabled(CopyTarget.AUTHOR, "onee1e", ""))
        assertTrue(BookmarkCopy.enabled(CopyTarget.ID, "", "12345678"))
        assertTrue(BookmarkCopy.enabled(CopyTarget.BOTH, "onee1e", "12345678"))
    }

    /** `enabled` 与 `payload` 必须同口径：只要 payload 非空就该可点。 */
    @Test
    fun enabled_agreesWithPayloadForEveryTarget() {
        val samples = listOf(
            "onee1e" to "12345678",
            "onee1e" to "",
            "" to "12345678",
            "" to "",
            null to null,
            "  " to "  ",
            "Alpha, Beta" to "42"
        )
        for (target in CopyTarget.values()) {
            for ((authors, id) in samples) {
                val payload = BookmarkCopy.payload(target, authors, id)
                assertEquals(
                    "target=$target authors=$authors id=$id",
                    payload.isNotEmpty(),
                    BookmarkCopy.enabled(target, authors, id)
                )
            }
        }
    }

    /** 系列与外部作品的 id 不是纯数字，原样返回，不加前缀之外的加工。 */
    @Test
    fun nonNumericIds_arePassedThroughUnchanged() {
        assertEquals("#series/12345", BookmarkCopy.prefixedId("series/12345"))
        assertEquals("onee1e #series/12345", BookmarkCopy.combined("onee1e", "series/12345"))
        assertEquals("#external", BookmarkCopy.payload(CopyTarget.ID, "onee1e", "external"))
    }

    /** 全部三个复制目标都覆盖到，新增枚举值时这条会失败，提醒补文案与测试。 */
    @Test
    fun everyCopyTargetHasADistinctPayload() {
        val payloads = CopyTarget.values().map { BookmarkCopy.payload(it, "onee1e", "12345678") }
        assertEquals(3, payloads.size)
        assertEquals(3, payloads.distinct().size)
        assertEquals(listOf("onee1e", "#12345678", "onee1e #12345678"), payloads)
    }
}
