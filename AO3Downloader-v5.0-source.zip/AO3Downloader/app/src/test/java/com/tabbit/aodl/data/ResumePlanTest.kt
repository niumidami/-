package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * 需求 6 断点续传决策的离线断言。
 *
 * 穷举「服务端响应特征 × 本地断点大小」的组合，确认：
 * - 只有 206 且起点与请求一致时才接着写；
 * - 其余情况一律 `resumeFrom = 0`（调用方截断重写），不会错位拼接；
 * - 总长优先取 `Content-Range` 的完整长度，其次取本次响应体长度。
 */
class ResumePlanTest {

    private fun decide(
        partial: Boolean,
        confirmedStart: Long,
        probeBytes: Long,
        contentLength: Long,
        fullLength: Long
    ) = ResumePlan.decide(partial, confirmedStart, probeBytes, contentLength, fullLength)

    @Test
    fun `206 with matching start resumes and reports the full length`() {
        val plan = decide(partial = true, confirmedStart = 4096, probeBytes = 4096, contentLength = 5904, fullLength = 10000)
        assertEquals(4096L, plan.resumeFrom)
        assertEquals(10000L, plan.total)
    }

    @Test
    fun `206 without total falls back to probe plus body length`() {
        val plan = decide(partial = true, confirmedStart = 4096, probeBytes = 4096, contentLength = 5904, fullLength = -1)
        assertEquals(4096L, plan.resumeFrom)
        assertEquals(10000L, plan.total)
    }

    @Test
    fun `200 response ignores the local breakpoint and restarts`() {
        val plan = decide(partial = false, confirmedStart = 0, probeBytes = 4096, contentLength = 10000, fullLength = -1)
        assertEquals(0L, plan.resumeFrom)
        assertEquals(10000L, plan.total)
    }

    @Test
    fun `206 with mismatched start never appends to a stale part file`() {
        val plan = decide(partial = true, confirmedStart = 1024, probeBytes = 4096, contentLength = 8976, fullLength = 10000)
        assertEquals(0L, plan.resumeFrom)
        // 从头写时总长必须是即将写入的响应体长度，否则会显示错误进度
        assertEquals(8976L, plan.total)
    }

    @Test
    fun `no local part file means a plain download`() {
        val plan = decide(partial = true, confirmedStart = 0, probeBytes = 0, contentLength = 10000, fullLength = 10000)
        assertEquals(0L, plan.resumeFrom)
        assertEquals(10000L, plan.total)
    }

    @Test
    fun `unknown lengths yield zero total for an indeterminate progress bar`() {
        val plan = decide(partial = false, confirmedStart = 0, probeBytes = 0, contentLength = -1, fullLength = -1)
        assertEquals(0L, plan.resumeFrom)
        assertEquals(0L, plan.total)
    }

    @Test
    fun `fresh download keeps the full length from content range when body length is unknown`() {
        val plan = decide(partial = false, confirmedStart = 0, probeBytes = 0, contentLength = -1, fullLength = 10000)
        assertEquals(0L, plan.resumeFrom)
        assertEquals(10000L, plan.total)
    }

    @Test
    fun `resume is honoured even for a one byte part file`() {
        val plan = decide(partial = true, confirmedStart = 1, probeBytes = 1, contentLength = 9999, fullLength = 10000)
        assertEquals(1L, plan.resumeFrom)
        assertEquals(10000L, plan.total)
    }
}
