package com.tabbit.aodl.data

import com.tabbit.aodl.net.Ao3Client
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 需求 5「跳转官网自行登录并提取 Cookie」纯逻辑层的离线断言。
 *
 * [WebLoginPlan] 只碰字符串与 URL，不依赖 WebView / OkHttp / 网络，
 * 因此登录链路上最容易出错、又最难在真机上复现的部分都能在这里逐条钉死：
 * - 域名白名单必须**精确匹配**，子域与形近域名一律不走代理（收窄代理面 + 防钓鱼）；
 * - `CookieManager.getCookie()` 返回的裸串要做归一化，坏段、重复名、`#HttpOnly_` 前缀都要处理干净；
 * - 会话判据放宽到 `_otwarchive_session` **或** `remember_user_token`，避免把「记住我」用户挡在门外；
 * - POST 还原标记的解析要与注入的 JS 完全对称（含表单编码语义、重复字段名、`#` 片段不参与）；
 * - 重定向方法与 `Location` 解析要符合浏览器惯例，304 绝不能被当成跳转跟随；
 * - 请求/响应头的过滤规则（hop-by-hop、`Set-Cookie`、`Content-Length` 等）与多值合并；
 * - 注入 JS 的字符串转义，避免官网返回的地址里带引号时把脚本打断。
 */
class WebLoginPlanTest {

    // ------------------------------------------------------------------ 域名

    @Test
    fun `ao3 host whitelist matches exactly and is case and dot tolerant`() {
        assertTrue(WebLoginPlan.isAo3Host("archiveofourown.org"))
        assertTrue(WebLoginPlan.isAo3Host("www.archiveofourown.org"))
        assertTrue(WebLoginPlan.isAo3Host("ARCHIVEOFOUROWN.ORG"))
        assertTrue(WebLoginPlan.isAo3Host("  ArchiveOfOurOwn.org  "))
        // RFC 1034 的根点写法，部分内核会带上
        assertTrue(WebLoginPlan.isAo3Host("archiveofourown.org."))
    }

    @Test
    fun `ao3 host whitelist rejects subdomains lookalikes and blanks`() {
        assertFalse(WebLoginPlan.isAo3Host("cdn.archiveofourown.org"))
        assertFalse(WebLoginPlan.isAo3Host("static.www.archiveofourown.org"))
        assertFalse(WebLoginPlan.isAo3Host("evil-archiveofourown.org"))
        assertFalse(WebLoginPlan.isAo3Host("archiveofourown.org.evil.com"))
        assertFalse(WebLoginPlan.isAo3Host("notarchiveofourown.org"))
        assertFalse(WebLoginPlan.isAo3Host(null))
        assertFalse(WebLoginPlan.isAo3Host(""))
        assertFalse(WebLoginPlan.isAo3Host("   "))
    }

    @Test
    fun `cookie names stay in sync with the client constants`() {
        assertEquals(Ao3Client.SESSION_COOKIE, WebLoginPlan.SESSION_COOKIE)
        assertEquals(Ao3Client.REMEMBER_COOKIE, WebLoginPlan.REMEMBER_COOKIE)
        assertEquals("/users/login", WebLoginPlan.LOGIN_PATH)
        assertTrue(WebLoginPlan.MAX_REDIRECTS >= 3)
    }

    // ---------------------------------------------------------------- Cookie

    @Test
    fun `normalize cookies rejoins with a single space and trims every piece`() {
        assertEquals("", WebLoginPlan.normalizeCookies(null))
        assertEquals("", WebLoginPlan.normalizeCookies(""))
        assertEquals("", WebLoginPlan.normalizeCookies("   "))
        assertEquals("a=1; b=2", WebLoginPlan.normalizeCookies("a=1; b=2"))
        assertEquals("a=1; b=2", WebLoginPlan.normalizeCookies("a=1;b=2"))
        assertEquals("a=1; b=2", WebLoginPlan.normalizeCookies("  a = 1 ;  b = 2  "))
    }

    @Test
    fun `normalize cookies drops malformed segments but keeps empty values`() {
        // 空段与缺 `=` 的坏段直接丢掉
        assertEquals("a=1; b=2", WebLoginPlan.normalizeCookies("a=1; ; b=2"))
        assertEquals("a=1; b=2", WebLoginPlan.normalizeCookies("a=1; broken; b=2"))
        // `=1` 没有名字，`eq <= 0` 判掉
        assertEquals("b=2", WebLoginPlan.normalizeCookies("=1; b=2"))
        // CookieManager 可能带 `#HttpOnly_` 前缀，那是内部标记不是 Cookie 名
        assertEquals("b=2", WebLoginPlan.normalizeCookies("#HttpOnly_a=1; b=2"))
        // 空值是合法的（服务端用它表示「已清除」），不能被当成坏段丢掉
        assertEquals("foo=", WebLoginPlan.normalizeCookies("foo="))
        // 值里含 `=` 时只按第一个 `=` 切
        assertEquals("a=1=2", WebLoginPlan.normalizeCookies("a=1=2"))
    }

    @Test
    fun `normalize cookies keeps the first occurrence of a duplicated name`() {
        assertEquals("a=1", WebLoginPlan.normalizeCookies("a=1; a=2"))
        assertEquals("a=1; b=9", WebLoginPlan.normalizeCookies("a=1; b=9; a=2"))
    }

    @Test
    fun `cookie names and count read back from the normalized string`() {
        assertEquals(emptyList<String>(), WebLoginPlan.cookieNames(""))
        assertEquals(0, WebLoginPlan.cookieCount(""))
        assertEquals(listOf("a", "b"), WebLoginPlan.cookieNames("a=1; b=2"))
        assertEquals(2, WebLoginPlan.cookieCount("a=1; b=2"))
        // 空值 Cookie 也要计入条数，成功提示里给用户看的数字才对得上
        assertEquals(listOf("foo"), WebLoginPlan.cookieNames("foo="))
        assertEquals(1, WebLoginPlan.cookieCount("foo="))
    }

    @Test
    fun `usable login state accepts either the session or the remember cookie`() {
        assertTrue(WebLoginPlan.hasSessionCookie("_otwarchive_session=abc; x=1"))
        assertTrue(WebLoginPlan.hasSessionCookie("_OTWARCHIVE_SESSION=abc"))
        assertFalse(WebLoginPlan.hasSessionCookie("remember_user_token=abc"))

        assertTrue(WebLoginPlan.hasRememberCookie("remember_user_token=abc"))
        assertFalse(WebLoginPlan.hasRememberCookie("_otwarchive_session=abc"))

        assertTrue(WebLoginPlan.isUsable("_otwarchive_session=abc"))
        assertTrue(WebLoginPlan.isUsable("remember_user_token=abc"))
        assertTrue(WebLoginPlan.isUsable("x=1; remember_user_token=abc; y=2"))
        // 只有匿名 Cookie（如 `locale` / `_csrf`）说明还没登录成功，不能覆盖既有账号
        assertFalse(WebLoginPlan.isUsable("locale=en; _csrf=xyz"))
        assertFalse(WebLoginPlan.isUsable(""))
    }

    // ------------------------------------------------------------- POST 还原

    @Test
    fun `split post request returns null without the marker`() {
        assertNull(WebLoginPlan.splitPostRequest(null))
        assertNull(WebLoginPlan.splitPostRequest(""))
        assertNull(WebLoginPlan.splitPostRequest("https://archiveofourown.org/users/login"))
        assertNull(WebLoginPlan.splitPostRequest("https://archiveofourown.org/users/login?"))
        assertNull(WebLoginPlan.splitPostRequest("https://archiveofourown.org/users/login?a=1&b=2"))
        // 片段里出现标记不算，查询串才是判据
        assertNull(WebLoginPlan.splitPostRequest("https://archiveofourown.org/users/login?a=1#__aodl_post=1"))
    }

    @Test
    fun `split post request strips the marker and keeps the clean target url`() {
        val posted = WebLoginPlan.splitPostRequest(
            "https://archiveofourown.org/users/login?__aodl_post=1&utf8=%E2%9C%93"
        )
        assertEquals("https://archiveofourown.org/users/login", posted?.targetUrl)
        assertEquals(listOf("utf8" to "\u2713"), posted?.fields)
    }

    @Test
    fun `split post request decodes form encoding the way the injected js encodes it`() {
        // JS 侧用 encodeURIComponent，`+` 会被编码成 %2B；解码时 %2B 必须还原成 `+`
        val posted = WebLoginPlan.splitPostRequest(
            "https://archiveofourown.org/users/login" +
                "?__aodl_post=1&user%5Bname%5D=ab&user%5Bpassword%5D=p%2Bw%20x&remember=1"
        )
        assertEquals(
            listOf(
                "user[name]" to "ab",
                "user[password]" to "p+w x",
                "remember" to "1"
            ),
            posted?.fields
        )
    }

    @Test
    fun `split post request preserves order and duplicated field names`() {
        val posted = WebLoginPlan.splitPostRequest(
            "https://archiveofourown.org/x?__aodl_post=1&tag=a&tag=b&commit=Save"
        )
        assertEquals(listOf("tag" to "a", "tag" to "b", "commit" to "Save"), posted?.fields)
    }

    @Test
    fun `split post request ignores the fragment and tolerates a marker without value`() {
        val withFragment = WebLoginPlan.splitPostRequest("https://x.test/login?__aodl_post=1&a=1#frag")
        assertEquals("https://x.test/login", withFragment?.targetUrl)
        assertEquals(listOf("a" to "1"), withFragment?.fields)

        val bare = WebLoginPlan.splitPostRequest("https://x.test/login?__aodl_post")
        assertEquals("https://x.test/login", bare?.targetUrl)
        assertEquals(emptyList<Pair<String, String>>(), bare?.fields)

        // 只有标记、没有其它字段
        val only = WebLoginPlan.splitPostRequest("https://x.test/login?__aodl_post=1")
        assertEquals(emptyList<Pair<String, String>>(), only?.fields)
    }

    @Test
    fun `has post marker only looks at the query string`() {
        assertFalse(WebLoginPlan.hasPostMarker(null))
        assertFalse(WebLoginPlan.hasPostMarker(""))
        assertFalse(WebLoginPlan.hasPostMarker("https://x.test/login"))
        assertFalse(WebLoginPlan.hasPostMarker("https://x.test/login?a=1"))
        assertTrue(WebLoginPlan.hasPostMarker("https://x.test/login?__aodl_post=1&a=1"))
        assertTrue(WebLoginPlan.hasPostMarker("https://x.test/login?__aodl_post=1#frag"))
        assertFalse(WebLoginPlan.hasPostMarker("https://x.test/login?a=1#__aodl_post=1"))
    }

    // ------------------------------------------------------------------ 重定向

    @Test
    fun `redirect detection covers the real jumps but never 304`() {
        assertTrue(WebLoginPlan.isRedirect(301))
        assertTrue(WebLoginPlan.isRedirect(302))
        assertTrue(WebLoginPlan.isRedirect(303))
        assertTrue(WebLoginPlan.isRedirect(307))
        assertTrue(WebLoginPlan.isRedirect(308))
        // 304 是缓存协商，必须原样交回 WebView，否则页面资源永远拿不到缓存
        assertFalse(WebLoginPlan.isRedirect(304))
        assertFalse(WebLoginPlan.isRedirect(200))
        assertFalse(WebLoginPlan.isRedirect(300))
        assertFalse(WebLoginPlan.isRedirect(399))
        assertFalse(WebLoginPlan.isRedirect(404))
    }

    @Test
    fun `redirect method follows browser conventions`() {
        assertEquals("GET", WebLoginPlan.redirectMethod(303, "POST"))
        assertEquals("GET", WebLoginPlan.redirectMethod(303, "get"))
        // AO3 登录成功就是 302 → `/`，POST 必须降级成 GET 且丢掉 body
        assertEquals("GET", WebLoginPlan.redirectMethod(302, "POST"))
        assertEquals("GET", WebLoginPlan.redirectMethod(301, "post"))
        assertEquals("GET", WebLoginPlan.redirectMethod(302, "GET"))
        assertEquals("HEAD", WebLoginPlan.redirectMethod(301, "HEAD"))
        // 307/308 保留原方法
        assertEquals("POST", WebLoginPlan.redirectMethod(307, "POST"))
        assertEquals("POST", WebLoginPlan.redirectMethod(308, "post"))
    }

    @Test
    fun `location resolves absolute relative and protocol relative targets`() {
        val base = "https://archiveofourown.org/users/login"
        assertEquals("https://archiveofourown.org/", WebLoginPlan.resolveLocation(base, "/"))
        assertEquals(
            "https://archiveofourown.org/",
            WebLoginPlan.resolveLocation(base, "https://archiveofourown.org/")
        )
        assertEquals(
            "https://archiveofourown.org/users/index.html",
            WebLoginPlan.resolveLocation("$base?a=1", "index.html")
        )
        assertEquals(
            "https://cdn.example.com/x",
            WebLoginPlan.resolveLocation(base, "//cdn.example.com/x")
        )
    }

    @Test
    fun `location returns null when blank or unparsable`() {
        val base = "https://archiveofourown.org/users/login"
        assertNull(WebLoginPlan.resolveLocation(base, null))
        assertNull(WebLoginPlan.resolveLocation(base, ""))
        assertNull(WebLoginPlan.resolveLocation(base, "   "))
        // URI.create 对非法字符抛异常，两层 runCatching 之后必须安静地返回 null
        assertNull(WebLoginPlan.resolveLocation(base, "http://exa mple.com/"))
    }

    // -------------------------------------------------------------------- 头

    @Test
    fun `request headers drop hop by hop cookie and encoding but keep the rest`() {
        val raw = linkedMapOf(
            "Accept" to "text/html",
            "Cookie" to "a=1",
            "COOKIE" to "b=2",
            "Accept-Encoding" to "gzip, deflate, br",
            "Connection" to "keep-alive",
            "Transfer-Encoding" to "chunked",
            "Host" to "archiveofourown.org",
            "Content-Length" to "10",
            "Upgrade" to "websocket",
            ":authority" to "archiveofourown.org",
            "" to "junk",
            "User-Agent" to "Mozilla/5.0"
        )
        val out = WebLoginPlan.sanitizeRequestHeaders(raw)
        assertEquals(listOf("Accept", "User-Agent"), out.keys.toList())
        assertEquals("text/html", out["Accept"])

        assertEquals(emptyMap<String, String>(), WebLoginPlan.sanitizeRequestHeaders(null))
        assertEquals(emptyMap<String, String>(), WebLoginPlan.sanitizeRequestHeaders(emptyMap()))
    }

    @Test
    fun `response headers drop cookie location and length and merge multi values`() {
        val raw = linkedMapOf(
            "Content-Type" to listOf("text/html; charset=utf-8"),
            "Set-Cookie" to listOf("a=1; Path=/", "b=2; Path=/"),
            "Location" to listOf("/"),
            "Content-Length" to listOf("100"),
            "Content-Encoding" to listOf("gzip"),
            "Transfer-Encoding" to listOf("chunked"),
            "Connection" to listOf("close"),
            "Cache-Control" to listOf("no-cache", "private"),
            "X-Blank" to listOf("", "  ")
        )
        val out = WebLoginPlan.sanitizeResponseHeaders(raw)
        // 多值头合并成单值，WebResourceResponse 只接受 Map<String, String>
        assertEquals("no-cache, private", out["Cache-Control"])
        assertEquals("text/html; charset=utf-8", out["Content-Type"])
        assertFalse(out.containsKey("Set-Cookie"))
        assertFalse(out.containsKey("Location"))
        assertFalse(out.containsKey("Content-Length"))
        assertFalse(out.containsKey("Content-Encoding"))
        assertFalse(out.containsKey("Transfer-Encoding"))
        assertFalse(out.containsKey("Connection"))
        // 全空值的头不留空键，免得部分内核报错
        assertFalse(out.containsKey("X-Blank"))
        assertEquals(listOf("Content-Type", "Cache-Control"), out.keys.toList())

        assertEquals(emptyMap<String, String>(), WebLoginPlan.sanitizeResponseHeaders(null))
    }

    @Test
    fun `set cookies are extracted verbatim and case insensitively`() {
        // 必须整条原文交给 CookieManager.setCookie，Domain / Path / Expires 才不会丢
        assertEquals(
            listOf("a=1; Path=/; Domain=.archiveofourown.org", "b=2; Secure"),
            WebLoginPlan.extractSetCookies(
                mapOf("Set-Cookie" to listOf("a=1; Path=/; Domain=.archiveofourown.org", "b=2; Secure"))
            )
        )
        // OkHttp 的 toMultimap() 会把头名小写
        assertEquals(
            listOf("x=1"),
            WebLoginPlan.extractSetCookies(mapOf("set-cookie" to listOf("x=1")))
        )
        assertEquals(
            listOf("y=1"),
            WebLoginPlan.extractSetCookies(mapOf("Set-Cookie2" to listOf("y=1")))
        )
        assertEquals(
            listOf("a=1"),
            WebLoginPlan.extractSetCookies(mapOf("Set-Cookie" to listOf("a=1", "", "  ")))
        )
        assertEquals(
            emptyList<String>(),
            WebLoginPlan.extractSetCookies(mapOf("Content-Type" to listOf("text/html")))
        )
        assertEquals(emptyList<String>(), WebLoginPlan.extractSetCookies(null))
    }

    // ------------------------------------------------------------ 响应元信息

    @Test
    fun `reason phrase is never blank for any status code`() {
        assertEquals("OK", WebLoginPlan.reasonPhrase(200))
        assertEquals("Found", WebLoginPlan.reasonPhrase(302))
        assertEquals("Not Modified", WebLoginPlan.reasonPhrase(304))
        assertEquals("Not Found", WebLoginPlan.reasonPhrase(404))
        assertEquals("Unprocessable Entity", WebLoginPlan.reasonPhrase(422))
        assertEquals("Service Unavailable", WebLoginPlan.reasonPhrase(503))
        // 区间兜底：六参 WebResourceResponse 要求 reasonPhrase 非空，否则部分内核直接抛异常
        assertEquals("OK", WebLoginPlan.reasonPhrase(299))
        assertEquals("Redirect", WebLoginPlan.reasonPhrase(350))
        assertEquals("Client Error", WebLoginPlan.reasonPhrase(451))
        assertEquals("Server Error", WebLoginPlan.reasonPhrase(599))
        assertEquals("Server Error", WebLoginPlan.reasonPhrase(0))
        for (code in 0..600) {
            assertTrue("blank reason for $code", WebLoginPlan.reasonPhrase(code).isNotBlank())
        }
    }

    @Test
    fun `charset is parsed from content type and null when absent`() {
        assertNull(WebLoginPlan.charsetOf(null))
        assertNull(WebLoginPlan.charsetOf(""))
        assertNull(WebLoginPlan.charsetOf("text/html"))
        assertNull(WebLoginPlan.charsetOf("text/html; charset="))
        assertEquals("utf-8", WebLoginPlan.charsetOf("text/html; charset=utf-8"))
        assertEquals("UTF-8", WebLoginPlan.charsetOf("text/html;CHARSET=UTF-8"))
        assertEquals("utf-8", WebLoginPlan.charsetOf("text/html; charset=\"utf-8\""))
        assertEquals("gbk", WebLoginPlan.charsetOf("text/html; boundary=x; charset=gbk"))
    }

    @Test
    fun `mime is parsed from content type and null when absent`() {
        assertNull(WebLoginPlan.mimeOf(null))
        assertNull(WebLoginPlan.mimeOf(""))
        assertNull(WebLoginPlan.mimeOf("   "))
        assertEquals("text/html", WebLoginPlan.mimeOf("text/html; charset=utf-8"))
        assertEquals("application/json", WebLoginPlan.mimeOf("  application/json "))
        assertEquals("text/css", WebLoginPlan.mimeOf("text/css"))
    }

    // ------------------------------------------------------------------ 注入 JS

    @Test
    fun `js string literal escapes quotes backslashes and line terminators`() {
        assertEquals("'abc'", WebLoginPlan.jsStringLiteral("abc"))
        assertEquals("'a\\'b'", WebLoginPlan.jsStringLiteral("a'b"))
        assertEquals("'a\\\\b'", WebLoginPlan.jsStringLiteral("a\\b"))
        assertEquals("'a\\nb'", WebLoginPlan.jsStringLiteral("a\nb"))
        assertEquals("'a\\rb'", WebLoginPlan.jsStringLiteral("a\rb"))
        // U+2028 / U+2029 在 JS 里是行终止符，必须转义否则脚本被打断
        assertEquals("'a\\u2028b'", WebLoginPlan.jsStringLiteral("a\u2028b"))
        assertEquals("'a\\u2029b'", WebLoginPlan.jsStringLiteral("a\u2029b"))
        // 其余控制字符走 \uXXXX
        assertEquals("'a\\u0001b'", WebLoginPlan.jsStringLiteral("a\u0001b"))
        // 中文原样保留，不能被转义成一串 \u
        assertEquals("'\u4f5c\u54c1\u540d by \u4f5c\u8005'", WebLoginPlan.jsStringLiteral("作品名 by 作者"))
    }

    @Test
    fun `js string literal breaks up closing script tags`() {
        assertEquals("'<\\/script>'", WebLoginPlan.jsStringLiteral("</script>"))
        assertEquals("'a<\\/b'", WebLoginPlan.jsStringLiteral("a</b"))
        assertEquals("'<'", WebLoginPlan.jsStringLiteral("<"))
    }

    @Test
    fun `replace state js wraps the clean url and swallows errors`() {
        val js = WebLoginPlan.replaceStateJs("https://archiveofourown.org/")
        assertEquals(
            "try { window.history.replaceState(null, '', 'https://archiveofourown.org/'); } catch (e) {}",
            js
        )
        // 官网返回的地址里带引号时也要能安全拼进去
        assertTrue(WebLoginPlan.replaceStateJs("x'y").contains("\\'"))
    }

    @Test
    fun `form capture js is rendered and hooks only post forms once`() {
        val js = WebLoginPlan.FORM_CAPTURE_JS
        // 模板里的标记必须被真实渲染，留下 `$POST_MARKER` 就说明字符串模板写坏了
        assertFalse(js.contains("$"))
        assertTrue(js.contains(WebLoginPlan.POST_MARKER))
        assertTrue(js.contains("__aodlHooked"))
        assertTrue(js.contains("preventDefault"))
        assertTrue(js.contains("stopPropagation"))
        // 捕获阶段监听，才能在页面自己的 handler 之前拦下
        assertTrue(js.contains("addEventListener('submit'"))
        assertTrue(js.contains("}, true);"))
        // 只 hook 显式 POST 的表单，AO3 的搜索与筛选是 GET，必须保持原生
        assertTrue(js.contains("!== 'post'"))
        // Rails 的 commit 参数决定服务端走哪个分支，要靠 submitter 补回来
        assertTrue(js.contains("submitter"))
        assertTrue(js.contains("encodeURIComponent"))
    }

    @Test
    fun `post marker is a plain identifier safe to put in a query string`() {
        assertEquals("__aodl_post", WebLoginPlan.POST_MARKER)
        assertTrue(WebLoginPlan.POST_MARKER.all { it.isLetterOrDigit() || it == '_' })
    }
}
