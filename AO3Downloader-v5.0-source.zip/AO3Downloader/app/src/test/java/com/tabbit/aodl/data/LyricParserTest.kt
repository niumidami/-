package com.tabbit.aodl.data

import java.nio.charset.Charset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** [LyricParser] 的离线规则测试：LRC 时间轴、偏移、纯文本回退与字节解码。 */
class LyricParserTest {

    @Test
    fun `timed lines are sorted by timestamp`() {
        val lines = LyricParser.parse("[00:10.00]second\n[00:05.50]first")
        assertEquals(2, lines.size)
        assertEquals(5_500L, lines[0].timeMs)
        assertEquals("first", lines[0].text)
        assertEquals(10_000L, lines[1].timeMs)
    }

    @Test
    fun `multiple timestamps on one line expand into rows`() {
        val lines = LyricParser.parse("[00:01.00][00:30.00]chorus")
        assertEquals(2, lines.size)
        assertEquals(listOf(1_000L, 30_000L), lines.map { it.timeMs })
        assertTrue(lines.all { it.text == "chorus" })
    }

    @Test
    fun `metadata tags are ignored in timed mode`() {
        val lines = LyricParser.parse("[ti:Song Title]\n[ar:Artist]\n[00:01.00]line")
        assertEquals(1, lines.size)
        assertEquals("line", lines[0].text)
    }

    @Test
    fun `offset shifts every timestamp and clamps at zero`() {
        assertEquals(9_500L, LyricParser.parse("[offset:+500]\n[00:10.00]line")[0].timeMs)
        assertEquals(10_200L, LyricParser.parse("[offset:-200]\n[00:10.00]line")[0].timeMs)
        assertEquals(0L, LyricParser.parse("[offset:+99999]\n[00:01.00]line")[0].timeMs)
    }

    @Test
    fun `seconds over 59 are rejected`() {
        val lines = LyricParser.parse("[00:65.00]bad\n[00:00.20]ok")
        assertEquals(1, lines.size)
        assertEquals("ok", lines[0].text)
    }

    @Test
    fun `fraction digits scale to milliseconds`() {
        val lines = LyricParser.parse("[01:02.3]a\n[01:02.34]b\n[01:02.345]c")
        assertEquals(listOf(62_300L, 62_340L, 62_345L), lines.map { it.timeMs })
    }

    @Test
    fun `plain text fallback keeps trimmed non blank rows`() {
        val lines = LyricParser.parse("first line\n\n  second line  \n")
        assertEquals(2, lines.size)
        assertNull(lines[0].timeMs)
        assertEquals("first line", lines[0].text)
        assertEquals("second line", lines[1].text)
        assertFalse(LyricParser.isTimed(lines))
    }

    @Test
    fun `metadata only text parses to empty`() {
        assertTrue(LyricParser.parse("[ti:Song]\n[ar:Artist]").isEmpty())
    }

    @Test
    fun `blank or null input yields empty list`() {
        assertTrue(LyricParser.parse(null).isEmpty())
        assertTrue(LyricParser.parse("   \n ").isEmpty())
    }

    @Test
    fun `activeIndex follows playback position`() {
        val lines = LyricParser.parse("[00:01.00]a\n[00:05.00]b\n[00:09.00]c")
        assertEquals(-1, LyricParser.activeIndex(lines, 500))
        assertEquals(0, LyricParser.activeIndex(lines, 1_000))
        assertEquals(1, LyricParser.activeIndex(lines, 5_000))
        assertEquals(1, LyricParser.activeIndex(lines, 7_999))
        assertEquals(2, LyricParser.activeIndex(lines, 60_000))
    }

    @Test
    fun `activeIndex on plain text is always -1`() {
        val lines = LyricParser.parse("a\nb")
        assertEquals(-1, LyricParser.activeIndex(lines, 0))
        assertEquals(-1, LyricParser.activeIndex(lines, 99_999))
    }

    @Test
    fun `decodeText handles utf8 gbk and bom`() {
        assertEquals("中文歌词", LyricParser.decodeText("中文歌词".toByteArray(Charsets.UTF_8)))
        assertEquals("中文歌词", LyricParser.decodeText("中文歌词".toByteArray(Charset.forName("GBK"))))
        assertEquals("第一句", LyricParser.decodeText("﻿第一句".toByteArray(Charsets.UTF_8)))
    }
}
