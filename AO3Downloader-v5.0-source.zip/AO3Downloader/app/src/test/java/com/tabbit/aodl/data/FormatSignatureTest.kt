package com.tabbit.aodl.data

import com.tabbit.aodl.model.DownloadFormat
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 头部魔数校验的离线断言（v4.2 修复 #2）。
 *
 * 用户实测「PDF 打开都是坏的」的一条可复现路径：受限作品 / 登录失效 / 链路被拦截时，
 * 服务端或中间设备返回一段 HTML 提示页，旧实现照单全收并重命名成 `.pdf`。
 * 这里断言：内容不对时 [FormatSignature.check] 一定给出失败原因，正常内容一律放行。
 */
class FormatSignatureTest {

    /** 构造一段 [FormatSignature.HEAD_BYTES] 长度的头部字节。 */
    private fun head(vararg parts: ByteArray): ByteArray {
        val bytes = ByteArray(FormatSignature.HEAD_BYTES)
        var offset = 0
        parts.forEach { part ->
            System.arraycopy(part, 0, bytes, offset, minOf(part.size, bytes.size - offset))
            offset += part.size
        }
        return bytes
    }

    private fun ascii(text: String): ByteArray = text.toByteArray(Charsets.US_ASCII)

    private fun check(format: DownloadFormat, bytes: ByteArray, length: Int = bytes.size) =
        FormatSignature.check(format, bytes, length)

    // -------------------------------------------------------------------- PDF

    @Test
    fun `accepts a real pdf header`() {
        val bytes = head(ascii("%PDF-1.7\n%\u00e2\u00e3\u00cf\u00d3\n1 0 obj"))
        assertNull(check(DownloadFormat.PDF, bytes))
    }

    @Test
    fun `rejects an html page served in place of a pdf`() {
        // 正是用户遇到的情形：登录页 / 拦截页被当成 PDF 存下来
        val bytes = head(ascii("<!DOCTYPE html><html><head><title>Sign in</title>"))
        assertNotNull(check(DownloadFormat.PDF, bytes))
    }

    @Test
    fun `rejects a truncated pdf header`() {
        val bytes = ascii("%PD")
        assertNotNull("头部不足 4 字节时不能判为合法 PDF", check(DownloadFormat.PDF, bytes, 3))
    }

    @Test
    fun `rejects an empty pdf response`() {
        assertNotNull(check(DownloadFormat.PDF, ByteArray(FormatSignature.HEAD_BYTES), 0))
    }

    // ------------------------------------------------------------------- HTML

    @Test
    fun `accepts html starting with a tag`() {
        assertNull(check(DownloadFormat.HTML, head(ascii("<!DOCTYPE html>\n<html>"))))
        assertNull(check(DownloadFormat.HTML, head(ascii("<html><body>正文</body></html>"))))
    }

    @Test
    fun `accepts html with a bom and leading whitespace`() {
        val bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
        assertNull(check(DownloadFormat.HTML, head(bom, ascii("\n  \t<html>"))))
    }

    @Test
    fun `rejects binary content served in place of html`() {
        assertNotNull(check(DownloadFormat.HTML, head(ascii("%PDF-1.7"))))
        assertNotNull(check(DownloadFormat.HTML, head(ascii("BOOKMOBI"))))
    }

    @Test
    fun `rejects a blank response for html`() {
        assertNotNull(check(DownloadFormat.HTML, head(ascii("   \n\t "))))
    }

    // ------------------------------------------------------------------- EPUB

    @Test
    fun `accepts an epub zip container`() {
        val zip = byteArrayOf(0x50, 0x4B, 0x03, 0x04)
        assertNull(check(DownloadFormat.EPUB, head(zip, ascii("mimetypeapplication/epub+zip"))))
    }

    @Test
    fun `rejects a pdf served in place of an epub`() {
        assertNotNull(check(DownloadFormat.EPUB, head(ascii("%PDF-1.7"))))
    }

    // ------------------------------------------------------------- MOBI / AZW3

    @Test
    fun `accepts mobi and azw3 with the palmdb magic at offset 60`() {
        val bytes = ByteArray(FormatSignature.HEAD_BYTES)
        System.arraycopy(ascii("BOOKMOBI"), 0, bytes, 60, 8)
        assertNull(check(DownloadFormat.MOBI, bytes))
        assertNull(check(DownloadFormat.AZW3, bytes))
    }

    @Test
    fun `rejects mobi whose magic is not at offset 60`() {
        val bytes = ByteArray(FormatSignature.HEAD_BYTES)
        System.arraycopy(ascii("BOOKMOBI"), 0, bytes, 0, 8)
        assertNotNull(check(DownloadFormat.MOBI, bytes))
        assertNotNull(check(DownloadFormat.AZW3, bytes))
    }

    @Test
    fun `rejects mobi when fewer than 68 bytes arrived`() {
        val bytes = ByteArray(FormatSignature.HEAD_BYTES)
        System.arraycopy(ascii("BOOKMOBI"), 0, bytes, 60, 8)
        assertNotNull("响应被截断时不能判为合法 MOBI", check(DownloadFormat.MOBI, bytes, 40))
    }

    // ----------------------------------------------------------------- 描述文案

    @Test
    fun `every format has a human readable expectation`() {
        DownloadFormat.values().forEach { format ->
            assertTrue(
                "$format 缺少可读的头部描述",
                FormatSignature.expectation(format).isNotBlank()
            )
        }
        assertEquals("%PDF 文件头", FormatSignature.expectation(DownloadFormat.PDF))
    }

    @Test
    fun `head bytes cover the deepest magic offset`() {
        assertTrue(FormatSignature.HEAD_BYTES >= 68)
    }
}
