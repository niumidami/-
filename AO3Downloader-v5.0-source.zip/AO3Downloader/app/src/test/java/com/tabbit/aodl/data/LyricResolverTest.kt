package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** [LyricResolver] 的离线规则测试：同名歌词与封面的匹配优先级。 */
class LyricResolverTest {

    @Test
    fun `same base lrc matched case insensitively`() {
        val siblings = listOf("Song.LRC", "other.txt")
        assertEquals("Song.LRC", LyricResolver.findExternalLyric("song.mp3", siblings))
    }

    @Test
    fun `lyric requires matching base name`() {
        assertNull(LyricResolver.findExternalLyric("song.mp3", listOf("other.lrc")))
        assertNull(LyricResolver.findExternalLyric("song.mp3", listOf("song.jpg")))
    }

    @Test
    fun `lyric extension must be complete`() {
        assertNull(LyricResolver.findExternalLyric("song.mp3", listOf("song.lrc.bak")))
    }

    @Test
    fun `same base cover wins over generic names`() {
        val siblings = listOf("cover.jpg", "song.png")
        assertEquals("song.png", LyricResolver.findExternalCover("song.flac", siblings))
    }

    @Test
    fun `generic cover names follow priority order`() {
        val siblings = listOf("album.jpg", "folder.jpg", "cover.jpg")
        assertEquals("cover.jpg", LyricResolver.findExternalCover("song.flac", siblings))
        assertEquals("folder.jpg", LyricResolver.findExternalCover("song.flac", siblings - "cover.jpg"))
        assertEquals("album.jpg", LyricResolver.findExternalCover("song.flac", siblings - "cover.jpg" - "folder.jpg"))
    }

    @Test
    fun `generic cover matching is case insensitive and deterministic`() {
        val siblings = listOf("COVER.PNG", "cover.jpg")
        assertEquals("COVER.PNG", LyricResolver.findExternalCover("a.mp3", siblings))
    }

    @Test
    fun `cover without image file returns null`() {
        assertNull(LyricResolver.findExternalCover("song.flac", listOf("song.lrc", "notes.txt")))
        assertNull(LyricResolver.findExternalCover("song.flac", listOf("coverjpg")))
    }
}
