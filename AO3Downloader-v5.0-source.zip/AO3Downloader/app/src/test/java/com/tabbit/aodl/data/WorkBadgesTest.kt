package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 作品卡片「分级预警四徽章」映射规则的离线断言（neos 主题移植）。
 *
 * 符号约定与 AO3 站点图标一致：分级用字母（G/T/M/E/NR），预警用感叹号变体，
 * 分类用性别符号 + 双向箭头，完结用对勾；颜色取 neos「Charcoal × Rose」色板，
 * 全部为纯常量断言，不依赖 Android 与网络。
 */
class WorkBadgesTest {

    @Test
    fun `rating maps to ao3 letter symbols with neos icon colors`() {
        assertEquals(WorkBadges.Badge("E", 0xFFC93B6A, "Explicit"), WorkBadges.ratingBadge("Explicit"))
        assertEquals(WorkBadges.Badge("M", 0xFFD96AA9, "Mature"), WorkBadges.ratingBadge("Mature"))
        assertEquals(
            WorkBadges.Badge("T", 0xFFF59DB3, "Teen And Up Audiences"),
            WorkBadges.ratingBadge("Teen And Up Audiences")
        )
        assertEquals(
            WorkBadges.Badge("G", 0xFFFFABDF, "General Audiences"),
            WorkBadges.ratingBadge("General Audiences")
        )
        assertEquals(WorkBadges.Badge("NR", 0xFFAB6F7D, "Not Rated"), WorkBadges.ratingBadge("Not Rated"))
    }

    @Test
    fun `rating falls back to NR for blank or unknown text`() {
        assertEquals("NR", WorkBadges.ratingBadge("").symbol)
        assertEquals("NR", WorkBadges.ratingBadge("something else").symbol)
        // 空文本时 label 给出可读的默认描述，无障碍不会读到空串
        assertEquals("Not Rated", WorkBadges.ratingBadge("").label)
    }

    @Test
    fun `warnings map to exclamation variants`() {
        // 有具体预警内容 → "!"，且用 explicit 的图标色
        val applies = WorkBadges.warningBadge("Graphic Depictions Of Violence")
        assertEquals("!", applies.symbol)
        assertEquals(0xFFC93B6A, applies.color)
        assertEquals("Graphic Depictions Of Violence", applies.label)

        // 作者选择不使用预警 → "!?"（参考图一的第二个徽章）
        val choseNot = WorkBadges.warningBadge("Creator Chose Not To Use Archive Warnings")
        assertEquals("!?", choseNot.symbol)
        assertEquals(0xFFD96AA9, choseNot.color)

        // 明确无预警 → "✓"；站点没给出 → "?"
        assertEquals("✓", WorkBadges.warningBadge("No Archive Warnings Apply").symbol)
        assertEquals("?", WorkBadges.warningBadge("").symbol)
    }

    @Test
    fun `categories map to gender arrow symbols with neos category colors`() {
        val mm = WorkBadges.categoryBadge("M/M")
        assertEquals("♂↔♂", mm.symbol)
        assertEquals(0xFFF59DB3, mm.color)

        val ff = WorkBadges.categoryBadge("F/F")
        assertEquals("♀↔♀", ff.symbol)
        assertEquals(0xFFC93B6A, ff.color)

        val fm = WorkBadges.categoryBadge("F/M")
        assertEquals("♀↔♂", fm.symbol)
        assertEquals(0xFFD96AA9, fm.color)

        assertEquals("○", WorkBadges.categoryBadge("Gen").symbol)
        assertEquals("✦", WorkBadges.categoryBadge("Multi").symbol)
        assertEquals("✱", WorkBadges.categoryBadge("Other").symbol)
        assertEquals("?", WorkBadges.categoryBadge("").symbol)
        assertEquals("No category", WorkBadges.categoryBadge("").label)
    }

    @Test
    fun `completion maps to check or ellipsis`() {
        val complete = WorkBadges.completionBadge("Complete Work")
        assertEquals("✓", complete.symbol)
        assertEquals(0xFFFFABDF, complete.color)

        val wip = WorkBadges.completionBadge("Work in Progress")
        assertEquals("…", wip.symbol)
        assertEquals(0xFFC93B6A, wip.color)
    }

    @Test
    fun `tag palette constants match the neos charcoal rose skin`() {
        // 与 refs/neos_theme_charcoal-rose.css 的 --tag-* 变量逐值对应
        assertEquals(0x59AB6F7D, WorkBadges.TAG_BORDER)
        assertEquals(0xFFD3C5C8, WorkBadges.TAG_TEXT)
        assertEquals(0xFFC93B6A, WorkBadges.TAG_BG_WARNING)
        assertEquals(0xFFD96AA9, WorkBadges.TAG_BG_RELATIONSHIP)
        assertEquals(0xFF111111, WorkBadges.TAG_TEXT_DARK)
        assertEquals(0xFFE077AC, WorkBadges.TAG_TEXT_CHARACTER)
        assertEquals(0xFFFFB3D8, WorkBadges.TAG_TEXT_FREEFORM)
    }

    @Test
    fun `fourBadges always returns exactly four in rating warning category completion order`() {
        val badges = WorkBadges.fourBadges(
            rating = "Explicit",
            warnings = "No Archive Warnings Apply",
            categories = "F/M",
            completion = "Complete Work"
        )
        assertEquals(4, badges.size)
        assertEquals(listOf("E", "✓", "♀↔♂", "✓"), badges.map { it.symbol })
    }

    @Test
    fun `fourBadges keeps all four slots with fallback badges when fields are missing`() {
        // 站点永远渲染四个符号位，卡片缺值也必须给兜底徽章而不是省略（S6 硬规则）
        val badges = WorkBadges.fourBadges("", "", "", "")
        assertEquals(4, badges.size)
        assertEquals(listOf("NR", "?", "?", "…"), badges.map { it.symbol })
        badges.forEach { badge -> assertTrue(badge.symbol.isNotBlank()) }

        // 站点缺分类时给 "No category" 文案，同样落到 "?" 兜底徽章
        assertEquals("?", WorkBadges.categoryBadge("No category").symbol)
    }

    @Test
    fun `badge symbols never exceed three glyphs so the 20dp square stays readable`() {
        listOf(
            WorkBadges.ratingBadge("Explicit"),
            WorkBadges.warningBadge("Graphic Depictions Of Violence"),
            WorkBadges.warningBadge("Creator Chose Not To Use Archive Warnings"),
            WorkBadges.categoryBadge("F/M"),
            WorkBadges.completionBadge("Work in Progress")
        ).forEach { badge ->
            assertTrue(badge.symbol.isNotBlank())
            assertTrue(badge.symbol.length <= 3)
        }
    }
}
