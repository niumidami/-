package com.tabbit.aodl.data

import com.tabbit.aodl.model.ShelfBook
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 书架/历史/书签落盘序列化的离线断言（v5.0 新增 2）。
 *
 * 重点覆盖三件事：往返无损、脏字符（分隔符 / 换行 / 反斜杠 / 控制字符）不破坏分帧、
 * 以及坏数据只丢单条而不连坐整份。
 */
class ShelfStoreTest {

    private fun book(
        id: String,
        title: String = "标题$id",
        authors: String = "作者$id",
        tags: String = "Fantasy",
        chapters: String = "3/15",
        read: Int = 0,
        group: String = "",
        addedAt: Long = 1000L,
        restricted: Boolean = false
    ) = ShelfBook(
        workId = id,
        title = title,
        authors = authors,
        tags = tags,
        chapters = chapters,
        readChapters = read,
        updated = "2026-10-25",
        group = group,
        addedAt = addedAt,
        restricted = restricted
    )

    @Test
    fun `round trip keeps every field`() {
        val books = listOf(
            book("123456", read = 9, group = "追更", restricted = true),
            book("7890", title = "只读了一章", chapters = "1/?", read = 1)
        )
        val decoded = ShelfStore.decode(ShelfStore.encode(books))
        assertEquals(books, decoded)
    }

    @Test
    fun `empty or null input decodes to empty list`() {
        assertTrue(ShelfStore.decode(null).isEmpty())
        assertTrue(ShelfStore.decode("").isEmpty())
        assertTrue(ShelfStore.decode("   ").isEmpty())
    }

    @Test
    fun `encode drops blank ids`() {
        assertEquals("", ShelfStore.encode(listOf(book(""), book("   "))))
    }

    @Test
    fun `separators and newlines inside fields survive`() {
        val tricky = book(
            "42",
            title = "标题|带竖线\n还带换行\\反斜杠",
            authors = "a|b",
            tags = "tag\u001F控制符"
        )
        val encoded = ShelfStore.encode(listOf(tricky, book("43")))
        // 行分隔符只用于分帧：两条记录编码后应当只有一行分隔
        assertEquals(1, encoded.count { it == '\n' })
        val decoded = ShelfStore.decode(encoded)
        assertEquals(2, decoded.size)
        assertEquals(tricky, decoded[0])
    }

    @Test
    fun `broken row is dropped without losing the rest`() {
        val good = book("100")
        val raw = ShelfStore.encode(listOf(good)) + "\n只有一段坏数据\n" + ShelfStore.encode(listOf(book("200")))
        val decoded = ShelfStore.decode(raw)
        assertEquals(listOf("100", "200"), decoded.map { it.workId })
    }

    @Test
    fun `numeric fields fall back to defaults when unparsable`() {
        val decoded = ShelfStore.decode("id123|title|author|tags|3/15|abc|updated|group|notanumber|0")
        assertEquals(1, decoded.size)
        assertEquals(0, decoded[0].readChapters)
        assertEquals(0L, decoded[0].addedAt)
    }

    @Test
    fun `restricted flag is preserved`() {
        val decoded = ShelfStore.decode(ShelfStore.encode(listOf(book("9", restricted = true))))
        assertTrue(decoded[0].restricted)
        assertEquals(false, ShelfStore.decode(ShelfStore.encode(listOf(book("9"))))[0].restricted)
    }

    @Test
    fun `field count grows safely via defaults`() {
        // 只有 9 个字段的旧行按坏行丢弃，避免把错位数据当成正确字段
        val shortRow = "1|t|a|tags|3/15|2|upd|grp|1000"
        assertTrue(ShelfStore.decode(shortRow).isEmpty())
    }
}