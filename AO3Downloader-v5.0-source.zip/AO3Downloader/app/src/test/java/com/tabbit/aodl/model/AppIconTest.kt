package com.tabbit.aodl.model

import com.tabbit.aodl.R
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * v4.5 启动闪退修复的防回归测试。
 *
 * v4.3 根因：`ic_launcher` 被换成 `drawable-anydpi-v26` 下的 `<adaptive-icon>` XML，
 * 而应用内图标位用 Compose `painterResource` 渲染它——该 API 只支持矢量与位图，
 * 遇到自适应图标会在首帧抛 IllegalArgumentException，API ≥ 26 打开即闪退。
 *
 * 修复策略：应用内渲染一律走 [AppIcon.logoRes]（默认款为纯位图 `ic_logo_sakura`），
 * 与桌面启动器使用的 `ic_launcher`（自适应图标）彻底分离。以下用例锁定这一分离
 * 不被未来的改动悄悄破坏。
 */
class AppIconTest {

    @Test
    fun sakuraLogo_isSeparateFromLauncherAdaptiveIcon() {
        // 默认款的应用内 logo 必须不再是 ic_launcher（后者在 v26+ 解析为 adaptive-icon）。
        assertNotEquals(AppIcon.SAKURA.drawableRes, AppIcon.SAKURA.logoRes)
        assertNotEquals(R.drawable.ic_launcher, AppIcon.SAKURA.logoRes)
        assertEquals(R.drawable.ic_launcher, AppIcon.SAKURA.drawableRes)
    }

    @Test
    fun allIcons_haveDistinctLogoResources() {
        val logos = AppIcon.entries.map { it.logoRes }
        assertEquals(logos.size, logos.toSet().size)
    }

    @Test
    fun sakuraLogo_isPngInEveryDensity() {
        val res = resDir()
        val densities = listOf("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi")
        for (density in densities) {
            val png = File(res, "drawable-$density/ic_logo_sakura.png")
            assertTrue("缺少 drawable-$density/ic_logo_sakura.png", png.isFile)
            // PNG 魔数：89 50 4E 47
            png.inputStream().use { input ->
                val magic = ByteArray(4)
                assertEquals(4, input.read(magic))
                assertEquals("ic_logo_sakura 必须是位图 PNG", "89504e47", magic.toHex())
            }
        }
    }

    @Test
    fun noLogoResource_isAdaptiveIconXml() {
        val res = resDir()
        // 应用内 logo 资源名下不允许出现任何 XML 形态（尤其是 <adaptive-icon>）。
        val offenders = res.walkTopDown()
            .filter { it.isFile && it.name.startsWith("ic_logo_") && it.extension == "xml" }
            .toList()
        assertTrue("应用内 logo 资源不得使用 XML/adaptive-icon：$offenders", offenders.isEmpty())
    }

    @Test
    fun launcherIcon_remainsAdaptiveForHomeScreen() {
        // 对照组：桌面启动器图标继续走 adaptive-icon（系统渲染，不进 Compose）。
        val xml = File(resDir(), "drawable-anydpi-v26/ic_launcher.xml")
        assertTrue("桌面图标应保留自适应图标 XML", xml.isFile)
        assertTrue(xml.readText().contains("adaptive-icon"))
    }

    /** Gradle 单元测试的工作目录是模块目录（app/）。 */
    private fun resDir(): File = File(System.getProperty("user.dir"), "src/main/res")

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
}
