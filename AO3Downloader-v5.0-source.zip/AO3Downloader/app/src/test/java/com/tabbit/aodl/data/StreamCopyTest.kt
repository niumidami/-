package com.tabbit.aodl.data

import com.tabbit.aodl.model.DownloadFormat
import okio.Buffer
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.IOException

/**
 * 流式写盘与完整性校验的离线断言（v4.2 修复 #2）。
 *
 * 断言三件事，正对应用户实测的两个缺陷：
 * 1. **落盘字节与响应体逐字节一致**（不多不少、不错位）；
 * 2. **响应体被提前结束时判为失败**，绝不会被当成"下载成功"重命名成正式文件
 *    —— 这是「PDF 打开都是坏的」的直接成因；
 * 3. **内容根本不是该格式时立刻中止**（登录页 / 拦截页冒充 PDF），且一个字节都不落盘。
 */
class StreamCopyTest {

    /** 生成一段以 [prefix] 开头、内容确定可复现的载荷。 */
    private fun payload(size: Int, prefix: String): ByteArray {
        val bytes = ByteArray(size)
        val head = prefix.toByteArray(Charsets.US_ASCII)
        System.arraycopy(head, 0, bytes, 0, minOf(head.size, size))
        var seed = 20261024
        for (index in head.size until size) {
            seed = (seed * 1103515245 + 12345) and 0x7FFFFFFF
            bytes[index] = (seed % 251 + 1).toByte()
        }
        return bytes
    }

    private fun pdfPayload(size: Int): ByteArray = payload(size, "%PDF-1.7\n%\u00e2\u00e3\u00cf\u00d3\n")

    private fun source(bytes: ByteArray) = Buffer().apply { write(bytes) }

    // --------------------------------------------------------- 落盘字节一致性

    @Test
    fun `writes the response body byte for byte`() {
        val body = pdfPayload(200_000)
        val out = ByteArrayOutputStream()

        val result = StreamCopy.copy(source(body), out, body.size.toLong(), 0L, DownloadFormat.PDF)

        assertTrue("完整响应必须判为成功，实际：$result", result is CopyResult.Ok)
        assertEquals(body.size.toLong(), (result as CopyResult.Ok).bytes)
        assertArrayEquals("落盘字节必须与响应体完全一致", body, out.toByteArray())
    }

    @Test
    fun `writes a small body byte for byte`() {
        val body = pdfPayload(FormatSignature.HEAD_BYTES + 1)
        val out = ByteArrayOutputStream()

        val result = StreamCopy.copy(source(body), out, body.size.toLong(), 0L, DownloadFormat.PDF)

        assertTrue(result is CopyResult.Ok)
        assertArrayEquals(body, out.toByteArray())
    }

    @Test
    fun `reports progress up to the declared total`() {
        val body = pdfPayload(200_000)
        val reports = ArrayList<Pair<Long, Long>>()

        StreamCopy.copy(source(body), ByteArrayOutputStream(), body.size.toLong(), 0L, DownloadFormat.PDF) {
                written, total, _ ->
            reports += written to total
            true
        }

        assertTrue("应至少上报一次进度", reports.isNotEmpty())
        assertEquals("最后一次进度必须正好等于完整大小", body.size.toLong(), reports.last().first)
        assertEquals(body.size.toLong(), reports.last().second)
        assertTrue("进度必须单调不回退", reports.map { it.first }.zipWithNext().all { (a, b) -> b >= a })
    }

    // ------------------------------------------------------------- 截断判失败

    @Test
    fun `a truncated response is not reported as success`() {
        // 服务端声明 100000 字节，实际只送来 60000（链路被优雅地提前收尾）
        val declared = 100_000L
        val body = pdfPayload(60_000)
        val out = ByteArrayOutputStream()

        val result = StreamCopy.copy(source(body), out, declared, 0L, DownloadFormat.PDF)

        assertTrue("残缺响应必须判为 INCOMPLETE，实际：$result", result is CopyResult.Err)
        val err = result as CopyResult.Err
        assertEquals(CopyError.INCOMPLETE, err.reason)
        assertTrue(err.detail.contains("expected=$declared"))
        assertTrue(err.detail.contains("got=${body.size}"))
    }

    @Test
    fun `an over long response is not reported as success either`() {
        val body = pdfPayload(20_000)

        val result = StreamCopy.copy(source(body), ByteArrayOutputStream(), 10_000L, 0L, DownloadFormat.PDF)

        assertTrue(result is CopyResult.Err)
        assertEquals(CopyError.INCOMPLETE, (result as CopyResult.Err).reason)
    }

    @Test
    fun `an empty body for a declared size is incomplete`() {
        val result = StreamCopy.copy(source(ByteArray(0)), ByteArrayOutputStream(), 4096L, 0L, DownloadFormat.PDF)

        assertTrue(result is CopyResult.Err)
        assertEquals(CopyError.INCOMPLETE, (result as CopyResult.Err).reason)
    }

    @Test
    fun `chunked responses without a declared length are accepted as they are`() {
        // totalLength <= 0 表示服务端未声明长度（chunked），此时无法比对总长，按实际写入返回
        val body = pdfPayload(5_000)
        val out = ByteArrayOutputStream()

        val result = StreamCopy.copy(source(body), out, -1L, 0L, DownloadFormat.PDF)

        assertTrue(result is CopyResult.Ok)
        assertEquals(body.size.toLong(), (result as CopyResult.Ok).bytes)
        assertArrayEquals(body, out.toByteArray())
    }

    // --------------------------------------------------------- 内容不符判失败

    @Test
    fun `an html page served in place of a pdf is rejected before anything is written`() {
        val html = payload(8_000, "<!DOCTYPE html><html><head><title>Sign in</title>")
        val out = ByteArrayOutputStream()

        val result = StreamCopy.copy(source(html), out, html.size.toLong(), 0L, DownloadFormat.PDF)

        assertTrue("提示页冒充 PDF 必须判为 INVALID_CONTENT，实际：$result", result is CopyResult.Err)
        assertEquals(CopyError.INVALID_CONTENT, (result as CopyResult.Err).reason)
        assertEquals("非法内容一个字节都不该落盘", 0, out.size())
    }

    @Test
    fun `a short error page is rejected too`() {
        // 不足 68 字节的错误响应在读完后再补一次头部校验
        val body = "Access denied".toByteArray(Charsets.US_ASCII)

        val result = StreamCopy.copy(source(body), ByteArrayOutputStream(), -1L, 0L, DownloadFormat.PDF)

        assertTrue(result is CopyResult.Err)
        assertEquals(CopyError.INVALID_CONTENT, (result as CopyResult.Err).reason)
    }

    @Test
    fun `format specific magic numbers are enforced`() {
        val epubBody = payload(4_000, "PK\u0003\u0004mimetypeapplication/epub+zip")
        val out = ByteArrayOutputStream()
        val ok = StreamCopy.copy(source(epubBody), out, epubBody.size.toLong(), 0L, DownloadFormat.EPUB)
        assertTrue(ok is CopyResult.Ok)
        assertArrayEquals(epubBody, out.toByteArray())

        val wrong = StreamCopy.copy(
            source(payload(4_000, "%PDF-1.7")),
            ByteArrayOutputStream(),
            4_000L,
            0L,
            DownloadFormat.EPUB
        )
        assertTrue(wrong is CopyResult.Err)
        assertEquals(CopyError.INVALID_CONTENT, (wrong as CopyResult.Err).reason)
    }

    @Test
    fun `skipping the format check keeps the length check`() {
        val body = payload(4_000, "anything at all")

        val ok = StreamCopy.copy(source(body), ByteArrayOutputStream(), body.size.toLong(), 0L, null)
        assertTrue(ok is CopyResult.Ok)

        val truncated = StreamCopy.copy(source(body), ByteArrayOutputStream(), 9_000L, 0L, null)
        assertTrue(truncated is CopyResult.Err)
        assertEquals(CopyError.INCOMPLETE, (truncated as CopyResult.Err).reason)
    }

    // ------------------------------------------------------------------- 续传

    @Test
    fun `resume skips the head check and counts the local offset`() {
        val full = pdfPayload(120_000)
        val alreadyOnDisk = 40_000
        val remaining = full.copyOfRange(alreadyOnDisk, full.size)
        val out = ByteArrayOutputStream()
        val reports = ArrayList<Long>()

        val result = StreamCopy.copy(
            source = source(remaining),
            output = out,
            totalLength = full.size.toLong(),
            baseOffset = alreadyOnDisk.toLong(),
            format = DownloadFormat.PDF
        ) { written, total, _ ->
            reports += written
            assertEquals(full.size.toLong(), total)
            true
        }

        assertTrue("续传写入的是文件尾部，不该再校验头部魔数，实际：$result", result is CopyResult.Ok)
        assertEquals(full.size.toLong(), (result as CopyResult.Ok).bytes)
        assertArrayEquals("本次落盘的必须正好是缺失的那一段", remaining, out.toByteArray())
        assertEquals(full.size.toLong(), reports.last())
    }

    @Test
    fun `resume that receives nothing is incomplete`() {
        val result = StreamCopy.copy(
            source = source(ByteArray(0)),
            output = ByteArrayOutputStream(),
            totalLength = 120_000L,
            baseOffset = 40_000L,
            format = DownloadFormat.PDF
        )

        assertTrue(result is CopyResult.Err)
        assertEquals(CopyError.INCOMPLETE, (result as CopyResult.Err).reason)
    }

    // ------------------------------------------------------------------- 取消与 IO

    @Test
    fun `cancellation stops writing and reports what is already on disk`() {
        val body = pdfPayload(300_000)
        val out = ByteArrayOutputStream()
        var calls = 0

        val result = StreamCopy.copy(source(body), out, body.size.toLong(), 0L, DownloadFormat.PDF) { _, _, _ ->
            calls++
            calls < 2
        }

        assertTrue("用户取消必须返回 Cancelled，实际：$result", result is CopyResult.Cancelled)
        val cancelled = result as CopyResult.Cancelled
        assertTrue(cancelled.bytes > 0L)
        assertTrue("取消后不该继续写完整份文件", cancelled.bytes < body.size)
        assertEquals("上报字节数必须等于实际落盘字节数", out.size().toLong(), cancelled.bytes)
    }

    @Test
    fun `io failures are reported as io errors`() {
        val body = pdfPayload(4_000)
        val failing = object : ByteArrayOutputStream() {
            override fun write(buffer: ByteArray, offset: Int, length: Int) {
                throw IOException("disk full")
            }
        }

        val result = StreamCopy.copy(source(body), failing, body.size.toLong(), 0L, DownloadFormat.PDF)

        assertTrue(result is CopyResult.Err)
        val err = result as CopyResult.Err
        assertEquals(CopyError.IO, err.reason)
        assertTrue(err.detail.contains("IOException"))
    }
}
