package com.tabbit.aodl.data

import com.tabbit.aodl.model.BeautifySettings
import com.tabbit.aodl.model.BeautifyStyle
import org.jsoup.Jsoup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 文档版式美化器（v4.4 默认风格）的离线断言。
 *
 * fixture 按 AO3 官方下载模板（downloads/show + _download_preface/_chapter/_afterword）
 * 的结构自造，断言输出与参照文档版式逐项对应：
 * 扉页 / 作品信息（含统计行拆分）/ 前言 / 目录 / 章节（含章末注）/ THE END / 关于页，
 * 以及内置「暗夜樱粉」主题与幂等重跑行为。
 */
class DocBeautifierTest {

    // ------------------------------------------------------------ fixtures

    /** 多章作品：2 章 + Summary/Notes + 章元数据 + 章末注 + 作品尾注。 */
    private fun chapteredSource(): String = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>春日信笺 - Tabbit - Archive of Our Own</title></head>
<body>
<div id="preface">
  <h2 class="toc-heading">Preface</h2>
  <p class="message"><b>春日信笺</b><br />Originally posted on <a href="https://archiveofourown.org">Archive of Our Own</a> at <a href="https://archiveofourown.org/works/87654321">https://archiveofourown.org/works/87654321</a>.</p>
  <div class="meta">
    <dl class="tags">
      <dt>Rating:</dt><dd>Teen And Up Audiences</dd>
      <dt>Fandoms:</dt><dd>Original Work</dd>
      <dt>Stats:</dt>
      <dd>
        Published: 2026-10-01
        Updated: 2026-10-20
        Words: 12,480
        Chapters: 2/2
      </dd>
    </dl>
    <h1>春日信笺</h1>
    <div class="byline">by <a href="https://archiveofourown.org/users/tabbit">Tabbit</a></div>
    <p>Summary:</p>
    <blockquote class="userstuff"><p>一段摘要。</p></blockquote>
    <p>Notes:</p>
    <blockquote class="userstuff"><p>一段附言。</p></blockquote>
  </div>
</div>
<div id="chapters" class="userstuff">
  <div class="meta group">
    <h2 class="heading">Chapter 1</h2>
  </div>
  <div class="userstuff"><p>第一章正文，樱花落在站台上。</p></div>
  <div class="meta" id="endnotes1">
    <p>Chapter End Notes:</p>
    <blockquote class="userstuff"><p>第一章末注。</p></blockquote>
  </div>
  <div class="meta group">
    <h2 class="heading">Chapter 2: 档案 243-104-18-6</h2>
    <p>Chapter Summary:</p>
    <blockquote class="userstuff"><p>第二章摘要。</p></blockquote>
  </div>
  <div class="userstuff"><p>第二章正文，影子比来时更长。</p></div>
</div>
<div id="afterword">
  <h2 class="toc-heading">Afterword</h2>
  <div class="meta">
    <div id="endnotes">
      <p>End Notes:</p>
      <blockquote class="userstuff"><p>作品尾注。</p></blockquote>
    </div>
  </div>
</div>
</body>
</html>
""".trimIndent()

    /** 单章作品：#chapters 直接含隐藏标题与正文（官方模板的单章分支）。 */
    private fun singleChapterSource(): String = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>独白 - Tabbit - Archive of Our Own</title></head>
<body>
<div id="preface">
  <div class="meta">
    <dl class="tags"><dt>Rating:</dt><dd>General Audiences</dd></dl>
    <h1>独白</h1>
    <div class="byline">by <a href="https://archiveofourown.org/users/tabbit">Tabbit</a></div>
  </div>
</div>
<div id="chapters" class="userstuff">
  <h2 class="toc-heading">独白</h2>
  <div class="userstuff"><p>唯一一章的正文。</p></div>
</div>
</body>
</html>
""".trimIndent()

    // ------------------------------------------------------------ 结构断言

    @Test
    fun chapteredWork_rendersAllBookSections() {
        val out = DocBeautifier.beautify(chapteredSource())
        val doc = Jsoup.parse(out)

        // 扉页
        val titlePage = doc.selectFirst(".title-page")
        assertNotNull(titlePage)
        assertEquals("春日信笺", titlePage!!.selectFirst("h1")!!.text())
        assertEquals("by Tabbit", titlePage.selectFirst("h2")!!.text())

        // 作品信息页：作者版权行 + 来源 + 标签行
        val imprint = doc.selectFirst(".imprint-page")!!
        assertNotNull(imprint)
        val rows = imprint.select("p").map { it.text() }
        assertTrue(rows.any { it.contains("Original Copyright ©") && it.contains("Tabbit") })
        assertTrue(rows.any { it.contains("Source:") && it.contains("/works/87654321") })
        assertTrue(rows.any { it.startsWith("Rating:") && it.contains("Teen") })
        assertTrue(rows.any { it.startsWith("Fandoms:") && it.contains("Original Work") })
        // 统计行被拆成四个独立「标签: 值」行
        assertTrue(rows.any { it.startsWith("Published:") && it.contains("2026-10-01") })
        assertTrue(rows.any { it.startsWith("Updated:") && it.contains("2026-10-20") })
        assertTrue(rows.any { it.startsWith("Words:") && it.contains("12,480") })
        assertTrue(rows.any { it.startsWith("Chapters:") && it.contains("2/2") })
        assertTrue(rows.any { it.contains("Exported by obkk下载中") })
        // 拆分后不再残留整体 Stats 行
        assertFalse(rows.any { it.startsWith("Stats:") })

        // 前言页：Summary + Notes 两节
        val sections = doc.select(".foreword-section")
        assertEquals(2, sections.size)
        assertEquals("Summary", sections[0].selectFirst("h3")!!.text())
        assertEquals("Notes", sections[1].selectFirst("h3")!!.text())
        assertTrue(sections[0].text().contains("一段摘要。"))

        // 目录页：两项，文案为「第 N 章（标题）」
        val tocItems = doc.select(".toc-list .toc-item a")
        assertEquals(2, tocItems.size)
        assertEquals("第 1 章", tocItems[0].text())
        assertEquals("第 2 章 档案 243-104-18-6", tocItems[1].text())
        assertEquals("#chapter-1", tocItems[0].attr("href"))
        assertEquals("#chapter-2", tocItems[1].attr("href"))

        // 章节页：id、章名、正文保留、第二章元数据、第一章末注、作品尾注
        val ch1 = doc.selectFirst("#chapter-1")!!
        val ch2 = doc.selectFirst("#chapter-2")!!
        assertEquals("第 1 章", ch1.selectFirst("h2")!!.text())
        assertEquals("第 2 章 档案 243-104-18-6", ch2.selectFirst("h2")!!.text())
        assertTrue(ch1.selectFirst(".chapter-text")!!.text().contains("第一章正文"))
        assertTrue(ch2.selectFirst(".chapter-text")!!.text().contains("第二章正文"))
        assertTrue(ch2.selectFirst(".chapter-meta")!!.text().contains("第二章摘要。"))
        val endNotes = doc.select(".chapter-end-notes")
        assertEquals(2, endNotes.size)
        assertTrue(endNotes[0].text().contains("第一章末注。"))
        assertTrue(endNotes[1].text().contains("作品尾注。"))

        // 结尾与关于页
        assertEquals("THE END", doc.selectFirst(".the-end h2")!!.text())
        assertTrue(doc.selectFirst("#about-page")!!.text().contains("obkk下载中"))

        // 结构元素出现且仅出现一次（无重复重建）
        assertEquals(1, doc.select(".content-wrapper").size)
        assertEquals(1, doc.select(".title-page").size)
        assertEquals(1, doc.select(".imprint-page").size)
        assertEquals(1, doc.select(".toc-page").size)
    }

    @Test
    fun themeCss_isEmbeddedAndMatchesReference() {
        val out = DocBeautifier.beautify(chapteredSource())
        val doc = Jsoup.parse(out)
        val theme = doc.selectFirst("style#aodl-doc-theme")
        assertNotNull(theme)
        val css = theme!!.data()
        // 暗夜樱粉主题关键规则逐项在位
        assertTrue(css.contains("#17161a"))
        assertTrue(css.contains(".content-wrapper"))
        assertTrue(css.contains(".title-page"))
        assertTrue(css.contains(".imprint-page"))
        assertTrue(css.contains(".toc-list"))
        assertTrue(css.contains(".chapter-text"))
        assertTrue(css.contains(".the-end"))
        assertTrue(css.contains("text-transform: none !important"))
        assertTrue(css.contains("@media (max-width: 768px)"))
    }

    @Test
    fun customCss_isAppendedAsSeparateBlock() {
        val out = DocBeautifier.beautify(chapteredSource(), "p { color: red; }")
        val doc = Jsoup.parse(out)
        val custom = doc.selectFirst("style#aodl-doc-custom")
        assertNotNull(custom)
        assertTrue(custom!!.data().contains("p { color: red; }"))
        // 自定义块位于主题块之后
        assertTrue(out.indexOf("aodl-doc-theme") < out.indexOf("aodl-doc-custom"))
    }

    @Test
    fun beautify_isIdempotent_onlyStyleBlocksRefresh() {
        val once = DocBeautifier.beautify(chapteredSource(), "p { color: red; }")
        val twice = DocBeautifier.beautify(once, "p { color: blue; }")
        val doc = Jsoup.parse(twice)

        // 结构未被二次重建
        assertEquals(1, doc.select(".content-wrapper").size)
        assertEquals(1, doc.select(".title-page").size)
        assertEquals(2, doc.select(".chapter-page").size)
        // 主题仍在，自定义 CSS 被替换而非追加
        assertTrue(doc.selectFirst("style#aodl-doc-theme")!!.data().contains("#17161a"))
        val custom = doc.selectFirst("style#aodl-doc-custom")!!
        assertTrue(custom.data().contains("blue"))
        assertFalse(custom.data().contains("red"))
        // 再跑一遍传空自定义：自定义块被移除
        val third = DocBeautifier.beautify(twice, "")
        assertNull(Jsoup.parse(third).selectFirst("style#aodl-doc-custom"))
    }

    @Test
    fun singleChapter_rendersOneTocEntry() {
        val out = DocBeautifier.beautify(singleChapterSource())
        val doc = Jsoup.parse(out)
        val items = doc.select(".toc-list .toc-item a")
        assertEquals(1, items.size)
        assertEquals("第 1 章", items[0].text())
        assertTrue(doc.selectFirst("#chapter-1 .chapter-text")!!.text().contains("唯一一章的正文。"))
        assertEquals("独白", doc.selectFirst(".title-page h1")!!.text())
    }

    @Test
    fun genericHtml_fallsBackToSingleChapter() {
        val html = "<!DOCTYPE html><html><head><title>随便一页</title></head>" +
            "<body><p>普通网页正文。</p></body></html>"
        val out = DocBeautifier.beautify(html)
        val doc = Jsoup.parse(out)
        assertEquals(1, doc.select(".content-wrapper").size)
        assertEquals("随便一页", doc.selectFirst(".title-page h1")!!.text())
        assertEquals(1, doc.select(".chapter-page").size)
        assertTrue(doc.selectFirst(".chapter-text")!!.text().contains("普通网页正文。"))
    }

    // ------------------------------------------------------------ 标签与章节名归一化

    @Test
    fun normalizeLabel_mapsKnownLabels() {
        assertEquals("Summary", DocBeautifier.normalizeLabel("Summary:"))
        assertEquals("Summary", DocBeautifier.normalizeLabel("摘要"))
        assertEquals("End Notes", DocBeautifier.normalizeLabel("End Notes:"))
        assertEquals("End Notes", DocBeautifier.normalizeLabel("Chapter End Notes:"))
        assertEquals("Notes", DocBeautifier.normalizeLabel("Notes："))
        assertEquals("自定义", DocBeautifier.normalizeLabel("自定义"))
    }

    @Test
    fun chapterLabel_stripsNumericPrefixes() {
        assertEquals("第 1 章", DocBeautifier.chapterLabel(1, "Chapter 1"))
        assertEquals("第 2 章 站台", DocBeautifier.chapterLabel(2, "Chapter 2: 站台"))
        assertEquals("第 3 章 雨夜", DocBeautifier.chapterLabel(3, "第3章：雨夜"))
        assertEquals("第 1 章", DocBeautifier.chapterLabel(1, ""))
        assertEquals("第 4 章 无编号标题", DocBeautifier.chapterLabel(4, "无编号标题"))
    }

    // ------------------------------------------------------------ HtmlBeautifier 路由

    @Test
    fun htmlBeautifier_routesByStyle() {
        val src = chapteredSource()
        // 默认（DOCUMENT）：重建为书籍版式
        val docOut = HtmlBeautifier.beautify(src, BeautifySettings(), appDark = true)
        assertTrue(docOut.contains("content-wrapper"))
        assertTrue(docOut.contains("aodl-doc-theme"))
        assertFalse(docOut.contains("aodl-beautify"))
        // CLASSIC：保持旧的注入式美化
        val classicOut = HtmlBeautifier.beautify(
            src, BeautifySettings(style = BeautifyStyle.CLASSIC), appDark = true
        )
        assertTrue(classicOut.contains("aodl-beautify"))
        assertFalse(classicOut.contains("content-wrapper"))
    }

    @Test
    fun sampleDocument_passesThroughFullPipeline() {
        val out = HtmlBeautifier.sampleDocument(
            settings = BeautifySettings(),
            appDark = true,
            title = "春日信笺",
            author = "Tabbit",
            notes = "附言示例。",
            metaLine = "",
            summary = "摘要示例。",
            paragraphs = listOf("第一段。", "第二段。")
        )
        val doc = Jsoup.parse(out)
        assertEquals("春日信笺", doc.selectFirst(".title-page h1")!!.text())
        assertEquals("by Tabbit", doc.selectFirst(".title-page h2")!!.text())
        assertEquals(2, doc.select(".chapter-page").size)
        assertTrue(doc.text().contains("第一段。"))
        assertTrue(doc.text().contains("附言示例。"))
    }
}
