package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** [Id3LyricReader] 的离线规则测试：手工构造 ID3v2.3 / v2.4 标签字节验证 USLT 提取。 */
class Id3LyricReaderTest {

    /* ---------------- 字节构造工具 ---------------- */

    private fun synchsafeBytes(value: Int): ByteArray = byteArrayOf(
        (value shr 21 and 0x7F).toByte(),
        (value shr 14 and 0x7F).toByte(),
        (value shr 7 and 0x7F).toByte(),
        (value and 0x7F).toByte()
    )

    private fun be32Bytes(value: Int): ByteArray = byteArrayOf(
        (value shr 24 and 0xFF).toByte(),
        (value shr 16 and 0xFF).toByte(),
        (value shr 8 and 0xFF).toByte(),
        (value and 0xFF).toByte()
    )

    private fun frame(id: String, content: ByteArray, v4: Boolean): ByteArray =
        id.toByteArray(Charsets.ISO_8859_1) +
            (if (v4) synchsafeBytes(content.size) else be32Bytes(content.size)) +
            byteArrayOf(0, 0) +
            content

    /** USLT 帧体：编码字节 + eng + 内容描述终止符 + 歌词正文。 */
    private fun usltContent(text: String, encoding: Int): ByteArray = when (encoding) {
        0 -> byteArrayOf(0) + LANG + byteArrayOf(0) + text.toByteArray(Charsets.ISO_8859_1)
        1 -> byteArrayOf(1) + LANG + byteArrayOf(0, 0) + text.toByteArray(Charsets.UTF_16)
        3 -> byteArrayOf(3) + LANG + byteArrayOf(0) + text.toByteArray(Charsets.UTF_8)
        else -> error("test only supports 0/1/3")
    }

    private fun tag(frames: ByteArray, v4: Boolean, flags: Int = 0): ByteArray =
        "ID3".toByteArray(Charsets.ISO_8859_1) +
            byteArrayOf(if (v4) 4 else 3, 0, flags.toByte()) +
            synchsafeBytes(frames.size) +
            frames

    /* ---------------- 用例 ---------------- */

    @Test
    fun `v2_3 uslt utf8 round trip`() {
        val bytes = tag(frame("USLT", usltContent("hello lyrics 你好", 3), v4 = false), v4 = false)
        assertEquals("hello lyrics 你好", Id3LyricReader.readEmbeddedLyrics(bytes))
    }

    @Test
    fun `v2_4 uslt utf16 with bom round trip`() {
        val bytes = tag(frame("USLT", usltContent("第二行\n第三行", 1), v4 = true), v4 = true)
        assertEquals("第二行\n第三行", Id3LyricReader.readEmbeddedLyrics(bytes))
    }

    @Test
    fun `v2_3 uslt latin1 round trip`() {
        val bytes = tag(frame("USLT", usltContent("café", 0), v4 = false), v4 = false)
        assertEquals("café", Id3LyricReader.readEmbeddedLyrics(bytes))
    }

    @Test
    fun `non lyric frames are skipped`() {
        val tit2 = frame("TIT2", byteArrayOf(3) + "Song".toByteArray(Charsets.UTF_8), v4 = false)
        val bytes = tag(tit2 + frame("USLT", usltContent("words", 3), v4 = false), v4 = false)
        assertEquals("words", Id3LyricReader.readEmbeddedLyrics(bytes))
    }

    @Test
    fun `padding after frames stops the scan`() {
        val bytes = tag(frame("USLT", usltContent("pad", 3), v4 = false) + ByteArray(16), v4 = false)
        assertEquals("pad", Id3LyricReader.readEmbeddedLyrics(bytes))
    }

    @Test
    fun `unsynchronisation removes inserted zero bytes`() {
        // ISO-8859-1 文本 aÿb 含 0xFF；标签体在 0xFF 后补 0x00，帧头仍登记补字节前的大小
        val raw = usltContent("aÿb", 0)
        val synced = mutableListOf<Byte>()
        raw.forEach { b ->
            synced += b
            if (b == 0xFF.toByte()) synced += 0
        }
        val frameBytes = "USLT".toByteArray(Charsets.ISO_8859_1) +
            be32Bytes(raw.size) +
            byteArrayOf(0, 0) +
            synced.toByteArray()
        val bytes = tag(frameBytes, v4 = false, flags = 0x80)
        assertEquals("aÿb", Id3LyricReader.readEmbeddedLyrics(bytes))
    }

    @Test
    fun `missing or malformed tag returns null`() {
        assertNull(Id3LyricReader.readEmbeddedLyrics("not an mp3".toByteArray()))
        assertNull(Id3LyricReader.readEmbeddedLyrics(ByteArray(0)))
        // 标签声明的大小超过可用字节
        val full = tag(frame("USLT", usltContent("hello", 3), v4 = false), v4 = false)
        assertNull(Id3LyricReader.readEmbeddedLyrics(full.copyOf(12)))
        // 只有标题帧没有歌词帧
        val tit2 = frame("TIT2", byteArrayOf(3) + "Song".toByteArray(Charsets.UTF_8), v4 = false)
        assertNull(Id3LyricReader.readEmbeddedLyrics(tag(tit2, v4 = false)))
        // 不支持的版本号
        val v2 = "ID3".toByteArray(Charsets.ISO_8859_1) + byteArrayOf(2, 0, 0) + synchsafeBytes(4) + ByteArray(4)
        assertNull(Id3LyricReader.readEmbeddedLyrics(v2))
    }

    private companion object {
        val LANG = "eng".toByteArray(Charsets.ISO_8859_1)
    }
}
