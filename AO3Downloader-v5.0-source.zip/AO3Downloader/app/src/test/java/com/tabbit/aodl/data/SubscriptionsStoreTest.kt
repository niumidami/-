package com.tabbit.aodl.data

import com.tabbit.aodl.model.SubscribedAuthor
import com.tabbit.aodl.model.WorkItem
import com.tabbit.aodl.model.WorkKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 「我的订阅」本地名单的离线断言（v5.1 快捷入口改造）。
 *
 * 订阅的作品连卡片字段一起落盘（24 列），这里验证：编解码往返字段不丢、
 * 按编号去重、作者忽略大小写、坏行丢弃、上限截断。
 */
class SubscriptionsStoreTest {

    private fun sampleWork(id: String) = WorkItem(
        id = id,
        title = "Title $id",
        authors = "alice, bob",
        words = "12,345",
        chapters = "3/10",
        updated = "2025-01-02",
        fandoms = "Fandom A, Fandom B",
        tags = "tag1, tag2",
        language = "中文",
        restricted = true,
        kind = WorkKind.WORK,
        rating = "Mature",
        archiveWarnings = "No Archive Warnings Apply",
        categories = "M/M",
        completion = "Work in Progress",
        warningTags = listOf("Major Character Death"),
        relationshipTags = listOf("A/B", "C & D"),
        characterTags = listOf("Alice", "Bob"),
        freeformTags = listOf("Time Travel", "Fluff"),
        summary = "多段简介\n第二段",
        comments = "12",
        kudos = "1,234",
        bookmarks = "56",
        hits = "7,890"
    )

    // ------------------------------------------------------------ 订阅的作品

    @Test
    fun `work encode decode round trip keeps every card field`() {
        val works = listOf(sampleWork("100"), sampleWork("200"))
        val decoded = SubscriptionsStore.decodeWorks(SubscriptionsStore.encodeWorks(works))
        assertEquals(2, decoded.size)
        val first = decoded.first()
        val source = works.first().copy(selected = false)
        assertEquals(source.id, first.id)
        assertEquals(source.title, first.title)
        assertEquals(source.authors, first.authors)
        assertEquals(source.words, first.words)
        assertEquals(source.chapters, first.chapters)
        assertEquals(source.updated, first.updated)
        assertEquals(source.fandoms, first.fandoms)
        assertEquals(source.tags, first.tags)
        assertEquals(source.language, first.language)
        assertEquals(source.restricted, first.restricted)
        assertEquals(source.kind, first.kind)
        assertEquals(source.rating, first.rating)
        assertEquals(source.archiveWarnings, first.archiveWarnings)
        assertEquals(source.categories, first.categories)
        assertEquals(source.completion, first.completion)
        assertEquals(source.warningTags, first.warningTags)
        assertEquals(source.relationshipTags, first.relationshipTags)
        assertEquals(source.characterTags, first.characterTags)
        assertEquals(source.freeformTags, first.freeformTags)
        assertEquals(source.summary, first.summary)
        assertEquals(source.comments, first.comments)
        assertEquals(source.kudos, first.kudos)
        assertEquals(source.bookmarks, first.bookmarks)
        assertEquals(source.hits, first.hits)
    }

    @Test
    fun `add work dedupes by id and clears selection flag`() {
        val base = listOf(sampleWork("100"))
        val again = SubscriptionsStore.addWork(base, sampleWork("100"))
        assertEquals(1, again.size)
        val added = SubscriptionsStore.addWork(base, sampleWork("200").copy(selected = true))
        assertEquals(2, added.size)
        assertFalse(added.last().selected)
    }

    @Test
    fun `toggle work subscribes then unsubscribes`() {
        val empty = emptyList<WorkItem>()
        val once = SubscriptionsStore.toggleWork(empty, sampleWork("100"))
        assertTrue(SubscriptionsStore.containsWork(once, "100"))
        val twice = SubscriptionsStore.toggleWork(once, sampleWork("100"))
        assertFalse(SubscriptionsStore.containsWork(twice, "100"))
    }

    @Test
    fun `remove work by id ignores spaces`() {
        val base = listOf(sampleWork("100"), sampleWork("200"))
        val updated = SubscriptionsStore.removeWork(base, " 100 ")
        assertEquals(listOf("200"), updated.map { it.id })
    }

    @Test
    fun `work decode drops broken rows`() {
        val good = SubscriptionsStore.encodeWorks(listOf(sampleWork("100")))
        // 手工拼一条只有 3 列的坏行进去
        val brokenRow = RecordCodec.encodeRow(listOf("999", "broken", "row"))
        val mixed = good + RecordCodec.ROW + brokenRow
        val decoded = SubscriptionsStore.decodeWorks(mixed)
        assertEquals(1, decoded.size)
        assertEquals("100", decoded.first().id)
    }

    @Test
    fun `work list capped at MAX_WORKS`() {
        val many = (1..(SubscriptionsStore.MAX_WORKS + 10)).map { sampleWork("$it") }
        assertEquals(
            SubscriptionsStore.MAX_WORKS,
            SubscriptionsStore.decodeWorks(SubscriptionsStore.encodeWorks(many)).size
        )
    }

    @Test
    fun `blank id rows are skipped on encode`() {
        val works = listOf(sampleWork("").copy(id = ""), sampleWork("100"))
        assertEquals(1, SubscriptionsStore.decodeWorks(SubscriptionsStore.encodeWorks(works)).size)
    }

    // ------------------------------------------------------------ 订阅的作者

    @Test
    fun `author encode decode round trip`() {
        val authors = listOf(
            SubscribedAuthor(username = "alice", addedAt = 1720000000000L),
            SubscribedAuthor(username = "bob", addedAt = 0L)
        )
        val decoded = SubscriptionsStore.decodeAuthors(SubscriptionsStore.encodeAuthors(authors))
        assertEquals(authors, decoded)
    }

    @Test
    fun `author dedupe ignores case`() {
        val base = listOf(SubscribedAuthor("Alice", 1L))
        assertTrue(SubscriptionsStore.containsAuthor(base, "alice"))
        assertEquals(base, SubscriptionsStore.addAuthor(base, "ALICE"))
        val removed = SubscriptionsStore.removeAuthor(base, " alice ")
        assertTrue(removed.isEmpty())
    }

    @Test
    fun `toggle author adds then removes`() {
        val empty = emptyList<SubscribedAuthor>()
        val once = SubscriptionsStore.toggleAuthor(empty, "alice", 123L)
        assertEquals(listOf(SubscribedAuthor("alice", 123L)), once)
        assertTrue(SubscriptionsStore.toggleAuthor(once, "alice").isEmpty())
    }

    @Test
    fun `author blank names are ignored`() {
        val empty = emptyList<SubscribedAuthor>()
        assertEquals(empty, SubscriptionsStore.addAuthor(empty, ""))
        assertEquals(empty, SubscriptionsStore.addAuthor(empty, "   "))
        assertFalse(SubscriptionsStore.containsAuthor(empty, "alice"))
    }

    @Test
    fun `author decode drops empty rows`() {
        val raw = RecordCodec.encodeRow(listOf("alice", "1")) + RecordCodec.ROW + RecordCodec.encodeRow(listOf("", "2"))
        val decoded = SubscriptionsStore.decodeAuthors(raw)
        assertEquals(listOf(SubscribedAuthor("alice", 1L)), decoded)
    }
}
