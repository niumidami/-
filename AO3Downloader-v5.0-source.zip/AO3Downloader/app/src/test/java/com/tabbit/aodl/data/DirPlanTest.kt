package com.tabbit.aodl.data

import com.tabbit.aodl.model.DownloadFormat
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 需求 2「按作者分类保存」目录规划的离线断言。
 *
 * [DirPlan] 是 `AppViewModel.resolveDir` 里剥离出来的纯决策部分，
 * 这里逐一核对 **「统一保存开 / 关」× 「按作者分类开 / 关」四种组合**，
 * 确认：
 * - 只要多种格式共用同一个根目录，就一定会补一层格式目录，
 *   五种格式不会全部落在同一个文件夹里（v4.0 缺陷的回归断言）；
 * - 统一保存时在作者目录下一次建齐 HTML / PDF / MOBI / EPUB / AZW3 五个二级目录；
 * - 分格式保存时每个格式的根目录只建当前格式这一个二级目录，不留空目录；
 * - 仅当「每种格式各有独立根目录」且关闭作者分类时不再套格式层
 *   （此时用户选的根目录本身就是格式隔离，与 v3.0 行为一致）；
 * - 目标二级目录一定在被创建的列表里（不会写进没建过的目录）；
 * - 作者名为空或形如 `..` 时回退到「未知作者」，含非法字符时先清洗。
 */
class DirPlanTest {

    private val fallback = "未知作者"

    /** 一个典型的 SAF 根目录 Uri 字面量，用于缓存键断言。 */
    private val ROOT = "content://com.android.externalstorage.documents/tree/primary%3ADownload"

    private fun author(classify: Boolean = true, label: String = "Alice") =
        DirPlan.authorSegment(classify, label, fallback)

    /**
     * 目标目录相对路径（不含根目录）：作者层 + 格式层。
     * 用于断言「不同格式不会落到同一个目录」。
     */
    private fun relPath(classify: Boolean, unified: Boolean, format: DownloadFormat): List<String> = buildList {
        author(classify = classify)?.let { add(it.first) }
        DirPlan.targetFormatDir(classify, unified, format)?.let { add(it) }
    }

    // ------------------------------------------------- -- 格式层判定

    @Test
    fun `format level is required whenever formats share one root folder`() {
        // 统一保存 = 五种格式共用一个根目录，必须分开
        assertTrue(DirPlan.needsFormatLevel(authorClassify = false, unifiedSave = true))
        assertTrue(DirPlan.needsFormatLevel(authorClassify = true, unifiedSave = true))
        // 按作者分类时，作者目录下同样要按格式分开
        assertTrue(DirPlan.needsFormatLevel(authorClassify = true, unifiedSave = false))
        // 每种格式各自一个根目录且不按作者分类：根目录本身已经是格式隔离
        assertFalse(DirPlan.needsFormatLevel(authorClassify = false, unifiedSave = false))
    }

    @Test
    fun `classify off with separate format roots keeps files in the picked root`() {
        assertNull(author(classify = false))
        DownloadFormat.entries.forEach { format ->
            assertTrue(DirPlan.formatSegments(false, unifiedSave = false, format).isEmpty())
            assertNull(DirPlan.targetFormatDir(false, unifiedSave = false, format))
        }
    }

    @Test
    fun `classify off with unified root still separates every format`() {
        // v4.0 缺陷：该组合下 formatSegments 返回空、targetFormatDir 返回 null，
        // 五种格式全部落进同一个文件夹。修复后必须各建一层格式目录。
        assertNull(author(classify = false))
        DownloadFormat.entries.forEach { format ->
            val created = DirPlan.formatSegments(false, unifiedSave = true, format)
            assertEquals(5, created.size)
            assertEquals(format.name, DirPlan.targetFormatDir(false, unifiedSave = true, format))
            assertTrue(created.contains(format))
        }
    }

    @Test
    fun `no two formats ever share the same relative target folder`() {
        // 回归断言：四种组合下，只要根目录是共用的，各格式的目标相对路径就必须互不相同。
        listOf(false to true, true to true, true to false).forEach { (classify, unified) ->
            val paths = DownloadFormat.entries.map { relPath(classify, unified, it) }
            assertEquals(
                "classify=$classify unified=$unified 出现重复目录：$paths",
                DownloadFormat.entries.size,
                paths.toSet().size
            )
        }
    }

    // ------------------------------------------------------- 分类开关

    @Test
    fun `classify on yields exactly one author level folder`() {
        val segment = author()
        assertEquals("Alice" to fallback, segment)
        // 一级目录名再走一次清洗必须幂等，否则缓存键与实际建出的目录会不一致
        assertEquals(segment!!.first, FileNameBuilder.dirName(segment.first, fallback))
    }

    @Test
    fun `author level is added ahead of the format level when classify is on`() {
        assertEquals(listOf("Alice", "EPUB"), relPath(classify = true, unified = true, DownloadFormat.EPUB))
        assertEquals(listOf("Alice", "PDF"), relPath(classify = true, unified = false, DownloadFormat.PDF))
        // 关闭作者分类时只剩格式层
        assertEquals(listOf("MOBI"), relPath(classify = false, unified = true, DownloadFormat.MOBI))
        assertTrue(relPath(classify = false, unified = false, DownloadFormat.MOBI).isEmpty())
    }

    // ------------------------------------------------------- 统一保存：开

    @Test
    fun `unified save creates all five format folders in declaration order`() {
        val created = DirPlan.formatSegments(true, unifiedSave = true, DownloadFormat.EPUB)
        assertEquals(
            listOf(
                DownloadFormat.HTML,
                DownloadFormat.PDF,
                DownloadFormat.MOBI,
                DownloadFormat.EPUB,
                DownloadFormat.AZW3
            ),
            created
        )
        assertEquals("EPUB", DirPlan.targetFormatDir(true, unifiedSave = true, DownloadFormat.EPUB))
    }

    @Test
    fun `unified save targets the folder of the current format for every format`() {
        DownloadFormat.entries.forEach { format ->
            val created = DirPlan.formatSegments(true, unifiedSave = true, format)
            assertEquals(5, created.size)
            assertEquals(
                format,
                DirPlan.targetFormatDir(true, unifiedSave = true, format)?.let { DownloadFormat.valueOf(it) }
            )
            assertTrue(created.contains(format))
        }
    }

    // ------------------------------------------------------- 统一保存：关

    @Test
    fun `per format save only creates the folder of the current format`() {
        DownloadFormat.entries.forEach { format ->
            val created = DirPlan.formatSegments(true, unifiedSave = false, format)
            assertEquals(listOf(format), created)
            assertEquals(format.name, DirPlan.targetFormatDir(true, unifiedSave = false, format))
        }
    }

    @Test
    fun `per format save never leaves four empty sibling folders behind`() {
        val created = DirPlan.formatSegments(true, unifiedSave = false, DownloadFormat.PDF)
        assertEquals(1, created.size)
        assertTrue(created.none { it != DownloadFormat.PDF })
    }

    @Test
    fun `the author folder name is identical in both save modes`() {
        // 同一作者在「统一目录」和「各格式目录」下必须落到同名一级目录，
        // 否则 preparedDirs 的缓存键会分裂成多份、目录被重复创建。
        assertEquals(author(), DirPlan.authorSegment(true, "Alice", fallback))
        val unified = DirPlan.formatSegments(true, unifiedSave = true, DownloadFormat.HTML)
        val perFormat = DirPlan.formatSegments(true, unifiedSave = false, DownloadFormat.HTML)
        assertTrue(perFormat.all { unified.contains(it) })
    }

    // ------------------------------------------------ 已解析目录的缓存键

    @Test
    fun `cache key separates formats that share one root folder`() {
        // v4.0 缺陷的回归断言：键里不带格式时，先解析出来的目录会被其余格式复用，
        // HTML / MOBI / AZW3 / EPUB / PDF 全部落进同一个文件夹。
        val keys = DownloadFormat.entries.map { DirPlan.cacheKey(ROOT, "Alice", formatLevel = true, it) }
        assertEquals(DownloadFormat.entries.size, keys.toSet().size)
        // 关闭作者分类、多格式共用根目录时同样必须分开
        val noAuthor = DownloadFormat.entries.map { DirPlan.cacheKey(ROOT, null, formatLevel = true, it) }
        assertEquals(DownloadFormat.entries.size, noAuthor.toSet().size)
    }

    @Test
    fun `cache key is stable for the same root author and format`() {
        // 同一作者的多个作品必须共用同一个键，否则目录会被反复建、恢复不到已有目录。
        assertEquals(
            DirPlan.cacheKey(ROOT, "Alice", formatLevel = true, DownloadFormat.PDF),
            DirPlan.cacheKey(ROOT, "Alice", formatLevel = true, DownloadFormat.PDF)
        )
        // 不同根目录、不同作者都不能撞键
        assertNotEquals(
            DirPlan.cacheKey(ROOT, "Alice", true, DownloadFormat.PDF),
            DirPlan.cacheKey("$ROOT/other", "Alice", true, DownloadFormat.PDF)
        )
        assertNotEquals(
            DirPlan.cacheKey(ROOT, "Alice", true, DownloadFormat.PDF),
            DirPlan.cacheKey(ROOT, "Bob", true, DownloadFormat.PDF)
        )
    }

    @Test
    fun `cache key separators can never be produced by a real author name`() {
        // 键用 \u0000 分隔、用 \u0001 占位，而真实作者名一律要过 FileNameBuilder 的清洗
        // （C0/C1 控制字符被替换成 `_`），所以占位符与真实名字不可能撞键。
        // 注意：不能直接断言 cacheKey(root, null, …) != cacheKey(root, "\u0001", …)——
        // 后者传的正是占位符本身，两者本来就该相等。
        listOf("Alice", "", "   ", ".", "..", "A/../B", "a\u0000b", "\u0000", "\u0001").forEach { label ->
            val name = FileNameBuilder.dirName(label, fallback)
            assertFalse("label=$label 清洗后仍带 \\u0000：$name", name.contains('\u0000'))
            assertFalse("label=$label 清洗后仍带 \\u0001：$name", name.contains('\u0001'))
        }
        // 「不建格式目录」与「格式层里的某个格式」必须落在不同的键上
        assertNotEquals(
            DirPlan.cacheKey(ROOT, "Alice", formatLevel = false, DownloadFormat.HTML),
            DirPlan.cacheKey(ROOT, "Alice", formatLevel = true, DownloadFormat.HTML)
        )
    }

    // ------------------------------------------------------------ 作者名清洗

    @Test
    fun `blank or traversal author names fall back to the placeholder`() {
        listOf("", "   ", ".", "..", "...", " . . ").forEach { label ->
            val segment = author(label = label)
            assertEquals(fallback, segment!!.first)
        }
    }

    @Test
    fun `illegal characters and separators are sanitised before creating the folder`() {
        assertEquals("A_B_C_D_", author(label = "A/B:C*D?")!!.first)
        assertEquals("Alice", author(label = "  ...Alice...  ")!!.first)
        assertEquals("Alice", author(label = "Al\u0000ice")!!.first.replace("_", ""))
    }

    @Test
    fun `a very long author name is truncated to a writable length`() {
        val long = "a".repeat(400)
        val name = author(label = long)!!.first
        assertTrue(name.length <= 80)
        assertTrue(name.isNotBlank())
    }
}