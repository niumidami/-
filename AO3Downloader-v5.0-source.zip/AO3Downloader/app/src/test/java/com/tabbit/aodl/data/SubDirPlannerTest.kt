package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Collections
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * 子目录「先查后建」竞态的离线断言（v4.2 修复 #1）。
 *
 * 假 provider（[FakeProvider]）复现外部存储提供者的两个关键行为：
 * 1. 目标名字已被占用时，新建会被**改名**成 `name (1)`（用户截图里的 `onee1e (1)`）；
 * 2. 目录创建成功后，provider 返回的是它**实际采用**的那个名字。
 *
 * 断言目标：同一（父目录 + 名字）在并发批量任务下只会产生一个目录。
 */
class SubDirPlannerTest {

    /** 可脚本化的假 SAF provider。 */
    private class FakeProvider(
        initial: Set<String> = emptySet(),
        private val renameOnCollision: Boolean = true
    ) : SubDirOps {

        /** 盘上真实存在的目录（名字 → 是否为空）。 */
        val disk: MutableMap<String, Boolean> = LinkedHashMap<String, Boolean>().apply {
            initial.forEach { put(it, true) }
        }

        /** true 时假装"查不到"：模拟并发任务读到的是旧快照。 */
        var hideExisting: Boolean = false

        /** 创建时先执行的动作（用于模拟"创建失败但目录已被别人建好"）。 */
        var beforeCreateFails: (() -> Unit)? = null

        /** true 时 createDir 返回 null（创建失败）。 */
        var failCreate: Boolean = false

        /** true 时新建出来的目录非空。 */
        var createdNonEmpty: Boolean = false

        var createCalls: Int = 0
            private set

        private var created: String? = null

        override fun existingDir(name: String): Boolean =
            !hideExisting && disk.containsKey(name)

        override fun createDir(name: String): String? {
            createCalls++
            if (failCreate) {
                beforeCreateFails?.invoke()
                hideExisting = false
                return null
            }
            val actual = if (renameOnCollision && disk.containsKey(name)) uniqueName(name) else name
            disk[actual] = !createdNonEmpty
            created = actual
            hideExisting = false
            return actual
        }

        override fun createdIsEmpty(): Boolean = created?.let { disk[it] } ?: false

        override fun dropCreated(): Boolean = created?.let { disk.remove(it) != null } ?: false

        private fun uniqueName(name: String): String {
            var index = 1
            while (disk.containsKey("$name ($index)")) index++
            return "$name ($index)"
        }
    }

    private fun resolver() = SubDirResolver<String>({ it })

    // ------------------------------------------------------------------ 复用

    @Test
    fun `existing same-named dir is reused without creating anything`() {
        val fake = FakeProvider(initial = setOf("onee1e"))

        val (outcome, _) = resolver().resolve("parent", "onee1e") { fake }

        assertEquals(SubDirOutcome.Reused("onee1e"), outcome)
        assertEquals("已有同名目录时不应再新建", 0, fake.createCalls)
        assertEquals(setOf("onee1e"), fake.disk.keys)
    }

    @Test
    fun `creates the dir once when it does not exist yet`() {
        val fake = FakeProvider()

        val (outcome, _) = resolver().resolve("parent", "onee1e") { fake }

        assertEquals(SubDirOutcome.Created("onee1e"), outcome)
        assertEquals(1, fake.createCalls)
        assertEquals(setOf("onee1e"), fake.disk.keys)
    }

    // ------------------------------------------------------------------ 并发

    @Test
    fun `concurrent tasks never create two dirs for the same name`() {
        val fake = FakeProvider()
        val resolver = resolver()
        val threads = 8
        val start = CountDownLatch(1)
        val done = CountDownLatch(threads)
        val outcomes = Collections.synchronizedList(ArrayList<SubDirOutcome>())

        repeat(threads) {
            Thread {
                start.await()
                val (outcome, _) = resolver.resolve("parent", "onee1e") { fake }
                outcomes += outcome
                done.countDown()
            }.start()
        }
        start.countDown()
        assertTrue("并发解析未在 5s 内完成", done.await(5, TimeUnit.SECONDS))

        assertEquals("同一作者目录只应创建一次", 1, fake.createCalls)
        assertEquals(setOf("onee1e"), fake.disk.keys)
        assertEquals(1, outcomes.count { it is SubDirOutcome.Created })
        assertEquals(threads - 1, outcomes.count { it is SubDirOutcome.Reused })
    }

    // ------------------------------------------------------------------ 改名折叠

    @Test
    fun `renamed duplicate is collapsed back onto the existing dir`() {
        // 并发场景：查询时同名目录还看不到（旧快照），创建时才发现重名 →
        // provider 把新目录改名成 onee1e (1)，此时应改用 onee1e 并回收 onee1e (1)。
        val fake = FakeProvider(initial = setOf("onee1e"))
        fake.hideExisting = true

        val (outcome, _) = resolver().resolve("parent", "onee1e") { fake }

        assertEquals(SubDirOutcome.Collapsed("onee1e", "onee1e (1)"), outcome)
        assertEquals("重复目录应被回收，用户只会看到一个作者目录", setOf("onee1e"), fake.disk.keys)
    }

    @Test
    fun `non empty duplicate is kept and reported as not dropped`() {
        val fake = FakeProvider(initial = setOf("onee1e"))
        fake.hideExisting = true
        fake.createdNonEmpty = true

        val (outcome, _) = resolver().resolve("parent", "onee1e") { fake }

        assertEquals(SubDirOutcome.Collapsed("onee1e", null), outcome)
        assertEquals(setOf("onee1e", "onee1e (1)"), fake.disk.keys)
    }

    @Test
    fun `keeps provider name when the sibling cannot be found`() {
        // 极端兜底：名字被改写、又查不到既有同名目录时，保留 provider 给的名字，绝不丢文件。
        val fake = object : SubDirOps {
            private var created: String? = null
            override fun existingDir(name: String) = false
            override fun createDir(name: String): String? {
                created = "onee1e (1)"
                return created
            }
            override fun createdIsEmpty() = true
            override fun dropCreated() = true
        }

        val (outcome, _) = resolver().resolve("parent", "onee1e") { fake }

        assertEquals(SubDirOutcome.Created("onee1e (1)"), outcome)
    }

    // ------------------------------------------------------------------ 失败

    @Test
    fun `fails when neither create nor lookup succeeds`() {
        val fake = FakeProvider()
        fake.failCreate = true

        val (outcome, _) = resolver().resolve("parent", "onee1e") { fake }

        assertEquals(SubDirOutcome.Failed, outcome)
    }

    @Test
    fun `reuses the dir when create fails but a sibling appeared meanwhile`() {
        val fake = FakeProvider()
        fake.failCreate = true
        fake.beforeCreateFails = { fake.disk["onee1e"] = true }

        val (outcome, _) = resolver().resolve("parent", "onee1e") { fake }

        assertEquals(SubDirOutcome.Reused("onee1e"), outcome)
    }
}