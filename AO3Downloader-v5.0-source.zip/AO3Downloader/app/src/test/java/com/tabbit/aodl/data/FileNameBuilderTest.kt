package com.tabbit.aodl.data

import com.tabbit.aodl.model.DownloadFormat
import com.tabbit.aodl.model.WorkMeta
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 需求 1「作品名by作者名」命名规则的离线断言。
 *
 * 全部在纯 JVM 下运行，不访问网络、不依赖 Android：
 * [FileNameBuilder] 只使用 [WorkMeta] 与 [DownloadFormat] 两个纯数据类型。
 */
class FileNameBuilderTest {

    private fun meta(title: String, vararg authors: String) = WorkMeta(
        workId = "1234567",
        title = title,
        authors = authors.toList()
    )

    @Test
    fun `title and author produce Title by Author dot ext`() {
        assertEquals(
            "夜航西飞 by 张三.epub",
            FileNameBuilder.build(meta("夜航西飞", "张三"), "1234567", DownloadFormat.EPUB)
        )
    }

    @Test
    fun `all five formats use their own extension`() {
        val expected = mapOf(
            DownloadFormat.HTML to "Work by Author.html",
            DownloadFormat.PDF to "Work by Author.pdf",
            DownloadFormat.MOBI to "Work by Author.mobi",
            DownloadFormat.EPUB to "Work by Author.epub",
            DownloadFormat.AZW3 to "Work by Author.azw3"
        )
        expected.forEach { (format, name) ->
            assertEquals(name, FileNameBuilder.build(meta("Work", "Author"), "1", format))
        }
    }

    @Test
    fun `multiple authors are joined with comma space`() {
        assertEquals(
            "Work by A, B.epub",
            FileNameBuilder.build(meta("Work", "A", "B"), "1", DownloadFormat.EPUB)
        )
    }

    @Test
    fun `blank authors are filtered out`() {
        assertEquals(
            "Work by A.epub",
            FileNameBuilder.build(meta("Work", "A", "  ", ""), "1", DownloadFormat.EPUB)
        )
    }

    @Test
    fun `title only falls back to title without author segment`() {
        assertEquals("Solo Work.html", FileNameBuilder.build(meta("Solo Work"), "9", DownloadFormat.HTML))
    }

    @Test
    fun `no title falls back to work id`() {
        // 需求 1：这种格式名字（取不到作品名/作者）自动改用作品 ID 命名
        assertEquals("1234567.pdf", FileNameBuilder.build(meta(""), "1234567", DownloadFormat.PDF))
        assertEquals("1234567.pdf", FileNameBuilder.build(null, "1234567", DownloadFormat.PDF))
    }

    @Test
    fun `no title and no id falls back to server suggested name then constant`() {
        assertEquals(
            "work.azw3",
            FileNameBuilder.build(meta("", ""), "", DownloadFormat.AZW3, "work.azw3")
        )
        assertEquals(FileNameBuilder.FALLBACK_BASE + ".mobi", FileNameBuilder.build(meta("", ""), "", DownloadFormat.MOBI))
    }

    @Test
    fun `illegal characters are replaced and never leak into the file name`() {
        val name = FileNameBuilder.build(meta("A/B:C*D?E\"F<G>H|I", "x\\y"), "1", DownloadFormat.EPUB)
        listOf('\\', '/', ':', '*', '?', '"', '<', '>', '|').forEach { illegal ->
            assertFalse("非法字符 $illegal 未被清洗：$name", name.contains(illegal))
        }
        assertTrue(name.endsWith(".epub"))
    }

    @Test
    fun `control characters are stripped`() {
        val name = FileNameBuilder.build(meta("Bad\u0000Name\u001F", "A\u007FB"), "1", DownloadFormat.HTML)
        name.forEach { ch ->
            assertTrue("控制字符未被清洗: ${ch.code}", ch.code >= 0x20 && ch.code != 0x7F)
        }
    }

    @Test
    fun `consecutive whitespace collapses and dots are trimmed`() {
        assertEquals(
            "a b.epub",
            FileNameBuilder.build(meta("  a   b  "), "1", DownloadFormat.EPUB)
        )
        assertEquals(
            "trailing.epub",
            FileNameBuilder.build(meta("trailing..."), "1", DownloadFormat.EPUB)
        )
    }

    @Test
    fun `over long title and author are truncated within the total limit`() {
        val longTitle = "标".repeat(300)
        val longAuthor = "作".repeat(200)
        val name = FileNameBuilder.build(meta(longTitle, longAuthor), "1", DownloadFormat.EPUB)
        assertTrue("文件名过长：${name.length}", name.length <= 120)
        assertTrue(name.endsWith(".epub"))
        assertTrue(name.contains(FileNameBuilder.AUTHOR_SEPARATOR))
    }

    @Test
    fun `base name is reusable for directory naming`() {
        assertEquals("Work by Author", FileNameBuilder.baseName(meta("Work", "Author"), "1"))
        assertEquals("1", FileNameBuilder.baseName(null, "1"))
    }

    @Test
    fun `dir name sanitizes path separators and uses fallback when blank`() {
        assertEquals("A_B", FileNameBuilder.dirName("A/B", "未知作者"))
        // 分隔符被替换成下划线，而不是留空——留空才会退回 fallback
        assertEquals("___", FileNameBuilder.dirName("///", "未知作者"))
        assertEquals("未知作者", FileNameBuilder.dirName("   ", "未知作者"))
        // "." / ".." 会被当成相对路径，必须退回 fallback
        assertEquals("未知作者", FileNameBuilder.dirName("..", "未知作者"))
        assertEquals("未知作者", FileNameBuilder.dirName(".", "未知作者"))
    }

    @Test
    fun `part name appends the resume suffix`() {
        assertEquals("Work by A.epub.part", FileNameBuilder.partName("Work by A.epub"))
        assertEquals(FileNameBuilder.PART_SUFFIX, ".part")
    }

    @Test
    fun `clean truncates to the requested maximum`() {
        assertEquals("abcdef", FileNameBuilder.clean("abcdefghij", 6))
        assertEquals("abc", FileNameBuilder.clean("  abc  ", 10))
        assertEquals("", FileNameBuilder.clean("", 10))
    }
}
