package com.tabbit.aodl.net

import com.tabbit.aodl.data.FilterOption
import org.jsoup.Jsoup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * `/works/search` 表单候选项解析与筛选参数拼装的离线断言（v5.1 结果页筛选）。
 *
 * fixture 按 otwcode/otwarchive `app/views/works/_search_form.html.erb` 的结构手工还原
 * （`select[name=work_search[...]]`、`input[name=work_search[...][]]` 复选框、
 * `label[for=id]` 或包裹式 `label`），不访问 archiveofourown.org。
 */
class SearchFormParserTest {

    private fun doc(html: String) =
        Jsoup.parse(html, "https://archiveofourown.org/works/search")

    @Test
    fun `parseSearchFormOptions reads site form selects and checkboxes`() {
        val html = """
            <form id="work-filters" action="/works/search" accept-charset="UTF-8" method="get">
              <select name="work_search[rating_ids]" id="work_search_rating_ids">
                <option value="">All Ratings</option>
                <option value="9">Not Rated</option>
                <option value="12">Mature</option>
              </select>
              <ol class="filters group">
                <li>
                  <input type="checkbox" name="work_search[archive_warning_ids][]"
                         id="work_search_archive_warning_ids_14" value="14" />
                  <label for="work_search_archive_warning_ids_14">Creator Chose Not To Use Archive Warnings</label>
                </li>
                <li>
                  <label><input type="checkbox" name="work_search[archive_warning_ids][]" value="18" /> Major Character Death</label>
                </li>
              </ol>
              <ol class="filters group">
                <li><label><input type="checkbox" name="work_search[category_ids][]" value="21" /> Gen</label></li>
                <li>
                  <input type="checkbox" name="work_search[category_ids][]"
                         id="work_search_category_ids_23" value="23" />
                  <label for="work_search_category_ids_23">M/M</label>
                </li>
              </ol>
              <select name="work_search[language_id]" id="work_search_language_id">
                <option value="">Any</option>
                <option value="en">English</option>
                <option value="zh">中文</option>
              </select>
              <select name="work_search[sort_column]" id="work_search_sort_column">
                <option value="">Best Match</option>
                <option value="title_to_sort_on">Title</option>
                <option value="hits">Hits</option>
              </select>
            </form>
        """.trimIndent()

        val options = parseSearchFormOptions(doc(html))

        assertEquals(
            listOf(FilterOption("9", "Not Rated"), FilterOption("12", "Mature")),
            options.ratings
        )
        assertEquals(
            listOf(
                FilterOption("14", "Creator Chose Not To Use Archive Warnings"),
                FilterOption("18", "Major Character Death")
            ),
            options.warnings
        )
        assertEquals(
            listOf(FilterOption("21", "Gen"), FilterOption("23", "M/M")),
            options.categories
        )
        assertEquals(
            listOf(FilterOption("en", "English"), FilterOption("zh", "中文")),
            options.languages
        )
        assertEquals(
            listOf(FilterOption("title_to_sort_on", "Title"), FilterOption("hits", "Hits")),
            options.sorts
        )
    }

    @Test
    fun `parseSearchFormOptions falls back to value when label missing`() {
        val html = """<input type="checkbox" name="work_search[category_ids][]" value="2246" />"""
        val options = parseSearchFormOptions(doc(html))
        assertEquals(listOf(FilterOption("2246", "2246")), options.categories)
    }

    @Test
    fun `parseSearchFormOptions on page without form yields empty`() {
        val options = parseSearchFormOptions(doc("<html><body><p>hi</p></body></html>"))
        assertTrue(options.isEmpty())
    }

    @Test
    fun `searchRequest appends extra filter params`() {
        val request = searchRequest(
            query = "test",
            page = 2,
            extraParams = listOf(
                "work_search[complete]" to "T",
                "work_search[archive_warning_ids][]" to "14"
            )
        )
        assertEquals("test", request.url.queryParameter("work_search[query]"))
        assertEquals("T", request.url.queryParameter("work_search[complete]"))
        assertEquals("14", request.url.queryParameter("work_search[archive_warning_ids][]"))
        assertEquals("Search", request.url.queryParameter("commit"))
        assertEquals("2", request.url.queryParameter("page"))
    }
}
