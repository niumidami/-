package com.tabbit.aodl.net

import com.tabbit.aodl.model.DownloadFormat
import com.tabbit.aodl.model.WorkKind
import org.jsoup.Jsoup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * AO3 页面解析与下载请求构造的离线断言（需求 1 / 需求 5 / 需求 6）。
 *
 * 全部 fixture 按 otwcode/otwarchive master 分支模板手工还原
 * （`_work_header.html.erb`、`_work_meta.html.erb`、`_stats.html.erb`、
 * `_login.html.erb`、`layouts/_header.html.erb`），
 * 不访问 archiveofourown.org，因此在无网络的沙箱里同样可执行。
 */
class Ao3ParsersTest {

    // ---------------------------------------------------------------- 下载请求

    @Test
    fun `downloadRequest builds official download url for every format`() {
        DownloadFormat.entries.forEach { format ->
            val request = downloadRequest(
                workId = "12345",
                format = format,
                viewAdult = false,
                loggedIn = false,
                referer = "https://archiveofourown.org/works/12345"
            )
            assertEquals(
                "https://archiveofourown.org/downloads/12345/work.${format.ext}",
                request.url.toString()
            )
            assertEquals("GET", request.method)
        }
    }

    @Test
    fun `downloadRequest disables transparent gzip so Range offsets stay truthful`() {
        val request = downloadRequest("1", DownloadFormat.HTML, false, false, "r")
        assertEquals("identity", request.header("Accept-Encoding"))
        assertEquals("r", request.header("Referer"))
        assertTrue(request.header("User-Agent").isNullOrBlank().not())
    }

    @Test
    fun `downloadRequest sends Range only when resume offset is positive`() {
        val none = downloadRequest("1", DownloadFormat.EPUB, false, false, "r", rangeStart = -1L)
        assertNull(none.header("Range"))

        val zero = downloadRequest("1", DownloadFormat.EPUB, false, false, "r", rangeStart = 0L)
        assertNull(zero.header("Range"))

        val resume = downloadRequest("1", DownloadFormat.EPUB, false, false, "r", rangeStart = 4096L)
        assertEquals("bytes=4096-", resume.header("Range"))
    }

    @Test
    fun `view_adult is appended only for logged in sessions`() {
        val anonymous = downloadRequest("9", DownloadFormat.PDF, viewAdult = true, loggedIn = false, referer = "r")
        assertEquals("https://archiveofourown.org/downloads/9/work.pdf", anonymous.url.toString())

        val loggedIn = downloadRequest("9", DownloadFormat.PDF, viewAdult = true, loggedIn = true, referer = "r")
        assertEquals(
            "https://archiveofourown.org/downloads/9/work.pdf?view_adult=true",
            loggedIn.url.toString()
        )

        val off = downloadRequest("9", DownloadFormat.PDF, viewAdult = false, loggedIn = true, referer = "r")
        assertEquals("https://archiveofourown.org/downloads/9/work.pdf", off.url.toString())
    }

    // ----------------------------------------------------------- Content-Range

    @Test
    fun `parseContentRange reads full spec`() {
        val parsed = parseContentRange("bytes 100-199/5000")
        assertEquals(ContentRange(100L, 199L, 5000L), parsed)
    }

    @Test
    fun `parseContentRange tolerates unknown total and missing header`() {
        assertEquals(ContentRange(0L, 99L, -1L), parseContentRange("bytes 0-99/*"))
        assertEquals(ContentRange(100L, -1L, -1L), parseContentRange("bytes 100-"))
        assertEquals(ContentRange(-1L, -1L, -1L), parseContentRange(null))
        assertEquals(ContentRange(-1L, -1L, -1L), parseContentRange("   "))
        assertEquals(ContentRange(-1L, -1L, -1L), parseContentRange("garbage"))
    }

    // -------------------------------------------------------------- 重试判定

    @Test
    fun `network class failures are retryable`() {
        assertTrue(isRetryable(Ao3Error.NETWORK, "java.net.UnknownHostException"))
        assertTrue(isRetryable(Ao3Error.TIMEOUT, "timeout"))
        assertTrue(isRetryable(Ao3Error.TLS, "handshake failure"))
    }

    @Test
    fun `transient http failures are retryable but deterministic ones are not`() {
        assertTrue(isRetryable(Ao3Error.HTTP, "HTTP 500"))
        assertTrue(isRetryable(Ao3Error.HTTP, "HTTP 503 Service Unavailable"))
        assertTrue(isRetryable(Ao3Error.HTTP, "HTTP 429"))
        assertTrue(isRetryable(Ao3Error.HTTP, "HTTP 408"))
        assertFalse(isRetryable(Ao3Error.HTTP, "HTTP 404 Not Found"))
        assertFalse(isRetryable(Ao3Error.HTTP, "HTTP 403 Forbidden"))
        assertFalse(isRetryable(Ao3Error.HTTP, "unreadable code"))
    }

    @Test
    fun `deterministic failures never retry`() {
        assertFalse(isRetryable(Ao3Error.NOT_FOUND))
        assertFalse(isRetryable(Ao3Error.LOGIN_REQUIRED))
        assertFalse(isRetryable(Ao3Error.SESSION_EXPIRED))
        assertFalse(isRetryable(Ao3Error.RANGE_INVALID))
        assertFalse(isRetryable(Ao3Error.WRITE))
        assertFalse(isRetryable(Ao3Error.CANCELLED))
        assertFalse(isRetryable(Ao3Error.NO_FOLDER))
        assertFalse(isRetryable(Ao3Error.UNEXPECTED_HTML))
        assertFalse(isRetryable(Ao3Error.PARSE))
        assertFalse(isRetryable(Ao3Error.UNKNOWN))
    }

    // ---------------------------------------------------------------- 作品页

    @Test
    fun `parseWorkMeta reads title authors and stats from work header`() {
        val meta = parseWorkMeta(Jsoup.parse(WORK_PAGE), "42424242")
        assertEquals("42424242", meta.workId)
        assertEquals("Sakura Nights", meta.title)
        assertEquals(listOf("StarDust", "CoAuthor"), meta.authors)
        assertEquals("StarDust, CoAuthor", meta.authorLabel)
        assertEquals("3/5", meta.chapters)
        assertEquals("12,345", meta.words)
        assertEquals("Original Work, Haikyuu!!", meta.fandoms)
        assertFalse(meta.restricted)
        assertTrue(meta.nameable)
        assertTrue(meta.fetchedAt > 0L)
    }

    @Test
    fun `parseWorkMeta flags explicit rating as restricted`() {
        val html = WORK_PAGE
            .replace("<dd class=\"rating tags\">Teen And Up Audiences</dd>", "<dd class=\"rating tags\">Explicit</dd>")
        assertTrue(parseWorkMeta(Jsoup.parse(html), "1").restricted)
    }

    @Test
    fun `parseWorkMeta flags restricted work marker image`() {
        val html = WORK_PAGE
            .replace("<dd class=\"rating tags\">Teen And Up Audiences</dd>", "<dd class=\"rating tags\">Not Rated</dd>")
            .replace(
                "<h2 class=\"title heading\">Sakura Nights</h2>",
                "<h2 class=\"title heading\">Locked Work <img alt=\"(Restricted)\" title=\"Restricted\" /></h2>"
            )
        assertTrue(parseWorkMeta(Jsoup.parse(html), "1").restricted)
    }

    @Test
    fun `parseWorkMeta falls back to og title then document title`() {
        val ogOnly = """
            <html><head><meta property="og:title" content="Og Title" /></head>
            <body><div class="primary header module"><h3 class="byline heading">
            <a href="/users/a/pseuds/a">a</a></h3></div></body></html>
        """.trimIndent()
        val og = parseWorkMeta(Jsoup.parse(ogOnly), "7")
        assertEquals("Og Title", og.title)
        assertEquals(listOf("a"), og.authors)

        val docTitleOnly = """
            <html><head><title>Chapter 3 - Fallen Leaves - Archive of Our Own</title></head>
            <body></body></html>
        """.trimIndent()
        assertEquals("Fallen Leaves", parseWorkMeta(Jsoup.parse(docTitleOnly), "8").title)
    }

    @Test
    fun `parseWorkMeta tolerates a page without any usable metadata`() {
        val meta = parseWorkMeta(Jsoup.parse("<html><body><p>Nothing here</p></body></html>"), "555")
        assertEquals("555", meta.workId)
        assertEquals("", meta.title)
        assertTrue(meta.authors.isEmpty())
        assertFalse(meta.nameable)
    }

    @Test
    fun `looksLikeWorkPage recognises work structure only`() {
        assertTrue(looksLikeWorkPage(Jsoup.parse(WORK_PAGE)))
        assertFalse(looksLikeWorkPage(Jsoup.parse("<html><body><h1>404</h1></body></html>")))
    }

    @Test
    fun `restrictedGate detects login wall on gated works`() {
        val loginForm = """
            <html><body>
            <h2 class="heading">Restricted Work</h2>
            <p>This work is only available to registered users.</p>
            <form id="new_user_session" action="/users/login" method="post"></form>
            </body></html>
        """.trimIndent()
        assertEquals("login form", restrictedGate(Jsoup.parse(loginForm)))

        val registeredOnly = """
            <html><body><p>This work is only available to registered users of the Archive.</p></body></html>
        """.trimIndent()
        assertEquals("registered users only", restrictedGate(Jsoup.parse(registeredOnly)))

        val restrictedText = """
            <html><body><p>This work is only available to the author and invited users.</p></body></html>
        """.trimIndent()
        assertEquals("restricted work", restrictedGate(Jsoup.parse(restrictedText)))
    }

    @Test
    fun `restrictedGate returns null for a readable work page`() {
        assertNull(restrictedGate(Jsoup.parse(WORK_PAGE)))
    }

    // -------------------------------------------------------------- 登录用户名

    @Test
    fun `parseLoggedInUsername returns null on a logged out header`() {
        // 未登录时 `#login` 容器同样存在，里面是指向 /users/login 与 /users/sign_up 的链接。
        val html = """
            <html><body>
            <div id="header">
              <ul id="login">
                <li><a href="/users/login">Log In</a></li>
                <li><a href="/users/sign_up">Register</a></li>
              </ul>
            </div>
            </body></html>
        """.trimIndent()
        assertNull(parseLoggedInUsername(Jsoup.parse(html)))
    }

    @Test
    fun `parseLoggedInUsername decodes percent encoded greeting link`() {
        val html = """
            <html><body>
            <ul id="greeting">
              <li><a href="/users/Test%20User/pseuds/Test%20User">Hi, Test User!</a></li>
            </ul>
            </body></html>
        """.trimIndent()
        assertEquals("Test User", parseLoggedInUsername(Jsoup.parse(html)))
    }

    @Test
    fun `parseLoggedInUsername skips logout link inside login block`() {
        val html = """
            <html><body>
            <div id="login">
              <a href="/users/logout?authenticity_token=abc" data-method="post">Log Out</a>
              <a href="/users/stardust/pseuds/stardust">Hi, stardust!</a>
            </div>
            </body></html>
        """.trimIndent()
        assertEquals("stardust", parseLoggedInUsername(Jsoup.parse(html)))
    }

    @Test
    fun `parseLoggedInUsername supports user paragraph and pseud fallbacks`() {
        val paragraph = """
            <html><body><p class="user"><a href="/users/Mina/pseuds/Mina">Mina</a></p></body></html>
        """.trimIndent()
        assertEquals("Mina", parseLoggedInUsername(Jsoup.parse(paragraph)))

        val bare = """
            <html><body><a href="https://archiveofourown.org/users/Kite/pseuds/Kite">Kite</a></body></html>
        """.trimIndent()
        assertEquals("Kite", parseLoggedInUsername(Jsoup.parse(bare)))
    }

    @Test
    fun `parseLoggedInUsername keeps real users whose name contains auth words`() {
        val html = """
            <html><body>
            <a href="/users/alogin/pseuds/alogin">Hi, alogin!</a>
            </body></html>
        """.trimIndent()
        assertEquals("alogin", parseLoggedInUsername(Jsoup.parse(html)))
    }

    // ------------------------------------------------------- 站点作品搜索请求

    @Test
    fun `searchRequest targets works search with the work_search query parameter`() {
        val request = searchRequest("sakura", page = 1)
        assertEquals("GET", request.method)
        assertEquals("/works/search", request.url.encodedPath)
        assertEquals("sakura", request.url.queryParameter("work_search[query]"))
        assertEquals("Search", request.url.queryParameter("commit"))
        assertNull(request.url.queryParameter("page"))
        // 参数名必须逐字为 work_search[query]，AO3 的 form_for as: :work_search 只认这个键
        val decoded = java.net.URLDecoder.decode(request.url.encodedQuery, "UTF-8")
        assertTrue(decoded.contains("work_search[query]=sakura"))
        assertTrue(request.header("User-Agent").isNullOrBlank().not())
        assertEquals("https://archiveofourown.org", request.url.scheme + "://" + request.url.host)
    }

    @Test
    fun `searchRequest appends page from the second page on`() {
        assertNull(searchRequest("a", page = 0).url.queryParameter("page"))
        assertNull(searchRequest("a", page = 1).url.queryParameter("page"))
        assertEquals("2", searchRequest("a", page = 2).url.queryParameter("page"))
        assertEquals("7", searchRequest("a", page = 7).url.queryParameter("page"))
    }

    @Test
    fun `searchRequest keeps non ascii and reserved characters round trippable`() {
        val keyword = "sakura & 樱花 nights"
        val request = searchRequest(keyword, page = 2)
        assertEquals(keyword, request.url.queryParameter("work_search[query]"))
        assertEquals("2", request.url.queryParameter("page"))
        assertFalse(request.url.encodedQuery?.contains(' ') == true)
        assertEquals(keyword, java.net.URLDecoder.decode(request.url.queryParameter("work_search[query]")!!, "UTF-8"))
    }

    @Test
    fun `searchRequest rejects an unusable base url instead of sending a broken request`() {
        val failure = runCatching { searchRequest("a", 1, baseUrl = "not a url") }.exceptionOrNull()
        assertTrue(failure is IllegalArgumentException)
    }

    // ------------------------------------------------------- 作品条目列表解析

    @Test
    fun `parseWorkList reads every search result blurb field`() {
        val items = parseWorkList(Jsoup.parse(SEARCH_RESULTS))
        assertEquals(2, items.size)

        val first = items[0]
        assertEquals("101", first.id)
        assertEquals("Sakura Nights", first.title)
        assertEquals("StarDust", first.authors)
        assertEquals("12,345", first.words)
        assertEquals("3/5", first.chapters)
        assertEquals("2023-11-1", first.updated.take(9))
        assertEquals("Original Work", first.fandoms)
        assertEquals(
            "Creator Chose Not To Use Archive Warnings, StarDust/CoAuthor, StarDust (character), Fluff, Angst",
            first.tags
        )
        assertEquals("English", first.language)
        assertTrue(first.restricted)
        assertEquals(WorkKind.WORK, first.kind)
        assertTrue(first.downloadable)

        // 简介卡片字段（v4.7）：分级预警四徽章、按类型拆开的 tag、简介与统计补充
        assertEquals("Mature", first.rating)
        assertEquals("Creator Chose Not To Use Archive Warnings", first.archiveWarnings)
        assertEquals("M/M", first.categories)
        assertEquals("Complete Work", first.completion)
        assertEquals(listOf("Creator Chose Not To Use Archive Warnings"), first.warningTags)
        assertEquals(listOf("StarDust/CoAuthor"), first.relationshipTags)
        assertEquals(listOf("StarDust (character)"), first.characterTags)
        assertEquals(listOf("Fluff", "Angst"), first.freeformTags)
        assertEquals("A test summary.", first.summary)
        assertEquals("7", first.comments)
        assertEquals("42", first.kudos)
        assertEquals("5", first.bookmarks)
        assertEquals("999", first.hits)

        val second = items[1]
        assertEquals("202", second.id)
        assertEquals("Fallen Leaves", second.title)
        assertEquals("CoAuthor, Guest", second.authors)
        assertEquals("8,900", second.words)
        assertEquals("1/1", second.chapters)
        assertEquals("Kite", second.fandoms)
        assertFalse(second.restricted)
    }

    @Test
    fun `parseWorkList tolerates blurbs without required tags or classified tags`() {
        // BLURB_202 没有 ul.required-tags、类型 li 与 summary，新字段必须全部退化为空，
        // 界面据此自动退回原有的紧凑展示。
        val second = parseWorkList(Jsoup.parse(SEARCH_RESULTS))[1]
        assertEquals("202", second.id)
        assertEquals("", second.rating)
        assertEquals("", second.archiveWarnings)
        assertEquals("", second.categories)
        assertEquals("", second.completion)
        assertTrue(second.warningTags.isEmpty())
        assertTrue(second.relationshipTags.isEmpty())
        assertTrue(second.characterTags.isEmpty())
        assertEquals(listOf("Hurt/Comfort"), second.freeformTags)
        assertEquals("", second.summary)
        assertEquals("", second.comments)
        assertEquals("", second.kudos)
        assertEquals("", second.bookmarks)
        assertEquals("", second.hits)
    }

    @Test
    fun `requiredTagOf prefers the title attribute and falls back to visible text`() {
        val titled = Jsoup.parse(
            """<li><ul class="required-tags">
                <li><span class="rating-teen rating" title="Teen And Up Audiences"><span class="text">Teen</span></span></li>
               </ul></li>"""
        ).selectFirst("li")!!
        assertEquals("Teen And Up Audiences", requiredTagOf(titled, "rating"))

        val textOnly = Jsoup.parse(
            """<li><ul class="required-tags">
                <li><span class="rating-general-audience rating"><span class="text">General Audiences</span></span></li>
               </ul></li>"""
        ).selectFirst("li")!!
        assertEquals("General Audiences", requiredTagOf(textOnly, "rating"))

        assertEquals("", requiredTagOf(titled, "warnings"))
    }

    @Test
    fun `requiredTagOf reads category from the singular category token used by the real site`() {
        // otwarchive `get_category_class` 产出的是 `category-slash category`
        // （单数 `category` 兜底 token），外层再套 `a.help.symbol.question`；
        // 误用复数 `categories` 槽位会让分类徽章整块缺失（S6 回归用例）。
        val li = Jsoup.parse(
            """<li><ul class="required-tags">
                <li><a class="help symbol question" href="/help/symbols-key.html" title="Symbols key"><span class="category-gen category" title="Gen"><span class="text">Gen</span></span></a></li>
               </ul></li>"""
        ).selectFirst("li")!!
        assertEquals("Gen", requiredTagOf(li, "category"))

        // 缺分类时站点给 `category-none category` + "No category"，也要能取出来
        val none = Jsoup.parse(
            """<li><ul class="required-tags">
                <li><a class="help symbol question" href="/help/symbols-key.html" title="Symbols key"><span class="category-none category" title="No category"><span class="text">No category</span></span></a></li>
               </ul></li>"""
        ).selectFirst("li")!!
        assertEquals("No category", requiredTagOf(none, "category"))
    }

    @Test
    fun `summaryOf joins multiple paragraphs with line breaks`() {
        val li = Jsoup.parse(
            """<li><blockquote class="userstuff summary">
                <p>First paragraph.</p><p>Second paragraph.</p>
               </blockquote></li>"""
        ).selectFirst("li")!!
        assertEquals("First paragraph.\nSecond paragraph.", summaryOf(li))
    }

    @Test
    fun `typed tag parsing excludes the bookmarkers own meta tags`() {
        // 收藏条目的作品 tag 列表后面跟着收藏者自己的 ul.meta.tags.commas，
        // 分类解析与 workTagsOf 一样不得把后者混进来。
        val li = Jsoup.parse(
            """<li>
                <ul class="tags commas">
                  <li class="relationships"><a class="tag" href="/tags/A*s*B/works">A/B</a></li>
                  <li><a class="tag" href="/tags/Fluff/works">Fluff</a></li>
                </ul>
                <ul class="meta tags commas">
                  <li class="relationships"><a class="tag" href="/tags/C*s*D/works">C/D</a></li>
                  <li><a class="tag" href="/tags/ReadLater/works">ReadLater</a></li>
                </ul>
               </li>"""
        ).selectFirst("li")!!
        assertEquals(listOf("A/B"), typedTagsOf(li, "relationships"))
        assertEquals(listOf("Fluff"), freeformTagsOf(li))
    }

    @Test
    fun `search results and author listings share one parse so the fields match exactly`() {
        // 同一段 _work_blurb 标记分别放进 search_results.html.erb 与 works/index.html.erb 的外壳里。
        // 两页容器选择器相同、条目结构相同，解析结果必须逐字段相同：
        // 这就是「站点搜索结果复用作者作品列表口径」的可执行证据。
        val search = parseWorkList(Jsoup.parse(SEARCH_RESULTS)).sortedBy { it.id }
        val index = parseWorkList(Jsoup.parse(AUTHOR_INDEX)).sortedBy { it.id }
        assertEquals(2, search.size)
        assertEquals(search, index)
        assertEquals("101", search[0].id)
        assertEquals("202", search[1].id)
    }

    @Test
    fun `parseWorkList skips series and blurb items that are not works`() {
        val html = """
            <html><body>
            <ol class="work index group">
              <li class="series blurb group" role="article">
                <h4 class="heading"><a href="/series/77">A Series</a> by <a href="/users/Someone/pseuds/Someone">Someone</a></h4>
              </li>
              $BLURB_101
            </ol>
            </body></html>
        """.trimIndent()
        val items = parseWorkList(Jsoup.parse(html))
        assertEquals(1, items.size)
        assertEquals("101", items[0].id)
        assertEquals(WorkKind.WORK, items[0].kind)
    }

    @Test
    fun `parseWorkList returns an empty list for the no results page`() {
        val html = """
            <html><body>
            <h2 class="heading">Search Results</h2>
            <p>No results found. You may want to edit your search to make it less specific.</p>
            </body></html>
        """.trimIndent()
        assertTrue(parseWorkList(Jsoup.parse(html)).isEmpty())
    }

    @Test
    fun `parseWorkBlurb falls back to the title link when the item id is missing`() {
        val li = Jsoup.parse(BLURB_101.replaceFirst("id=\"work_101\" ", "")).selectFirst("li.work.blurb")!!
        val item = parseWorkBlurb(li)
        assertEquals("101", item?.id)
        assertEquals("Sakura Nights", item?.title)
    }

    @Test
    fun `parseWorkList skips blurbs that carry no work id at all`() {
        val html = """
            <html><body>
            <ol class="work index group">
              <li class="work blurb group"><h4 class="heading"><span>Anonymous</span></h4></li>
            </ol>
            </body></html>
        """.trimIndent()
        assertTrue(parseWorkList(Jsoup.parse(html)).isEmpty())
    }

    // ---------------------------------------------------------------- fixtures

    private companion object {
        /**
         * 按 `_work_header.html.erb` + `_work_meta.html.erb` + `_stats.html.erb`
         * 还原的作品页最小骨架。
         */
        val WORK_PAGE = """
            <html>
            <head><title>Chapter 1 - Sakura Nights - Archive of Our Own</title></head>
            <body>
              <div id="main" class="works-show region">
                <ul id="skiplinks"><li><a href="#work">Work</a></li></ul>
                <div class="flash"></div>
                <div id="workskin">
                  <div class="primary header module">
                    <ul class="tags commas meta"><li class="rating">Teen And Up Audiences</li></ul>
                    <div class="header">
                      <h2 class="title heading">Sakura Nights</h2>
                      <h3 class="byline heading">
                        <a rel="author" href="/users/StarDust/pseuds/StarDust">StarDust</a>,
                        <a rel="author" href="/users/CoAuthor/pseuds/CoAuthor">CoAuthor</a>
                      </h3>
                      <div class="module"><h3 class="landmark heading">Summary</h3>
                        <div class="userstuff"><p>A short test work.</p></div></div>
                    </div>
                    <dl class="work meta group">
                      <dt class="rating">Rating:</dt>
                      <dd class="rating tags">Teen And Up Audiences</dd>
                      <dt class="fandom">Fandom:</dt>
                      <dd class="fandom tags">
                        <ul class="commas tags">
                          <li class="fandom"><a href="/tags/Original%20Work/works">Original Work</a></li>
                          <li class="fandom"><a href="/tags/Haikyuu!!/works">Haikyuu!!</a></li>
                        </ul>
                      </dd>
                      <dt class="stats">Stats:</dt>
                      <dd class="stats">
                        <dl class="stats">
                          <dt class="language">Language:</dt><dd class="language">English</dd>
                          <dt class="words">Words:</dt><dd class="words">12,345</dd>
                          <dt class="chapters">Chapters:</dt><dd class="chapters">3/5</dd>
                          <dt class="comments">Comments:</dt><dd class="comments">7</dd>
                        </dl>
                      </dd>
                    </dl>
                  </div>
                  <div id="chapters" role="article">
                    <div class="module userstuff"><p>Chapter one body text.</p></div>
                  </div>
                </div>
              </div>
            </body>
            </html>
        """.trimIndent()

        /**
         * `_work_blurb.html.erb` + `_work_module.html.erb` 还原的作品条目：
         * 受限标记、模板注释里的 `updated_at`、分级预警四徽章（`ul.required-tags`，
         * 对齐 `get_symbols_for` 的输出）、按类型拆开的 tag、fandoms / summary / stats 齐备。
         */
        val BLURB_101 = """
            <li id="work_101" class="work blurb group" role="article">
              <div class="header module">
                <!-- updated_at=1700000000 -->
                <h4 class="heading">
                  <a href="/works/101">Sakura Nights</a>
                  by <a rel="author" href="/users/StarDust/pseuds/StarDust">StarDust</a>
                  <img alt="(Restricted)" title="Restricted" src="/images/lockblue.png" />
                </h4>
                <h5 class="fandoms heading">
                  <span class="landmark">Fandoms:</span>
                  <a class="tag" href="/tags/Original%20Work/works">Original Work</a>
                </h5>
                <ul class="required-tags">
                  <li><a class="help symbol question" href="/help/symbols-key.html" title="Symbols key"><span class="rating-mature rating" title="Mature"><span class="text">Mature</span></span></a></li>
                  <li><a class="help symbol question" href="/help/symbols-key.html" title="Symbols key"><span class="warning-choosenotto warnings" title="Creator Chose Not To Use Archive Warnings"><span class="text">Creator Chose Not To Use Archive Warnings</span></span></a></li>
                  <li><a class="help symbol question" href="/help/symbols-key.html" title="Symbols key"><span class="category-slash category" title="M/M"><span class="text">M/M</span></span></a></li>
                  <li><a class="help symbol question" href="/help/symbols-key.html" title="Symbols key"><span class="complete-yes iswip" title="Complete Work"><span class="text">Complete Work</span></span></a></li>
                </ul>
                <p class="datetime">2023-11-14</p>
              </div>
              <h6 class="landmark heading">Tags</h6>
              <ul class="tags commas">
                <li class="warnings"><a class="tag" href="/tags/Creator%20Chose%20Not%20To%20Use%20Archive%20Warnings/works">Creator Chose Not To Use Archive Warnings</a></li>
                <li class="relationships"><a class="tag" href="/tags/StarDust*s*CoAuthor/works">StarDust/CoAuthor</a></li>
                <li class="characters"><a class="tag" href="/tags/StarDust/works">StarDust (character)</a></li>
                <li><a class="tag" href="/tags/Fluff/works">Fluff</a></li>
                <li><a class="tag" href="/tags/Angst/works">Angst</a></li>
              </ul>
              <h6 class="landmark heading">Summary</h6>
              <blockquote class="userstuff summary"><p>A test summary.</p></blockquote>
              <dl class="stats">
                <dt class="language">Language:</dt><dd class="language">English</dd>
                <dt class="words">Words:</dt><dd class="words">12,345</dd>
                <dt class="chapters">Chapters:</dt><dd class="chapters">3/5</dd>
                <dt class="comments">Comments:</dt><dd class="comments"><a href="/works/101?show_comments=true#comments">7</a></dd>
                <dt class="kudos">Kudos:</dt><dd class="kudos"><a href="/works/101/kudos">42</a></dd>
                <dt class="bookmarks">Bookmarks:</dt><dd class="bookmarks"><a href="/works/101/bookmarks">5</a></dd>
                <dt class="hits">Hits:</dt><dd class="hits">999</dd>
              </dl>
            </li>
        """.trimIndent()

        /** 第二个条目：多作者、未受限、无 `updated_at` 注释（走可见日期兜底）。 */
        val BLURB_202 = """
            <li id="work_202" class="work blurb group" role="article">
              <div class="header module">
                <h4 class="heading">
                  <a href="/works/202?view_adult=true">Fallen Leaves</a>
                  by <a rel="author" href="/users/CoAuthor/pseuds/CoAuthor">CoAuthor</a>,
                  <a rel="author" href="/users/Guest/pseuds/Guest">Guest</a>
                </h4>
                <h5 class="fandoms heading">
                  <span class="landmark">Fandoms:</span>
                  <a class="tag" href="/tags/Kite/works">Kite</a>
                </h5>
                <p class="datetime">2024-01-02</p>
              </div>
              <h6 class="landmark heading">Tags</h6>
              <ul class="tags commas">
                <li><a class="tag" href="/tags/Hurt%2FComfort/works">Hurt/Comfort</a></li>
              </ul>
              <dl class="stats">
                <dt class="words">Words:</dt><dd class="words">8,900</dd>
                <dt class="chapters">Chapters:</dt><dd class="chapters">1/1</dd>
              </dl>
            </li>
        """.trimIndent()

        /**
         * `app/views/works/search_results.html.erb`（sr.erb）还原的搜索结果页：
         * 标题层级 + `ol.work.index.group` + `will_paginate` 分页。
         */
        val SEARCH_RESULTS = """
            <html>
            <head><title>Search Results - Archive of Our Own</title></head>
            <body>
              <h2 class="heading">Search Results</h2>
              <h4 class="heading">You searched for: sakura</h4>
              <div id="main" class="works-search region">
                <h3 class="heading">42 Found</h3>
                <h3 class="landmark heading">Works List</h3>
                <ol class="work index group">
                  $BLURB_101
                  $BLURB_202
                </ol>
                <div class="pagination">
                  <em class="current">1</em>
                  <a class="next_page" rel="next" href="/works/search?page=2&amp;work_search%5Bquery%5D=sakura">Next &rsaquo;</a>
                </div>
              </div>
            </body>
            </html>
        """.trimIndent()

        /** `app/views/works/index.html.erb` 还原的作者作品列表页：同一个容器、同一段条目。 */
        val AUTHOR_INDEX = """
            <html>
            <head><title>Works - Archive of Our Own</title></head>
            <body>
              <h2 class="heading">2 Works</h2>
              <h3 class="landmark heading">Listing Works</h3>
              <ol class="work index group">
                $BLURB_101
                $BLURB_202
              </ol>
            </body>
            </html>
        """.trimIndent()
    }
}
