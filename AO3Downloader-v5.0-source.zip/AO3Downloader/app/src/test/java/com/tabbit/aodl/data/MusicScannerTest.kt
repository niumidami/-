package com.tabbit.aodl.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 本地音乐扫描规则的离线断言（v5.1 本地音乐入口）。
 *
 * [MusicScanner] 是纯对象：扩展名白名单、展示名、大小格式化都在这里验证。
 */
class MusicScannerTest {

    @Test
    fun `audio extensions are matched case insensitively`() {
        assertTrue(MusicScanner.isAudioFile("song.mp3"))
        assertTrue(MusicScanner.isAudioFile("Song.FLAC"))
        assertTrue(MusicScanner.isAudioFile("a.m4a"))
        assertTrue(MusicScanner.isAudioFile("b.OGG"))
        assertTrue(MusicScanner.isAudioFile("c.opus"))
        assertTrue(MusicScanner.isAudioFile("d.wav"))
    }

    @Test
    fun `non audio names are rejected`() {
        assertFalse(MusicScanner.isAudioFile(null))
        assertFalse(MusicScanner.isAudioFile(""))
        assertFalse(MusicScanner.isAudioFile("cover.jpg"))
        assertFalse(MusicScanner.isAudioFile("lyrics.lrc"))
        assertFalse(MusicScanner.isAudioFile("no-extension"))
        assertFalse(MusicScanner.isAudioFile(".hidden"))
        assertFalse(MusicScanner.isAudioFile("folder."))
    }

    @Test
    fun `display title strips the last extension only`() {
        assertEquals("song", MusicScanner.displayTitle("song.mp3"))
        assertEquals("my.love.song", MusicScanner.displayTitle("my.love.song.flac"))
        assertEquals("noext", MusicScanner.displayTitle("noext"))
    }

    @Test
    fun `sort by title ignores case`() {
        val sorted = MusicScanner.sortByTitle(listOf("beta", "Alpha", "gamma")) { it }
        assertEquals(listOf("Alpha", "beta", "gamma"), sorted)
    }

    @Test
    fun `format size covers units`() {
        assertEquals("", MusicScanner.formatSize(0))
        assertEquals("512 B", MusicScanner.formatSize(512))
        assertEquals("1.5 KB", MusicScanner.formatSize(1536))
        assertEquals("3.3 MB", MusicScanner.formatSize(3_500_000))
        assertEquals("2.00 GB", MusicScanner.formatSize(2_147_483_648L))
    }
}
