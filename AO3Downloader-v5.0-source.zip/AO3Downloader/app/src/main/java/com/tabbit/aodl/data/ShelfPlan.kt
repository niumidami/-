package com.tabbit.aodl.data

import com.tabbit.aodl.model.ShelfBook

/**
 * 需求（v5.0 新增 2 / 3）：书架页的纯逻辑——封面、进度、过滤与上限。
 *
 * 全部都是不依赖 Android 的纯函数，界面只负责画：
 * 1. 封面块按标题哈希从 6 套暗色渐变里取一套，同一本书每次都是同一套；
 * 2. 「已读/总章」从 AO3 的章节串（如 `12/15`、`3/?`）解析而来，取不到就不编造进度；
 * 3. 搜索框按标题 / 作者 / tag / 作品编号任一命中即算匹配；
 * 4. 阅读历史同一作品只留最新一条、上限 300；书签上限 200。
 */
object ShelfPlan {

    /** 阅读历史上限。 */
    const val HISTORY_LIMIT = 300

    /** 书签同步上限。 */
    const val BOOKMARK_LIMIT = 200

    /** 6 套暗色渐变（起点色 → 终点色，ARGB）。 */
    val COVERS: List<Pair<Long, Long>> = listOf(
        0xFF2B1B2E to 0xFF5B2B45,
        0xFF1D2433 to 0xFF3A4C63,
        0xFF231D2B to 0xFF4A3A5C,
        0xFF2A1F1B to 0xFF5A3A2A,
        0xFF1B2A26 to 0xFF2F5247,
        0xFF2A1B23 to 0xFF63303C
    )

    /** 按标题哈希取封面下标；标题为空时用作品编号兜底，保证同一本书稳定。 */
    fun coverIndex(title: String, fallbackKey: String = ""): Int {
        val key = title.trim().ifBlank { fallbackKey.trim() }
        if (key.isEmpty()) return 0
        val size = COVERS.size
        return ((key.hashCode() % size) + size) % size
    }

    fun coverOf(title: String, fallbackKey: String = ""): Pair<Long, Long> = COVERS[coverIndex(title, fallbackKey)]

    /** 封面块上的首字：取标题第一个非空白字符，标题为空时用 `#`。 */
    fun initial(title: String): String {
        val ch = title.trim().firstOrNull() ?: return "#"
        return ch.toString()
    }

    /**
     * 解析 AO3 的章节串。
     *
     * 站点格式是 `已发布/总章`（`12/15`）；未知总章显示为 `?`（`3/?`），
     * 这种情况下总章记 0，界面退化成"只有章节数、不显示进度条"。
     */
    fun chaptersTotal(chapters: String): Int = chapters.trim().substringAfter('/', "").toIntOrNull() ?: 0

    fun chaptersPublished(chapters: String): Int = chapters.trim().substringBefore('/').toIntOrNull() ?: 0

    /** 进度 = 已读 / 总章；总章未知时返回 0，不画推断出来的进度。 */
    fun progress(readChapters: Int, totalChapters: Int): Float {
        if (totalChapters <= 0) return 0f
        return (readChapters.toFloat() / totalChapters).coerceIn(0f, 1f)
    }

    /** 搜索：标题 / 作者 / tag / 作品编号任一命中即匹配（大小写不敏感）。 */
    fun matches(book: ShelfBook, query: String): Boolean {
        val keyword = query.trim().lowercase()
        if (keyword.isEmpty()) return true
        val haystacks = listOf(book.title, book.authors, book.tags, book.workId)
        return haystacks.any { it.lowercase().contains(keyword) }
    }

    fun filter(books: List<ShelfBook>, query: String): List<ShelfBook> =
        if (query.isBlank()) books else books.filter { matches(it, query) }

    /**
     * 记一条阅读历史：同一作品只保留最新一条，最新在最前，超出上限丢弃最早的。
     *
     * 命中已有条目时会继承其阅读进度，只刷新标题、作者等站点字段与时间戳，
     * 避免「刚读到第 9 章，回列表看一眼进度就被清零」。
     */
    fun recordHistory(
        books: List<ShelfBook>,
        item: ShelfBook,
        limit: Int = HISTORY_LIMIT
    ): List<ShelfBook> {
        val key = item.workId.trim()
        if (key.isEmpty()) return books
        val previous = books.firstOrNull { it.workId == key }
        val merged = item.copy(
            readChapters = maxOf(item.readChapters, previous?.readChapters ?: 0),
            group = item.group.ifBlank { previous?.group.orEmpty() },
            addedAt = if (item.addedAt > 0L) item.addedAt else System.currentTimeMillis()
        )
        val rest = books.filterNot { it.workId == key }
        return (listOf(merged) + rest).take(limit)
    }

    /** 加入书架：已在架上则原样返回（调用方据此提示"已存在"）。 */
    fun addToShelf(books: List<ShelfBook>, item: ShelfBook): List<ShelfBook> {
        val key = item.workId.trim()
        if (key.isEmpty()) return books
        if (books.any { it.workId == key }) return books
        val entry = item.copy(addedAt = if (item.addedAt > 0L) item.addedAt else System.currentTimeMillis())
        return listOf(entry) + books
    }

    fun removeFromShelf(books: List<ShelfBook>, workId: String): List<ShelfBook> =
        books.filterNot { it.workId == workId.trim() }

    fun onShelf(books: List<ShelfBook>, workId: String): Boolean =
        books.any { it.workId == workId.trim() }

    /**
     * 书签同步：按作者书签顺序去重后截到上限，超出部分直接丢掉并在日志里说明。
     */
    fun syncBookmarks(
        existing: List<ShelfBook>,
        fetched: List<ShelfBook>,
        limit: Int = BOOKMARK_LIMIT
    ): List<ShelfBook> {
        val seen = LinkedHashMap<String, ShelfBook>()
        fetched.forEach { book ->
            val key = book.workId.trim()
            if (key.isEmpty()) return@forEach
            val previous = existing.firstOrNull { it.workId == key }
            seen[key] = if (previous != null) book.copy(addedAt = previous.addedAt) else book
        }
        return seen.values.take(limit).toList()
    }

    /** 更新阅读进度：把「已读到第几章」写回书架与历史。 */
    fun withProgress(books: List<ShelfBook>, workId: String, readChapters: Int): List<ShelfBook> {
        val key = workId.trim()
        return books.map { book ->
            if (book.workId == key) book.copy(readChapters = maxOf(0, readChapters)) else book
        }
    }

    /** 分组标签：没有分组时统一显示为「未分组」占位，界面据此决定是否画标签。 */
    fun hasGroup(book: ShelfBook): Boolean = book.group.isNotBlank()
}