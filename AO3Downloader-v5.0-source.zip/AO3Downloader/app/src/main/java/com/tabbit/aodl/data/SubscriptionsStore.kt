package com.tabbit.aodl.data

import com.tabbit.aodl.model.SubscribedAuthor
import com.tabbit.aodl.model.WorkItem
import com.tabbit.aodl.model.WorkKind

/**
 * 「我的订阅」本地名单（v5.1）：订阅的作品 + 订阅的作者。
 *
 * 只做 App 内本地维护：作品按编号去重、作者按用户名去重；订阅的作品连**卡片所需的字段**
 * 一起存下来（标题、作者、分级预警四徽章、tag、统计行、编号），因此列表离线也能按统一的
 * 卡片格式渲染，不必为了画一张卡片再去请求站点。
 *
 * 与原站的双向同步（订阅回站点）属于账号同步模块，这里只负责编解码、增删与去重。
 * 纯对象，可直接跑 JVM 单测。
 */
object SubscriptionsStore {

    /** 订阅作品 / 作者各自的上限。 */
    const val MAX_WORKS = 200
    const val MAX_AUTHORS = 200

    /** 作品记录字段数；解码时少于该数量的行视为坏行丢弃。 */
    private const val WORK_FIELDS = 24

    // ------------------------------------------------------------------ 订阅的作品

    fun decodeWorks(raw: String?): List<WorkItem> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(RecordCodec.ROW).mapNotNull { decodeWorkRow(it) }
    }

    fun encodeWorks(items: List<WorkItem>): String =
        items.filter { it.id.isNotBlank() }
            .distinctBy { it.id }
            .take(MAX_WORKS)
            .joinToString(RecordCodec.ROW.toString()) { encodeWorkRow(it) }

    fun containsWork(items: List<WorkItem>, id: String): Boolean =
        items.any { it.id == id.trim() }

    /** 订阅（已存在则原样返回，相当于幂等的新增）。 */
    fun addWork(items: List<WorkItem>, item: WorkItem): List<WorkItem> {
        if (item.id.isBlank()) return items
        if (containsWork(items, item.id)) return items
        return (items + item.copy(selected = false)).take(MAX_WORKS)
    }

    fun removeWork(items: List<WorkItem>, id: String): List<WorkItem> =
        items.filterNot { it.id == id.trim() }

    /** 订阅 / 取消订阅一键切换。 */
    fun toggleWork(items: List<WorkItem>, item: WorkItem): List<WorkItem> =
        if (containsWork(items, item.id)) removeWork(items, item.id) else addWork(items, item)

    private fun encodeWorkRow(item: WorkItem): String = RecordCodec.encodeRow(
        listOf(
            item.id,
            item.title,
            item.authors,
            item.words,
            item.chapters,
            item.updated,
            item.fandoms,
            item.tags,
            item.language,
            if (item.restricted) "1" else "0",
            item.kind.name,
            item.rating,
            item.archiveWarnings,
            item.categories,
            item.completion,
            RecordCodec.encodeList(item.warningTags),
            RecordCodec.encodeList(item.relationshipTags),
            RecordCodec.encodeList(item.characterTags),
            RecordCodec.encodeList(item.freeformTags),
            item.summary,
            item.comments,
            item.kudos,
            item.bookmarks,
            item.hits
        )
    )

    private fun decodeWorkRow(row: String): WorkItem? {
        val parts = RecordCodec.decodeRow(row) ?: return null
        if (parts.size < WORK_FIELDS) return null
        val id = parts[0].trim()
        if (id.isEmpty()) return null
        return WorkItem(
            id = id,
            title = parts[1],
            authors = parts[2],
            words = parts[3],
            chapters = parts[4],
            updated = parts[5],
            fandoms = parts[6],
            tags = parts[7],
            language = parts[8],
            restricted = parts[9] == "1",
            kind = runCatching { WorkKind.valueOf(parts[10]) }.getOrDefault(WorkKind.WORK),
            rating = parts[11],
            archiveWarnings = parts[12],
            categories = parts[13],
            completion = parts[14],
            warningTags = RecordCodec.decodeList(parts[15]),
            relationshipTags = RecordCodec.decodeList(parts[16]),
            characterTags = RecordCodec.decodeList(parts[17]),
            freeformTags = RecordCodec.decodeList(parts[18]),
            summary = parts[19],
            comments = parts[20],
            kudos = parts[21],
            bookmarks = parts[22],
            hits = parts[23]
        )
    }

    // ------------------------------------------------------------------ 订阅的作者

    fun decodeAuthors(raw: String?): List<SubscribedAuthor> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(RecordCodec.ROW).mapNotNull { row ->
            val parts = RecordCodec.decodeRow(row) ?: return@mapNotNull null
            val name = parts.firstOrNull()?.trim().orEmpty()
            if (name.isEmpty()) return@mapNotNull null
            SubscribedAuthor(
                username = name,
                addedAt = parts.getOrNull(1)?.toLongOrNull() ?: 0L
            )
        }.distinctBy { it.username.lowercase() }.take(MAX_AUTHORS)
    }

    fun encodeAuthors(list: List<SubscribedAuthor>): String =
        list.filter { it.username.isNotBlank() }
            .distinctBy { it.username.lowercase() }
            .take(MAX_AUTHORS)
            .joinToString(RecordCodec.ROW.toString()) { author ->
                RecordCodec.encodeRow(listOf(author.username, author.addedAt.toString()))
            }

    fun containsAuthor(list: List<SubscribedAuthor>, username: String): Boolean =
        list.any { it.username.equals(username.trim(), ignoreCase = true) }

    fun addAuthor(
        list: List<SubscribedAuthor>,
        username: String,
        addedAt: Long = 0L
    ): List<SubscribedAuthor> {
        val name = username.trim()
        if (name.isEmpty()) return list
        if (containsAuthor(list, name)) return list
        return (list + SubscribedAuthor(username = name, addedAt = addedAt)).take(MAX_AUTHORS)
    }

    fun removeAuthor(list: List<SubscribedAuthor>, username: String): List<SubscribedAuthor> =
        list.filterNot { it.username.equals(username.trim(), ignoreCase = true) }

    fun toggleAuthor(
        list: List<SubscribedAuthor>,
        username: String,
        addedAt: Long = 0L
    ): List<SubscribedAuthor> =
        if (containsAuthor(list, username)) removeAuthor(list, username) else addAuthor(list, username, addedAt)
}