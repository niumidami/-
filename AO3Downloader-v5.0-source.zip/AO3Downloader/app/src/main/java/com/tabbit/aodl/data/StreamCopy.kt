package com.tabbit.aodl.data

import com.tabbit.aodl.model.DownloadFormat
import okio.BufferedSource
import java.io.OutputStream

/** 流式写盘的结果；不依赖 Android API，可在 JVM 单测里断言。 */
internal sealed class CopyResult {

    data class Ok(val bytes: Long) : CopyResult()

    data class Err(val reason: CopyError, val detail: String = "") : CopyResult()

    data class Cancelled(val bytes: Long) : CopyResult()
}

internal enum class CopyError { IO, INCOMPLETE, INVALID_CONTENT }

/**
 * 把响应体流式写入输出流，并在写盘过程中完成完整性校验（v4.2 修复 #2）。
 *
 * ### 为什么要改
 *
 * 旧实现只以「读不到数据（EOF）」判定完成，从不比对服务端声明的总长。
 * 响应体被**提前且正常地**结束时（链路被重置后优雅收尾、chunked 提前结束等），
 * 残缺内容会被当成"下载成功"重命名为正式文件，用户打开就是损坏的 PDF——
 * 这正是用户实测「PDF 打开都是坏的」的可复现路径之一。
 *
 * ### 两道校验
 *
 * 1. **头部魔数**：从 0 开始时先按 [FormatSignature] 校验首字节，内容根本不对
 *    （HTML 提示页、被拦截的响应）立刻中止，返回 [CopyError.INVALID_CONTENT]，
 *    上层会删除残片而不是留下一个打不开的"成品"；
 * 2. **字节总数**：服务端声明了总长时，写完必须**正好等于**声明值，
 *    少了（截断）或多了都判 [CopyError.INCOMPLETE]，交给上层保留 `.part` 重试/续传。
 *
 * [totalLength] 为 0 或负数表示服务端未声明（chunked），此时跳过第 2 项校验；
 * [baseOffset] 大于 0 表示续传，头部字节已在本地文件中，跳过第 1 项校验。
 *
 * 收尾时的判定顺序是「先总长、后头部」：内容为空或被截断优先按 [CopyError.INCOMPLETE]
 * 处理（残片有续传价值，上层会保留并重试），只有字节数对得上、内容却不对时才判
 * [CopyError.INVALID_CONTENT]（残片毫无价值，上层会删除且不再重试）。
 * 写入途中一旦凑够头部字节就立即校验，非法内容一个字节都不会落盘。
 */
internal object StreamCopy {

    const val BUFFER_SIZE = 64 * 1024

    /** 进度回调触发条件：写满 64 KiB 或超过 250 ms，取先到者。 */
    private const val PROGRESS_BYTES = 64 * 1024L
    private const val PROGRESS_MILLIS = 250L

    /** 速度采样窗口，用指数移动平均抑制抖动。 */
    private const val SPEED_WINDOW_MILLIS = 800L

    /**
     * @param totalLength 服务端声明的完整文件大小；未知（chunked）时传 0 或负数
     * @param baseOffset 续传时本地已有字节数，进度按 `baseOffset + 本次写入` 上报
     * @param format 请求的格式，用于头部魔数校验；null 表示不校验
     * @param onProgress `(已写入总字节, 完整大小, 瞬时速度 B/s)`，返回 false 表示用户取消
     */
    fun copy(
        source: BufferedSource,
        output: OutputStream,
        totalLength: Long,
        baseOffset: Long = 0L,
        format: DownloadFormat? = null,
        onProgress: (written: Long, total: Long, speedBps: Long) -> Boolean = { _, _, _ -> true }
    ): CopyResult {
        var written = 0L
        var lastReportBytes = 0L
        var windowStartBytes = 0L
        var speed = 0L
        val buffer = ByteArray(BUFFER_SIZE)
        val head = ByteArray(FormatSignature.HEAD_BYTES)
        var headLength = 0
        var headChecked = baseOffset > 0L || format == null
        val input = source.inputStream()
        val startedAt = System.currentTimeMillis()
        var lastReportAt = startedAt
        var windowStartAt = startedAt

        try {
            output.use { out ->
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    if (read == 0) continue

                    if (!headChecked) {
                        val take = minOf(read, head.size - headLength)
                        if (take > 0) {
                            System.arraycopy(buffer, 0, head, headLength, take)
                            headLength += take
                        }
                        if (headLength >= head.size) {
                            headChecked = true
                            FormatSignature.check(format!!, head, headLength)?.let { reason ->
                                return CopyResult.Err(CopyError.INVALID_CONTENT, reason)
                            }
                        }
                    }

                    out.write(buffer, 0, read)
                    written += read

                    val now = System.currentTimeMillis()
                    val elapsedWindow = now - windowStartAt
                    if (elapsedWindow >= SPEED_WINDOW_MILLIS) {
                        val delta = written - windowStartBytes
                        speed = if (delta > 0 && elapsedWindow > 0) {
                            delta * 1000L / elapsedWindow
                        } else {
                            speed
                        }
                        windowStartAt = now
                        windowStartBytes = written
                    }

                    val dueBytes = written - lastReportBytes >= PROGRESS_BYTES
                    val dueTime = now - lastReportAt >= PROGRESS_MILLIS
                    val isEnd = totalLength > 0 && baseOffset + written >= totalLength
                    if (dueBytes || dueTime || isEnd) {
                        lastReportBytes = written
                        lastReportAt = now
                        if (!onProgress(baseOffset + written, totalLength, speed)) {
                            out.flush()
                            return CopyResult.Cancelled(baseOffset + written)
                        }
                    }
                }
                out.flush()
            }
        } catch (e: Exception) {
            return CopyResult.Err(CopyError.IO, "${e.javaClass.simpleName}: ${e.message.orEmpty()}")
        }

        val bytes = baseOffset + written

        // 先比总长：内容为空或被截断时优先按「不完整」处理，交给上层保留 `.part` 重试续传；
        // 总长对得上（或压根没声明）才轮到头部校验，判定内容是不是该格式。
        if (totalLength > 0L && bytes != totalLength) {
            return CopyResult.Err(
                CopyError.INCOMPLETE,
                "expected=$totalLength got=$bytes"
            )
        }

        // 内容太短、还没凑够头部校验字节的响应（例如几百字节的错误页）在这里补一次
        if (!headChecked) {
            FormatSignature.check(format!!, head, headLength)?.let { reason ->
                return CopyResult.Err(CopyError.INVALID_CONTENT, reason)
            }
        }

        return CopyResult.Ok(bytes)
    }
}