package com.tabbit.aodl.ui

import android.text.format.DateUtils
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.data.BookmarkCopy
import com.tabbit.aodl.data.NekoText
import com.tabbit.aodl.model.AccountState
import com.tabbit.aodl.model.CookieSource
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 我的账号：登录状态、账号密码登录、手动 Cookie 备用入口、Session 校验与收藏列表。
 *
 * 密码只存在于本页的临时 state 中，提交后立即清空，不会写入 SharedPreferences。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    vm: AppViewModel,
    onOpenSettings: () -> Unit,
    /** 需求 5：打开官网登录层，由用户自行在官网页面完成登录。 */
    onOpenWebLogin: () -> Unit
) {
    val account by vm.account.collectAsStateWithLifecycle()
    val bookmarks by vm.bookmarks.collectAsStateWithLifecycle()
    val icon by vm.icon.collectAsStateWithLifecycle()
    // v4.6：收藏条目的复制动作直接写系统剪贴板
    val clipboard = LocalClipboardManager.current

    var loginInput by rememberSaveable { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var rememberMe by rememberSaveable { mutableStateOf(true) }
    var manualName by rememberSaveable { mutableStateOf("") }
    var manualCookie by rememberSaveable { mutableStateOf("") }
    var showLogoutDialog by rememberSaveable { mutableStateOf(false) }
    var showManual by rememberSaveable { mutableStateOf(false) }

    // 登录成功后立即清空输入框中的密码与用户名
    LaunchedEffect(account.loggedIn) {
        if (account.loggedIn) {
            passwordInput = ""
            loginInput = ""
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        CenterAlignedTopAppBar(
            title = {
                ScreenTitle(
                    icon = icon,
                    text = stringResource(R.string.screen_account_title)
                )
            },
            actions = {
                IconButton(onClick = onOpenSettings) {
                    Icon(
                        Icons.Filled.Settings,
                        contentDescription = stringResource(R.string.action_settings),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            },
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
                titleContentColor = MaterialTheme.colorScheme.onBackground
            )
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
        ) {
            StatusCard(account = account)

            // 需求 5：官网登录（推荐）。用户在官网页面里自己输入账号密码，
            // 验证码与两步验证都在官网完成，本应用只提取登录后的会话 Cookie，密码不经手、不落盘。
            SectionTitle(
                text = stringResource(R.string.account_web_title),
                subtitle = stringResource(R.string.account_web_subtitle)
            )
            SakuraCard {
                GradientButton(
                    text = if (account.loggedIn) {
                        stringResource(R.string.account_web_relogin)
                    } else {
                        stringResource(R.string.account_web_button)
                    },
                    onClick = onOpenWebLogin,
                    icon = Icons.Filled.Language
                )
            }

            if (!account.loggedIn) {
                SectionTitle(text = stringResource(R.string.account_login_title))
                SakuraCard {
                    SakuraTextField(
                        value = loginInput,
                        onValueChange = { loginInput = it },
                        label = stringResource(R.string.account_username),
                        imeAction = ImeAction.Next
                    )
                    Spacer(Modifier.height(10.dp))
                    SakuraTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        label = stringResource(R.string.account_password),
                        password = true,
                        imeAction = ImeAction.Done
                    )
                    SwitchRow(
                        title = stringResource(R.string.account_remember),
                        checked = rememberMe,
                        onCheckedChange = { rememberMe = it }
                    )
                    if (account.message.isNotBlank()) {
                        Text(
                            text = NekoText.catify(account.message),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(Modifier.height(6.dp))
                    }
                    Text(
                        text = stringResource(R.string.account_login_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.textSecondary
                    )
                    Spacer(Modifier.height(12.dp))
                    GradientButton(
                        text = stringResource(R.string.account_login),
                        onClick = {
                            vm.login(loginInput.trim(), passwordInput, rememberMe)
                            passwordInput = ""
                        },
                        enabled = loginInput.isNotBlank() && passwordInput.isNotEmpty(),
                        loading = account.busy,
                        icon = Icons.Filled.Login
                    )
                    Spacer(Modifier.height(10.dp))
                    SecondaryButton(
                        text = stringResource(R.string.account_manual_title),
                        onClick = { showManual = !showManual },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (showManual) {
                        Spacer(Modifier.height(12.dp))
                        ManualCookieForm(
                            username = manualName,
                            onUsernameChange = { manualName = it },
                            cookie = manualCookie,
                            onCookieChange = { manualCookie = it },
                            onSubmit = {
                                vm.applyManualCookie(manualName, manualCookie)
                                manualCookie = ""
                            }
                        )
                    }
                }
            } else {
                SectionTitle(text = stringResource(R.string.account_info_title))
                SakuraCard {
                    ValueRow(
                        title = stringResource(R.string.account_info_name),
                        value = account.username.ifBlank { "—" },
                        valueColor = MaterialTheme.colorScheme.primary
                    )
                    ValueRow(
                        title = stringResource(R.string.account_info_source),
                        value = sourceLabel(account.cookieSource)
                    )
                    ValueRow(
                        title = stringResource(R.string.account_info_login_at),
                        value = formatTime(account.loginAt)
                    )
                    ValueRow(
                        title = stringResource(R.string.account_info_last_check),
                        value = sessionLabel(account.lastCheckOk),
                        valueColor = when (account.lastCheckOk) {
                            true -> MaterialTheme.ext.success
                            false -> MaterialTheme.colorScheme.error
                            null -> null
                        }
                    )
                    if (account.cookiePreview.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = stringResource(R.string.account_info_cookie),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.ext.textSecondary
                        )
                        Text(
                            text = account.cookiePreview,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.ext.textSecondary,
                            maxLines = 3
                        )
                    }
                    if (account.message.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = NekoText.catify(account.message),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SecondaryButton(
                            text = stringResource(R.string.account_verify),
                            onClick = { vm.verifySession(silent = false) },
                            icon = Icons.Filled.VerifiedUser,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = { showLogoutDialog = true },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.account_logout), fontSize = 13.sp)
                        }
                    }
                }

                /* --------------------------------------------------- 收藏 */
                SectionTitle(
                    text = stringResource(R.string.account_bookmarks_title),
                    subtitle = stringResource(R.string.account_bookmarks_subtitle)
                )
                SakuraCard {
                    if (bookmarks.error.isNotBlank()) {
                        Text(
                            text = bookmarks.error,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    if (bookmarks.items.isEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (bookmarks.loading) {
                                CatLoading(size = 28.dp)
                                Spacer(Modifier.width(10.dp))
                            }
                            Text(
                                text = if (bookmarks.loading) {
                                    stringResource(R.string.author_loading_more)
                                } else {
                                    stringResource(R.string.account_bookmarks_empty)
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.ext.textSecondary
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        GradientButton(
                            text = stringResource(R.string.account_bookmarks_load),
                            onClick = { vm.loadBookmarks(reset = true) },
                            enabled = !bookmarks.loading,
                            icon = Icons.Filled.BookmarkBorder
                        )
                    } else {
                        bookmarks.items.forEach { item ->
                            BookmarkRow(
                                item = item,
                                onDownload = { vm.downloadBookmark(item) },
                                onCopy = { target ->
                                    // 复制内容取自条目已有字段，不再发请求；空内容直接忽略
                                    val text = BookmarkCopy.payload(target, item.authors, item.id)
                                    if (text.isNotEmpty()) {
                                        clipboard.setText(AnnotatedString(text))
                                        vm.noteCopied(target, text)
                                    }
                                }
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (bookmarks.hasMore) {
                                SecondaryButton(
                                    text = stringResource(R.string.account_bookmarks_more),
                                    onClick = { vm.loadBookmarks(reset = false) },
                                    enabled = !bookmarks.loading,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            SecondaryButton(
                                text = stringResource(R.string.account_bookmarks_load),
                                onClick = { vm.loadBookmarks(reset = true) },
                                enabled = !bookmarks.loading,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            /* 原「管理」一级入口取消后并入「我的」：下载管理（格式 / 保存位置 / 运行日志）。 */
            Spacer(Modifier.height(16.dp))
            DownloadManageSections(vm = vm, onOpenSettings = onOpenSettings)
        }
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            containerColor = MaterialTheme.ext.card,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            textContentColor = MaterialTheme.ext.textSecondary,
            title = { Text(stringResource(R.string.account_logout_title)) },
            text = { Text(NekoText.catify(stringResource(R.string.account_logout_message))) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showLogoutDialog = false
                        vm.logout()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.account_logout)) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text(stringResource(R.string.cancel), color = MaterialTheme.colorScheme.primary)
                }
            }
        )
    }
}

@Composable
private fun StatusCard(account: AccountState) {
    SakuraCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (account.loggedIn) Icons.Filled.CheckCircle else Icons.Filled.Logout,
                contentDescription = null,
                tint = if (account.loggedIn) MaterialTheme.ext.success else MaterialTheme.ext.textSecondary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (account.loggedIn) {
                        account.username.ifBlank { stringResource(R.string.account_state_logged_in) }
                    } else {
                        stringResource(R.string.account_state_logged_out)
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (account.loggedIn && account.lastCheckOk != null) {
                    Text(
                        text = stringResource(R.string.account_info_last_check) + "：" + sessionLabel(account.lastCheckOk),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.textSecondary
                    )
                }
            }
            StatusChip(
                text = if (account.loggedIn) {
                    stringResource(R.string.account_state_logged_in)
                } else {
                    stringResource(R.string.account_state_logged_out)
                },
                color = if (account.loggedIn) MaterialTheme.ext.success else MaterialTheme.ext.warning
            )
        }
    }
}

@Composable
private fun ManualCookieForm(
    username: String,
    onUsernameChange: (String) -> Unit,
    cookie: String,
    onCookieChange: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Column {
        Text(
            text = stringResource(R.string.account_manual_subtitle),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.ext.textSecondary
        )
        Spacer(Modifier.height(8.dp))
        SakuraTextField(
            value = username,
            onValueChange = onUsernameChange,
            label = stringResource(R.string.account_username),
            imeAction = ImeAction.Next
        )
        Spacer(Modifier.height(10.dp))
        SakuraTextField(
            value = cookie,
            onValueChange = onCookieChange,
            label = stringResource(R.string.account_manual_cookie),
            placeholder = "_otwarchive_session=…",
            singleLine = false,
            imeAction = ImeAction.Done
        )
        Spacer(Modifier.height(10.dp))
        GradientButton(
            text = stringResource(R.string.account_manual_apply),
            onClick = onSubmit,
            enabled = cookie.isNotBlank(),
            icon = Icons.Filled.CheckCircle
        )
    }
}

@Composable
private fun sourceLabel(source: CookieSource): String = when (source) {
    CookieSource.PASSWORD -> stringResource(R.string.account_source_password)
    CookieSource.MANUAL -> stringResource(R.string.account_source_manual)
    CookieSource.WEBVIEW -> stringResource(R.string.account_source_web)
    CookieSource.NONE -> stringResource(R.string.account_source_none)
}

@Composable
private fun sessionLabel(ok: Boolean?): String = when (ok) {
    true -> stringResource(R.string.account_session_valid)
    false -> stringResource(R.string.account_session_invalid)
    null -> stringResource(R.string.account_session_unchecked)
}

private val absoluteTimeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

/** 绝对时间 + 相对时间，例如「2026-10-23 06:15（5 分钟前）」。 */
@Composable
private fun formatTime(millis: Long): String {
    if (millis <= 0L) return "—"
    val absolute = absoluteTimeFormat.format(Date(millis))
    val relative = DateUtils.getRelativeTimeSpanString(
        millis,
        System.currentTimeMillis(),
        DateUtils.MINUTE_IN_MILLIS
    ).toString()
    return stringResource(R.string.account_time_format, absolute, relative)
}
