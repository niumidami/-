package com.tabbit.aodl.data

import org.jsoup.Jsoup
import org.jsoup.nodes.DataNode
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.parser.Tag
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * 文档版式美化器（v4.4 起为默认美化风格）。
 *
 * 与 [HtmlBeautifier] 的「注入 CSS 覆盖原排版」不同，本器按 AO3 官方下载模板
 * （`downloads/show` + `_download_preface` + `_download_chapter` + `_download_afterword`）
 * 的结构**解析后重建**整篇文档，输出与参照文档（扉页 / 作品信息 / 前言 / 目录 /
 * 章节 / THE END / 关于）逐项对应的书籍版式，并注入内置「暗夜樱粉」主题。
 *
 * 解析一律按结构定位（`#preface` / `dl.tags` 的 dt-dd 对 / `blockquote.userstuff` /
 * `#chapters` 的 `.meta.group` 与 `div[id^=endnotes]` / `#afterword`），
 * 不依赖任何语言的标签文本；标签文字只用于小节标题的展示归一化。
 */
object DocBeautifier {

    const val APP_NAME = "obkk下载中"

    private const val THEME_STYLE_ID = "aodl-doc-theme"
    private const val CUSTOM_STYLE_ID = "aodl-doc-custom"
    private const val GENERATOR = "obkk-doc-beautifier"
    private const val FALLBACK_TITLE = "Document"

    /** 内置「暗夜樱粉」主题 CSS（用户提供的第二段美化代码，原文未删改）。 */
    val THEME_CSS: String = """
/* ========= 1. 全局基础设置（暗夜樱粉主题） ========= */
* { font-style: normal !important; }

body {
  font-family: "Georgia", "Times New Roman", "Microsoft YaHei", serif;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  line-height: 1.75em;
  color: #e8c9d6;                /* 淡粉白正文 */
  background: #17161a;           /* 深夜黑背景 */
  text-align: justify;
  word-wrap: break-word;
  text-transform: none !important;   /* [修复] 禁止任何首字母强制大写 */
}
h1, h2, h3, h4, h5, h6, b, strong { font-weight: bold !important; }
h1, h2, h3, h4, h5, h6 { color: #f7a8c6; }          /* 标题统一樱粉色 */
a { color: #7fd3f0; text-decoration: none; }         /* 链接用清亮蓝 */
a:hover { color: #a9e5fb; text-decoration: underline; }
.text-center, .text-center * { text-align: center !important; }

/* ========= 2. 页面容器与分页 ========= */
.content-wrapper {
  background: #1e1c22;
  padding: 40px;
  border-radius: 10px;
  box-shadow: 0 2px 14px rgba(0, 0, 0, 0.55);
  border: 1px solid #2c2932;
}
.page-break {
  margin-top: 4em;
  padding-top: 2em;
  border-top: 1px solid #332f3a;
}

/* ========= 3. 扉页 (Title Page) ========= */
.title-page { padding: 4em 2em; text-align: center; }
.title-page h1 {
  font-size: 2.1em !important;
  line-height: 1.4;
  color: #ffb9d4;                /* 扉页大标题：亮粉 */
  letter-spacing: 0.03em;
}
.title-page h2 {
  font-size: 1.3em !important;
  margin-top: 2em;
  color: #d8b6c6;                /* 作者名：灰粉 */
  font-weight: normal !important;
}

/* ========= 4. 作品信息页 (Imprint Page) ========= */
.imprint-page {
  font-size: 0.92em;
  line-height: 1.7em;
  background: #211f26;
  padding: 2em;
  border-radius: 6px;
  border: 1px solid #2f2b36;
  color: #dcc3d0;
}
.imprint-page h2 {
  font-size: 1.4em !important;
  margin-bottom: 1.2em !important;
  padding-bottom: 0.4em;
  border-bottom: 1px solid #4a3f4d;   /* 粉标题下的细分割线 */
}
.imprint-page p { margin: 0.55em 0; padding: 0; }
.meta-label { font-weight: bold; font-size: 1.05em; color: #f7a8c6; }

/* 元数据标签胶囊（分类/关系/角色/预警等） */
.imprint-page .tags li,
.imprint-page li.tag,
.imprint-page .tag {
  display: inline-block;
  background: #2b2731;
  border: 1px solid #453e4e;
  border-radius: 6px;
  padding: 0.15em 0.7em;
  margin: 0.2em 0.35em 0.2em 0;
  color: #dcd2e0;
  font-size: 0.95em;
  list-style: none;
}
.imprint-page li { list-style: none; }

/* 统计行 */
.imprint-page .stats,
.imprint-page .statistics {
  color: #c9a7b8;
  line-height: 1.9em;
}

/* ========= 5. 目录页 (Table of Contents) ========= */
.toc-page { padding: 2em 0; }
.toc-list { list-style: none; padding: 0; margin: 0; }
.toc-item { margin-bottom: 1.0em; line-height: 1.8em; }
.toc-item a {
  text-decoration: none;
  color: #e8c9d6;
  display: block;
  transition: color 0.2s;
  font-size: 1.2em;
  font-weight: 500;
  padding-left: 0.4em;
  border-left: 3px solid transparent;
}
.toc-item a:hover {
  color: #ffb9d4;
  text-decoration: none;
  border-left-color: #f7a8c6;    /* 悬停时左侧出现粉色指示条 */
}

/* ========= 6. 章节与正文 (Chapters & Text) ========= */
.foreword-page h2, .chapter-page h2, .toc-page h2 {
  font-size: 1.7em !important;
  margin-bottom: 1.6em !important;
  padding-bottom: 0.5em;
  border-bottom: 1px solid #4a3f4d;
  color: #ffb9d4;
  text-align: center;
}
.foreword-section h3 {
  font-size: 1.3em !important;
  margin-bottom: 0.5em !important;
  color: #f7a8c6;
}
.chapter-meta {
  font-size: 0.95em;
  margin-bottom: 2.5em;
  padding: 1em 1.2em;
  border-left: 3px solid #f7a8c6;   /* 粉色左侧竖线 */
  background: #211f26;
  border-radius: 0 6px 6px 0;
  color: #d8bccb;
}
.meta-heading { font-size: 1.2em; font-weight: bold; margin-bottom: 0.4em; color: #f7a8c6; }
.chapter-end-notes { margin-top: 3em; color: #c9a7b8; font-size: 0.95em; }

.chapter-text p {
  text-indent: 2em;
  margin: 0 0 1.25em 0;
  line-height: 1.8em;
  color: #e8c9d6;
  text-transform: none !important;   /* [修复] 禁止段落首字母大写 */
}
.chapter-text > p:first-of-type { text-indent: 0; }

/* [修复] 首字下沉：不再放大/浮动首字符，恢复正常显示 */
.drop-cap {
  font-size: inherit !important;
  float: none !important;
  margin: 0 !important;
  line-height: inherit !important;
  color: inherit !important;
}
/* [修复] 保险规则：覆盖 ::first-letter 可能带来的放大效果 */
.chapter-text p::first-letter,
.chapter-text p::first-line {
  font-size: inherit !important;
  text-transform: none !important;
  font-weight: inherit !important;
  color: inherit !important;
  float: none !important;
}

/* ========= 7. 双语对照显示控制 ========= */
.ao3-original-content { display: block; color: inherit; font-weight: inherit; }
.ao3-translated-content {
  display: block;
  margin-top: 1.2em;
  color: #cbb3c2;                 /* 译文稍灰，区分原文 */
  font-weight: inherit;
}
.chapter-text > p:first-of-type .ao3-translated-content { text-indent: 2em; }
.title-page h1 .ao3-translated-content,
.chapter-page h2 .ao3-translated-content {
  margin-top: 1.2em;
  font-size: 0.75em;
  color: #a892a4;
  display: block;
  font-weight: normal !important;
}

/* ========= 8. 结尾与关于页 ========= */
.the-end {
  margin-top: 4em;
  margin-bottom: 2em;
  text-align: center;
  color: #f7a8c6;
  letter-spacing: 0.3em;
}
.about-page { padding-top: 2em; color: #d8bccb; }

/* ========= 9. 移动端适配 ========= */
@media (max-width: 768px) {
  body { padding: 10px; text-align: left; line-height: 1.75em; }
  .content-wrapper { padding: 20px 15px; }
  .title-page { padding: 2em 1em; }
  .title-page h1 { font-size: 1.6em !important; }
  .chapter-text p { text-align: left; }
  .page-break { margin-top: 2em; padding-top: 1em; }
  .imprint-page { padding: 1.5em; }
  .foreword-page h2, .chapter-page h2, .toc-page h2 { font-size: 1.4em !important; }
}
    """.trimIndent()

    // ------------------------------------------------------------ 数据结构

    /** 一个带标题的内容块（Summary / Notes / End Notes 等），[html] 为可直接插入的片段。 */
    data class MetaSection(val label: String, val html: String)

    data class Chapter(
        val label: String,
        val headingRaw: String = "",
        val sections: List<MetaSection> = emptyList(),
        val contentHtml: String = "",
        val endNotes: MetaSection? = null
    )

    data class ParsedWork(
        val title: String,
        val author: String,
        val sourceUrl: String,
        val metaLines: List<MetaSection>,
        val foreword: List<MetaSection>,
        val chapters: List<Chapter>,
        val workEndNotes: MetaSection? = null
    )

    // ------------------------------------------------------------ 入口

    /**
     * 解析 [html] 并重建为书籍版式文档。
     *
     * [customCss] 非空时作为独立样式块追加在主题之后，可覆盖主题规则。
     * 重复美化本器产物时只刷新样式块，不再次重建结构（幂等）。
     */
    fun beautify(html: String, customCss: String = ""): String {
        val doc = Jsoup.parse(html)
        doc.outputSettings().prettyPrint(false)

        // 幂等：已是本生成器产物时仅替换主题/自定义样式
        if (doc.selectFirst("meta[name=generator][content=$GENERATOR]") != null) {
            val theme = doc.selectFirst("style#$THEME_STYLE_ID") ?: return html
            setStyleData(theme, THEME_CSS)
            val custom = doc.selectFirst("style#$CUSTOM_STYLE_ID")
            when {
                customCss.isBlank() -> custom?.remove()
                custom != null -> setStyleData(custom, customCss.trim())
                else -> theme.after(styleElement(CUSTOM_STYLE_ID, customCss.trim()))
            }
            return doc.outerHtml()
        }

        return render(parse(doc), customCss)
    }

    /** 设置页预览：先造一份符合 AO3 官方模板结构的样例源码，再走完整解析-重建链路。 */
    fun sampleDocument(
        title: String,
        author: String,
        summary: String,
        notes: String,
        paragraph1: String,
        paragraph2: String
    ): String {
        val url = "https://archiveofourown.org/works/12345678"
        val source = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>${esc(title)} - ${esc(author)}</title></head>
<body>
<div id="preface">
  <h2 class="toc-heading">Preface</h2>
  <p class="message"><b>${esc(title)}</b><br />Originally posted on <a href="https://archiveofourown.org">Archive of Our Own</a> at <a href="$url">$url</a>.</p>
  <div class="meta">
    <dl class="tags">
      <dt>Rating:</dt><dd>Teen And Up Audiences</dd>
      <dt>Fandoms:</dt><dd>Original Work</dd>
      <dt>Stats</dt>
      <dd>
        Published: 2026-10-01
        Updated: 2026-10-20
        Words: 12,480
        Chapters: 2/2
      </dd>
    </dl>
    <h1>${esc(title)}</h1>
    <div class="byline">by <a href="https://archiveofourown.org/users/sample">${esc(author)}</a></div>
    <p>Summary:</p>
    <blockquote class="userstuff"><p>${esc(summary)}</p></blockquote>
    <p>Notes:</p>
    <blockquote class="userstuff"><p>${esc(notes)}</p></blockquote>
  </div>
</div>
<div id="chapters" class="userstuff">
  <div class="meta group">
    <h2 class="heading">Chapter 1</h2>
  </div>
  <div class="userstuff"><p>${esc(paragraph1)}</p></div>
  <div class="meta" id="endnotes1">
    <p>Chapter End Notes:</p>
    <blockquote class="userstuff"><p>${esc(notes)}</p></blockquote>
  </div>
  <div class="meta group">
    <h2 class="heading">Chapter 2: 站台</h2>
    <p>Chapter Summary:</p>
    <blockquote class="userstuff"><p>${esc(summary)}</p></blockquote>
  </div>
  <div class="userstuff"><p>${esc(paragraph2)}</p></div>
</div>
<div id="afterword"><h2 class="toc-heading">Afterword</h2></div>
</body>
</html>
""".trimIndent()
        return beautify(source)
    }

    // ------------------------------------------------------------ 解析

    internal fun parse(doc: Document): ParsedWork {
        val preface = doc.selectFirst("#preface")
        val chaptersEl = doc.selectFirst("#chapters")
        if (preface == null && chaptersEl == null) return parseGeneric(doc)

        val meta = preface?.selectFirst(".meta")

        val title = meta?.selectFirst("h1")?.text()?.trim()?.takeIf { it.isNotEmpty() }
            ?: doc.title().trim().substringBeforeLast(" - ").ifBlank { FALLBACK_TITLE }

        val bylineEl = meta?.selectFirst(".byline")
        val author = bylineEl?.let { b ->
            val links = b.select("a").map { it.text().trim() }.filter { it.isNotEmpty() }
            if (links.isNotEmpty()) links.joinToString(", ")
            else b.text().trim().replace(Regex("^by\\s+", RegexOption.IGNORE_CASE), "")
        }.orEmpty()

        val sourceUrl = preface?.selectFirst("p.message a[href*=\"/works/\"]")
            ?.attr("href")?.trim().orEmpty()

        val metaLines = mutableListOf<MetaSection>()
        val dts = meta?.select("dl.tags > dt").orEmpty()
        dts.forEachIndexed { index, dt ->
            val dd = dt.nextElementSibling() ?: return@forEachIndexed
            if (dd.tagName() != "dd") return@forEachIndexed
            val label = dt.text().trim()
            if (label.isEmpty()) return@forEachIndexed
            // 官方模板中统计行固定为 dl.tags 最后一组：拆成独立的「标签: 值」行
            if (index == dts.lastIndex) {
                val stats = splitStats(dd)
                if (stats != null) {
                    metaLines += stats
                    return@forEachIndexed
                }
            }
            metaLines += MetaSection(label, esc(dd.text().trim()))
        }

        val foreword = meta?.let { extractLabelBlocks(it) }.orEmpty()

        val chapters = mutableListOf<Chapter>()
        if (chaptersEl != null) {
            val hasGroups = chaptersEl.children().any { it.hasClass("meta") && it.hasClass("group") }
            if (hasGroups) {
                var heading: String? = null
                var sections: List<MetaSection> = emptyList()
                var content: String? = null
                var endNotes: MetaSection? = null

                fun flush() {
                    if (heading != null || content != null) {
                        chapters += Chapter(
                            label = "",
                            headingRaw = heading.orEmpty(),
                            sections = sections,
                            contentHtml = content.orEmpty(),
                            endNotes = endNotes
                        )
                    }
                    heading = null
                    sections = emptyList()
                    content = null
                    endNotes = null
                }

                for (child in chaptersEl.children()) {
                    when {
                        child.hasClass("meta") && child.hasClass("group") -> {
                            flush()
                            heading = child.selectFirst("h2.heading")?.text()?.trim()
                            sections = extractLabelBlocks(child)
                        }
                        child.tagName() == "div" && child.hasClass("userstuff") ->
                            content = child.html().trim()
                        child.hasClass("meta") && child.id().startsWith("endnotes") -> {
                            val bq = child.selectFirst("blockquote.userstuff")
                            if (bq != null) {
                                val label = child.selectFirst("p")?.text().orEmpty()
                                endNotes = MetaSection(
                                    normalizeLabel(label).ifBlank { "End Notes" },
                                    bq.html().trim()
                                )
                            }
                        }
                    }
                }
                flush()
            } else {
                // 单章且未分章：#chapters 直接含隐藏标题与正文
                val content = chaptersEl.children()
                    .firstOrNull { it.tagName() == "div" && it.hasClass("userstuff") }
                    ?.html()?.trim()
                    ?: chaptersEl.html().trim()
                chapters += Chapter(label = "", contentHtml = content)
            }
        }
        val labeledChapters = chapters.mapIndexed { i, ch ->
            ch.copy(label = chapterLabel(i + 1, ch.headingRaw))
        }

        val workEndNotes = doc.selectFirst("#afterword #endnotes")?.let { en ->
            val bq = en.selectFirst("blockquote.userstuff") ?: return@let null
            MetaSection(
                normalizeLabel(en.selectFirst("p")?.text().orEmpty()).ifBlank { "End Notes" },
                bq.html().trim()
            )
        }

        return ParsedWork(
            title = title,
            author = author,
            sourceUrl = sourceUrl,
            metaLines = metaLines,
            foreword = foreword,
            chapters = labeledChapters,
            workEndNotes = workEndNotes
        )
    }

    /** 非 AO3 下载结构（无 #preface / #chapters）的兜底：整篇正文作为单章重排。 */
    private fun parseGeneric(doc: Document): ParsedWork {
        val title = doc.title().trim().ifBlank {
            doc.selectFirst("h1, h2")?.text()?.trim().orEmpty()
        }.ifBlank { FALLBACK_TITLE }
        val content = doc.body()?.html()?.trim().orEmpty()
        return ParsedWork(
            title = title,
            author = "",
            sourceUrl = "",
            metaLines = emptyList(),
            foreword = emptyList(),
            chapters = listOf(Chapter(label = chapterLabel(1, ""), contentHtml = content))
        )
    }

    /** 把「标签 <p> + 紧随的 blockquote.userstuff」配对成内容块，标签文字做展示归一化。 */
    private fun extractLabelBlocks(container: Element): List<MetaSection> {
        val out = mutableListOf<MetaSection>()
        val children = container.children()
        var i = 0
        while (i < children.size) {
            val el = children[i]
            if (el.tagName() == "p" && !el.hasClass("message") && !el.hasClass("byline")) {
                val next = el.nextElementSibling()
                if (next != null && next.tagName() == "blockquote" && next.hasClass("userstuff")) {
                    val label = normalizeLabel(el.text())
                    if (label.isNotBlank()) out += MetaSection(label, next.html().trim())
                    i += 2
                    continue
                }
            }
            i++
        }
        return out
    }

    /**
     * 统计 dd（如「Published: … Updated: … Words: … Chapters: 4/4」）拆成独立行。
     * 含链接或行数不足时不拆，返回 null 由调用方按普通行输出。
     */
    private fun splitStats(dd: Element): List<MetaSection>? {
        if (dd.selectFirst("a") != null) return null
        val segments = dd.html()
            .split(Regex("\\r?\\n|<br\\s*/?>", RegexOption.IGNORE_CASE))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        if (segments.size < 2) return null
        val pattern = Regex("^(.{1,30}?[:：])\\s*(.*)$")
        val out = segments.mapNotNull { seg ->
            val plain = Jsoup.parseBodyFragment(seg).text().trim()
            val m = pattern.find(plain) ?: return@mapNotNull null
            MetaSection(m.groupValues[1], esc(m.groupValues[2]))
        }
        return if (out.size == segments.size) out else null
    }

    /**
     * 小节标题展示归一化：定位全部靠结构，这里只把已取到的标签文字
     * 映射成参照文档的固定小节名（Summary / Notes / End Notes），
     * 无法识别时保留原文。
     */
    internal fun normalizeLabel(raw: String): String {
        val t = raw.trim().trimEnd(':', '：').trim()
        val low = t.lowercase()
        return when {
            low.contains("summary") || t.contains("摘要") || t.contains("简介") -> "Summary"
            (low.contains("end") && low.contains("note")) || t.contains("文末") || t.contains("末尾") -> "End Notes"
            low.contains("note") || t.contains("注释") || t.contains("备注") -> "Notes"
            else -> t
        }
    }

    /**
     * 章节显示名：「第 N 章」或「第 N 章 标题」。
     * 从源章标题中剥离编号前缀（英「Chapter N[: 标题]」/ 中「第N章[:：标题]」），
     * 剥离失败时整体作为标题。
     */
    internal fun chapterLabel(index: Int, headingRaw: String): String {
        val h = headingRaw.trim()
        var title = ""
        if (h.isNotEmpty()) {
            val en = Regex("^Chapter\\s+\\d+\\s*[:：.\\-–]?\\s*(.*)$", RegexOption.IGNORE_CASE).find(h)
            val zh = Regex("^第\\s*\\d+\\s*章\\s*[:：.\\-–]?\\s*(.*)$").find(h)
            title = when {
                en != null -> en.groupValues[1].trim()
                zh != null -> zh.groupValues[1].trim()
                else -> h
            }
        }
        return if (title.isEmpty()) "第 $index 章" else "第 $index 章 $title"
    }

    // ------------------------------------------------------------ 渲染

    internal fun render(work: ParsedWork, customCss: String): String {
        val sb = StringBuilder()
        sb.appendLine("<!DOCTYPE html>")
        sb.appendLine("<html>")
        sb.appendLine("<head>")
        sb.appendLine("<meta charset=\"utf-8\">")
        sb.appendLine("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">")
        sb.appendLine("<meta name=\"generator\" content=\"$GENERATOR\">")
        val headTitle = if (work.author.isNotBlank()) "${work.title} - ${work.author}" else work.title
        sb.appendLine("<title>${esc(headTitle)}</title>")
        sb.appendLine("<style id=\"$THEME_STYLE_ID\">")
        sb.appendLine(THEME_CSS)
        sb.appendLine("</style>")
        if (customCss.isNotBlank()) {
            sb.appendLine("<style id=\"$CUSTOM_STYLE_ID\">")
            sb.appendLine("/* ---- 用户自定义 CSS ---- */")
            sb.appendLine(customCss.trim())
            sb.appendLine("</style>")
        }
        sb.appendLine("</head>")
        sb.appendLine("<body>")
        sb.appendLine("<div class=\"content-wrapper\">")

        // 扉页
        sb.appendLine("<div class=\"title-page text-center\">")
        sb.appendLine("<h1>${esc(work.title)}</h1>")
        if (work.author.isNotBlank()) sb.appendLine("<h2>by ${esc(work.author)}</h2>")
        sb.appendLine("</div>")
        sb.appendLine("<div class=\"page-break\"></div>")

        // 作品信息页
        sb.appendLine("<div class=\"imprint-page\">")
        sb.appendLine("<h2 class=\"text-center\">Imprint</h2>")
        if (work.author.isNotBlank()) {
            sb.appendLine("<p><span class=\"meta-label\">Original Copyright ©</span> <strong>${esc(work.author)}</strong></p>")
        }
        sb.appendLine("<p>Original Work published on Archive of Our Own.</p>")
        if (work.sourceUrl.isNotBlank()) {
            sb.appendLine("<p><span class=\"meta-label\">Source:</span> ${esc(work.sourceUrl)}</p>")
        }
        if (work.metaLines.isNotEmpty()) {
            sb.appendLine("<br/>")
            for (line in work.metaLines) {
                sb.appendLine("<p><span class=\"meta-label\">${esc(line.label)}</span> ${line.html}</p>")
            }
        }
        sb.appendLine("<br/>")
        sb.appendLine("<p>Exported by $APP_NAME on ${exportDate()}.</p>")
        sb.appendLine("</div>")

        // 前言页
        if (work.foreword.isNotEmpty()) {
            sb.appendLine("<div class=\"page-break\"></div>")
            sb.appendLine("<div class=\"foreword-page\">")
            sb.appendLine("<h2 class=\"text-center\">Foreword</h2>")
            work.foreword.forEachIndexed { i, sec ->
                if (i > 0) sb.appendLine("<br/>")
                sb.appendLine("<div class=\"foreword-section\"><h3>${esc(sec.label)}</h3>")
                sb.appendLine("<div>${sec.html}</div></div>")
            }
            sb.appendLine("</div>")
        }

        // 目录页
        if (work.chapters.isNotEmpty()) {
            sb.appendLine("<div class=\"page-break\"></div>")
            sb.appendLine("<div class=\"toc-page\"><h2 class=\"text-center\">Table of Contents</h2>")
            sb.appendLine("<ul class=\"toc-list\">")
            work.chapters.forEachIndexed { i, ch ->
                sb.appendLine("<li class=\"toc-item\"><a href=\"#chapter-${i + 1}\">${esc(ch.label)}</a></li>")
            }
            sb.appendLine("</ul></div>")
        }

        // 章节页
        work.chapters.forEachIndexed { i, ch ->
            sb.appendLine("<div class=\"page-break\"></div>")
            sb.appendLine("<div class=\"chapter-page\" id=\"chapter-${i + 1}\">")
            sb.appendLine("<h2 class=\"text-center\">${esc(ch.label)}</h2>")
            if (ch.sections.isNotEmpty()) {
                sb.appendLine("<div class=\"chapter-meta\">")
                ch.sections.forEachIndexed { j, sec ->
                    if (j > 0) sb.appendLine("<br/>")
                    sb.appendLine("<div><div class=\"meta-heading\">${esc(sec.label)}</div>")
                    sb.appendLine("<div>${sec.html}</div></div>")
                }
                sb.appendLine("</div>")
            }
            sb.appendLine("<div class=\"chapter-text\">")
            sb.appendLine(ch.contentHtml)
            sb.appendLine("</div>")
            ch.endNotes?.let { en ->
                sb.appendLine("<div class=\"chapter-meta chapter-end-notes\">")
                sb.appendLine("<div class=\"meta-heading\">${esc(en.label)}</div>")
                sb.appendLine("<div>${en.html}</div></div>")
            }
            sb.appendLine("</div>")
        }

        // 作品级尾注（附在最后一章之后）
        work.workEndNotes?.let { en ->
            sb.appendLine("<div class=\"chapter-meta chapter-end-notes\">")
            sb.appendLine("<div class=\"meta-heading\">${esc(en.label)}</div>")
            sb.appendLine("<div>${en.html}</div></div>")
        }

        // 结尾与关于页
        sb.appendLine("<div class=\"the-end text-center\"><h2>THE END</h2>")
        sb.appendLine("<hr style=\"width: 50%; margin: 2em auto; border: 1px solid #ccc;\"/></div>")
        sb.appendLine("<div class=\"page-break\"></div>")
        sb.appendLine("<div class=\"about-page text-center\" id=\"about-page\">")
        sb.appendLine("<h3>About $APP_NAME</h3>")
        sb.appendLine("<p>This document was generated by $APP_NAME, an AO3 downloader that re-typesets downloaded works into a book-style layout.</p>")
        sb.appendLine("</div>")

        sb.appendLine("</div>")
        sb.appendLine("</body>")
        sb.appendLine("</html>")
        return sb.toString()
    }

    // ------------------------------------------------------------ 工具

    internal fun esc(text: String): String = buildString(text.length) {
        for (c in text) when (c) {
            '&' -> append("&amp;")
            '<' -> append("&lt;")
            '>' -> append("&gt;")
            '"' -> append("&quot;")
            else -> append(c)
        }
    }

    private fun exportDate(): String =
        DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH).format(LocalDate.now())

    private fun setStyleData(style: Element, css: String) {
        style.empty()
        style.appendChild(DataNode("\n$css\n"))
    }

    private fun styleElement(id: String, css: String): Element =
        Element(Tag.valueOf("style"), "").attr("id", id).appendChild(DataNode("\n$css\n"))
}
