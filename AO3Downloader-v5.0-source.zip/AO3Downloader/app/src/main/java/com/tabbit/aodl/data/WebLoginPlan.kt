package com.tabbit.aodl.data

import java.net.URI
import java.net.URLDecoder

/**
 * 需求 5：「跳转 AO3 官网 → 用户自行登录 → 提取会话 Cookie」的纯逻辑层。
 *
 * 这里只做与 Android 无关的字符串与 URL 计算，全部可以离线断言；
 * 真正碰 [android.webkit.WebView] / [android.webkit.CookieManager] / OkHttp 的代码
 * 在 `net/Ao3WebProxy.kt` 与 `ui/LoginWebScreen.kt`。
 *
 * 隐私约定（与既有账号体系一致）：
 * - 密码只出现在官网页面自身的表单里，本应用不读取、不保存密码；
 * - 为了绕过系统 DNS 污染，表单提交被改写成带 [POST_MARKER] 的 GET 跳转，
 *   **这会短暂把表单字段（含密码）放进 URL**，因此：
 *   URL 一律不写日志、界面不显示地址栏、`onPageFinished` 后立刻用
 *   [replaceStateJs] 把当前历史条目替换成不含密码的干净地址并 `clearHistory()`。
 */
internal object WebLoginPlan {

    /** 官网登录页路径，入口固定跳这里。 */
    const val LOGIN_PATH = "/users/login"

    /** AO3 的会话 Cookie 名，登录态的主判据。 */
    const val SESSION_COOKIE = "_otwarchive_session"

    /** 勾选「记住我」后 Devise 下发的长效 Cookie，作为会话缺失时的兜底判据。 */
    const val REMEMBER_COOKIE = "remember_user_token"

    /**
     * 表单改写标记。
     *
     * `WebResourceRequest` 不暴露 POST body（Android 没有公开 API），
     * 所以注入的 JS 会阻止表单默认提交，把字段序列化进查询串并加上这个标记；
     * 代理侧看到标记就剥掉它、把其余参数还原成 `FormBody` 发真实 POST。
     */
    const val POST_MARKER = "__aodl_post"

    /** 主框架重定向的最大跳数，防止官网异常配置导致死循环。 */
    const val MAX_REDIRECTS = 5

    /**
     * 只代理这两个主机名。
     *
     * 刻意不做通配匹配：CDN / 静态资源子域的响应格式与缓存策略不同，
     * 一律交回 WebView 原生加载更稳，也能把代理面收窄到登录真正需要的域名。
     */
    private val AO3_HOSTS = setOf("archiveofourown.org", "www.archiveofourown.org")

    /**
     * 请求侧要丢弃的头。
     *
     * - hop-by-hop 头（Connection / Transfer-Encoding …）按 RFC 7230 不该转发；
     * - `Host` / `Content-Length` 由 OkHttp 依最终 URL 与 body 自己算；
     * - `Cookie` 以 [android.webkit.CookieManager] 为准，避免与 WebView 传来的旧值冲突；
     * - `Accept-Encoding` 交给 OkHttp，它会自己加 `gzip` 并透明解压，
     *   若照搬 WebView 的 `br` 就会把未解压的字节塞回 WebView。
     */
    private val REQUEST_DROP = setOf(
        "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
        "te", "trailer", "transfer-encoding", "upgrade",
        "host", "content-length", "cookie", "accept-encoding"
    )

    /**
     * 响应侧要丢弃的头。
     *
     * - `Set-Cookie` 已写回 CookieManager，再交给 WebView 会二次解析；
     * - `Location` 由代理自己跟随，透传会让 WebView 再跳一次；
     * - `Content-Length` / `Transfer-Encoding` / `Content-Encoding` 与代理交出的流长度对不上，
     *   留着会导致 WebView 认为响应被截断。
     */
    private val RESPONSE_DROP = setOf(
        "set-cookie", "set-cookie2", "location",
        "transfer-encoding", "content-length", "content-encoding",
        "connection", "keep-alive"
    )

    // ------------------------------------------------------------------ 域名

    /** 是否属于需要经安全 DNS 代理的 AO3 主机名（精确匹配，含末尾点号与大小写归一）。 */
    fun isAo3Host(host: String?): Boolean {
        val normalized = host?.trim()?.lowercase()?.removeSuffix(".") ?: return false
        if (normalized.isEmpty()) return false
        return normalized in AO3_HOSTS
    }

    // ------------------------------------------------------------------ Cookie

    /**
     * 归一化 `CookieManager.getCookie(url)` 的返回值。
     *
     * 该 API 返回的是 `a=1; b=2` 形式的裸串，可能带首尾空白、空段或缺 `=` 的坏段。
     * 处理规则：按 `;` 切分 → 去空白 → 丢弃没有名字或没有 `=` 的段 → 按名字去重（保留首次出现，
     * 与服务端读 Cookie 头时取第一个同名值的惯例一致）→ 用 `"; "` 重新拼接。
     * 空值 Cookie（`foo=`）视为合法并保留。
     */
    fun normalizeCookies(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val kept = LinkedHashMap<String, String>()
        raw.split(';').forEach { piece ->
            val item = piece.trim()
            if (item.isEmpty()) return@forEach
            val eq = item.indexOf('=')
            if (eq <= 0) return@forEach
            val name = item.substring(0, eq).trim()
            if (name.isEmpty() || name.startsWith("#")) return@forEach
            if (!kept.containsKey(name)) kept[name] = item.substring(eq + 1).trim()
        }
        return kept.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    /** 归一化串里的 Cookie 名列表，顺序与串中一致。 */
    fun cookieNames(normalized: String): List<String> =
        if (normalized.isBlank()) {
            emptyList()
        } else {
            normalized.split("; ").map { it.substringBefore('=') }.filter { it.isNotBlank() }
        }

    fun cookieCount(normalized: String): Int = cookieNames(normalized).size

    fun hasSessionCookie(normalized: String): Boolean =
        cookieNames(normalized).any { it.equals(SESSION_COOKIE, ignoreCase = true) }

    fun hasRememberCookie(normalized: String): Boolean =
        cookieNames(normalized).any { it.equals(REMEMBER_COOKIE, ignoreCase = true) }

    /**
     * 能否作为登录态落盘。
     *
     * 主判据是 `_otwarchive_session`；只拿到 `remember_user_token`（官网在会话过期后
     * 用它重新签发会话）也算可用，否则会把「记住我」用户挡在门外。
     * 两者都没有就说明用户还没真正登录成功，不能覆盖既有账号。
     */
    fun isUsable(normalized: String): Boolean = hasSessionCookie(normalized) || hasRememberCookie(normalized)

    // ------------------------------------------------------------- POST 还原

    /** 还原后的表单提交：[targetUrl] 已剥掉标记，[fields] 为解码后的键值对（保留原始顺序与重复名）。 */
    internal data class PostRequest(val targetUrl: String, val fields: List<Pair<String, String>>)

    /**
     * 识别并拆解 JS 改写出来的「假 GET 真 POST」地址。
     *
     * 没有查询串、查询串里没有 [POST_MARKER] 时返回 null，调用方据此判定
     * 「这是一次拿不到 body 的原生 POST」并回退给 WebView 自己提交。
     * 片段（`#…`）不参与解析，剥标记后也不会带回 targetUrl。
     */
    fun splitPostRequest(rawUrl: String?): PostRequest? {
        if (rawUrl.isNullOrBlank()) return null
        val queryStart = rawUrl.indexOf('?')
        if (queryStart < 0) return null
        val base = rawUrl.substring(0, queryStart)
        val query = rawUrl.substring(queryStart + 1).substringBefore('#')
        if (query.isBlank()) return null
        val pairs = query.split('&').mapNotNull { token ->
            if (token.isBlank()) return@mapNotNull null
            val eq = token.indexOf('=')
            val key = if (eq < 0) token else token.substring(0, eq)
            val value = if (eq < 0) "" else token.substring(eq + 1)
            decodeComponent(key) to decodeComponent(value)
        }
        if (pairs.none { it.first == POST_MARKER }) return null
        return PostRequest(base, pairs.filter { it.first != POST_MARKER })
    }

    /** 地址里是否带着 [POST_MARKER]，用于决定是否要清理历史条目。 */
    fun hasPostMarker(rawUrl: String?): Boolean {
        if (rawUrl.isNullOrBlank()) return false
        val queryStart = rawUrl.indexOf('?')
        if (queryStart < 0) return false
        val query = rawUrl.substring(queryStart + 1).substringBefore('#')
        return query.split('&').any { it.substringBefore('=') == POST_MARKER }
    }

    private fun decodeComponent(raw: String): String =
        runCatching { URLDecoder.decode(raw, "UTF-8") }.getOrDefault(raw)

    // ------------------------------------------------------------------ 重定向

    /** 需要代理自己跟随的 3xx（304 不在内，它是缓存协商，必须原样交回 WebView）。 */
    fun isRedirect(statusCode: Int): Boolean =
        statusCode == 301 || statusCode == 302 || statusCode == 303 ||
            statusCode == 307 || statusCode == 308

    /**
     * 重定向后应使用的方法。
     *
     * 303 一律转 GET；301/302 的 POST 按浏览器惯例也转 GET（AO3 登录成功就是 302 → `/`）；
     * 307/308 保持原方法与 body。
     */
    fun redirectMethod(statusCode: Int, currentMethod: String): String {
        val method = currentMethod.trim().uppercase()
        return when {
            statusCode == 303 -> "GET"
            (statusCode == 301 || statusCode == 302) && method == "POST" -> "GET"
            else -> method
        }
    }

    /** 把 `Location` 解析成绝对地址；相对地址基于当前请求 URL，解析失败返回 null。 */
    fun resolveLocation(baseUrl: String, location: String?): String? {
        val target = location?.trim().orEmpty()
        if (target.isEmpty()) return null
        val resolved = runCatching { URI.create(baseUrl).resolve(target).toString() }.getOrNull()
        if (!resolved.isNullOrEmpty()) return resolved
        return runCatching { URI.create(target).toString() }.getOrNull()
    }

    // -------------------------------------------------------------------- 头

    /** 过滤请求头，见 [REQUEST_DROP] 的说明。 */
    fun sanitizeRequestHeaders(raw: Map<String, String>?): Map<String, String> {
        if (raw.isNullOrEmpty()) return emptyMap()
        val out = LinkedHashMap<String, String>()
        raw.forEach { (key, value) ->
            val name = key.trim()
            if (name.isEmpty() || name.startsWith(":")) return@forEach // HTTP/2 伪头
            if (name.lowercase() in REQUEST_DROP) return@forEach
            out[name] = value
        }
        return out
    }

    /** 过滤响应头并把多值头合并成单值，见 [RESPONSE_DROP] 的说明。 */
    fun sanitizeResponseHeaders(raw: Map<String, List<String>>?): Map<String, String> {
        if (raw.isNullOrEmpty()) return emptyMap()
        val out = LinkedHashMap<String, String>()
        raw.forEach { (key, values) ->
            val name = key.trim()
            if (name.isEmpty()) return@forEach
            if (name.lowercase() in RESPONSE_DROP) return@forEach
            val joined = values.filter { it.isNotBlank() }.joinToString(", ")
            if (joined.isNotEmpty()) out[name] = joined
        }
        return out
    }

    /**
     * 取出响应里的 `Set-Cookie` **原文**（含 Domain / Path / Expires / Secure 等属性）。
     *
     * 必须整条交给 `CookieManager.setCookie(url, value)`，它才会正确处理作用域与过期时间；
     * 只留 `name=value` 会让 Cookie 变成会话级、且作用域退化成当前主机。
     */
    fun extractSetCookies(headers: Map<String, List<String>>?): List<String> {
        if (headers.isNullOrEmpty()) return emptyList()
        return headers.entries
            .filter { it.key.trim().lowercase() == "set-cookie" || it.key.trim().lowercase() == "set-cookie2" }
            .flatMap { it.value }
            .filter { it.isNotBlank() }
    }

    /**
     * `WebResourceResponse` 六参构造要求 reasonPhrase 非空，否则部分内核会抛异常。
     * OkHttp 的 `Response.message` 在 HTTP/2 下恒为空串，所以这里自己兜一份。
     */
    fun reasonPhrase(statusCode: Int): String = when (statusCode) {
        200 -> "OK"
        201 -> "Created"
        202 -> "Accepted"
        204 -> "No Content"
        301 -> "Moved Permanently"
        302 -> "Found"
        303 -> "See Other"
        304 -> "Not Modified"
        307 -> "Temporary Redirect"
        308 -> "Permanent Redirect"
        400 -> "Bad Request"
        401 -> "Unauthorized"
        403 -> "Forbidden"
        404 -> "Not Found"
        405 -> "Method Not Allowed"
        408 -> "Request Timeout"
        410 -> "Gone"
        422 -> "Unprocessable Entity"
        429 -> "Too Many Requests"
        500 -> "Internal Server Error"
        502 -> "Bad Gateway"
        503 -> "Service Unavailable"
        504 -> "Gateway Timeout"
        in 200..299 -> "OK"
        in 300..399 -> "Redirect"
        in 400..499 -> "Client Error"
        else -> "Server Error"
    }

    /** 从 `Content-Type` 里取字符集，取不到返回 null（调用方兜 UTF-8）。 */
    fun charsetOf(contentType: String?): String? {
        val value = contentType?.trim().orEmpty()
        if (value.isEmpty()) return null
        return value.split(';')
            .map { it.trim() }
            .firstOrNull { it.startsWith("charset=", ignoreCase = true) }
            ?.substringAfter('=')
            ?.trim()
            ?.trim('"', '\'')
            ?.takeIf { it.isNotEmpty() }
    }

    /** 从 `Content-Type` 里取 MIME，取不到返回 null（调用方按扩展名猜）。 */
    fun mimeOf(contentType: String?): String? =
        contentType?.substringBefore(';')?.trim()?.takeIf { it.isNotEmpty() }

    // ------------------------------------------------------------------ 注入 JS

    /**
     * 表单捕获脚本：给所有 `method="post"` 的表单挂**捕获阶段**的 submit 监听，
     * 阻止默认提交，把字段序列化成查询串后跳到 `<action>?__aodl_post=1&<fields>`。
     *
     * 只 hook 显式声明 POST 的表单，GET 表单（AO3 的搜索与筛选）保持原生行为；
     * 跳过 submit/image/button/reset 类控件，改用 `event.submitter` 补上真正被点中的那个，
     * 因为 Rails 的 `commit` 参数决定服务端走哪个分支。
     * `window.__aodlHooked` 保证 `onPageFinished` 多次注入时不会重复绑定。
     */
    val FORM_CAPTURE_JS: String = """
        (function () {
          if (window.__aodlHooked) { return; }
          window.__aodlHooked = true;
          var enc = function (v) { return encodeURIComponent(v === null || v === undefined ? '' : String(v)); };
          document.addEventListener('submit', function (e) {
            var form = e.target;
            if (!form || form.tagName !== 'FORM') { return; }
            if ((form.getAttribute('method') || '').toLowerCase() !== 'post') { return; }
            e.preventDefault();
            e.stopPropagation();
            var action = form.action || window.location.href;
            var parts = [];
            var nodes = form.querySelectorAll('input, select, textarea, button');
            for (var i = 0; i < nodes.length; i++) {
              var el = nodes[i];
              if (!el.name || el.disabled) { continue; }
              var type = (el.type || '').toLowerCase();
              if (type === 'submit' || type === 'image' || type === 'button' || type === 'reset') { continue; }
              if ((type === 'checkbox' || type === 'radio') && !el.checked) { continue; }
              if (el.tagName === 'SELECT' && el.multiple) {
                for (var j = 0; j < el.options.length; j++) {
                  if (el.options[j].selected) { parts.push(enc(el.name) + '=' + enc(el.options[j].value)); }
                }
                continue;
              }
              parts.push(enc(el.name) + '=' + enc(el.value));
            }
            var sub = e.submitter;
            if (sub && sub.name && (sub.type || '').toLowerCase() === 'submit') {
              parts.push(enc(sub.name) + '=' + enc(sub.value));
            }
            var sep = action.indexOf('?') >= 0 ? '&' : '?';
            window.location.href = action + sep + '$POST_MARKER=1' + (parts.length ? '&' + parts.join('&') : '');
          }, true);
        })();
    """.trimIndent()

    /**
     * 生成安全的 JS 字符串字面量（含首尾单引号）。
     *
     * 转义反斜杠、单引号、换行与回车，并干掉 `</script>` 之类可能提前终止脚本的序列；
     * 用于把地址拼进注入脚本，避免官网返回的 Location 里带引号时把脚本打断。
     */
    fun jsStringLiteral(raw: String): String {
        val sb = StringBuilder(raw.length + 8)
        sb.append('\'')
        raw.forEach { ch ->
            when (ch) {
                '\\' -> sb.append("\\\\")
                '\'' -> sb.append("\\'")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\u2028' -> sb.append("\\u2028")
                '\u2029' -> sb.append("\\u2029")
                else -> if (ch < ' ') {
                    sb.append("\\u").append(ch.code.toString(16).padStart(4, '0'))
                } else {
                    sb.append(ch)
                }
            }
        }
        sb.append('\'')
        return sb.toString().replace("</", "<\\/")
    }

    /**
     * 登录 POST 之后，把当前历史条目替换成不含表单字段的干净地址。
     *
     * `history.replaceState` 同源即可执行、且不触发重新加载，正好用来抹掉
     * 地址里残留的密码；随后调用方再 `clearHistory()`，密码就不会留在任何历史里。
     */
    fun replaceStateJs(cleanUrl: String): String =
        "try { window.history.replaceState(null, '', ${jsStringLiteral(cleanUrl)}); } catch (e) {}"
}
