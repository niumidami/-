package com.tabbit.aodl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.data.BookmarkCopy
import com.tabbit.aodl.data.CopyTarget
import com.tabbit.aodl.data.WorkBadges
import com.tabbit.aodl.model.AuthorUiState
import com.tabbit.aodl.model.WorkItem
import com.tabbit.aodl.model.WorkKind
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel
import kotlinx.coroutines.delay

/* ---------------------------------------------- 子页：搜索作者（「下载」格内） */

/**
 * 搜索作者：抓取 `/users/<username>/works`，支持分页加载、多选与一键下载全部。
 *
 * 顶栏与分段切换由「下载」格容器 [DownloadTabScreen] 提供。作者搜索仍然是
 * **下载分支**（批量挑作品下来存本地），因此这里保留全选、下载所选等全部下载控件；
 * 首页的搜索结果列表不带任何下载控件（下载入口统一收进「下载」格）。
 */
@Composable
fun AuthorSearchPane(vm: AppViewModel) {
    val state by vm.author.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    val cardShape = RoundedCornerShape(14.dp)

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.weight(1f)) {
                    SakuraTextField(
                        value = state.usernameInput,
                        onValueChange = vm::onAuthorInputChange,
                        label = stringResource(R.string.author_input_label),
                        placeholder = stringResource(R.string.author_input_placeholder)
                    )
                }
                Spacer(Modifier.width(10.dp))
                GradientButton(
                    text = stringResource(R.string.author_search),
                    onClick = { vm.searchAuthor() },
                    enabled = state.usernameInput.isNotBlank(),
                    loading = state.loading,
                    icon = Icons.Filled.Search,
                    modifier = Modifier.width(132.dp)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = stringResource(R.string.author_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.ext.textSecondary
            )

            if (state.error.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                ErrorBanner(text = state.error, shape = cardShape)
            }

            if (state.works.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                AuthorBatchBar(state = state, vm = vm)
            }
        }

        when {
            state.loading && state.works.isEmpty() -> CenterLoading()

            state.works.isEmpty() -> EmptyHint(
                text = if (state.username.isEmpty()) {
                    stringResource(R.string.author_empty)
                } else {
                    stringResource(R.string.log_author_empty)
                }
            )

            else -> LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
            ) {
                items(state.works, key = { it.id + "|" + it.title }) { item ->
                    WorkCard(
                        item = item,
                        showDownload = true,
                        onToggle = { vm.toggleWorkSelected(item.id) },
                        onDownload = { vm.startDownload(workIds = listOf(item.id)) },
                        onCopy = { target -> copyWorkField(vm, clipboard, target, item) },
                        onOpenWork = { vm.openBrowserWork(item.id) },
                        onOpenAuthor = { vm.openBrowserAuthor(it) },
                        onOpenTag = { vm.openBrowserTag(it) },
                        onAddShelf = { vm.addToShelfFrom(item) }
                    )
                }

                item {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Spacer(Modifier.height(4.dp))
                        CenterNote(
                            text = stringResource(R.string.author_count, state.works.size) +
                                " · " + stringResource(R.string.author_page, state.page)
                        )
                        Spacer(Modifier.height(6.dp))
                        CenterNote(text = stringResource(R.string.author_batch_hint))
                        Spacer(Modifier.height(10.dp))
                        if (state.hasMore) {
                            SecondaryButton(
                                text = if (state.loadingMore) {
                                    stringResource(R.string.author_loading_more)
                                } else {
                                    stringResource(R.string.author_load_more)
                                },
                                onClick = vm::loadMoreAuthorWorks,
                                enabled = !state.loadingMore,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}

/* ------------------------------------------------------- 批量操作工具条 */

@Composable
private fun AuthorBatchBar(state: AuthorUiState, vm: AppViewModel) {
    val allSelected = state.works.isNotEmpty() &&
        state.works.filter { it.downloadable }.all { it.selected } &&
        state.works.any { it.downloadable }

    SakuraCard(contentPadding = PaddingValues(12.dp)) {
        SelectRow(
            allSelected = allSelected,
            selectedCount = state.selectedCount,
            onToggleAll = { vm.setAllSelected(!allSelected) }
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryButton(
                text = stringResource(R.string.author_download_selected),
                onClick = vm::downloadSelectedWorks,
                enabled = state.selectedCount > 0,
                icon = Icons.Filled.Download,
                modifier = Modifier.weight(1f)
            )
            GradientButton(
                text = stringResource(R.string.author_download_all),
                onClick = { vm.downloadAllAuthorWorks() },
                loading = state.busy,
                icon = Icons.Filled.CloudDownload,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SelectRow(allSelected: Boolean, selectedCount: Int, onToggleAll: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onToggleAll)
                .padding(end = 8.dp)
        ) {
            Checkbox(
                checked = allSelected,
                onCheckedChange = { onToggleAll() },
                colors = checkBoxColors()
            )
            Text(
                text = if (allSelected) {
                    stringResource(R.string.author_unselect_all)
                } else {
                    stringResource(R.string.author_select_all)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        Spacer(Modifier.weight(1f))
        Text(
            text = stringResource(R.string.author_selected, selectedCount),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

/* ------------------------------------------------------------ 作品卡片 */

/**
 * 作品条目卡片：**首页搜索结果、作者作品列表、以及后续的作品清单入口共用这一个组件**。
 *
 * 版式按「neos 站点皮肤」重排（即用户参考图一的效果）：
 * 标题行（作品名 by 作者名 + 右侧日期）→ 分级预警四徽章 → 按类型着色的 tag 胶囊
 * → 简介段落 → 带图标的统计行 → 元信息行 → 复制按钮行 → 浏览页 / 加入书架行。
 *
 * 三条硬规则：
 * 1. **四徽章永远齐四枚**（[WorkBadges.fourBadges]），缺值的槽位给兜底徽章而不是省略；
 *    徽章行用 [FlowRow] 自动换行，屏幕窄或标题过长时换行铺开，绝不裁切。
 * 2. **标题、作者名、每个 tag 都可点击**，分别落到作品页 / 作者作品页 / tag 作品页。
 * 3. **下载控件只在 [showDownload] 为 true 时出现**（即「下载」格内的作者搜索），
 *    首页搜索结果不出现勾选框、单条下载图标与批量操作条。
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun WorkCard(
    item: WorkItem,
    onCopy: (CopyTarget) -> Unit,
    onOpenWork: () -> Unit,
    onOpenAuthor: (String) -> Unit,
    onOpenTag: (String) -> Unit,
    onAddShelf: () -> Unit,
    showDownload: Boolean = false,
    onToggle: () -> Unit = {},
    onDownload: () -> Unit = {},
    /** v5.1：当前作品是否已在「我的订阅」里。 */
    subscribed: Boolean = false,
    /** v5.1：非空时底部动作行追加「订阅 / 已订阅」入口。 */
    onToggleSubscribe: (() -> Unit)? = null
) {
    val ext = MaterialTheme.ext
    val shape = RoundedCornerShape(14.dp)
    val selectable = showDownload && item.downloadable
    val borderColor = if (selectable && item.selected) MaterialTheme.colorScheme.primary else ext.cardBorder

    // 复制成功的即时反馈：被点的复制按钮短暂变成对勾，约 1.2 秒后自动恢复
    var copiedTarget by remember { mutableStateOf<CopyTarget?>(null) }
    LaunchedEffect(copiedTarget) {
        if (copiedTarget != null) {
            delay(1200)
            copiedTarget = null
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(ext.card)
            .border(1.dp, borderColor, shape)
            .clickable(enabled = selectable, onClick = onToggle)
            .padding(horizontal = 6.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top
    ) {
        if (showDownload) {
            if (item.downloadable) {
                Checkbox(
                    checked = item.selected,
                    onCheckedChange = { onToggle() },
                    colors = checkBoxColors()
                )
            } else {
                Spacer(Modifier.width(48.dp))
            }
        }

        Column(modifier = Modifier.weight(1f)) {
            /* -------------------------------- 标题行：作品名 by 作者名 + 右侧日期 */
            Row(verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title.ifBlank { "#${item.id}" },
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable(onClick = onOpenWork)
                            .padding(vertical = 1.dp)
                    )
                    AuthorLine(authors = item.authors, onOpenAuthor = onOpenAuthor)
                }
                if (item.updated.isNotBlank()) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = item.updated,
                        fontSize = 10.sp,
                        color = ext.textSecondary
                    )
                }
            }

            /* -------------------------------- 分级预警四徽章：永远齐四枚，窄屏自动换行 */
            Spacer(Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                WorkBadges.fourBadges(
                    rating = item.rating,
                    warnings = item.archiveWarnings,
                    categories = item.categories,
                    completion = item.completion
                ).forEach { badge -> SquareBadge(badge) }
            }

            /* -------------------------------- tag 区（按 AO3 类型着色，每个 tag 可点） */
            val hasTypedTags = item.fandoms.isNotBlank() || item.warningTags.isNotEmpty() ||
                item.relationshipTags.isNotEmpty() || item.characterTags.isNotEmpty() ||
                item.freeformTags.isNotEmpty()
            if (hasTypedTags) {
                Spacer(Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // fandom 只有一个逗号分隔字段，拆成单个胶囊展示
                    item.fandoms.split(", ").filter { it.isNotBlank() }.forEach { fandom ->
                        TagChip(
                            text = fandom,
                            background = Color(WorkBadges.TAG_TEXT).copy(alpha = 0.08f),
                            textColor = Color(WorkBadges.TAG_TEXT),
                            borderColor = Color(WorkBadges.TAG_BORDER),
                            onClick = { onOpenTag(fandom) }
                        )
                    }
                    item.warningTags.forEach { tag ->
                        TagChip(
                            text = tag,
                            background = Color(WorkBadges.TAG_BG_WARNING),
                            textColor = Color(WorkBadges.TAG_TEXT_DARK),
                            borderColor = Color.Transparent,
                            onClick = { onOpenTag(tag) }
                        )
                    }
                    item.relationshipTags.forEach { tag ->
                        TagChip(
                            text = tag,
                            background = Color(WorkBadges.TAG_BG_RELATIONSHIP),
                            textColor = Color(WorkBadges.TAG_TEXT_DARK),
                            borderColor = Color.Transparent,
                            onClick = { onOpenTag(tag) }
                        )
                    }
                    item.characterTags.forEach { tag ->
                        TagChip(
                            text = tag,
                            background = Color(WorkBadges.TAG_TEXT).copy(alpha = 0.08f),
                            textColor = Color(WorkBadges.TAG_TEXT_CHARACTER),
                            borderColor = Color(WorkBadges.TAG_BORDER),
                            onClick = { onOpenTag(tag) }
                        )
                    }
                    item.freeformTags.forEach { tag ->
                        TagChip(
                            text = tag,
                            background = Color(WorkBadges.TAG_TEXT).copy(alpha = 0.08f),
                            textColor = Color(WorkBadges.TAG_TEXT_FREEFORM),
                            borderColor = Color(WorkBadges.TAG_BORDER),
                            onClick = { onOpenTag(tag) }
                        )
                    }
                }
            } else if (item.tags.isNotBlank()) {
                // 无类型信息的旧数据路径：保持原有的单行 tag 展示
                Spacer(Modifier.height(6.dp))
                Text(
                    text = item.tags,
                    style = MaterialTheme.typography.bodySmall,
                    color = ext.textSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            /* -------------------------------- 简介 */
            if (item.summary.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = item.summary,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
            }

            /* -------------------------------- 统计行（语言/字数/章节/评论/获赞/书签/浏览量） */
            val stats = buildList<Pair<ImageVector, Pair<Int, String>>> {
                if (item.language.isNotBlank()) {
                    add(Icons.Filled.Language to (R.string.stats_language to item.language))
                }
                if (item.words.isNotBlank()) {
                    add(Icons.Filled.Create to (R.string.stats_words to item.words))
                }
                if (item.chapters.isNotBlank()) {
                    add(Icons.Filled.Description to (R.string.stats_chapters to item.chapters))
                }
                if (item.comments.isNotBlank()) {
                    add(Icons.Filled.ChatBubbleOutline to (R.string.stats_comments to item.comments))
                }
                if (item.kudos.isNotBlank()) {
                    add(Icons.Filled.Favorite to (R.string.stats_kudos to item.kudos))
                }
                if (item.bookmarks.isNotBlank()) {
                    add(Icons.Filled.BookmarkBorder to (R.string.stats_bookmarks to item.bookmarks))
                }
                if (item.hits.isNotBlank()) {
                    add(Icons.Filled.Visibility to (R.string.stats_hits to item.hits))
                }
            }
            if (stats.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    stats.forEach { (icon, labelAndValue) ->
                        val (labelRes, value) = labelAndValue
                        Icon(
                            icon,
                            contentDescription = stringResource(labelRes),
                            tint = ext.textSecondary,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(3.dp))
                        Text(text = value, fontSize = 10.sp, color = ext.textSecondary)
                        Spacer(Modifier.width(12.dp))
                    }
                }
            }

            /* -------------------------------- 元信息行（受限 / 类型 / 编号 / 下载） */
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (item.restricted) {
                    Icon(
                        Icons.Filled.Lock,
                        contentDescription = stringResource(R.string.author_restricted),
                        tint = ext.warning,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.author_restricted),
                        fontSize = 10.sp,
                        color = ext.warning
                    )
                    Spacer(Modifier.width(8.dp))
                }
                if (item.kind != WorkKind.WORK) {
                    Text(
                        text = kindLabel(item.kind),
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    text = "#${item.id}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = ext.textSecondary
                )
                Spacer(Modifier.weight(1f))
                if (showDownload && item.downloadable) {
                    Icon(
                        Icons.Filled.Download,
                        contentDescription = stringResource(R.string.download_button),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(18.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .clickable(onClick = onDownload)
                            .padding(1.dp)
                    )
                }
            }

            /* -------------------------------------------- 复制作者名 / 编号 */
            Spacer(Modifier.height(2.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CopyTarget.entries.forEach { target ->
                    CopyChip(
                        label = stringResource(copyTargetLabel(target)),
                        enabled = BookmarkCopy.enabled(target, item.authors, item.id),
                        copied = copiedTarget == target,
                        onClick = {
                            // 按钮仅在内容非空时可点，点下即视为复制成功并给出对勾反馈
                            copiedTarget = target
                            onCopy(target)
                        }
                    )
                }
            }

            /* -------------------------------- 浏览页打开 / 加入书架 / 订阅 */
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.work_card_open),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onOpenWork)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    text = stringResource(R.string.work_card_shelf),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onAddShelf)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
                if (onToggleSubscribe != null) {
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = stringResource(
                            if (subscribed) R.string.work_card_subscribed else R.string.work_card_subscribe
                        ),
                        fontSize = 12.sp,
                        color = if (subscribed) MaterialTheme.ext.textSecondary else MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(onClick = onToggleSubscribe)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

/** `by 作者名` 一行：每个作者名单独可点，落到该作者的作品列表。 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AuthorLine(authors: String, onOpenAuthor: (String) -> Unit) {
    val names = authors.split(", ").map { it.trim() }.filter { it.isNotBlank() }
    if (names.isEmpty()) return
    FlowRow(
        verticalArrangement = Arrangement.spacedBy(2.dp),
        horizontalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        Text(
            text = stringResource(R.string.author_by_prefix),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.ext.textSecondary
        )
        names.forEachIndexed { index, name ->
            Text(
                text = name,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable { onOpenAuthor(name) }
                    .padding(horizontal = 2.dp)
            )
            if (index != names.lastIndex) {
                Text(
                    text = ", ",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.ext.textSecondary
                )
            }
        }
    }
}

/** neos 风格的圆角方形徽章：类型底色渐变 + 白色符号，`label` 作为无障碍描述。 */
@Composable
private fun SquareBadge(badge: WorkBadges.Badge) {
    val base = Color(badge.color)
    Box(
        modifier = Modifier
            .size(20.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Brush.linearGradient(listOf(base, base.copy(alpha = 0.72f))))
            .semantics { contentDescription = badge.label },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = badge.symbol,
            fontSize = if (badge.symbol.length > 1) 8.sp else 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 1,
            softWrap = false
        )
    }
}

/** neos 主题 tag 胶囊：圆角 8dp（--radius-tag）、1dp 描边、11sp 文字；点击进该 tag 的作品页。 */
@Composable
private fun TagChip(
    text: String,
    background: Color,
    textColor: Color,
    borderColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(background)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            color = textColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** 复制目标对应的按钮文案。 */
private fun copyTargetLabel(target: CopyTarget): Int = when (target) {
    CopyTarget.AUTHOR -> R.string.bookmark_copy_author
    CopyTarget.ID -> R.string.bookmark_copy_id
    CopyTarget.BOTH -> R.string.bookmark_copy_both
}

/**
 * 复制作品卡片上的字段：内容取自条目已有字段，不再发请求；空内容直接忽略。
 *
 * 作者列表、作者搜索、首页搜索结果三处卡片共用这一条复制路径。
 */
internal fun copyWorkField(
    vm: AppViewModel,
    clipboard: androidx.compose.ui.platform.ClipboardManager,
    target: CopyTarget,
    item: WorkItem
) {
    val text = BookmarkCopy.payload(target, item.authors, item.id)
    if (text.isEmpty()) return
    clipboard.setText(AnnotatedString(text))
    vm.noteCopied(target, text)
}

/* ------------------------------------------------------------ 公共小块 */

@Composable
internal fun ErrorBanner(text: String, shape: RoundedCornerShape) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.error.copy(alpha = 0.12f))
            .border(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f), shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
internal fun CenterLoading() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CatLoading(size = 72.dp)
    }
}

@Composable
internal fun CenterNote(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.ext.textSecondary,
        modifier = Modifier.fillMaxWidth(),
        textAlign = TextAlign.Center
    )
}

@Composable
private fun checkBoxColors() = CheckboxDefaults.colors(
    checkedColor = MaterialTheme.colorScheme.primary,
    uncheckedColor = MaterialTheme.ext.cardBorder,
    checkmarkColor = Color.White
)