package com.tabbit.aodl.data

import com.tabbit.aodl.model.ShelfBook

/**
 * 书架 / 阅读历史 / 书签的本地序列化（v5.0 新增 2）。
 *
 * 三者共用 [ShelfBook] 结构，落盘时统一走这里：
 * 1. 每行一条记录（行分隔 `\n`），行内字段用 `|` 分隔；
 * 2. 字段里的分隔符、反斜杠与控制字符一律转义为可打印的 `\\n` / `\\p` / `\\xNN`，
 *    保证写进 SharedPreferences 的 XML 里不会出现非法控制字符；
 * 3. 全部逻辑不依赖 Android，可直接跑 JVM 单测；字段缺失时按默认值容错，
 *    便于旧版本数据或半截数据反序列化时不至于整份丢掉。
 */
object ShelfStore {

    private const val ROW_SEP = "\n"
    private const val COL_SEP = "|"

    /** 当前字段数；解码时少于该数量视为坏行丢弃。 */
    private const val FIELD_COUNT = 10

    fun encode(books: List<ShelfBook>): String =
        books.filter { it.workId.isNotBlank() }.joinToString(ROW_SEP) { encodeRow(it) }

    fun decode(raw: String?): List<ShelfBook> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(ROW_SEP).mapNotNull { decodeRow(it) }
    }

    private fun encodeRow(book: ShelfBook): String = listOf(
        book.workId,
        book.title,
        book.authors,
        book.tags,
        book.chapters,
        book.readChapters.toString(),
        book.updated,
        book.group,
        book.addedAt.toString(),
        if (book.restricted) "1" else "0"
    ).joinToString(COL_SEP) { escape(it) }

    private fun decodeRow(row: String): ShelfBook? {
        if (row.isBlank()) return null
        val parts = row.split(COL_SEP)
        if (parts.size < FIELD_COUNT) return null
        val workId = unescape(parts[0])
        if (workId.isBlank()) return null
        return ShelfBook(
            workId = workId,
            title = unescape(parts[1]),
            authors = unescape(parts[2]),
            tags = unescape(parts[3]),
            chapters = unescape(parts[4]),
            readChapters = parts[5].toIntOrNull() ?: 0,
            updated = unescape(parts[6]),
            group = unescape(parts[7]),
            addedAt = parts[8].toLongOrNull() ?: 0L,
            restricted = parts[9] == "1"
        )
    }

    private fun escape(text: String): String {
        if (text.isEmpty()) return text
        val sb = StringBuilder(text.length + 8)
        for (ch in text) {
            when {
                ch == '\\' -> sb.append("\\\\")
                ch == '|' -> sb.append("\\p")
                ch == '\n' -> sb.append("\\n")
                ch == '\r' -> sb.append("\\r")
                ch < ' ' || ch == '\u007F' -> sb.append("\\x").append(hex(ch.code))
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun unescape(text: String): String {
        val slash = text.indexOf('\\')
        if (slash < 0) return text
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (ch != '\\' || i + 1 >= text.length) {
                sb.append(ch)
                i++
                continue
            }
            when (text[i + 1]) {
                '\\' -> { sb.append('\\'); i += 2 }
                'p' -> { sb.append('|'); i += 2 }
                'n' -> { sb.append('\n'); i += 2 }
                'r' -> { sb.append('\r'); i += 2 }
                'x' -> {
                    val hex = text.substring(i + 2, minOf(i + 4, text.length))
                    val code = hex.toIntOrNull(16)
                    if (hex.length == 2 && code != null) {
                        sb.append(code.toChar())
                        i += 4
                    } else {
                        sb.append(ch)
                        i++
                    }
                }
                else -> { sb.append(ch); i++ }
            }
        }
        return sb.toString()
    }

    private fun hex(code: Int): String = code.toString(16).padStart(2, '0')
}