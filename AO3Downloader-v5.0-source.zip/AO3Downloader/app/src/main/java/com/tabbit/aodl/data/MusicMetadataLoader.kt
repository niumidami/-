package com.tabbit.aodl.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri

/**
 * 本地音乐的封面 / 歌词加载器（v5.2，Android 胶水层）。
 *
 * 只负责「把内容 Uri 变成字节 / 位图」，解析规则全部委托给
 * [Id3LyricReader] / [LyricParser] / [LyricResolver] 纯对象，
 * 因此本类不需要也无法离线单测，逻辑都在可测的一侧。
 */
object MusicMetadataLoader {

    /** 读取上限：ID3 标签 / 歌词文件通常远小于 1MB。 */
    private const val MAX_READ_BYTES = 1024 * 1024

    /** 内嵌封面：MediaMetadataRetriever 提取 APIC 图片。 */
    fun loadEmbeddedCover(context: Context, uri: Uri): Bitmap? = runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            retriever.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        } finally {
            retriever.release()
        }
    }.getOrNull()

    /** 内嵌歌词：读文件头交给 [Id3LyricReader] 解析 USLT 帧。 */
    fun loadEmbeddedLyrics(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.openInputStream(uri)?.use { input ->
            Id3LyricReader.readEmbeddedLyrics(readUpTo(input, MAX_READ_BYTES))
        }
    }.getOrNull()

    /** 外部歌词文件：读字节后按 [LyricParser.decodeText] 规则解码。 */
    fun loadSidecarLyrics(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.openInputStream(uri)?.use { input ->
            LyricParser.decodeText(readUpTo(input, MAX_READ_BYTES))
        }
    }.getOrNull()

    /** 外部封面图片文件。 */
    fun loadImageFile(context: Context, uri: Uri): Bitmap? = runCatching {
        context.contentResolver.openInputStream(uri)?.use { input ->
            BitmapFactory.decodeStream(input)
        }
    }.getOrNull()

    private fun readUpTo(input: java.io.InputStream, limit: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        var total = 0
        while (total < limit) {
            val n = input.read(buffer, 0, minOf(buffer.size, limit - total))
            if (n <= 0) break
            out.write(buffer, 0, n)
            total += n
        }
        return out.toByteArray()
    }
}
