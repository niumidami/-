package com.tabbit.aodl.ui

import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.data.LyricParser
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel
import kotlin.math.roundToInt

/**
 * App 内桌面歌词条（v5.2）：悬浮在所有页面之上，可上下拖动换位。
 * 带时间轴的歌词随播放进度高亮当前行并预告下一行；纯文本歌词显示首行。
 */
@Composable
fun DesktopLyricBar(vm: AppViewModel) {
    val state by vm.music.collectAsStateWithLifecycle()
    val track = state.current ?: return

    val active = LyricParser.activeIndex(state.currentLyrics, state.positionMs)
    val rawLine = state.currentLyrics.getOrNull(active)?.text
    val currentLine = when {
        rawLine != null -> rawLine.ifBlank { "…" }
        state.currentLyrics.isNotEmpty() -> state.currentLyrics.first().text.ifBlank { "…" }
        else -> track.title
    }
    val nextLine = state.currentLyrics.getOrNull(active + 1)?.text?.takeIf { it.isNotBlank() }

    var offsetY by remember { mutableStateOf(0f) }

    Box(modifier = Modifier.fillMaxSize()) {
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 16.dp)
                .padding(bottom = 92.dp)
                .offset { IntOffset(0, offsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetY += dragAmount.y
                    }
                },
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f),
            tonalElevation = 4.dp,
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentLine,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (nextLine != null) {
                        Text(
                            text = nextLine,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.ext.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                IconButton(onClick = vm::togglePlayPause) {
                    Icon(
                        imageVector = if (state.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = stringResource(
                            if (state.playing) R.string.music_pause else R.string.music_play
                        ),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(onClick = vm::toggleLyricBar) {
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = stringResource(R.string.music_lyric_bar_hide),
                        tint = MaterialTheme.ext.textSecondary
                    )
                }
            }
        }
    }
}
