package com.tabbit.aodl.data

import java.util.concurrent.ConcurrentHashMap

/**
 * 子目录「先查后建」的纯决策逻辑（v4.2 修复 #1）。
 *
 * ### 用户实测缺陷
 *
 * 一次批量下载里，同一作者 / 同一格式会有多个任务并发开工（默认并发度 2），
 * 它们几乎同时执行「查同名目录 → 查不到 → 新建」。旧实现里这段是**非原子**的：
 *
 * ```
 * parent.findFile(name)?.takeIf { it.isDirectory }?.let { return it.uri }   // 两个线程都查不到
 * val created = parent.createDirectory(name)                               // 两个线程都去建
 * if (created != null && created.isDirectory) return created.uri            // 各返回各的
 * ```
 *
 * SAF provider 为保证同名唯一，会把后建的那个目录改名成 `onee1e (1)`，
 * 于是用户每次批量下载都会多出一个重复文件夹，文件还散落在两个目录里
 * （用户截图里 `onee1e` 与 `onee1e (1)` 并存即由此而来）。
 *
 * ### 修复
 *
 * 1. [SubDirResolver] 把同一「父目录 + 名字」的查建过程**串行化**，并发任务不会各建一个；
 * 2. [resolveSubDir] 在同名目录已存在时**一律复用，绝不新建**；
 * 3. 新建后**复核 provider 实际给出的名字**：名字被改写即说明同名目录已经存在，
 *    此时改用既有目录，并回收自己刚建出来的空目录；
 * 4. 名字被改写、既有同名目录又查不到时保留 provider 给的名字（宁可名字难看，也不丢文件）。
 *
 * 本文件不依赖 Android API，[SubDirOps] 在 `SafStore` 里由真实 SAF 实现，
 * 单测（`SubDirPlannerTest`）用可模拟「重名改名」的假 provider 断言竞态结果。
 */
internal interface SubDirOps {

    /** 父目录中是否已存在该名字的目录。 */
    fun existingDir(name: String): Boolean

    /** 创建目录并返回 provider **实际采用**的名字（重名时可能不是 [name]）；失败返回 null。 */
    fun createDir(name: String): String?

    /** 刚创建的目录是否为空，用于判断能否安全回收。 */
    fun createdIsEmpty(): Boolean

    /** 删除刚创建的那个目录。 */
    fun dropCreated(): Boolean
}

/** [resolveSubDir] 的结果。 */
internal sealed class SubDirOutcome {

    /** 复用了已存在的同名目录（没有新建任何目录）。 */
    data class Reused(val name: String) : SubDirOutcome()

    /** 新建成功，且 provider 未改写名字。 */
    data class Created(val name: String) : SubDirOutcome()

    /**
     * 新建被 provider 改名（说明同名目录已存在），已回退到既有同名目录；
     * [dropped] 是被回收的重复目录名（无法回收时为 null）。
     */
    data class Collapsed(val name: String, val dropped: String?) : SubDirOutcome()

    /** 目录既建不出来也查不到。 */
    object Failed : SubDirOutcome()
}

/**
 * 在父目录下解析出名为 [requested] 的子目录。
 *
 * @param ops 由调用方实现的目录操作（真实 SAF 或测试用假 provider）
 */
internal fun resolveSubDir(requested: String, ops: SubDirOps): SubDirOutcome {
    if (ops.existingDir(requested)) return SubDirOutcome.Reused(requested)

    val createdName = ops.createDir(requested)
    if (createdName == null) {
        // 创建失败：再复核一次，可能是并发任务刚好建好
        return if (ops.existingDir(requested)) SubDirOutcome.Reused(requested) else SubDirOutcome.Failed
    }
    if (createdName == requested) return SubDirOutcome.Created(requested)

    // provider 把新目录改名成 "name (1)"：同名目录已经存在（并发任务或上一批建的），
    // 改用既有目录，并回收自己刚建出来的空目录，避免用户看到重复文件夹。
    if (ops.existingDir(requested)) {
        val dropped = if (ops.createdIsEmpty() && ops.dropCreated()) createdName else null
        return SubDirOutcome.Collapsed(requested, dropped)
    }
    return SubDirOutcome.Created(createdName)
}

/**
 * 按「父目录 + 目录名」串行化的子目录解析器。
 *
 * 泛型 [P] 是父目录句柄（生产代码里是 `DocumentFile`，单测里是字符串键），
 * 因此互斥逻辑本身也能在 JVM 单测里用真线程验证。
 *
 * 返回操作对象是为了让调用方能拿到「这次真正用到的那个目录」的 Uri
 * （provider 可能改写名字，光靠名字回查未必可靠）。
 */
internal class SubDirResolver<P>(
    private val keyOf: (P) -> String
) {

    private val locks = ConcurrentHashMap<String, Any>()

    fun <O : SubDirOps> resolve(
        parent: P,
        requested: String,
        opsFactory: () -> O
    ): Pair<SubDirOutcome, O> {
        val lock = locks.computeIfAbsent("${keyOf(parent)}\u0000$requested") { Any() }
        return synchronized(lock) {
            val ops = opsFactory()
            resolveSubDir(requested, ops) to ops
        }
    }
}