package com.tabbit.aodl.net

import com.tabbit.aodl.data.FilterOption
import com.tabbit.aodl.data.SearchFormOptions
import com.tabbit.aodl.model.Chapter
import com.tabbit.aodl.model.DownloadFormat
import com.tabbit.aodl.model.WorkContent
import com.tabbit.aodl.model.WorkItem
import com.tabbit.aodl.model.WorkKind
import com.tabbit.aodl.model.WorkMeta
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * AO3 页面解析与下载请求构造的**纯函数**集合（v4.0 从 [Ao3Client] 中拆出）。
 *
 * 这些函数不依赖 Android 框架、不依赖网络与 [com.tabbit.aodl.data.Prefs]，
 * 因此可以在 JVM 单元测试里用离线 HTML fixture 直接断言（见 `app/src/test`），
 * 不需要真实访问 archiveofourown.org。
 *
 * 选择器全部对齐 otwcode/otwarchive master 分支模板：
 * - 作品页头部 `app/views/works/_work_header.html.erb`
 * - 作品元信息 `app/views/works/_work_meta.html.erb`
 * - 受限作品登录墙 `app/views/works/_login.html.erb`
 * - 站点头部登录态 `app/views/layouts/_header.html.erb`
 */

private val HTTP_CODE_REGEX = Regex("""HTTP (\d{3})""")
private val USERNAME_PATH_REGEX = Regex("[A-Za-z0-9_%-]+")
private val UPDATED_AT_REGEX = Regex("""updated_at=(\d{9,})""")

/**
 * 登录/注册相关的 URL 路径段。
 *
 * 未登录时站点头部同样渲染 `#login` 容器，里面是指向 `/users/login`、
 * `/users/sign_up` 的链接；这些 href 也匹配 `/users/`，若不按路径段排除，
 * 未登录页面会被误判成"用户名 = login"。按**整段**比较而不是子串包含，
 * 以免误伤名字里带这些字母的真实用户（如 `/users/alogin/pseuds/alogin`）。
 */
private val AUTH_PATH_SEGMENTS = setOf(
    "login", "logout", "sign_in", "sign_out", "sign_up", "password", "registrations"
)

private fun isAuthLink(href: String): Boolean {
    val path = href.substringBefore('?').substringBefore('#')
    return path.split('/').any { it.lowercase() in AUTH_PATH_SEGMENTS }
}

/**
 * 是否值得自动重试（需求 6）。
 *
 * 只对网络层故障与服务端临时错误（5xx / 429 / 408）重试；
 * 作品不存在、需要登录、会话过期、用户取消属于确定性失败，
 * 重试只会拖慢队列并重复触发站点风控。
 */
internal fun isRetryable(error: Ao3Error, detail: String = ""): Boolean = when (error) {
    Ao3Error.NETWORK, Ao3Error.TIMEOUT, Ao3Error.TLS -> true
    Ao3Error.HTTP -> {
        val code = HTTP_CODE_REGEX.find(detail)?.groupValues?.get(1)?.toIntOrNull() ?: -1
        code in 500..599 || code == 429 || code == 408
    }
    else -> false
}

/**
 * 解析 `Content-Range: bytes <start>-<end>/<total>` 头。
 *
 * `total` 为 `*`（服务端未知总长）时返回 -1；头缺失或格式异常时三项均为 -1，
 * 调用方据此退化为「整文件重新下载」，不会写出错位的内容。
 */
internal fun parseContentRange(header: String?): ContentRange {
    if (header.isNullOrBlank()) return ContentRange(-1, -1, -1)
    val spec = header.substringAfter("bytes", "").trim()
    if (spec.isEmpty()) return ContentRange(-1, -1, -1)
    val range = spec.substringBefore('/').trim()
    val totalText = spec.substringAfter('/', "").trim()
    val start = range.substringBefore('-').trim().toLongOrNull() ?: -1L
    val end = range.substringAfter('-', "").trim().toLongOrNull() ?: -1L
    val total = if (totalText.isEmpty() || totalText == "*") -1L else totalText.toLongOrNull() ?: -1L
    return ContentRange(start, end, total)
}

/**
 * 构造官方下载接口的 GET 请求：`GET <baseUrl>/downloads/<作品编号>/work.<格式后缀>`。
 *
 * 关键点（需求 6）：
 * - `Accept-Encoding: identity` 显式关闭透明 gzip，否则 OkHttp 自动解压会让
 *   `Content-Length` 与 `Range` 的字节偏移失真，续传写出错位内容；
 * - [rangeStart] 大于 0 时才发送 `Range: bytes=<n>-`；
 * - `view_adult=true` 仅在**已登录且用户开启成人内容**时附加，未登录时加了也无效。
 */
internal fun downloadRequest(
    workId: String,
    format: DownloadFormat,
    viewAdult: Boolean,
    loggedIn: Boolean,
    referer: String,
    rangeStart: Long = -1L,
    baseUrl: String = Ao3Client.BASE_URL,
    userAgent: String = Ao3Client.USER_AGENT
): Request {
    val urlBuilder = StringBuilder("$baseUrl/downloads/$workId/work.${format.ext}")
    if (viewAdult && loggedIn) urlBuilder.append("?view_adult=true")
    val builder = Request.Builder()
        .url(urlBuilder.toString())
        .header("User-Agent", userAgent)
        .header("Referer", referer)
        .header("Accept-Encoding", "identity")
    if (rangeStart > 0L) builder.header("Range", "bytes=$rangeStart-")
    return builder.get().build()
}

/**
 * 从首页解析登录用户名（需求 5：官网 WebView 登录后自动补全账号信息）。
 *
 * otwarchive 的 `app/views/layouts/_header.html.erb` 在登录态下渲染
 * `#login` / `#greeting` 区块，其中带一条指向当前用户 pseuds 页的链接。
 *
 * 注意：**未登录时 `#login` 区块同样存在**，里面是指向 `/users/login`、
 * `/users/sign_up`、`/users/logout` 的链接，这些 href 一样匹配 `/users/`。
 * 因此必须用 [isAuthLink] 按**路径整段**排除，否则未登录页面会被解析成
 * "用户名 = login"，进而让需求 5 的 WebView 登录态判断误报成功。
 */
internal fun parseLoggedInUsername(doc: Document): String? {
    val selectors = listOf(
        "#greeting a[href*=/users/]",
        "#login a[href*=/users/]",
        "p.user a[href*=/users/]",
        "a[href*=/users/][href*=/pseuds/]"
    )
    for (selector in selectors) {
        for (link in doc.select(selector)) {
            val href = link.attr("href")
            if (isAuthLink(href)) continue
            val fromPath = href.substringAfter("/users/", "")
                .substringBefore('/').substringBefore('?')
                .takeIf { it.isNotBlank() && it.matches(USERNAME_PATH_REGEX) }
                ?.let { runCatching { java.net.URLDecoder.decode(it, "UTF-8") }.getOrDefault(it) }
            val fromText = link.text().trim()
                .removePrefix("Hi,").removeSuffix("!").trim()
                .takeIf { it.isNotBlank() && !it.contains(' ') }
            val name = fromText ?: fromPath
            if (!name.isNullOrBlank()) return name
        }
    }
    return null
}

/**
 * 解析作品页头部。选择器对齐 otwarchive master 分支的
 * `app/views/works/_work_header.html.erb`（标题 `h2.title.heading`、
 * 作者 `h3.byline.heading` 内的 pseud 链接）与
 * `app/views/works/_work_meta.html.erb`（`dl.stats` 内的 `dd.words` / `dd.chapters`、
 * `dd.fandom` 内的 fandom 列表）。
 */
internal fun parseWorkMeta(doc: Document, workId: String): WorkMeta {
    val ogTitle = doc.selectFirst("meta[property=og:title]")?.attr("content")
    val docTitle = doc.title()
        .removeSuffix(" - Archive of Our Own")
        .substringAfterLast(" - ")
        .trim()
    val title = firstNonBlank(
        doc.selectFirst("h2.title.heading")?.text(),
        doc.selectFirst("div.primary.header.module h2")?.text(),
        ogTitle,
        docTitle
    )
    val authors = doc.select("h3.byline.heading a[href*=/users/]").map { it.text().trim() }
        .filter { it.isNotBlank() }
        .ifEmpty { doc.select("h3.byline.heading a").map { it.text().trim() }.filter { it.isNotBlank() } }
        .ifEmpty { doc.select("a[rel=author]").map { it.text().trim() }.filter { it.isNotBlank() } }
        .distinct()
    return WorkMeta(
        workId = workId,
        title = title,
        authors = authors,
        chapters = doc.selectFirst("dd.chapters")?.text().orEmpty().trim(),
        words = doc.selectFirst("dd.words")?.text().orEmpty().trim(),
        fandoms = doc.select("dd.fandom ul.commas a, dd.fandom.tags a, ul.fandoms a")
            .map { it.text().trim() }.filter { it.isNotBlank() }.distinct().joinToString(", "),
        restricted = doc.selectFirst("dd.rating")?.text()?.contains("Explicit", ignoreCase = true) == true ||
            doc.selectFirst("img[alt=(Restricted)], img[title=Restricted]") != null,
        fetchedAt = System.currentTimeMillis()
    )
}

/** 作品页的最小结构特征：正文容器或作品头部模块存在。 */
internal fun looksLikeWorkPage(doc: Document): Boolean =
    doc.selectFirst("div#workskin, div.primary.header.module, div#chapters, dl.tags") != null

/**
 * 受限作品的登录墙判定。
 *
 * 未登录访问受限作品时，otwarchive 渲染
 * `app/views/works/_login.html.erb`（正文含 "only available to registered users"）
 * 或直接 302 到 /users/login。成人内容确认页（`div#adult`）不在此列：
 * 它带 view_adult=true 时不会出现，真出现也会由下载请求的 HTML 检测如实报错。
 */
internal fun restrictedGate(doc: Document): String? {
    if (doc.selectFirst("div#workskin, div.primary.header.module") != null) return null
    val body = doc.body()?.text().orEmpty()
    return when {
        doc.selectFirst("form#new_user_session") != null -> "login form"
        body.contains("only available to registered users", ignoreCase = true) -> "registered users only"
        body.contains("This work is only available to", ignoreCase = true) -> "restricted work"
        else -> null
    }
}

// ------------------------------------------------------------- 作品条目列表解析

/**
 * 解析作品列表页的条目集合（v4.6 从 [Ao3Client] 提为纯函数，便于离线断言）。
 *
 * 选择器对齐 otwarchive master 分支的 `app/views/works/index.html.erb` 与
 * `app/views/works/search_results.html.erb`：作者作品列表与站点搜索结果渲染的是
 * 同一套 `<ol class="work index group">` + `_work_blurb.html.erb` 结构，
 * 因此两种页面共用本函数。
 */
internal fun parseWorkList(doc: Document): List<WorkItem> {
    val elements = doc.select("ol.work.index > li[id^=work_]").ifEmpty {
        doc.select("li.work.blurb[id^=work_]").ifEmpty { doc.select("li[id^=work_]") }
    }
    return elements.mapNotNull { parseWorkBlurb(it) }
}

/**
 * 解析单个作品条目（`_work_blurb.html.erb` → `_work_module.html.erb`）。
 *
 * 标题取 `h4.heading` 内指向 `/works/` 的链接，作者取同一 `h4.heading` 内的
 * byline 链接（`/users/<pseud>`）；编号优先取 `li#work_<id>`，缺失时回退标题链接。
 *
 * v4.7 起同时解析简介卡片需要的全部字段：分级预警四徽章（`ul.required-tags`）、
 * 按类型拆开的 tag（`ul.tags.commas` 内带类型 class 的 `li`）、简介
 * （`blockquote.userstuff.summary`）与统计区补充字段（`dd.comments` 等）。
 */
internal fun parseWorkBlurb(li: Element): WorkItem? {
    val titleLink = li.selectFirst("h4.heading a[href*=/works/]")
        ?: li.selectFirst("a[href*=/works/]")
    val href = titleLink?.attr("href").orEmpty()
    val id = li.id().removePrefix("work_").ifEmpty {
        href.substringAfter("/works/", "").substringBefore('?').substringBefore('/')
    }
    if (id.isEmpty()) return null
    val title = titleLink?.text()?.takeIf { it.isNotBlank() } ?: "work #$id"
    return WorkItem(
        id = id,
        title = title,
        authors = li.select("h4.heading a[href*=/users/]").joinToString(", ") { it.text() },
        words = li.selectFirst("dd.words")?.text().orEmpty(),
        chapters = li.selectFirst("dd.chapters")?.text().orEmpty(),
        updated = updatedOf(li),
        fandoms = li.select("h5.fandoms a").joinToString(", ") { it.text() },
        tags = workTagsOf(li),
        language = li.selectFirst("dd.language")?.text().orEmpty(),
        restricted = li.selectFirst("img[alt=(Restricted)], img[title=Restricted]") != null,
        kind = WorkKind.WORK,
        rating = requiredTagOf(li, "rating"),
        archiveWarnings = requiredTagOf(li, "warnings"),
        categories = requiredTagOf(li, "category"),
        completion = requiredTagOf(li, "iswip"),
        warningTags = typedTagsOf(li, "warnings"),
        relationshipTags = typedTagsOf(li, "relationships"),
        characterTags = typedTagsOf(li, "characters"),
        freeformTags = freeformTagsOf(li),
        summary = summaryOf(li),
        comments = li.selectFirst("dd.comments")?.text().orEmpty(),
        kudos = li.selectFirst("dd.kudos")?.text().orEmpty(),
        bookmarks = li.selectFirst("dd.bookmarks")?.text().orEmpty(),
        hits = li.selectFirst("dd.hits")?.text().orEmpty()
    )
}

/**
 * 分级预警四徽章（`ul.required-tags`）的可读文本。
 *
 * otwarchive 的 `get_symbols_for` 把可读文本同时放在两处：外层 span 的 `title`
 * 属性，以及内层 `span.text` 的可见副本；`title` 优先，依次回退可见文本。
 *
 * [slot] 是四类符号各自真实带有的 class 标记，必须与 `TagsHelper` 生成的
 * class 完全一致（见 `get_ratings_class` / `get_warnings_class` /
 * `get_category_class` 与 `get_symbols_for` 的第四个符号）：
 * - rating    → `class="rating-teen rating"`
 * - warnings  → `class="warning-yes warnings"`
 * - category  → `class="category-gen category"`（注意是单数 `category`，
 *               不是复数 `categories`；写错会让分类徽章整块缺失）
 * - iswip     → `class="complete-yes iswip"`
 */
internal fun requiredTagOf(li: Element, slot: String): String {
    val span = li.selectFirst("ul.required-tags span.$slot") ?: return ""
    return span.attr("title").trim()
        .ifEmpty { span.selectFirst("span.text")?.text()?.trim().orEmpty() }
        .ifEmpty { span.text().trim() }
}

/**
 * 指定类型的作品 tag（`ul.tags.commas` 内 `li.<type> a.tag`）。
 *
 * 收藏条目后面还会跟着收藏者自己的 `ul.meta.tags.commas`，`:not(.meta)` 排除之。
 */
internal fun typedTagsOf(li: Element, type: String): List<String> =
    li.select("ul.tags.commas:not(.meta) li.$type a.tag")
        .map { it.text().trim() }.filter { it.isNotBlank() }.distinct()

/**
 * 自由 tag：类型 li（warnings / relationships / characters）之外的条目。
 *
 * `blurb_tag_block` 渲染时 freeform 的 li 不一定带类型 class，
 * 因此用「排除已知类型」而不是 `li.freeforms` 选择器，两种渲染都兼容。
 */
internal fun freeformTagsOf(li: Element): List<String> =
    li.select("ul.tags.commas:not(.meta) li:not(.warnings):not(.relationships):not(.characters) a.tag")
        .map { it.text().trim() }.filter { it.isNotBlank() }.distinct()

/** 作品简介：逐段取出 `p` 文本、段间以换行连接；没有 `p` 时退化为整块文本。 */
internal fun summaryOf(li: Element): String {
    val block = li.selectFirst("blockquote.userstuff.summary") ?: return ""
    val paragraphs = block.select("p").map { it.text().trim() }.filter { it.isNotBlank() }
    return if (paragraphs.isNotEmpty()) paragraphs.joinToString("\n") else block.text().trim()
}

/**
 * 作品自身标签。
 *
 * 作品模块渲染 `<ul class="tags commas">`；收藏条目后面还会跟着收藏者自己的
 * `<ul class="meta tags commas">`，用 `:not(.meta)` 排除，避免把收藏者标签混进作品标签。
 */
internal fun workTagsOf(li: Element): String {
    val own = li.select("ul.tags.commas:not(.meta) a").ifEmpty { li.select("ul.tags a") }
    return own.take(8).joinToString(", ") { it.text() }
}

/** 优先使用模板注释里的 updated_at 时间戳，其次使用可见日期文本。 */
internal fun updatedOf(li: Element): String {
    val epoch = UPDATED_AT_REGEX.find(li.html())?.groupValues?.get(1)?.toLongOrNull()
    if (epoch != null && epoch > 0) {
        return SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(epoch * 1000L))
    }
    return li.selectFirst("p.datetime")?.text().orEmpty()
        .ifEmpty { li.selectFirst("dd.status")?.text().orEmpty() }
}

// ------------------------------------------------------------- 站点作品搜索请求

/**
 * 构造站点作品搜索请求：`GET /works/search?work_search[query]=<关键词>&commit=Search`。
 *
 * 参数名对齐 otwarchive 的 `app/views/works/_search_form.html.erb`
 * （`form_for @search, as: :work_search, url: search_works_path, method: :get`）；
 * `WorksController#search` 在 `params[:work_search].present?` 时渲染
 * `app/views/works/search_results.html.erb`，即 `ol.work.index.group` 作品列表。
 * 第 2 页起附 `page=<n>`，与 `will_paginate` 的分页口径一致。
 */
internal fun searchRequest(
    query: String,
    page: Int,
    baseUrl: String = Ao3Client.BASE_URL,
    userAgent: String = Ao3Client.USER_AGENT,
    extraParams: List<Pair<String, String>> = emptyList()
): Request {
    val base = "$baseUrl/works/search".toHttpUrlOrNull()
        ?: throw IllegalArgumentException("invalid base url: $baseUrl")
    val url = base.newBuilder()
        .addQueryParameter("work_search[query]", query)
        .apply { extraParams.forEach { (name, value) -> addQueryParameter(name, value) } }
        .addQueryParameter("commit", "Search")
        .apply { if (page > 1) addQueryParameter("page", page.toString()) }
        .build()
    return Request.Builder()
        .url(url)
        .header("User-Agent", userAgent)
        .get()
        .build()
}

// ------------------------------------------------------------- 站点筛选项解析

/**
 * 从站点 `/works/search` 的表单里解析真实候选项（v5.1 结果页筛选）。
 *
 * 选择器对齐 otwarchive `app/views/works/_search_form.html.erb`：
 * - 分级 `select[name=work_search[rating_ids]]`（`collection_select`，提交 canonical tag id）
 * - 内容预警 `input[name=work_search[archive_warning_ids][]][type=checkbox]`（提交 id）
 * - 配对 `input[name=work_search[category_ids][]][type=checkbox]`（提交 id）
 * - 语言 `select[name=work_search[language_id]]`（提交 `Language#short`）
 * - 排序 `select[name=work_search[sort_column]]`（提交 `WorkSearchForm::SORT_OPTIONS` 列名）
 *
 * 空 value 的占位项（如「All Ratings」）一律跳过——面板自己提供「不限」。
 * 展示名取控件文本或邻近 `label`，都取不到时退回 value，保证面板始终有可点的项。
 */
internal fun parseSearchFormOptions(doc: Document): SearchFormOptions {
    fun selectOptions(name: String): List<FilterOption> =
        doc.select("select[name=\"$name\"] option").mapNotNull { option ->
            val value = option.attr("value").trim()
            if (value.isEmpty()) null
            else FilterOption(value, option.text().trim().ifEmpty { value })
        }

    fun checkBoxes(name: String): List<FilterOption> =
        doc.select("input[name=\"$name\"]").mapNotNull { input ->
            val value = input.attr("value").trim()
            if (value.isEmpty()) null
            else FilterOption(value, checkboxLabel(doc, input).ifEmpty { value })
        }

    return SearchFormOptions(
        ratings = selectOptions("work_search[rating_ids]"),
        warnings = checkBoxes("work_search[archive_warning_ids][]"),
        categories = checkBoxes("work_search[category_ids][]"),
        languages = selectOptions("work_search[language_id]"),
        sorts = selectOptions("work_search[sort_column]")
    )
}

/** 复选框的展示名：`label[for=id]` → 最近的祖先 `label` → 兄弟 `label` → 空串。 */
private fun checkboxLabel(doc: Document, input: Element): String {
    val id = input.id()
    if (id.isNotEmpty()) {
        doc.selectFirst("label[for=\"$id\"]")?.let { return it.text().trim() }
    }
    input.parents().firstOrNull { it.tagName() == "label" }?.let { return it.text().trim() }
    input.parent()?.selectFirst("label")?.let { return it.text().trim() }
    input.nextElementSibling()?.let { if (it.tagName() == "label") return it.text().trim() }
    return ""
}

// ------------------------------------------------------------- 阅读模式正文解析

/**
 * 解析作品页正文，供阅读模式（v5.0 新增 3）使用。
 *
 * 选择器对齐 otwarchive master 分支 `app/views/works/_work_text.html.erb`：
 * 全部章节装在 `div#chapters` 里，每章一个 `div.chapter[id=chapter-N]`，
 * 章名在 `div.chapter.preface h3.title`，正文在该章内最后一个 `div.userstuff`；
 * 作品简介在 `div.summary.module blockquote.userstuff`。
 *
 * 由于章节数与简介都不是阅读所必需（简介可能为空、无章节时正文直接落在 `#workskin`），
 * 这里对结构缺失一律容错：拿不到分章就退化成「整篇一章」，拿不到简介就置空。
 */
internal fun parseWorkContent(doc: Document, workId: String): WorkContent {
    val meta = parseWorkMeta(doc, workId)
    val summary = doc.selectFirst("div.summary.module blockquote.userstuff")
        ?.let { paragraphsOf(it) }
        .orEmpty()

    val chapterElements = doc.select("div#chapters > div.chapter")
        .ifEmpty { doc.select("div.chapter[id^=chapter-]") }
    val chapters = chapterElements.mapIndexedNotNull { position, element ->
        parseChapter(element, position + 1)
    }
    val effective = if (chapters.isNotEmpty()) {
        chapters
    } else {
        // 单章或无分章结构：整页正文当作一章，至少保证阅读模式有内容可读
        val body = doc.selectFirst("div#workskin div.userstuff, div#workskin")
            ?: return WorkContent(workId = workId, meta = meta, summary = summary, chapters = emptyList())
        listOf(Chapter(index = 1, title = meta.title, text = paragraphsOf(body)))
    }

    return WorkContent(
        workId = workId,
        meta = meta,
        summary = summary,
        chapters = effective.filterNot { it.empty }
    )
}

/** 解析单章：编号取自 `id=chapter-N`，取不到时用顺序位；标题缺失时回退为「第 N 章」。 */
private fun parseChapter(element: Element, fallbackIndex: Int): Chapter? {
    val index = element.id()
        .substringAfter("chapter-", "")
        .toIntOrNull()
        ?: fallbackIndex
    val title = element.selectFirst("div.chapter.preface h3.title")?.text()?.trim()
        .orEmpty()
        .ifEmpty { element.selectFirst("h3.title")?.text()?.trim().orEmpty() }
    val body = element.select("div.userstuff").lastOrNull() ?: element
    return Chapter(index = index, title = title, text = paragraphsOf(body))
}

/**
 * 逐段取文本：优先 `p`，段落之间用空行分隔（阅读模式据此排版）；没有 `p` 时退化为整块文本。
 *
 * AO3 正文里的空段（`<p> </p>`）会被滤掉，避免阅读模式出现整屏空白。
 */
internal fun paragraphsOf(block: Element): String {
    val paragraphs = block.select("p").map { it.text().trim() }.filter { it.isNotBlank() }
    return if (paragraphs.isNotEmpty()) paragraphs.joinToString("\n\n") else block.text().trim()
}

internal fun firstNonBlank(vararg values: String?): String =
    values.firstOrNull { !it.isNullOrBlank() }?.trim().orEmpty()
