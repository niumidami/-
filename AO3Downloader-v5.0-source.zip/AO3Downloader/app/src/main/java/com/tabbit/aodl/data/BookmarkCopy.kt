package com.tabbit.aodl.data

/** 收藏条目上可复制的目标。 */
enum class CopyTarget { AUTHOR, ID, BOTH }

/**
 * 收藏条目「复制作者名 / 复制作品编号」的取值与拼装规则（v4.6 新增）。
 *
 * 复制内容全部来自 `WorkItem` 已有字段，不再为复制发一次请求：作者名是解析好的
 * byline 文本（多作者为逗号分隔原文），编号是作品 id。把「复制什么」抽成纯函数、
 * 「怎么复制」（系统剪贴板）留在界面层，前者就能离线断言，后者只需调一次。
 */
object BookmarkCopy {

    /** 作品编号统一带 `#` 前缀，与界面卡片上的显示口径一致。 */
    const val ID_PREFIX = "#"

    /** 组合复制时作者名与编号之间的分隔符。 */
    const val SEPARATOR = " "

    /** 作者名：多作者时保留逗号分隔原文，只做首尾空白清理。 */
    fun authorText(authors: String?): String = authors?.trim().orEmpty()

    /**
     * 作品编号。
     *
     * 收藏列表里除了普通作品还可能是系列（`/series/<id>`）或外部链接，
     * 后两者的 id 不是纯数字，这里原样返回，只去掉空白——复制的目的就是
     * 让用户拿到能定位这条记录的东西，不做二次加工。
     */
    fun idText(id: String?): String = id?.trim().orEmpty()

    /** 带前缀的编号文本；编号为空时返回空串而不是只剩一个 `#`。 */
    fun prefixedId(id: String?): String {
        val value = idText(id)
        return if (value.isEmpty()) "" else ID_PREFIX + value
    }

    /** 一次性复制的文本：`作者名 #编号`；缺一项时自动退化成只剩另一项。 */
    fun combined(authors: String?, id: String?): String {
        val author = authorText(authors)
        val pid = prefixedId(id)
        return when {
            author.isNotEmpty() && pid.isNotEmpty() -> author + SEPARATOR + pid
            else -> author.ifEmpty { pid }
        }
    }

    /** 按目标取要写进剪贴板的文本；无可复制内容时返回空串。 */
    fun payload(target: CopyTarget, authors: String?, id: String?): String = when (target) {
        CopyTarget.AUTHOR -> authorText(authors)
        CopyTarget.ID -> prefixedId(id)
        CopyTarget.BOTH -> combined(authors, id)
    }

    /** 该目标是否有内容可复制，界面据此决定是否禁用按钮。 */
    fun enabled(target: CopyTarget, authors: String?, id: String?): Boolean =
        payload(target, authors, id).isNotEmpty()
}
