package com.tabbit.aodl.ui

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.net.Ao3Client
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel

/**
 * 需求（v5.0 新增 1 / 4）：内置浏览页。
 *
 * 搜索入口、作品页与 tag 页都在这里落地，页面本身走安全 DNS 直连 AO3
 * （复用官网登录的 [AppViewModel.webProxy]），顶部提供「译 中文 / 返回原文」，
 * 底部把当前作品接入书架、阅读与下载。
 *
 * 提示：译文页面由第三方翻译服务渲染，非 AO3 主机，代理不介入、交回 WebView 原生加载。
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(vm: AppViewModel, onClose: () -> Unit) {
    val state by vm.browser.collectAsStateWithLifecycle()
    val ext = MaterialTheme.ext
    val cookieManager = remember { CookieManager.getInstance() }
    val proxy = vm.webProxy
    var webView by remember { mutableStateOf<WebView?>(null) }

    // 地址变化（翻译 / 返回原文 / 站内跳转）时把 WebView 带到新地址；
    // 与 WebView 当前地址一致的重复回调不会再触发一次加载。
    LaunchedEffect(state.url) {
        val view = webView ?: return@LaunchedEffect
        if (view.url != state.url) view.loadUrl(state.url)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            /* ------------------------------------------------------ 顶栏 */
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.browser_close),
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = state.title.ifBlank { stringResource(R.string.browser_title) },
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = state.url,
                        fontSize = 10.sp,
                        color = ext.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = { webView?.reload() }) {
                    Icon(
                        Icons.Filled.Refresh,
                        contentDescription = stringResource(R.string.browser_refresh),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            if (state.loading) {
                LinearProgressIndicator(
                    progress = { (state.progress / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                HorizontalDivider(color = ext.cardBorder)
            }

            /* ------------------------------------------------ 翻译 / 返回原文 */
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (state.translated) {
                    ActionChip(
                        label = stringResource(R.string.browser_translate_original),
                        icon = Icons.Filled.Translate,
                        onClick = { vm.browserReturnOriginal() }
                    )
                } else {
                    ActionChip(
                        label = stringResource(R.string.browser_translate),
                        icon = Icons.Filled.Translate,
                        onClick = { vm.browserTranslate() }
                    )
                }
                if (state.workId != null) {
                    ActionChip(
                        label = stringResource(R.string.browser_add_shelf),
                        icon = Icons.Filled.BookmarkBorder,
                        onClick = { vm.browserAddToShelf() }
                    )
                    ActionChip(
                        label = stringResource(R.string.browser_read),
                        onClick = { vm.browserRead() }
                    )
                    ActionChip(
                        label = stringResource(R.string.browser_download),
                        icon = Icons.Filled.Download,
                        onClick = { vm.browserDownload() }
                    )
                }
            }

            /* ------------------------------------------------------ 正文 */
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(ext.logBackground)
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        WebView(context).apply {
                            setBackgroundColor(AndroidColor.WHITE)
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.loadsImagesAutomatically = true
                            cookieManager.setAcceptCookie(true)
                            cookieManager.setAcceptThirdPartyCookies(this, true)
                            webViewClient = object : WebViewClient() {
                                override fun shouldInterceptRequest(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): WebResourceResponse? = proxy.intercept(request, cookieManager)

                                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                    if (url != null) vm.onBrowserUrl(url)
                                    vm.onBrowserProgress(0)
                                    vm.onBrowserNavigated(
                                        canBack = view?.canGoBack() == true,
                                        canForward = view?.canGoForward() == true
                                    )
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    if (url != null) vm.onBrowserUrl(url)
                                    vm.onBrowserTitle(view?.title.orEmpty())
                                    vm.onBrowserFinished()
                                }
                            }
                            webChromeClient = object : android.webkit.WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    vm.onBrowserProgress(newProgress)
                                }
                            }
                            loadUrl(state.url)
                            webView = this
                        }
                    },
                    update = { view ->
                        if (view.url != state.url) view.loadUrl(state.url)
                    }
                )

                if (state.error.isNotBlank()) {
                    EmptyHint(
                        text = state.error,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                    )
                }
            }
        }
    }
}

/** 浏览页操作条的胶囊按钮：图标可选，纯文字按钮同样走这一套。 */
@Composable
private fun ActionChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onClick: () -> Unit
) {
    TextButton(onClick = onClick) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
        }
        Text(
            text = label,
            modifier = Modifier.padding(start = if (icon != null) 6.dp else 0.dp),
            fontSize = 13.sp
        )
    }
}