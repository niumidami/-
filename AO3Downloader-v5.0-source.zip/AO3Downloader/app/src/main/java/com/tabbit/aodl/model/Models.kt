package com.tabbit.aodl.model

import com.tabbit.aodl.data.LyricParser
import com.tabbit.aodl.data.SearchFormOptions
import com.tabbit.aodl.data.WorkSearchDefaults
import com.tabbit.aodl.data.WorkSearchFilter

/**
 * v3.0 起的全局数据模型（v4.0 扩充下载引擎相关类型）。
 *
 * 说明：本文件不依赖 Android 框架类，便于纯 JVM 单元测试。
 */

/** AO3 官方下载接口支持的五种格式。 */
enum class DownloadFormat(val ext: String, val mime: String) {
    HTML("html", "text/html"),
    PDF("pdf", "application/pdf"),
    MOBI("mobi", "application/x-mobipocket-ebook"),
    EPUB("epub", "application/epub+zip"),
    AZW3("azw3", "application/vnd.amazon.ebook");

    /** 界面展示名，格式名本身无需翻译。 */
    val displayName: String get() = name

    companion object {
        fun fromName(value: String?): DownloadFormat? =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) }

        fun fromExt(value: String?): DownloadFormat? =
            entries.firstOrNull { it.ext.equals(value, ignoreCase = true) }
    }
}

enum class LogLevel { INFO, SUCCESS, WARN, ERROR }

/** 运行日志条目。 */
data class LogEntry(
    val seq: Long,
    val time: String,
    val message: String,
    val level: LogLevel = LogLevel.INFO
)

/** 收藏/列表条目的类型：作品可直接下载，系列与外部作品不支持单文件下载。 */
enum class WorkKind { WORK, SERIES, EXTERNAL, DELETED }

/**
 * 作品条目（作者作品列表、收藏列表、站点搜索共用）。
 *
 * v4.7 扩充「作品与 tag 简介」字段：分级预警四徽章的可读文本、按 AO3 tag 类型
 * 拆开的 tag 列表、简介纯文本与统计区补充字段。全部带默认值，收藏列表等不解析
 * 这些字段的构造点无需改动；字段为空时界面自动退回原有的单行展示。
 */
data class WorkItem(
    val id: String,
    val title: String,
    val authors: String = "",
    val words: String = "",
    val chapters: String = "",
    val updated: String = "",
    val fandoms: String = "",
    val tags: String = "",
    val language: String = "",
    val restricted: Boolean = false,
    val kind: WorkKind = WorkKind.WORK,
    val selected: Boolean = false,
    /** 分级徽章可读文本（`ul.required-tags span.rating` 的 title），如 "Mature"。 */
    val rating: String = "",
    /** 预警徽章可读文本，如 "Creator Chose Not To Use Archive Warnings"。 */
    val archiveWarnings: String = "",
    /** 分类徽章可读文本，如 "M/M"。 */
    val categories: String = "",
    /** 完结状态徽章可读文本，如 "Complete Work" / "Work in Progress"。 */
    val completion: String = "",
    /** 预警类 tag（`ul.tags.commas li.warnings`）。 */
    val warningTags: List<String> = emptyList(),
    /** 关系类 tag（`ul.tags.commas li.relationships`）。 */
    val relationshipTags: List<String> = emptyList(),
    /** 角色类 tag（`ul.tags.commas li.characters`）。 */
    val characterTags: List<String> = emptyList(),
    /** 自由 tag（类型 li 之外的条目）。 */
    val freeformTags: List<String> = emptyList(),
    /** 作品简介纯文本（`blockquote.userstuff.summary`），多段以换行连接。 */
    val summary: String = "",
    /** 评论数（站点原文，含千分位）。 */
    val comments: String = "",
    /** 获赞（kudos）数。 */
    val kudos: String = "",
    /** 书签数。 */
    val bookmarks: String = "",
    /** 浏览量（hits）。 */
    val hits: String = ""
) {
    val downloadable: Boolean get() = kind == WorkKind.WORK && id.isNotEmpty()
}

/**
 * 作品页预解析结果（v4.0 新增）。
 *
 * 下载前先 `GET /works/<id>` 取标题与作者，用于三件事：
 * 1. 生成「作品名 by 作者名.<后缀>」文件名；
 * 2. 按作者分类保存时确定一级目录名；
 * 3. 作品不存在 / 需要登录时**提前报错**，避免创建空文件或半截文件。
 */
data class WorkMeta(
    val workId: String,
    val title: String = "",
    val authors: List<String> = emptyList(),
    val chapters: String = "",
    val words: String = "",
    val fandoms: String = "",
    val restricted: Boolean = false,
    val fetchedAt: Long = 0L
) {
    /** 展示、命名与目录名共用的作者串，多作者以 ", " 连接。 */
    val authorLabel: String get() = authors.filter { it.isNotBlank() }.joinToString(", ")

    /** 标题是否可用（决定能否组成「作品名 by 作者名」，否则回退作品 ID）。 */
    val nameable: Boolean get() = title.isNotBlank()
}

/** 单个下载任务的生命周期状态。 */
enum class DownloadStatus { QUEUED, RUNNING, SUCCESS, FAILED, CANCELLED }

/**
 * 下载记录（v4.0 新增，同时作为实时进度的载体）。
 *
 * 所有字段均来自下载引擎的真实回调：[downloaded]/[total]/[speedBps] 由
 * `SafStore.writeFrom` 的进度回调写入，不存在假进度或估算填充。
 */
data class DownloadRecord(
    val recordId: String,
    val workId: String,
    val format: DownloadFormat,
    val title: String = "",
    val authors: String = "",
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val downloaded: Long = 0L,
    val total: Long = 0L,
    val speedBps: Long = 0L,
    val fileName: String = "",
    val dirUri: String = "",
    val errorText: String = "",
    val attempts: Int = 0,
    val resumedFromBytes: Long = 0L,
    val elapsedMillis: Long = 0L,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    /** true 表示这条记录是上次进程被杀时留下的未完成任务，不是本次运行判定的失败。 */
    val interrupted: Boolean = false
) {
    /** 服务端未给 Content-Length 时为 false，界面据此显示不确定进度条。 */
    val determinate: Boolean get() = total > 0L

    val progress: Float
        get() = if (total > 0L) (downloaded.toFloat() / total).coerceIn(0f, 1f) else 0f

    /** 剩余时间（毫秒）；无总大小或速度为 0 时返回 null。 */
    val etaMillis: Long?
        get() = if (speedBps > 0L && total > downloaded) (total - downloaded) * 1000L / speedBps else null

    val finished: Boolean get() = status == DownloadStatus.SUCCESS ||
        status == DownloadStatus.FAILED ||
        status == DownloadStatus.CANCELLED
}

/** 安全 DNS（DoH）请求方式。 */
enum class DohMethod(val label: String) {
    AUTO("AUTO"),
    GET("GET"),
    POST("POST");

    companion object {
        fun fromName(value: String?): DohMethod =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: AUTO
    }
}

/** DoH 连接状态。 */
enum class DohLinkState { UNKNOWN, TESTING, CONNECTED, FAILED, DISABLED }

data class DohState(
    val enabled: Boolean = true,
    val configuredEndpoint: String = "",
    val activeEndpoint: String? = null,
    val linkState: DohLinkState = DohLinkState.UNKNOWN,
    val message: String = "",
    val resolvedIps: List<String> = emptyList(),
    val latencyMs: Long = 0L,
    val usedFallback: Boolean = false,
    val queryCount: Int = 0,
    val systemFallbackCount: Int = 0
)

/** 登录凭据来源：官网 WebView 登录 / 密码登录 / 手动填入 Cookie。 */
enum class CookieSource { NONE, PASSWORD, MANUAL, WEBVIEW }

data class AccountState(
    val username: String = "",
    val loggedIn: Boolean = false,
    val loginAt: Long = 0L,
    val rememberMe: Boolean = true,
    val cookieSource: CookieSource = CookieSource.NONE,
    val cookiePreview: String = "",
    val lastCheckAt: Long = 0L,
    val lastCheckOk: Boolean? = null,
    val busy: Boolean = false,
    val message: String = ""
)

/** 阅读主题（HTML 美化用）。 */
enum class ReaderTheme { LIGHT, DARK, FOLLOW_APP }

/**
 * 需求（v5.0 新增 3）：阅读界面的两种模式。
 *
 * - [TOMATO]：番茄小说式沉浸阅读——正文抽成纯文本、逐章翻页、阅读器排版；
 * - [SITE]：照搬 AO3 原站样式的渲染——直接用官网页面原文排版。
 */
enum class ReaderMode { TOMATO, SITE }

/** HTML 美化风格：DOCUMENT = 参照导出文档重建版式（默认）；CLASSIC = 旧版注入式美化。 */
enum class BeautifyStyle { DOCUMENT, CLASSIC }

/** 正文字体族。 */
enum class ReaderFont(val cssFamily: String) {
    SERIF("Georgia, 'Times New Roman', 'Songti SC', 'Noto Serif CJK SC', serif"),
    SANS("system-ui, -apple-system, 'PingFang SC', 'Noto Sans CJK SC', sans-serif"),
    MONO("'JetBrains Mono', Menlo, Consolas, 'Noto Sans Mono CJK SC', monospace")
}

/** HTML 美化设置。 */
data class BeautifySettings(
    val style: BeautifyStyle = BeautifyStyle.DOCUMENT,
    val font: ReaderFont = ReaderFont.SERIF,
    val customFontFamily: String = "",
    val fontSizeSp: Int = 18,
    val lineHeight: Float = 1.85f,
    val marginDp: Int = 20,
    val paragraphSpacingEm: Float = 0.9f,
    val justify: Boolean = true,
    val theme: ReaderTheme = ReaderTheme.FOLLOW_APP,
    val customCss: String = "",
    val keepOriginal: Boolean = true
)

/** 应用主题。 */
enum class ThemeMode { SAKURA_DARK, MIDNIGHT, SAKURA_LIGHT }

/**
 * 阅读页背景主题（v5.3，番茄模式）。
 *
 * 色值以 ARGB Long 承载（本文件不依赖 Android 框架类，界面层再转 Color）；
 * [FOLLOW_APP] 的三个色值无意义——界面直接使用 MaterialTheme 配色。
 */
enum class ReaderPalette(val backgroundArgb: Long, val textArgb: Long, val secondaryArgb: Long) {
    /** 跟随应用主题（默认）。 */
    FOLLOW_APP(0L, 0L, 0L),

    /** 纸张白：暖白底深棕字。 */
    PAPER(0xFFF7F0E3, 0xFF3B3229, 0xFF8A7F6D),

    /** 护眼绿：浅绿底深绿字。 */
    SEPIA(0xFFE4F0E2, 0xFF2F4032, 0xFF6B8270),

    /** 夜间黑：纯黑底浅灰字。 */
    NIGHT(0xFF121418, 0xFFB8BDC7, 0xFF7A8190)
}

/** 阅读页排版设置（v5.3：字体 / 字号 / 行距 / 页边距 / 背景主题，随设置持久化）。 */
data class ReaderTypography(
    val font: ReaderFont = ReaderFont.SERIF,
    val fontSizeSp: Int = 18,
    val lineHeightMul: Float = 1.8f,
    val marginDp: Int = 20,
    val palette: ReaderPalette = ReaderPalette.FOLLOW_APP
)

/** 界面语言。 */
enum class LanguageMode { SYSTEM, ZH, EN }

/** 应用设置快照。 */
data class AppSettings(
    val enabledFormats: Set<DownloadFormat> = DownloadFormat.entries.toSet(),
    val unifiedSave: Boolean = false,
    val unifiedDir: String? = null,
    val formatDirs: Map<DownloadFormat, String?> = DownloadFormat.entries.associateWith { null },
    val dohEnabled: Boolean = true,
    val dohEndpoint: String = DEFAULT_DOH_ENDPOINT,
    val dohMethod: DohMethod = DohMethod.AUTO,
    val dohFallbackEnabled: Boolean = true,
    val autoBeautify: Boolean = false,
    val beautify: BeautifySettings = BeautifySettings(),
    val theme: ThemeMode = ThemeMode.SAKURA_DARK,
    val language: LanguageMode = LanguageMode.SYSTEM,
    val viewAdult: Boolean = true,
    /** 需求 1：文件名自动生成「作品名 by 作者名.<后缀>」，关闭则用服务端建议名。 */
    val autoName: Boolean = true,
    /** 需求 2：按「作者名 / 格式名」两级目录分类保存，默认开启。 */
    val authorClassify: Boolean = true,
    /** 需求 6：并行下载的任务数上限。 */
    val concurrency: Int = DEFAULT_CONCURRENCY,
    /** 需求 6：单任务失败后的额外重试次数（0 表示不重试）。 */
    val retryCount: Int = DEFAULT_RETRY,
    /** 需求 6：断点续传（Range）开关。 */
    val resumeEnabled: Boolean = true,
    /**
     * 需求 5 的逃生开关：官网登录时 WebView 直连，不经本应用的安全 DNS 代理。
     *
     * 默认关闭（= 走代理）。仅在用户已经配置了系统级 Private DNS 或全局 VPN、
     * 而代理反而干扰页面加载时才建议打开。
     */
    val webDirect: Boolean = false,
    /**
     * 需求（v5.0 新增 1）：浏览页「译 中文」使用的翻译服务模板。
     *
     * 留空表示用 [com.tabbit.aodl.data.TranslatePlan.DEFAULT_TEMPLATE]（Google 网页翻译代理，免密钥）。
     * 支持 `{path}` `{url}` `{to}` 占位符，因此任意支持 URL 传参的翻译服务都能接进来。
     */
    val translateTemplate: String = "",
    /** 翻译目标语言，替换模板里的 `{to}`。 */
    val translateTarget: String = "zh-CN",
    /** 需求（v5.0 新增 3）：从书架或浏览页点开作品时默认使用的阅读模式。 */
    val readerMode: ReaderMode = ReaderMode.TOMATO
) {
    /** 当前生效的格式列表，保持枚举声明顺序。 */
    val activeFormats: List<DownloadFormat>
        get() = DownloadFormat.entries.filter { it in enabledFormats }

    fun dirFor(format: DownloadFormat): String? =
        if (unifiedSave) unifiedDir else formatDirs[format]

    companion object {
        const val DEFAULT_DOH_ENDPOINT = "https://cs4x9fcgvq.cloudflare-gateway.com/dns-query"
        val FALLBACK_DOH_ENDPOINTS = listOf(
            "https://dns.google/dns-query",
            "https://cloudflare-dns.com/dns-query"
        )

        const val DEFAULT_CONCURRENCY = 2
        const val MIN_CONCURRENCY = 1
        const val MAX_CONCURRENCY = 4
        const val DEFAULT_RETRY = 2
        const val MAX_RETRY = 5
    }
}

/** 目录选择目标：统一目录或某格式的独立目录。 */
sealed class FolderTarget {
    data object Unified : FolderTarget()
    data class PerFormat(val format: DownloadFormat) : FolderTarget()
    /** 本地音乐文件夹（首页「本地音乐」入口，SAF 选择）。 */
    data object Music : FolderTarget()
}

/** 下载页状态。 */
data class DownloadUiState(
    val input: String = "",
    val parsedWorkId: String? = null,
    val busy: Boolean = false,
    val currentTask: String = "",
    val fileProgress: Float = 0f,
    val totalTasks: Int = 0,
    val finishedTasks: Int = 0,
    val succeeded: Int = 0,
    val failed: Int = 0,
    val sessionExpired: Boolean = false,
    /** 本批 + 历史的下载记录，倒序（最新在前）。 */
    val records: List<DownloadRecord> = emptyList(),
    /** 全部进行中任务的合计速度（字节/秒）。 */
    val speedBps: Long = 0L,
    /** 全部进行中任务里最慢的那个的剩余时间（毫秒）。 */
    val etaMillis: Long? = null,
    /** 当前生效的并发数，界面提示用。 */
    val concurrency: Int = AppSettings.DEFAULT_CONCURRENCY
) {
    val runningCount: Int get() = records.count { it.status == DownloadStatus.RUNNING }
    val queuedCount: Int get() = records.count { it.status == DownloadStatus.QUEUED }
}

/**
 * 「下载」格内用分段控件切换的两个子页（v5.1 导航重构）。
 *
 * 下载负责粘贴编号/链接批量下载，作者搜索查 `/users/<name>/works`，
 * 两者各自保留独立的输入框、结果集与分页状态，只共用一个顶栏与分段控件。
 * 原「搜索作品」子页已升为底部第一格「首页」，原「浏览」子页整体删除。
 */
enum class DownloadTab { DOWNLOAD, AUTHOR }

/** 搜索页「搜索作者」子页状态（v4.6 起与 [WorkSearchUiState] 各自独立）。 */
data class AuthorUiState(
    val usernameInput: String = "",
    val username: String = "",
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val works: List<WorkItem> = emptyList(),
    val page: Int = 1,
    val hasMore: Boolean = false,
    val error: String = "",
    val selectedCount: Int = 0,
    val busy: Boolean = false
)

/**
 * 首页「搜索作品」结果状态（v4.6 新增，走 AO3 站点搜索 `/works/search`）。
 *
 * v5.1 起首页不再折叠结果：搜到多少就铺多少（原「默认只显示前六条、其余折叠」
 * 已按需求删除），因此这里也没有「展开/收起」标记。
 */
data class WorkSearchUiState(
    val queryInput: String = "",
    /** 最近一次真正发起搜索用的关键词，与输入框解耦，翻页时以此为准。 */
    val query: String = "",
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val works: List<WorkItem> = emptyList(),
    val page: Int = 1,
    val hasMore: Boolean = false,
    /** 站点自己给出的命中条数文案（搜索结果页 `h3.heading`，如 "1,234 Found"）。 */
    val totalLabel: String = "",
    /** 从 [totalLabel] 解析出的命中总条数，供分页条算总页数（解析不到为 0）。 */
    val totalCount: Int = 0,
    val error: String = "",
    val selectedCount: Int = 0,
    /** 当前生效的筛选条件（v5.1 新增：结果页筛选面板）。 */
    val filters: WorkSearchFilter = WorkSearchFilter(),
    /** 筛选面板的候选项（分级 / 预警 / 配对 / 语言 / 排序）；内置兜底表 + 在线拉取覆盖。 */
    val filterOptions: SearchFormOptions = WorkSearchDefaults.options,
    /** 筛选面板是否打开。 */
    val filterPanelOpen: Boolean = false,
    /** 是否正在向站点拉取真实筛选项。 */
    val filterLoading: Boolean = false
)

/** 收藏列表状态。 */
data class BookmarkUiState(
    val loading: Boolean = false,
    val items: List<WorkItem> = emptyList(),
    val page: Int = 1,
    val hasMore: Boolean = false,
    val error: String = ""
)

/** HTML 预览状态。 */
data class PreviewState(
    val visible: Boolean = false,
    val title: String = "",
    val html: String = "",
    val original: Boolean = true
)

/**
 * 需求 5：官网 WebView 登录层的界面状态。
 *
 * 状态机很短：`visible` 打开登录页 → 用户自行登录 → 点「完成并提取 Cookie」进入 `busy`
 * → 成功置 `done`（界面据此关闭并回账号页）；官网读不到用户名时置 `needsUsername`，
 * 弹框让用户手填后再置 `done`。任何一步出错都只置 `failed` + `message`，不关页面。
 */
data class WebLoginState(
    val visible: Boolean = false,
    /** 正在校验并落盘 Cookie。 */
    val busy: Boolean = false,
    /** Cookie 已落盘，只差用户名，需要弹框让用户手填。 */
    val needsUsername: Boolean = false,
    /** 提取失败（还没登录、没有会话 Cookie 等），原因见 [message]。 */
    val failed: Boolean = false,
    /** 提取成功，界面据此关闭登录层。 */
    val done: Boolean = false,
    val username: String = "",
    /** 已保存的 Cookie 条数，成功提示里给用户一个可核对的凭据。 */
    val cookieCount: Int = 0,
    val message: String = ""
)

/* ==================== v5.0 新增：浏览页 / 书架 / 阅读 ==================== */

/**
 * 书架、阅读历史与书签共用的书目条目。
 *
 * 字段口径与 [WorkItem] 对齐（标题、作者、tag、章节串、更新时间），但只保留书架需要的那部分，
 * 并且额外承担两件事：**阅读进度**（[readChapters]）与**分组**（[group]）。
 * 全部带默认值，便于从旧数据反序列化时容错。
 */
data class ShelfBook(
    val workId: String,
    val title: String = "",
    val authors: String = "",
    /** 展示用 tag 串（fandom 与自由 tag 合并），搜索框按它命中也算匹配。 */
    val tags: String = "",
    /** AO3 原始章节串，如 `12/15`、`3/?`。 */
    val chapters: String = "",
    /** 已读到第几章（1 起）；0 表示还没读过正文。 */
    val readChapters: Int = 0,
    val updated: String = "",
    /** 分组标签，空串表示未分组。 */
    val group: String = "",
    val addedAt: Long = 0L,
    val restricted: Boolean = false
) {
    /** 列表展示名：标题缺失时退化为作品编号。 */
    val label: String get() = title.ifBlank { "#$workId" }

    val downloadable: Boolean get() = workId.isNotBlank() && workId.all { it.isDigit() }
}

/** 书架页的三个分栏。 */
enum class ShelfTab { HISTORY, BOOKMARKS, SHELF }

/**
 * 书架页状态。
 *
 * 三栏各自独立保存数据；[query] 是共用的搜索框，只做渲染层过滤（数据不丢），
 * 因此切栏、清空关键词都不会丢结果。[syncing] 只覆盖"拉取书签"这段时间。
 */
data class ShelfUiState(
    val tab: ShelfTab = ShelfTab.HISTORY,
    val query: String = "",
    val history: List<ShelfBook> = emptyList(),
    val bookmarks: List<ShelfBook> = emptyList(),
    val shelf: List<ShelfBook> = emptyList(),
    val syncing: Boolean = false,
    /** 拉取书签的提示文案（成功条数 / 需要登录等）。 */
    val message: String = ""
)

/**
 * 内置浏览页状态。
 *
 * [originalUrl] 非空时表示当前正处在译文视图，[url] 是译文地址；
 * 点「返回原文」直接回到 [originalUrl]，不做二次请求。
 */
data class BrowserState(
    val visible: Boolean = false,
    val url: String = "",
    val originalUrl: String = "",
    val title: String = "",
    val loading: Boolean = false,
    val progress: Int = 0,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val translated: Boolean = false,
    val error: String = ""
) {
    /** 当前页面能定位到作品编号时返回它（译文视图回退到原始地址解析）。 */
    val workId: String?
        get() {
            val source = if (translated && originalUrl.isNotBlank()) originalUrl else url
            val marker = "/works/"
            val at = source.indexOf(marker)
            if (at < 0) return null
            val id = source.substring(at + marker.length).takeWhile { it.isDigit() }
            return id.takeIf { it.isNotEmpty() }
        }
}

/** 一章正文：标题 + 段落文本（段落之间以换行分隔）。 */
data class Chapter(
    val index: Int,
    val title: String = "",
    val text: String = ""
) {
    val empty: Boolean get() = text.isBlank()
}

/** 阅读界面状态（v5.0 新增 3；v5.3 补目录 / 设置面板 / 排版 / 精细进度 / 缓存标记）。 */
data class ReaderState(
    val visible: Boolean = false,
    val mode: ReaderMode = ReaderMode.TOMATO,
    val workId: String = "",
    val title: String = "",
    val authors: String = "",
    val summary: String = "",
    val chapters: List<Chapter> = emptyList(),
    val chapterIndex: Int = 0,
    val loading: Boolean = false,
    val error: String = "",
    /** 番茄模式排版（字体字号行距边距与背景主题）。 */
    val typography: ReaderTypography = ReaderTypography(),
    /** 目录抽屉是否打开。 */
    val catalogOpen: Boolean = false,
    /** 阅读设置面板是否打开。 */
    val settingsOpen: Boolean = false,
    /** 当前章内的滚动进度（0..1），打开作品时用于恢复上次读到的位置。 */
    val offsetFrac: Float = 0f,
    /** 正文来自本地缓存（离线可读）；后台刷新成功后会自动转回 false。 */
    val fromCache: Boolean = false
) {
    val totalChapters: Int get() = chapters.size

    /** 已读章节数（1 起），空作品记 0。 */
    val readChapters: Int get() = if (chapters.isEmpty()) 0 else chapterIndex + 1

    val current: Chapter? get() = chapters.getOrNull(chapterIndex)

    val hasPrev: Boolean get() = chapterIndex > 0

    val hasNext: Boolean get() = chapterIndex < chapters.size - 1
}

/** 作品正文抓取结果：元信息 + 摘要 + 逐章正文。 */
data class WorkContent(
    val workId: String,
    val meta: WorkMeta = WorkMeta(workId = workId),
    val summary: String = "",
    val chapters: List<Chapter> = emptyList()
)

/* ==================== v5.1 新增：首页快捷入口与「我的订阅」 ==================== */

/**
 * 首页快捷入口打开的列表类型。
 *
 * 五类入口的列表统一走同一张卡片格式（分级图标、配对、标签胶囊、统计行、编号，
 * 且不含任何下载控件）；[ALL_WORKS] / [TAG_WORKS] / [AUTHOR_WORKS] / [BOOKMARKS]
 * 四类需要联网分页，[SUBSCRIBED_WORKS] / [SUBSCRIBED_AUTHORS] 直接读本地订阅名单。
 */
enum class EntryListKind {
    ALL_WORKS,
    TAG_WORKS,
    AUTHOR_WORKS,
    BOOKMARKS,
    SUBSCRIBED_WORKS,
    SUBSCRIBED_AUTHORS
}

/**
 * 入口列表状态（v5.1）。
 *
 * [works] 与 [authors] 二选一承载内容：作品类列表用 [works]，订阅作者列表用 [authors]。
 * 需要登录才能看的列表（收藏夹）用 [needsLogin] 标记，界面据此给出「去登录」入口。
 */
data class EntryListUiState(
    val visible: Boolean = false,
    val kind: EntryListKind = EntryListKind.ALL_WORKS,
    val title: String = "",
    /** [EntryListKind.TAG_WORKS] 的目标 tag。 */
    val tag: String = "",
    /** [EntryListKind.AUTHOR_WORKS] 的目标作者（pseud）。 */
    val author: String = "",
    val works: List<WorkItem> = emptyList(),
    val authors: List<SubscribedAuthor> = emptyList(),
    val page: Int = 1,
    val hasMore: Boolean = false,
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val error: String = "",
    val totalLabel: String = "",
    /** 需要登录才能继续（收藏夹未登录）。 */
    val needsLogin: Boolean = false
) {
    /** 联网分页的列表类型；订阅类列表是本地数据，不分页。 */
    val paged: Boolean
        get() = kind == EntryListKind.ALL_WORKS ||
            kind == EntryListKind.TAG_WORKS ||
            kind == EntryListKind.AUTHOR_WORKS ||
            kind == EntryListKind.BOOKMARKS

    val empty: Boolean get() = works.isEmpty() && authors.isEmpty()
}

/** 本地订阅的作者（v5.1）。 */
data class SubscribedAuthor(
    val username: String,
    val addedAt: Long = 0L
)

/** 「我的标签」弹窗状态（v5.1）。 */
data class MyTagsUiState(
    val visible: Boolean = false,
    /** 本地保存的标签名单。 */
    val tags: List<String> = emptyList(),
    /** 新增标签的输入框内容。 */
    val input: String = "",
    /** 输入校验或操作提示。 */
    val message: String = ""
)

/** 「我的订阅」面板状态：两栏（作品 / 作者）各自可进入。 */
data class SubscriptionsUiState(
    val panelOpen: Boolean = false,
    val works: List<WorkItem> = emptyList(),
    val authors: List<SubscribedAuthor> = emptyList(),
    /** 在订阅作者列表里直接输入用户名订阅。 */
    val authorInput: String = "",
    val message: String = ""
)

/* ==================== v5.1 新增：本地音乐入口 ==================== */

/** 本地音乐文件夹里扫描到的一条音频。 */
data class LocalTrack(
    /** 展示名（文件名去掉扩展名）。 */
    val title: String,
    /** 原始文件名（含扩展名）。 */
    val fileName: String,
    /** 文档树内的内容地址，播放时直接交给播放器。 */
    val uri: String,
    /** 文件大小（字节），取不到时为 0。 */
    val sizeBytes: Long = 0L,
    /** 同名外部歌词文件（.lrc）的内容地址；没有为 null。 */
    val lyricUri: String? = null,
    /** 同名 / 通用封面图片的内容地址；没有为 null。 */
    val coverUri: String? = null
)

/** 歌词来源：用于详情页展示与排查。 */
enum class LyricSource {
    /** 没找到歌词。 */
    NONE,

    /** 音频内嵌标签（ID3 USLT）。 */
    EMBEDDED,

    /** 同名外部歌词文件（.lrc）。 */
    EXTERNAL
}

/**
 * 「本地音乐」页状态：SAF 选文件夹 + 音频列表 + 播放 / 歌词 / 桌面歌词。
 * 封面位图属 Android 类型，由 ViewModel 侧的 musicCovers 单独承载，不进本模型。
 */
data class LocalMusicUiState(
    val visible: Boolean = false,
    /** 已选文件夹的展示路径；未选为 null。 */
    val folderLabel: String? = null,
    val tracks: List<LocalTrack> = emptyList(),
    val loading: Boolean = false,
    val message: String = "",

    /* ---------------- v5.2：播放与桌面歌词 ---------------- */
    /** 当前选中（播放中或暂停）的音轨。 */
    val current: LocalTrack? = null,
    val playing: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    /** 当前音轨的歌词（桌面歌词条按 positionMs 取行高亮）。 */
    val currentLyrics: List<LyricParser.LyricLine> = emptyList(),
    /** 是否显示 App 内桌面歌词条。 */
    val lyricBar: Boolean = false,

    /* ---------------- v5.2：封面与歌词详情层 ---------------- */
    /** 详情层打开的音轨；null 表示详情层关闭。 */
    val detail: LocalTrack? = null,
    val detailLyrics: List<LyricParser.LyricLine> = emptyList(),
    val detailLyricSource: LyricSource = LyricSource.NONE
)
