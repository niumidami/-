package com.tabbit.aodl.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import com.tabbit.aodl.model.DownloadFormat
import okio.BufferedSource
import java.io.OutputStream

/** SAF 写入结果。 */
sealed class SafWriteResult {
    data class Ok(val uri: Uri, val fileName: String, val bytes: Long) : SafWriteResult()
    data class Err(val reason: SafError, val detail: String = "") : SafWriteResult()
}

enum class SafError {
    NO_FOLDER,
    NOT_WRITABLE,
    CREATE_FAILED,
    IO,
    CANCELLED,

    /** 服务端声明的总长与实际写入字节不一致：响应体被提前结束（v4.2）。 */
    INCOMPLETE,

    /** 收到的头部不是该格式应有的魔数：提示页/被拦截的响应等（v4.2）。 */
    INVALID_CONTENT
}

/**
 * Storage Access Framework 封装：目录选择、持久化权限、文件创建与流式写入。
 *
 * 下载一律写入用户通过 [pickTreeIntent] 选择的目录，不使用应用私有目录，
 * 因此卸载前用户都能直接在文件管理器里看到成品。
 */
object SafStore {

    /** SAF 显示名长度上限（正式名由 FileNameBuilder 限制在 120，这里留出 `.part` 余量）。 */
    private const val MAX_NAME = 180

    /** 目录选择器 Intent（带持久化授权标记）。 */
    fun pickTreeIntent(): Intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
        addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
    }

    /** 取得跨进程重启仍然有效的读写权限。 */
    fun takePersistablePermission(context: Context, treeUri: Uri): Boolean = try {
        context.contentResolver.takePersistableUriPermission(
            treeUri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        true
    } catch (_: Exception) {
        false
    }

    fun releasePersistablePermission(context: Context, treeUri: Uri) {
        runCatching {
            context.contentResolver.releasePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
    }

    /** 目录是否仍然可写（权限被撤销或存储卡拔出时返回 false）。 */
    fun isWritable(context: Context, treeUri: Uri?): Boolean {
        if (treeUri == null) return false
        val dir = DocumentFile.fromTreeUri(context, treeUri) ?: return false
        return dir.exists() && dir.isDirectory && dir.canWrite()
    }

    /** 目录的可读名称，用于界面展示。 */
    fun displayName(context: Context, treeUri: Uri?): String? {
        if (treeUri == null) return null
        val dir = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        val self = dir.name
        if (!self.isNullOrBlank()) return self
        return runCatching {
            DocumentsContract.getTreeDocumentId(treeUri).substringAfterLast(':').ifBlank { treeUri.lastPathSegment }
        }.getOrNull()
    }

    /** 展示用完整路径（tree id 形如 `primary:Download/AO3`）。 */
    fun displayPath(treeUri: Uri?): String? {
        if (treeUri == null) return null
        return runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull()
    }

    /**
     * 在目录中创建文件并返回其 Uri 与 provider **实际采用**的显示名。
     *
     * 第二个值不是请求时的名字，而是回读文档得到的真实名字：provider 遇重名会改成
     * `name (1)`，部分实现还会按 MIME 再补一次扩展名（`.pdf.part` → `.pdf.part.pdf`）。
     * 调用方必须拿这个真实名字做后续查找、重命名与清理，否则会出现残片删不掉、
     * 续传找不到、越积越多的问题（v4.2 修复 #2 的目标场景）。
     *
     * @param overwrite true 时删除同名旧文件后重建；false 时自动生成 "name (1).ext" 之类的新名字。
     */
    fun createFile(
        context: Context,
        treeUri: Uri,
        fileName: String,
        mime: String,
        overwrite: Boolean = false
    ): Pair<Uri, String>? {
        val dir = DocumentFile.fromTreeUri(context, treeUri) ?: return null
        if (!dir.exists() || !dir.canWrite()) return null
        val safeName = sanitize(fileName)
        val existing = dir.findFile(safeName)
        if (existing != null) {
            if (overwrite) {
                if (!existing.delete()) return null
            } else {
                val unique = uniqueName(dir, safeName)
                val created = DocumentsContract.createDocument(context.contentResolver, dir.uri, mime, unique)
                return created?.let { it to (actualName(context, it) ?: unique) }
            }
        }
        val created = DocumentsContract.createDocument(context.contentResolver, dir.uri, mime, safeName)
        return created?.let { it to (actualName(context, it) ?: safeName) }
    }

    /** provider 实际采用的显示名；查询失败返回 null。 */
    fun actualName(context: Context, fileUri: Uri): String? =
        runCatching { DocumentFile.fromSingleUri(context, fileUri)?.name }
            .getOrNull()
            ?.takeIf { it.isNotBlank() }

    /** 打开输出流（覆盖模式，会截断已有内容）。 */
    fun openWrite(context: Context, fileUri: Uri): OutputStream? =
        runCatching { context.contentResolver.openOutputStream(fileUri, "wt") }
            .getOrNull()
            ?: runCatching { context.contentResolver.openOutputStream(fileUri) }.getOrNull()

    /** 打开输出流（追加模式，断点续传用）；provider 不支持时返回 null，调用方应退回覆盖模式。 */
    fun openAppend(context: Context, fileUri: Uri): OutputStream? =
        runCatching { context.contentResolver.openOutputStream(fileUri, "wa") }.getOrNull()

    /**
     * 从网络响应流式写入 SAF 文件，并在写入过程中完成完整性校验。
     *
     * 校验逻辑全部收在纯函数 [StreamCopy] 里（单测已覆盖：字节与响应体一致、
     * 截断判失败、头部魔数不符判失败），因此 v4.2 之后**不会再出现
     * "残缺内容被重命名为正式文件、用户打开是损坏文件"** 的情况。
     *
     * @param totalLength 服务端声明的完整文件大小；未知（chunked）时传 0 或负数
     * @param baseOffset 断点续传时本地已有字节数，进度按 `baseOffset + 本次写入` 上报
     * @param format 请求的格式，用于头部魔数校验；null 表示不校验
     * @param onProgress `(已写入总字节, 完整大小, 瞬时速度 B/s)`，返回 false 表示取消
     */
    fun writeFrom(
        source: BufferedSource,
        output: OutputStream,
        totalLength: Long,
        baseOffset: Long = 0L,
        format: DownloadFormat? = null,
        onProgress: (written: Long, total: Long, speedBps: Long) -> Boolean = { _, _, _ -> true }
    ): SafWriteResult =
        when (
            val result = StreamCopy.copy(source, output, totalLength, baseOffset, format, onProgress)
        ) {
            is CopyResult.Ok -> SafWriteResult.Ok(Uri.EMPTY, "", result.bytes)
            is CopyResult.Cancelled -> SafWriteResult.Err(SafError.CANCELLED)
            is CopyResult.Err -> SafWriteResult.Err(result.reason.toSafError(), result.detail)
        }

    private fun CopyError.toSafError(): SafError = when (this) {
        CopyError.IO -> SafError.IO
        CopyError.INCOMPLETE -> SafError.INCOMPLETE
        CopyError.INVALID_CONTENT -> SafError.INVALID_CONTENT
    }

    // ------------------------------------------------------------ 子目录管理

    /** 目录「先查后建」的串行化解析器（决策逻辑在 [resolveSubDir]，此处只做适配）。 */
    private val subDirResolver = SubDirResolver<DocumentFile>({ it.uri.toString() })

    /**
     * 在目录下查找或创建子目录（需求 2）。
     *
     * 决策收在纯函数 [resolveSubDir] 里（单测用假 provider 覆盖「同名目录已存在」
     * 「新建被 provider 改名成 name (1)」两种情形），这里只把 DocumentFile 适配成 [SubDirOps]。
     *
     * v4.2 修复：同一「父目录 + 名字」的查建过程按名字串行化。旧实现是非原子的
     * 「查 → 建 → 复核」，并发批量任务会同时判定"目录不存在"而各建一个，被 provider
     * 改名成 `onee1e (1)`，于是每次批量下载都多出一个重复文件夹（用户实测缺陷）。
     */
    fun ensureSubDir(context: Context, parentUri: Uri, rawName: String, fallbackName: String): Uri? {
        val name = FileNameBuilder.dirName(rawName, fallbackName)
        val parent = DocumentFile.fromTreeUri(context, parentUri) ?: return null
        if (!parent.exists() || !parent.canWrite()) return null
        val (outcome, ops) = subDirResolver.resolve(parent, name) { TreeSubDirOps(parent) }
        val resolved = when (outcome) {
            is SubDirOutcome.Reused -> outcome.name
            is SubDirOutcome.Created -> outcome.name
            is SubDirOutcome.Collapsed -> outcome.name
            SubDirOutcome.Failed -> return null
        }
        return ops.resolve(resolved)
    }

    /** 逐级创建/复用子目录，任一级失败返回 null。 */
    fun ensureSubDirs(context: Context, rootUri: Uri, names: List<Pair<String, String>>): Uri? {
        var current = rootUri
        names.forEach { (raw, fallback) ->
            current = ensureSubDir(context, current, raw, fallback) ?: return null
        }
        return current
    }

    /** 在目录中按名字查找子项，返回其 Uri。 */
    fun findChild(context: Context, dirUri: Uri, name: String): Uri? =
        DocumentFile.fromTreeUri(context, dirUri)?.findFile(name)?.uri

    /**
     * 目录内可用的唯一文件名：目标名空闲时原样返回，否则追加 " (1)"、" (2)"…
     *
     * 断点续传完成后把 `xxx.part` 改回正式名时使用——已存在同名成品时不覆盖，
     * 与 v3.0 的 `createFile(overwrite = false)` 行为保持一致。
     */
    fun uniqueChildName(context: Context, dirUri: Uri, fileName: String): String {
        val safe = sanitize(fileName)
        val dir = DocumentFile.fromTreeUri(context, dirUri) ?: return safe
        return if (dir.findFile(safe) == null) safe else uniqueName(dir, safe)
    }

    /** 子项大小；不存在返回 -1。 */
    fun childSize(context: Context, dirUri: Uri, name: String): Long =
        DocumentFile.fromTreeUri(context, dirUri)?.findFile(name)?.takeIf { it.isFile }?.length() ?: -1L

    // ------------------------------------------------------------ 中间文件（.part）

    /** 盘上的一份中间文件。 */
    data class PartFile(val uri: Uri, val name: String, val bytes: Long)

    /**
     * 找出目录里属于 [finalName] 的中间文件（v4.2 修复 #2）。
     *
     * 不再用 `findChild(请求名)`：provider 可能把名字改成 `xxx.pdf.part.pdf` 或 `xxx (1).pdf.part`，
     * 按名字精确查找会全部落空——断点探测不到、`dropPart` 删不掉、续传还会再建一份新的，
     * 残片于是越积越多。这里改用 [PartCleanup] 的名字模式扫描，多份残留时取**最大**的一份作为断点。
     */
    fun findPart(context: Context, dirUri: Uri, finalName: String): PartFile? {
        if (finalName.isBlank()) return null
        val dir = DocumentFile.fromTreeUri(context, dirUri) ?: return null
        return dir.listFiles()
            .asSequence()
            .filter { !it.isDirectory && PartCleanup.isIntermediateOf(it.name.orEmpty(), finalName) }
            .maxByOrNull { it.length() }
            ?.let { PartFile(it.uri, it.name.orEmpty(), it.length().coerceAtLeast(0L)) }
    }

    /** 目录下的全部子文件（不含子目录）；目录不可用时返回 null。 */
    private fun childFiles(context: Context, dirUri: Uri): List<DocumentFile>? =
        DocumentFile.fromTreeUri(context, dirUri)
            ?.listFiles()
            ?.filter { !it.isDirectory }

    /**
     * 按 [PartCleanup.planCleanup] 的决策清理 [finalName] 名下的中间文件（v4.2 修复 #2）。
     *
     * 「留哪份、删哪些、要不要改名」全部由纯函数决定，单测已覆盖两种收尾
     * （成功/失败全清、取消只留一份规范 `.part`）；这里只负责把决策落到 SAF 上。
     * 正式成品永远不会被选中，因此不可能被误删。
     *
     * @param keepForResume true=保留断点（取消/中断），false=全部清除
     * @return 实际删掉的那些文件名，供日志如实告知用户清理了什么
     */
    fun cleanupParts(
        context: Context,
        dirUri: Uri,
        finalName: String,
        keepForResume: Boolean
    ): List<String> {
        if (finalName.isBlank()) return emptyList()
        val files = childFiles(context, dirUri) ?: return emptyList()
        val byName = files.associateBy { it.name.orEmpty() }
        val plan = PartCleanup.planCleanup(
            children = byName.keys.toList(),
            finalName = finalName,
            sizeOf = { name -> byName[name]?.length()?.coerceAtLeast(0L) ?: 0L },
            keepForResume = keepForResume
        )
        if (plan.isNothingToDo) return emptyList()

        val removed = ArrayList<String>()
        plan.delete.forEach { name ->
            val file = byName[name] ?: return@forEach
            if (runCatching { file.delete() }.getOrDefault(false)) removed += name
        }
        // 先删变体再改名：目标规范名可能正被某份变体占着，删完才不会撞名
        val renameTo = plan.renameTo
        if (renameTo != null) {
            byName[plan.keep]?.let { renameIn(context, dirUri, it.uri, renameTo) }
        }
        return removed
    }

    /**
     * 删除除 [keep] 之外的全部中间文件，返回删掉的文件名。
     *
     * 只用于一种场合：内容已经写完整，但 provider 不支持重命名，成品只能继续以
     * `.part` 形式留在盘上。此时不能按大小挑「保留哪一份」（旧版本留下的超长残片
     * 可能比刚写完的这份还大），必须**按 Uri 明确保住刚写完的那一份**。
     */
    fun deletePartsExcept(context: Context, dirUri: Uri, finalName: String, keep: Uri?): List<String> {
        if (finalName.isBlank()) return emptyList()
        val files = childFiles(context, dirUri) ?: return emptyList()
        val removed = ArrayList<String>()
        files.forEach { file ->
            val name = file.name.orEmpty()
            if (file.uri != keep &&
                PartCleanup.isIntermediateOf(name, finalName) &&
                runCatching { file.delete() }.getOrDefault(false)
            ) {
                removed += name
            }
        }
        return removed
    }

    /**
     * 把中间文件收敛成唯一一份规范命名的 `finalName.part`（v4.2 修复 #2）。
     *
     * 用于「下载中断 / 用户取消」的场合：删掉全部变体与重复，只留最大的一份，名字回到
     * 规范形式，下次续传按 [findPart] 稳定命中。不改动正式成品。
     *
     * @return 收敛后那份文件的 Uri；目录里没有任何中间文件时返回 null。
     */
    fun normalizePart(context: Context, dirUri: Uri, finalName: String): Uri? {
        cleanupParts(context, dirUri, finalName, keepForResume = true)
        return findPart(context, dirUri, finalName)?.uri
    }

    /** 清掉 [finalName] 的全部中间文件（正式成品不受影响），返回删掉的文件名。 */
    fun dropParts(context: Context, dirUri: Uri, finalName: String): List<String> =
        cleanupParts(context, dirUri, finalName, keepForResume = false)

    /**
     * 重命名文档（断点续传完成后把 `xxx.part` 改回正式名）。
     *
     * 目标名已存在时先删除，避免 provider 自动改成 "name (1)"；
     * 重命名失败（个别 provider 不支持）时返回 null，调用方保留 `.part` 并如实上报。
     */
    fun renameIn(context: Context, dirUri: Uri, fileUri: Uri, newName: String): Uri? {
        val safe = sanitize(newName)
        val dir = DocumentFile.fromTreeUri(context, dirUri) ?: return null
        dir.findFile(safe)?.let { existing ->
            if (existing.uri == fileUri) return fileUri
            runCatching { existing.delete() }
        }
        val renamed = runCatching {
            DocumentsContract.renameDocument(context.contentResolver, fileUri, safe)
        }.getOrNull()
        if (renamed != null) return renamed
        return dir.findFile(safe)?.uri
    }

    /** 直接写入文本（HTML 美化结果使用）。 */
    fun writeText(context: Context, fileUri: Uri, text: String): SafWriteResult = try {
        val bytes = text.toByteArray(Charsets.UTF_8)
        val out = context.contentResolver.openOutputStream(fileUri, "wt")
        if (out == null) {
            SafWriteResult.Err(SafError.IO, "cannot open output stream")
        } else {
            out.use { stream ->
                stream.write(bytes)
                stream.flush()
            }
            SafWriteResult.Ok(fileUri, "", bytes.size.toLong())
        }
    } catch (e: Exception) {
        SafWriteResult.Err(SafError.IO, "${e.javaClass.simpleName}: ${e.message.orEmpty()}")
    }

    /** 读取文本内容（美化时解析已下载的 HTML）。 */
    fun readText(context: Context, fileUri: Uri): String? = try {
        context.contentResolver.openInputStream(fileUri)?.use { input ->
            input.readBytes().toString(Charsets.UTF_8)
        }
    } catch (_: Exception) {
        null
    }

    fun fileSize(context: Context, fileUri: Uri): Long =
        DocumentFile.fromSingleUri(context, fileUri)?.length() ?: 0L

    fun delete(context: Context, fileUri: Uri): Boolean =
        DocumentFile.fromSingleUri(context, fileUri)?.delete() ?: false

    fun exists(context: Context, treeUri: Uri, fileName: String): Boolean {
        val dir = DocumentFile.fromTreeUri(context, treeUri) ?: return false
        return dir.findFile(sanitize(fileName)) != null
    }

    /** 目录下已存在的文件数，用于"保存位置"展示。 */
    fun childCount(context: Context, treeUri: Uri?): Int {
        if (treeUri == null) return 0
        val dir = DocumentFile.fromTreeUri(context, treeUri) ?: return 0
        return dir.listFiles().size
    }

    private fun uniqueName(dir: DocumentFile, fileName: String): String {
        val base = fileName.substringBeforeLast('.', fileName)
        val ext = if (fileName.contains('.')) "." + fileName.substringAfterLast('.') else ""
        var index = 1
        var candidate = "$base ($index)$ext"
        while (dir.findFile(candidate) != null && index < 999) {
            index++
            candidate = "$base ($index)$ext"
        }
        return candidate
    }

    fun sanitize(raw: String): String {
        val cleaned = raw.trim().substringAfterLast('/')
            .replace(Regex("[\\\\/:*?\"<>|\\x00-\\x1F]"), "_")
            .replace(Regex("\\s+"), " ")
            .trim()
        // 上限放宽到 MAX_NAME，避免把断点续传的 ".part" 后缀截掉；
        // 正式文件名长度由 FileNameBuilder 控制在 120 以内。
        return cleaned.ifEmpty { "AO3-download" }.take(MAX_NAME)
    }

    /** [SubDirOps] 的 SAF 实现：把 DocumentFile 适配成纯决策逻辑需要的那几个动作。 */
    private class TreeSubDirOps(private val parent: DocumentFile) : SubDirOps {

        private var created: DocumentFile? = null

        override fun existingDir(name: String): Boolean =
            parent.findFile(name)?.isDirectory == true

        override fun createDir(name: String): String? {
            val dir = parent.createDirectory(name) ?: return null
            created = dir
            // provider 遇到重名会把新目录改名成 "name (1)"，因此回读它实际采用的名字
            return dir.name ?: name
        }

        override fun createdIsEmpty(): Boolean = created?.listFiles()?.isEmpty() ?: false

        override fun dropCreated(): Boolean = created?.delete() == true

        /** 最终要使用的目录 Uri：优先按名字回查，查不到时退回刚创建的那个。 */
        fun resolve(name: String): Uri? =
            parent.findFile(name)?.takeIf { it.isDirectory }?.uri
                ?: created?.takeIf { it.name == name }?.uri
    }
}
