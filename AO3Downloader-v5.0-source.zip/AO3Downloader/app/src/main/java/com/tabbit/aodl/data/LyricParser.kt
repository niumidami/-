package com.tabbit.aodl.data

import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/**
 * LRC 歌词解析规则（v5.2）。
 *
 * 纯对象：不碰 Android 与文件系统，可离线跑 JVM 单测。
 * 支持标准 LRC 时间轴（mm:ss / mm:ss.xx / mm:ss.xxx）、一行多时间轴、
 * [offset:] 整体偏移；没有时间轴的文本按纯文本逐行处理。
 */
object LyricParser {

    /** 一行歌词；[timeMs] 为 null 表示纯文本行（不参与时间定位）。 */
    data class LyricLine(
        val timeMs: Long?,
        val text: String
    )

    /** 时间轴：[mm:ss]、[mm:ss.x]、[mm:ss.xx]、[mm:ss.xxx]，分钟可多位。 */
    private val TIME_TAG = Regex("""\[(\d{1,4}):(\d{1,2})(?:[.:](\d{1,3}))?]""")

    /** 整体偏移：[offset:+500] / [offset:-200]，单位毫秒。 */
    private val OFFSET_TAG = Regex("""\[offset:\s*([+-]?\d+)\s*]""", RegexOption.IGNORE_CASE)

    /** 元数据行：[ti:..] [ar:..] 等；纯文本回退时不作为歌词行。 */
    private val META_TAG = Regex("""\[[a-zA-Z#]+:[^]]*]""")

    /**
     * 解析歌词文本。
     * 存在时间轴时返回按时间升序的带轴行（一行多轴会拆成多行）；
     * 完全没有时间轴时按纯文本返回非空行（timeMs = null）。
     */
    fun parse(raw: String?): List<LyricLine> {
        if (raw.isNullOrBlank()) return emptyList()
        var offset = 0L
        val timed = mutableListOf<LyricLine>()
        raw.lineSequence().forEach { line ->
            OFFSET_TAG.find(line)?.let { match ->
                offset += match.groupValues[1].toLongOrNull() ?: 0L
            }
            val stamps = TIME_TAG.findAll(line).toList()
            if (stamps.isEmpty()) return@forEach
            val text = line.replace(TIME_TAG, "").replace(OFFSET_TAG, "").trim()
            stamps.forEach { stamp ->
                val minutes = stamp.groupValues[1].toLongOrNull() ?: return@forEach
                val seconds = stamp.groupValues[2].toLongOrNull() ?: return@forEach
                if (seconds >= 60L) return@forEach
                val fracRaw = stamp.groupValues[3]
                val frac = if (fracRaw.isEmpty()) 0L else fracRaw.toLong() * pow10(3 - fracRaw.length)
                val time = minutes * 60_000L + seconds * 1_000L + frac - offset
                timed += LyricLine(timeMs = time.coerceAtLeast(0L), text = text)
            }
        }
        if (timed.isNotEmpty()) return timed.sortedBy { it.timeMs }
        return raw.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .filterNot { META_TAG.matches(it) }
            .map { LyricLine(timeMs = null, text = it) }
    }

    /** 是否含时间轴（决定能否随播放进度高亮）。 */
    fun isTimed(lines: List<LyricLine>): Boolean = lines.any { it.timeMs != null }

    /**
     * 播放进度对应的歌词行下标：最后一个 timeMs <= positionMs 的行。
     * 纯文本、空列表或尚未到第一行时返回 -1。
     */
    fun activeIndex(lines: List<LyricLine>, positionMs: Long): Int {
        if (!isTimed(lines)) return -1
        var index = -1
        for (i in lines.indices) {
            val time = lines[i].timeMs ?: continue
            if (time <= positionMs) index = i else break
        }
        return index
    }

    /**
     * 歌词文件字节解码：优先 UTF-8（严格校验），失败退 GBK，最后 ISO-8859-1 兜底。
     * 开头的 BOM 一律去掉。
     */
    fun decodeText(bytes: ByteArray): String {
        if (bytes.isEmpty()) return ""
        val strictUtf8 = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        val decoded = runCatching { strictUtf8.decode(ByteBuffer.wrap(bytes)).toString() }
            .getOrElse {
                runCatching { String(bytes, Charset.forName("GBK")) }
                    .getOrElse { String(bytes, Charsets.ISO_8859_1) }
            }
        return decoded.removePrefix("\uFEFF")
    }

    private fun pow10(n: Int): Long = when (n) {
        0 -> 1L
        1 -> 10L
        2 -> 100L
        else -> 1000L
    }
}
