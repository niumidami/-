package com.tabbit.aodl.data

import com.tabbit.aodl.model.DownloadFormat

/**
 * 下载产物头部魔数校验（v4.2 修复 #2）。
 *
 * 只靠 `Content-Type` 与 EOF 判定"下载成功"是不够的：受限作品、登录失效、
 * DNS/链路被拦截时，服务端或中间设备都可能返回一段 HTML 提示页，
 * 而 `Content-Type` 未必如实反映真实内容。这种内容一旦被命名为 `.pdf` 存下来，
 * 用户打开就是"文件已损坏"（用户实测截图里打开 .pdf 得到一屏二进制乱码）。
 *
 * 校验只取**格式规范里固定不变**的头部特征，不做严格解析，避免误判正常文件：
 *
 * | 格式 | 头部特征 |
 * | --- | --- |
 * | HTML | 跳过 UTF-8 BOM 与空白后以 `<` 开头 |
 * | PDF | 以 `%PDF` 开头 |
 * | EPUB | 以 ZIP 局部文件头 `PK` 开头 |
 * | MOBI / AZW3 | PalmDB 头部第 60–67 字节为 `BOOKMOBI` |
 *
 * 本文件不依赖 Android API，可在 JVM 单测里直接断言（见 `FormatSignatureTest`）。
 */
internal object FormatSignature {

    /** 判定魔数所需读取的头部字节数（取 MOBI 系列的最长偏移 60 + 8）。 */
    const val HEAD_BYTES = 68

    private val PDF_MAGIC = "%PDF".toByteArray(Charsets.US_ASCII)

    private val ZIP_MAGIC = byteArrayOf(0x50, 0x4B)

    private val MOBI_MAGIC = "BOOKMOBI".toByteArray(Charsets.US_ASCII)

    private const val MOBI_OFFSET = 60

    /**
     * 校验头部字节是否符合 [format]。
     *
     * @param head 从响应体开头读到的字节（至少 [length] 个有效字节）
     * @param length [head] 中的有效长度
     * @return 通过返回 null；否则返回人类可读的失败原因
     */
    fun check(format: DownloadFormat, head: ByteArray, length: Int): String? = when (format) {
        DownloadFormat.HTML ->
            if (looksLikeHtml(head, length)) null else "开头不是 HTML 文本"

        DownloadFormat.PDF ->
            if (matchesAt(head, length, PDF_MAGIC, 0)) null else "缺少 %PDF 文件头"

        DownloadFormat.EPUB ->
            if (matchesAt(head, length, ZIP_MAGIC, 0)) null else "不是 EPUB（ZIP）容器"

        DownloadFormat.MOBI, DownloadFormat.AZW3 ->
            if (matchesAt(head, length, MOBI_MAGIC, MOBI_OFFSET)) null else "缺少 BOOKMOBI 文件头"
    }

    /** 期望的头部特征描述，用于日志与错误提示。 */
    fun expectation(format: DownloadFormat): String = when (format) {
        DownloadFormat.HTML -> "< 开头的 HTML"
        DownloadFormat.PDF -> "%PDF 文件头"
        DownloadFormat.EPUB -> "PK（ZIP）文件头"
        DownloadFormat.MOBI, DownloadFormat.AZW3 -> "BOOKMOBI 文件头"
    }

    private fun matchesAt(head: ByteArray, length: Int, magic: ByteArray, offset: Int): Boolean {
        if (length < offset + magic.size) return false
        for (index in magic.indices) {
            if (head[offset + index] != magic[index]) return false
        }
        return true
    }

    /** HTML 允许 BOM 与前导空白，要求跳过之后第一个非空白字符是 `<`。 */
    private fun looksLikeHtml(head: ByteArray, length: Int): Boolean {
        var index = 0
        if (length >= 3 &&
            head[0] == 0xEF.toByte() && head[1] == 0xBB.toByte() && head[2] == 0xBF.toByte()
        ) {
            index = 3
        }
        while (index < length) {
            val ch = head[index].toInt().toChar()
            if (!ch.isWhitespace()) return ch == '<'
            index++
        }
        return false
    }
}