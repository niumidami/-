package com.tabbit.aodl.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.data.LyricParser
import com.tabbit.aodl.data.MusicScanner
import com.tabbit.aodl.model.LocalMusicUiState
import com.tabbit.aodl.model.LocalTrack
import com.tabbit.aodl.model.LyricSource
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel

/**
 * 本地音乐页（v5.2）。
 *
 * 音频列表带封面缩略图与播放态；点行播放/暂停；行尾进入「封面与歌词」详情层。
 * 桌面歌词条由 AppRoot 统一挂载（[DesktopLyricBar]），离开本页也能悬浮显示。
 */
@Composable
fun LocalMusicScreen(
    vm: AppViewModel,
    onPickFolder: () -> Unit
) {
    val state by vm.music.collectAsStateWithLifecycle()
    val covers by vm.musicCovers.collectAsStateWithLifecycle()

    Box(modifier = Modifier.fillMaxSize()) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                /* ---------------- 顶栏：返回 + 标题 + 桌面歌词 + 换文件夹 */
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = vm::closeLocalMusic) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = stringResource(R.string.music_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (state.current != null) {
                        IconButton(onClick = vm::toggleLyricBar) {
                            Icon(
                                Icons.Filled.Lyrics,
                                contentDescription = stringResource(
                                    if (state.lyricBar) R.string.music_lyric_bar_hide else R.string.music_lyric_bar_show
                                ),
                                tint = if (state.lyricBar) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.ext.textSecondary
                                }
                            )
                        }
                    }
                    if (state.tracks.isNotEmpty()) {
                        IconButton(onClick = vm::openLocalMusic) {
                            Icon(
                                Icons.Filled.Refresh,
                                contentDescription = stringResource(R.string.music_rescan),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    IconButton(onClick = onPickFolder) {
                        Icon(
                            Icons.Filled.FolderOpen,
                            contentDescription = stringResource(R.string.music_pick_folder),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // 已选文件夹的展示路径
                state.folderLabel?.takeIf { it.isNotBlank() }?.let { label ->
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }

                when {
                    state.loading -> CenterLoading()

                    state.folderLabel == null -> Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = stringResource(R.string.music_no_folder),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.ext.textSecondary
                            )
                            Spacer(Modifier.height(16.dp))
                            GradientButton(
                                text = stringResource(R.string.music_pick_folder),
                                onClick = onPickFolder,
                                icon = Icons.Filled.FolderOpen,
                                modifier = Modifier.width(200.dp)
                            )
                        }
                    }

                    state.tracks.isEmpty() -> EmptyHint(
                        text = state.message.ifBlank { stringResource(R.string.music_empty) }
                    )

                    else -> TrackList(
                        state = state,
                        covers = covers,
                        onPlay = vm::playTrack,
                        onDetail = vm::openTrackDetail,
                        onRequestCover = vm::ensureCover
                    )
                }
            }
        }

        // 封面与歌词详情层（不改变播放状态）
        state.detail?.let { track ->
            TrackDetailOverlay(
                track = track,
                state = state,
                cover = covers[track.uri],
                vm = vm
            )
        }
    }
}

/** 音频列表：封面缩略图 + 展示名 + 播放态，按名称排序（扫描侧已排好）。 */
@Composable
private fun TrackList(
    state: LocalMusicUiState,
    covers: Map<String, Bitmap>,
    onPlay: (LocalTrack) -> Unit,
    onDetail: (LocalTrack) -> Unit,
    onRequestCover: (LocalTrack) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
    ) {
        items(state.tracks, key = { it.uri }) { track ->
            TrackRow(
                track = track,
                isCurrent = state.current?.uri == track.uri,
                playing = state.playing,
                cover = covers[track.uri],
                onClick = { onPlay(track) },
                onDetail = { onDetail(track) },
                onRequestCover = { onRequestCover(track) }
            )
        }
    }
}

@Composable
private fun TrackRow(
    track: LocalTrack,
    isCurrent: Boolean,
    playing: Boolean,
    cover: Bitmap?,
    onClick: () -> Unit,
    onDetail: () -> Unit,
    onRequestCover: () -> Unit
) {
    LaunchedEffect(track.uri) { onRequestCover() }
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.ext.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CoverBox(cover = cover, size = 44.dp)
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = track.fileName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.ext.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (isCurrent) {
            Icon(
                imageVector = if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = stringResource(if (playing) R.string.music_pause else R.string.music_play),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(6.dp))
        }
        val size = MusicScanner.formatSize(track.sizeBytes)
        if (size.isNotBlank()) {
            Text(
                text = size,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.ext.textSecondary
            )
            Spacer(Modifier.width(4.dp))
        }
        IconButton(onClick = onDetail) {
            Icon(
                Icons.Filled.Lyrics,
                contentDescription = stringResource(R.string.music_detail),
                tint = MaterialTheme.ext.textSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/** 封面方块：有位图显示位图，没有则退回音乐符号占位。 */
@Composable
private fun CoverBox(cover: Bitmap?, size: androidx.compose.ui.unit.Dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.ext.card),
        contentAlignment = Alignment.Center
    ) {
        if (cover != null) {
            Image(
                bitmap = cover.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                Icons.Filled.MusicNote,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(size / 2)
            )
        }
    }
}

/** 「封面与歌词」详情层：大封面、来源标注、播放控制、歌词列表（带轴歌词随进度高亮）。 */
@Composable
private fun TrackDetailOverlay(
    track: LocalTrack,
    state: LocalMusicUiState,
    cover: Bitmap?,
    vm: AppViewModel
) {
    val isCurrent = state.current?.uri == track.uri
    val active = if (isCurrent) LyricParser.activeIndex(state.detailLyrics, state.positionMs) else -1
    val listState = rememberLazyListState()
    LaunchedEffect(active) {
        if (active > 1) listState.animateScrollToItem(active - 1)
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::closeTrackDetail) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.action_back),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = stringResource(R.string.music_detail),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CoverBox(cover = cover, size = 96.dp)
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = track.fileName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    val size = MusicScanner.formatSize(track.sizeBytes)
                    if (size.isNotBlank()) {
                        Text(
                            text = size,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.ext.textSecondary
                        )
                    }
                    when (state.detailLyricSource) {
                        LyricSource.EXTERNAL -> Text(
                            text = stringResource(R.string.music_lyrics_external),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        LyricSource.EMBEDDED -> Text(
                            text = stringResource(R.string.music_lyrics_embedded),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        LyricSource.NONE -> Unit
                    }
                }
            }

            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SecondaryButton(
                    text = stringResource(
                        if (isCurrent && state.playing) R.string.music_pause else R.string.music_play
                    ),
                    onClick = { vm.playTrack(track) },
                    icon = if (isCurrent && state.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow
                )
                SecondaryButton(
                    text = stringResource(
                        if (state.lyricBar) R.string.music_lyric_bar_hide else R.string.music_lyric_bar_show
                    ),
                    onClick = vm::toggleLyricBar,
                    enabled = state.current != null,
                    icon = Icons.Filled.Lyrics
                )
            }

            if (state.detailLyrics.isEmpty()) {
                EmptyHint(text = stringResource(R.string.music_lyrics_none))
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp),
                    contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(state.detailLyrics) { index, line ->
                        Text(
                            text = line.text.ifBlank { "…" },
                            style = if (index == active) {
                                MaterialTheme.typography.bodyLarge
                            } else {
                                MaterialTheme.typography.bodyMedium
                            },
                            color = when {
                                index == active -> MaterialTheme.colorScheme.primary
                                isCurrent && active >= 0 && index < active -> MaterialTheme.ext.textSecondary
                                else -> MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                }
            }
        }
    }
}
