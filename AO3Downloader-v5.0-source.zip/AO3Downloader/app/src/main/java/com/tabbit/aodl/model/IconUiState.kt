package com.tabbit.aodl.model

import android.graphics.Bitmap

/**
 * 图标选择状态（需求 4）。
 *
 * 单独成文件、不并入 `Models.kt`：那里刻意保持不依赖 Android 框架类以便纯 JVM 单测，
 * 而本状态必须持有解码后的 [Bitmap]。
 *
 * [activeIcon] 是**桌面 alias 正在使用**的那套内置图标；当 [choice] 为
 * [AppIcon.CUSTOM_CHOICE] 且 [customBitmap] 非空时，应用内的图标位改用它渲染。
 */
data class IconUiState(
    /** 当前选择：内置图标名（如 `SAKURA`）或 [AppIcon.CUSTOM_CHOICE]。 */
    val choice: String = AppIcon.DEFAULT.name,
    /** 桌面 alias 实际生效的内置图标；自定义图片模式下为回退用的那一套。 */
    val activeIcon: AppIcon = AppIcon.DEFAULT,
    /** 应用私有目录里是否存着用户上传的图片。 */
    val hasCustom: Boolean = false,
    /** 已上传图片的内存位图（256×256），为空表示当前不用自定义图渲染。 */
    val customBitmap: Bitmap? = null,
    /** 正在读取/缩放上传的图片。 */
    val importing: Boolean = false,
    /** 当前桌面是否支持固定快捷方式（API 26+ 还需桌面实现该能力）。 */
    val shortcutSupported: Boolean = false
) {
    /** 应用内图标位是否渲染用户上传的图片。 */
    val useCustom: Boolean get() = customBitmap != null && choice == AppIcon.CUSTOM_CHOICE
}
