package com.tabbit.aodl.data

import java.net.URLEncoder

/**
 * 需求（v5.0 新增 4）：内置浏览页与搜索入口的地址规划。
 *
 * 与 AO3 站点结构对应的几条固定路径都收敛在这里，界面层只做「拿路径 → 交给浏览页」，
 * 不在 Composable 里手写字符串拼 URL。纯函数，可离线断言。
 */
object BrowserPlan {

    const val SITE = "https://archiveofourown.org"

    /** 全部作品：站点作品索引。 */
    const val PATH_ALL_WORKS = "/works"

    /**
     * 最近更新：作品索引按「最近修订时间」倒序。
     *
     * 用的是作品索引页自己的筛选参数 `work_search[sort_column]`（已按 URL 规则转义方括号），
     * 与右侧筛选栏提交的地址形态一致。
     */
    const val PATH_RECENT =
        "/works?work_search%5Bsort_column%5D=revised_at&work_search%5Bsort_direction%5D=desc"

    /** 热门 tag：站点 tag 索引页。 */
    const val PATH_HOT_TAGS = "/tags"

    /** 全站公开书签（未登录时的收藏夹入口）。 */
    const val PATH_ALL_BOOKMARKS = "/bookmarks"

    const val PATH_SEARCH = "/works/search"

    fun workPath(workId: String): String = "/works/${workId.trim()}"

    fun workUrl(workId: String): String = SITE + workPath(workId)

    fun searchWorksPath(query: String): String =
        "$PATH_SEARCH?work_search%5Bquery%5D=${encode(query)}&commit=Search"

    /**
     * tag 作品页：`/tags/<tag>/works`，空格自动转下划线。
     *
     * AO3 的 tag 地址把空格写成下划线（`Time Travel` → `Time_Travel`），
     * 其余字符按 URL 规则转义，因此「搜 tag」不需要用户自己改成下划线。
     */
    fun tagPath(tag: String): String = "/tags/${tagSlug(tag)}/works"

    /**
     * tag 在地址里的 slug：空格写成下划线，其余字符按 URL 规则转义。
     *
     * 抽成独立纯函数，「我的标签」入口在请求 `/tags/<slug>/works` 与浏览页跳转两处
     * 共用同一份规则，不会一边下划线一边空格。
     */
    fun tagSlug(tag: String): String = encode(tag.trim().replace(' ', '_'))

    /** 收藏夹：已登录走账号书签页，未登录回退到全站公开书签。 */
    fun bookmarksPath(username: String?): String {
        val name = username?.trim().orEmpty()
        return if (name.isEmpty()) PATH_ALL_BOOKMARKS else "/users/${encode(name)}/bookmarks"
    }

    /**
     * 作者作品页：`/users/<pseud>/works`。
     *
     * 卡片上的作者名（`byline`）就是 pseud 名称，站点把 `/users/<pseud>` 直接
     * 服务成该作者的（伪）用户页，因此点击作者名即可落到他的作品列表。
     */
    fun authorPath(username: String): String {
        val name = username.trim()
        return if (name.isEmpty()) PATH_ALL_WORKS else "/users/${encode(name)}/works"
    }

    /** 把站点路径补成绝对地址；已经是绝对地址的原样返回。 */
    fun absolute(path: String): String {
        val value = path.trim()
        return when {
            value.startsWith("http://") || value.startsWith("https://") -> value
            value.startsWith("/") -> SITE + value
            value.isEmpty() -> SITE
            else -> "$SITE/$value"
        }
    }

    /** 是否站内地址（用于判断能否走代理、能否翻译）。 */
    fun isSiteUrl(url: String?): Boolean {
        val value = url?.trim().orEmpty()
        return value.startsWith(SITE)
    }

    /** 从作品地址里取作品编号；不是作品页返回 null。 */
    fun workIdOf(url: String?): String? {
        val value = url?.trim().orEmpty()
        val marker = "/works/"
        val at = value.indexOf(marker)
        if (at < 0) return null
        val rest = value.substring(at + marker.length)
        val id = rest.takeWhile { it.isDigit() }
        return id.takeIf { it.isNotEmpty() }
    }

    private fun encode(raw: String): String =
        URLEncoder.encode(raw.trim(), "UTF-8").replace("+", "%20")
}