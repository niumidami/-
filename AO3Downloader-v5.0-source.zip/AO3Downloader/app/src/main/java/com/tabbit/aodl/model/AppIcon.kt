package com.tabbit.aodl.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.tabbit.aodl.R

/**
 * 四套内置应用图标（需求 4）。
 *
 * 每套图标对应 AndroidManifest 里的一个 `activity-alias`：alias 自带
 * `MAIN/LAUNCHER` 意图过滤器和自己的 `android:icon`，切换时用
 * `PackageManager.setComponentEnabledSetting` 打开目标 alias、关掉其余三个，
 * 桌面图标即真实换图，不需要重装应用。
 *
 * 用户通过 SAF 上传的图片无法写进 APK，因此不参与桌面 alias，
 * 只用于渲染应用内的全部图标位，并可据此创建桌面快捷方式。
 */
enum class AppIcon(
    /** Manifest 中 activity-alias 的类名简称，完整类名为 `包名.简称`。 */
    val aliasSimple: String,
    @DrawableRes val drawableRes: Int,
    /**
     * 应用内图标位专用资源（顶栏 / Tab / 管理页 / 关于页 / 快捷方式回退）。
     *
     * 与 [drawableRes] 分离的原因：`drawableRes` 指向的 `ic_launcher` 自 v4.3 起
     * 在 `drawable-anydpi-v26` 下是 `<adaptive-icon>` XML，而 Compose 的
     * `painterResource` 只支持矢量与位图，直接渲染它会在启动首帧抛
     * IllegalArgumentException（v4.3 闪退根因）。应用内渲染一律改用本字段：
     * 默认款指向纯位图 `ic_logo_sakura`，其余三款沿用各自矢量。
     */
    @DrawableRes val logoRes: Int,
    @StringRes val labelRes: Int
) {
    SAKURA("LauncherSakura", R.drawable.ic_launcher, R.drawable.ic_logo_sakura, R.string.icon_sakura),
    NIGHT("LauncherNight", R.drawable.ic_launcher_night, R.drawable.ic_launcher_night, R.string.icon_night),
    MONO("LauncherMono", R.drawable.ic_launcher_mono, R.drawable.ic_launcher_mono, R.string.icon_mono),
    AO3("LauncherAo3", R.drawable.ic_launcher_ao3, R.drawable.ic_launcher_ao3, R.string.icon_ao3);

    companion object {
        /** 出厂默认图标，也是「自定义图片」模式下桌面 alias 的回退值。 */
        val DEFAULT: AppIcon = SAKURA

        /** Prefs 里代表「使用用户上传图片」的选择值，不属于本枚举成员。 */
        const val CUSTOM_CHOICE = "CUSTOM"

        /** 全部内置图标名，供 [com.tabbit.aodl.data.IconPlan] 做合法性校验。 */
        fun knownNames(): List<String> = entries.map { it.name }

        fun fromName(raw: String?): AppIcon =
            entries.firstOrNull { it.name.equals(raw?.trim(), ignoreCase = true) } ?: DEFAULT
    }
}
