package com.tabbit.aodl.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.data.NekoText
import com.tabbit.aodl.data.WebLoginPlan
import com.tabbit.aodl.net.Ao3Client
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel

/**
 * 需求 5：官网登录层。
 *
 * 内嵌 WebView 打开 AO3 官网登录页，**由用户自己在官网页面里输入账号密码**
 * （验证码、两步验证都在官网完成），登录成功后从 [CookieManager] 提取会话 Cookie
 * 与用户名写入既有账号存储。密码全程不经手、不落盘。
 *
 * 关键实现点：
 * - WebView 原生走系统 DNS，会被污染，因此请求经 [com.tabbit.aodl.net.Ao3WebProxy]
 *   改道到带 DoH 的 OkHttp；设置里的「官网登录直连」是逃生开关；
 * - 页面加载完成后注入 [WebLoginPlan.FORM_CAPTURE_JS]，把 POST 表单改写成带标记的跳转，
 *   代理侧再还原成真实 POST（`WebResourceRequest` 拿不到 body）；
 * - 登录跳转完成后立刻 `history.replaceState` + `clearHistory()`，
 *   把地址里残留的表单字段（含密码）从历史中抹掉；
 * - 非 AO3 域名的导航一律拦下，避免在登录页里被带去第三方站点。
 *
 * 界面不显示地址栏，URL 也不写日志。
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginWebScreen(
    vm: AppViewModel,
    onClose: () -> Unit
) {
    val state by vm.webLogin.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    val cookieManager = remember { CookieManager.getInstance() }
    val proxy = vm.webProxy

    var loading by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf(0) }
    var pageError by remember { mutableStateOf("") }
    var showCancelDialog by rememberSaveable { mutableStateOf(false) }
    var nameInput by rememberSaveable { mutableStateOf("") }

    /** 持有 WebView 实例，供「重新载入」按钮使用；`onRelease` 里清空避免持有已销毁的视图。 */
    val webViewRef = remember { mutableStateOf<WebView?>(null) }

    // WebViewClient 的回调不是 @Composable，错误文案必须在组合期先取出来
    val unknownPageText = stringResource(R.string.web_err_unknown_page)

    // 提取成功后关闭本层，回到账号页显示登录态
    LaunchedEffect(state.done) {
        if (state.done) onClose()
    }

    /** 点「完成并提取 Cookie」：先把 WebView 的 Cookie 落盘，再交给 ViewModel 校验与保存。 */
    fun extract() {
        cookieManager.flush()
        vm.extractWebCookie(cookieManager.getCookie(Ao3Client.BASE_URL))
    }

    /** 重新载入官网登录页：清掉错误提示，重新走一次完整导航（比 `reload()` 更可预期）。 */
    fun reload() {
        pageError = ""
        loading = true
        progress = 0
        vm.reloadWebLogin()
        webViewRef.value?.loadUrl(Ao3Client.BASE_URL + WebLoginPlan.LOGIN_PATH)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // ---------------------------------------------------------- 顶栏
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { showCancelDialog = true }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.web_action_cancel),
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.web_screen_title),
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (state.busy) {
                            stringResource(R.string.web_state_extracting)
                        } else if (loading) {
                            stringResource(R.string.web_state_loading)
                        } else {
                            stringResource(R.string.web_state_ready)
                        },
                        color = MaterialTheme.ext.textSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                // 占位以保持左右按钮对称（IconButton 默认 48dp），真正的刷新在下面的工具条上
                Spacer(Modifier.width(48.dp))
                IconButton(onClick = ::extract, enabled = !state.busy) {
                    Icon(
                        imageVector = Icons.Filled.Done,
                        contentDescription = stringResource(R.string.web_action_done),
                        tint = if (state.busy) {
                            MaterialTheme.ext.textSecondary
                        } else {
                            MaterialTheme.colorScheme.primary
                        }
                    )
                }
            }

            if (loading) {
                LinearProgressIndicator(
                    progress = { (progress.coerceIn(0, 100)) / 100f },
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.primary
                )
            } else {
                HorizontalDivider(color = MaterialTheme.ext.cardBorder)
            }

            // -------------------------------------------------------- 提示条
            val banner = when {
                state.failed && state.message.isNotBlank() -> NekoText.catify(state.message)
                pageError.isNotBlank() -> stringResource(R.string.web_err_page, pageError)
                settings.webDirect -> stringResource(R.string.web_hint_direct)
                else -> ""
            }
            if (banner.isNotBlank()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.error.copy(alpha = 0.10f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = banner,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.weight(1f)
                    )
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.web_hint_login),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.textSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = ::reload) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = stringResource(R.string.web_action_refresh),
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.ext.cardBorder)

            // ---------------------------------------------------------- 网页
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.White)
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        WebView(context).apply {
                            // 官网是浅色页面，垫白底避免深色主题下文字与背景糊在一起
                            setBackgroundColor(AndroidColor.WHITE)

                            cookieManager.setAcceptCookie(true)
                            cookieManager.setAcceptThirdPartyCookies(this, true)

                            // 外层有个同名的 `settings`（AppSettings），局部变量会盖掉隐式接收者的
                            // WebView.getSettings()，必须显式取一份，否则下面全部解析不到
                            val webSettings = this.settings
                            webSettings.javaScriptEnabled = true
                            webSettings.domStorageEnabled = true
                            // 登录流程不需要读本地文件，关掉以缩小攻击面
                            webSettings.allowFileAccess = false
                            webSettings.allowContentAccess = false
                            webSettings.allowFileAccessFromFileURLs = false
                            webSettings.allowUniversalAccessFromFileURLs = false
                            webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            webSettings.useWideViewPort = true
                            webSettings.loadWithOverviewMode = true
                            webSettings.setSupportZoom(true)
                            webSettings.builtInZoomControls = true
                            webSettings.displayZoomControls = false
                            webSettings.textZoom = 110
                            webSettings.cacheMode = WebSettings.LOAD_DEFAULT
                            // 与 OkHttp 侧保持一致，减少被风控识别为异常客户端的概率
                            webSettings.userAgentString = Ao3Client.USER_AGENT
                            webSettings.javaScriptCanOpenWindowsAutomatically = false
                            webSettings.setSupportMultipleWindows(false)

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    progress = newProgress
                                }
                            }

                            webViewClient = object : WebViewClient() {

                                override fun shouldInterceptRequest(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): WebResourceResponse? = proxy.intercept(request, cookieManager)

                                /** 只允许在 AO3 站内导航，第三方链接一律拦下。 */
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean = !WebLoginPlan.isAo3Host(request?.url?.host)

                                override fun onPageStarted(
                                    view: WebView?,
                                    url: String?,
                                    favicon: Bitmap?
                                ) {
                                    loading = true
                                    pageError = ""
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    val webView = view ?: return
                                    // 挂上表单捕获，POST 才能改道到安全 DNS 代理
                                    webView.evaluateJavascript(WebLoginPlan.FORM_CAPTURE_JS, null)
                                    if (WebLoginPlan.hasPostMarker(url)) {
                                        // 抹掉地址里残留的表单字段（含密码），再清掉这条历史
                                        val clean = proxy.lastMainFrameUrl
                                            ?: url.orEmpty().substringBefore('?')
                                        webView.evaluateJavascript(
                                            WebLoginPlan.replaceStateJs(clean),
                                            null
                                        )
                                        webView.clearHistory()
                                    }
                                    loading = false
                                    progress = 100
                                }

                                override fun onReceivedError(
                                    view: WebView?,
                                    request: WebResourceRequest?,
                                    error: WebResourceError?
                                ) {
                                    if (request?.isForMainFrame == true) {
                                        loading = false
                                        pageError = error?.description?.toString().orEmpty()
                                            .ifBlank { unknownPageText }
                                    }
                                }

                                override fun onReceivedHttpError(
                                    view: WebView?,
                                    request: WebResourceRequest?,
                                    errorResponse: WebResourceResponse?
                                ) {
                                    if (request?.isForMainFrame == true) {
                                        loading = false
                                        pageError = "HTTP ${errorResponse?.statusCode ?: 0}"
                                    }
                                }
                            }

                            loadUrl(Ao3Client.BASE_URL + WebLoginPlan.LOGIN_PATH)
                        }.also { webViewRef.value = it }
                    },
                    onRelease = { webView ->
                        webViewRef.value = null
                        webView.stopLoading()
                        webView.destroy()
                    }
                )

                if (state.busy) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.72f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CatLoading(size = 72.dp)
                            Spacer(Modifier.height(12.dp))
                            Text(
                                text = stringResource(R.string.web_state_extracting),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }

            // ------------------------------------------------------ 底部操作
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { showCancelDialog = true },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.ext.textSecondary),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.web_action_cancel), fontSize = 13.sp)
                }
                Spacer(Modifier.width(8.dp))
                GradientButton(
                    text = stringResource(R.string.web_action_done),
                    onClick = ::extract,
                    // GradientButton 自带 fillMaxWidth，在 Row 里必须用 weight 限宽，否则会溢出
                    modifier = Modifier.weight(1f),
                    enabled = !state.busy,
                    loading = state.busy,
                    icon = Icons.Filled.Done
                )
            }
        }
    }

    /* ---------------------------------------------------- 放弃登录确认 */
    if (showCancelDialog) {
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            containerColor = MaterialTheme.ext.card,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            textContentColor = MaterialTheme.ext.textSecondary,
            title = { Text(stringResource(R.string.web_cancel_title)) },
            text = { Text(NekoText.catify(stringResource(R.string.web_cancel_body))) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showCancelDialog = false
                        vm.cancelWebLogin()
                        onClose()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text(stringResource(R.string.web_cancel_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) {
                    Text(stringResource(R.string.web_action_keep), color = MaterialTheme.colorScheme.primary)
                }
            }
        )
    }

    /* ---------------------------------------- 官网读不到用户名时手填 */
    if (state.needsUsername) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = MaterialTheme.ext.card,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            textContentColor = MaterialTheme.ext.textSecondary,
            title = { Text(stringResource(R.string.web_need_username_title)) },
            text = {
                Column {
                    Text(NekoText.catify(stringResource(R.string.web_need_username_body)))
                    Spacer(Modifier.height(12.dp))
                    SakuraTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = stringResource(R.string.account_username),
                        imeAction = ImeAction.Done
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { vm.submitWebUsername(nameInput) },
                    enabled = nameInput.isNotBlank()
                ) { Text(stringResource(R.string.web_need_username_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { vm.cancelWebLogin(); onClose() }) {
                    Text(stringResource(R.string.web_cancel_confirm), color = MaterialTheme.colorScheme.error)
                }
            }
        )
    }
}
