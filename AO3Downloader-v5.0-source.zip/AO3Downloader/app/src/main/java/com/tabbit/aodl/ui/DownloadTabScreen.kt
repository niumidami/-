package com.tabbit.aodl.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.model.DownloadTab
import com.tabbit.aodl.vm.AppViewModel

/**
 * 底部第三格「下载」：页内用分段控件切换「下载 / 搜索作者」。
 *
 * 两区各自独立滚动、各自保留输入与结果，切换不清空对方状态——两个子页的状态都在
 * VM（[AppViewModel.downloadTab] / `download` / `author`）里，界面重建也不丢。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadTabScreen(
    vm: AppViewModel,
    onOpenSettings: () -> Unit,
    onGoAccount: () -> Unit
) {
    val tab by vm.downloadTab.collectAsStateWithLifecycle()
    val icon by vm.icon.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        CenterAlignedTopAppBar(
            title = {
                ScreenTitle(icon = icon, text = stringResource(R.string.screen_download_tab_title))
            },
            actions = {
                IconButton(onClick = onOpenSettings) {
                    Icon(
                        Icons.Filled.Settings,
                        contentDescription = stringResource(R.string.action_settings),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            },
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
                titleContentColor = MaterialTheme.colorScheme.onBackground
            )
        )

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            SegmentedRow(
                options = listOf(
                    stringResource(R.string.tab_download) to DownloadTab.DOWNLOAD,
                    stringResource(R.string.search_tab_author) to DownloadTab.AUTHOR
                ),
                selected = tab,
                onSelect = vm::setDownloadTab
            )
            Spacer(Modifier.height(12.dp))
        }

        when (tab) {
            DownloadTab.DOWNLOAD -> DownloadPane(vm = vm, onGoAccount = onGoAccount)
            DownloadTab.AUTHOR -> AuthorSearchPane(vm = vm)
        }
    }
}