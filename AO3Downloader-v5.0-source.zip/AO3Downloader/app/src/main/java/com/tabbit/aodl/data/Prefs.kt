package com.tabbit.aodl.data

import android.content.Context
import android.content.SharedPreferences
import com.tabbit.aodl.model.AppSettings
import com.tabbit.aodl.model.BeautifySettings
import com.tabbit.aodl.model.BeautifyStyle
import com.tabbit.aodl.model.CookieSource
import com.tabbit.aodl.model.DohMethod
import com.tabbit.aodl.model.DownloadFormat
import com.tabbit.aodl.model.LanguageMode
import com.tabbit.aodl.model.ReaderFont
import com.tabbit.aodl.model.ReaderMode
import com.tabbit.aodl.model.ReaderPalette
import com.tabbit.aodl.model.ReaderTheme
import com.tabbit.aodl.model.ReaderTypography
import com.tabbit.aodl.model.ShelfBook
import com.tabbit.aodl.model.SubscribedAuthor
import com.tabbit.aodl.model.ThemeMode
import com.tabbit.aodl.model.WorkItem

/**
 * 应用私有存储。
 *
 * 安全约定：
 * - 密码只在登录请求期间存在于内存，绝不落盘；
 * - 本地只保留会话 Cookie 值、用户名与登录时间，全部位于应用私有目录（其他应用不可读）；
 * - 手动填入的 Cookie 与密码登录得到的 Cookie 互斥保存，切换来源时清理另一份。
 */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- 设置快照

    fun settings(): AppSettings {
        val formats = DownloadFormat.entries.toSet()
        val enabledRaw = sp.getString(KEY_ENABLED_FORMATS, null)
        val enabled = if (enabledRaw == null) {
            formats
        } else {
            enabledRaw.split(',').mapNotNull { DownloadFormat.fromName(it.trim()) }.toSet()
                .ifEmpty { formats }
        }
        val dirs = DownloadFormat.entries.associateWith { sp.getString(KEY_DIR_PREFIX + it.ext, null) }
        return AppSettings(
            enabledFormats = enabled,
            unifiedSave = sp.getBoolean(KEY_UNIFIED_SAVE, false),
            unifiedDir = sp.getString(KEY_UNIFIED_DIR, null),
            formatDirs = dirs,
            dohEnabled = sp.getBoolean(KEY_DOH_ENABLED, true),
            dohEndpoint = sp.getString(KEY_DOH_ENDPOINT, AppSettings.DEFAULT_DOH_ENDPOINT)
                ?.trim()?.ifEmpty { AppSettings.DEFAULT_DOH_ENDPOINT }
                ?: AppSettings.DEFAULT_DOH_ENDPOINT,
            dohMethod = DohMethod.fromName(sp.getString(KEY_DOH_METHOD, null)),
            dohFallbackEnabled = sp.getBoolean(KEY_DOH_FALLBACK, true),
            autoBeautify = sp.getBoolean(KEY_AUTO_BEAUTIFY, false),
            beautify = beautify(),
            theme = themeMode(),
            language = languageMode(),
            viewAdult = sp.getBoolean(KEY_VIEW_ADULT, true),
            autoName = sp.getBoolean(KEY_AUTO_NAME, true),
            authorClassify = sp.getBoolean(KEY_AUTHOR_CLASSIFY, true),
            concurrency = sp.getInt(KEY_CONCURRENCY, AppSettings.DEFAULT_CONCURRENCY)
                .coerceIn(AppSettings.MIN_CONCURRENCY, AppSettings.MAX_CONCURRENCY),
            retryCount = sp.getInt(KEY_RETRY_COUNT, AppSettings.DEFAULT_RETRY)
                .coerceIn(0, AppSettings.MAX_RETRY),
            resumeEnabled = sp.getBoolean(KEY_RESUME_ENABLED, true),
            webDirect = sp.getBoolean(KEY_WEB_DIRECT, false),
            translateTemplate = sp.getString(KEY_TRANSLATE_TEMPLATE, "").orEmpty(),
            translateTarget = sp.getString(KEY_TRANSLATE_TARGET, AppSettings().translateTarget)!!
                .trim().ifEmpty { AppSettings().translateTarget },
            readerMode = readerMode()
        )
    }

    /** 需求（v5.0 新增 3）：默认阅读模式，读不出来时回番茄模式。 */
    fun readerMode(): ReaderMode =
        runCatching { ReaderMode.valueOf(sp.getString(KEY_READER_MODE, ReaderMode.TOMATO.name)!!) }
            .getOrDefault(ReaderMode.TOMATO)

    fun beautify(): BeautifySettings = BeautifySettings(
        style = runCatching { BeautifyStyle.valueOf(sp.getString(KEY_B_STYLE, BeautifyStyle.DOCUMENT.name)!!) }
            .getOrDefault(BeautifyStyle.DOCUMENT),
        font = runCatching { ReaderFont.valueOf(sp.getString(KEY_B_FONT, ReaderFont.SERIF.name)!!) }
            .getOrDefault(ReaderFont.SERIF),
        customFontFamily = sp.getString(KEY_B_CUSTOM_FONT, "").orEmpty(),
        fontSizeSp = sp.getInt(KEY_B_FONT_SIZE, 18).coerceIn(12, 32),
        lineHeight = sp.getFloat(KEY_B_LINE_HEIGHT, 1.85f).coerceIn(1.0f, 3.0f),
        marginDp = sp.getInt(KEY_B_MARGIN, 20).coerceIn(0, 80),
        paragraphSpacingEm = sp.getFloat(KEY_B_PARA_SPACING, 0.9f).coerceIn(0f, 4f),
        justify = sp.getBoolean(KEY_B_JUSTIFY, true),
        theme = runCatching { ReaderTheme.valueOf(sp.getString(KEY_B_THEME, ReaderTheme.FOLLOW_APP.name)!!) }
            .getOrDefault(ReaderTheme.FOLLOW_APP),
        customCss = sp.getString(KEY_B_CUSTOM_CSS, "").orEmpty(),
        keepOriginal = sp.getBoolean(KEY_B_KEEP_ORIGINAL, true)
    )

    fun themeMode(): ThemeMode =
        runCatching { ThemeMode.valueOf(sp.getString(KEY_THEME, ThemeMode.SAKURA_DARK.name)!!) }
            .getOrDefault(ThemeMode.SAKURA_DARK)

    fun languageMode(): LanguageMode =
        runCatching { LanguageMode.valueOf(sp.getString(KEY_LANGUAGE, LanguageMode.SYSTEM.name)!!) }
            .getOrDefault(LanguageMode.SYSTEM)

    // ---------------------------------------------------------------- 单项写入

    fun setEnabledFormats(formats: Set<DownloadFormat>) {
        sp.edit().putString(KEY_ENABLED_FORMATS, formats.joinToString(",") { it.name }).apply()
    }

    fun setUnifiedSave(enabled: Boolean) = sp.edit().putBoolean(KEY_UNIFIED_SAVE, enabled).apply()

    fun setUnifiedDir(uri: String?) = putOrNull(KEY_UNIFIED_DIR, uri)

    fun setFormatDir(format: DownloadFormat, uri: String?) = putOrNull(KEY_DIR_PREFIX + format.ext, uri)

    fun setDohEnabled(enabled: Boolean) = sp.edit().putBoolean(KEY_DOH_ENABLED, enabled).apply()

    fun setDohEndpoint(endpoint: String) =
        sp.edit().putString(KEY_DOH_ENDPOINT, endpoint.trim()).apply()

    fun setDohMethod(method: DohMethod) = sp.edit().putString(KEY_DOH_METHOD, method.name).apply()

    fun setDohFallbackEnabled(enabled: Boolean) = sp.edit().putBoolean(KEY_DOH_FALLBACK, enabled).apply()

    fun setAutoBeautify(enabled: Boolean) = sp.edit().putBoolean(KEY_AUTO_BEAUTIFY, enabled).apply()

    fun setBeautify(settings: BeautifySettings) {
        sp.edit()
            .putString(KEY_B_STYLE, settings.style.name)
            .putString(KEY_B_FONT, settings.font.name)
            .putString(KEY_B_CUSTOM_FONT, settings.customFontFamily.trim())
            .putInt(KEY_B_FONT_SIZE, settings.fontSizeSp)
            .putFloat(KEY_B_LINE_HEIGHT, settings.lineHeight)
            .putInt(KEY_B_MARGIN, settings.marginDp)
            .putFloat(KEY_B_PARA_SPACING, settings.paragraphSpacingEm)
            .putBoolean(KEY_B_JUSTIFY, settings.justify)
            .putString(KEY_B_THEME, settings.theme.name)
            .putString(KEY_B_CUSTOM_CSS, settings.customCss)
            .putBoolean(KEY_B_KEEP_ORIGINAL, settings.keepOriginal)
            .apply()
    }

    fun setThemeMode(mode: ThemeMode) = sp.edit().putString(KEY_THEME, mode.name).apply()

    fun setLanguageMode(mode: LanguageMode) = sp.edit().putString(KEY_LANGUAGE, mode.name).apply()

    fun setViewAdult(enabled: Boolean) = sp.edit().putBoolean(KEY_VIEW_ADULT, enabled).apply()

    /** 需求 1：文件名自动生成「作品名 by 作者名.<后缀>」。 */
    fun setAutoName(enabled: Boolean) = sp.edit().putBoolean(KEY_AUTO_NAME, enabled).apply()

    /** 需求 2：按「作者名 / 格式名」两级目录分类保存。 */
    fun setAuthorClassify(enabled: Boolean) = sp.edit().putBoolean(KEY_AUTHOR_CLASSIFY, enabled).apply()

    /** 需求 6：并行下载任务数。 */
    fun setConcurrency(value: Int) = sp.edit()
        .putInt(KEY_CONCURRENCY, value.coerceIn(AppSettings.MIN_CONCURRENCY, AppSettings.MAX_CONCURRENCY))
        .apply()

    /** 需求 6：单任务失败后的额外重试次数。 */
    fun setRetryCount(value: Int) = sp.edit()
        .putInt(KEY_RETRY_COUNT, value.coerceIn(0, AppSettings.MAX_RETRY))
        .apply()

    /** 需求 6：断点续传（Range）开关。 */
    fun setResumeEnabled(enabled: Boolean) = sp.edit().putBoolean(KEY_RESUME_ENABLED, enabled).apply()

    /** 需求 5 的逃生开关：官网登录时 WebView 直连，不经安全 DNS 代理。 */
    fun webDirect(): Boolean = sp.getBoolean(KEY_WEB_DIRECT, false)

    fun setWebDirect(enabled: Boolean) = sp.edit().putBoolean(KEY_WEB_DIRECT, enabled).apply()

    // ---------------------------------------------------------------- 图标

    /** 需求 4：当前图标选择，取值为 [com.tabbit.aodl.model.AppIcon] 名或 `CUSTOM`；空表示出厂默认。 */
    fun iconChoice(): String = sp.getString(KEY_ICON_CHOICE, "").orEmpty()

    /**
     * 需求 4：最后一次选中的**内置**图标名。
     * 桌面 alias 由它决定，因此切到「自定义图片」时桌面图标不会跳回出厂那一套。
     */
    fun iconBuiltin(): String = sp.getString(KEY_ICON_BUILTIN, "").orEmpty()

    fun setIconChoice(choice: String, builtin: String) {
        sp.edit()
            .putString(KEY_ICON_CHOICE, choice.trim())
            .putString(KEY_ICON_BUILTIN, builtin.trim())
            .apply()
    }

    // ---------------------------------------------------------------- 账号

    fun username(): String = sp.getString(KEY_ACC_USERNAME, "").orEmpty()

    fun sessionCookie(): String? = sp.getString(KEY_ACC_COOKIE, null)?.takeIf { it.isNotBlank() }

    fun manualCookie(): String? = sp.getString(KEY_ACC_MANUAL_COOKIE, null)?.takeIf { it.isNotBlank() }

    fun loginAt(): Long = sp.getLong(KEY_ACC_LOGIN_AT, 0L)

    fun rememberMe(): Boolean = sp.getBoolean(KEY_ACC_REMEMBER, true)

    fun cookieSource(): CookieSource =
        runCatching { CookieSource.valueOf(sp.getString(KEY_ACC_SOURCE, CookieSource.NONE.name)!!) }
            .getOrDefault(CookieSource.NONE)

    /** 密码登录成功后保存会话 Cookie；密码不会写入。 */
    fun savePasswordSession(username: String, cookieValue: String, rememberMe: Boolean) {
        sp.edit()
            .putString(KEY_ACC_USERNAME, username.trim())
            .putString(KEY_ACC_COOKIE, cookieValue.trim())
            .remove(KEY_ACC_MANUAL_COOKIE)
            .putLong(KEY_ACC_LOGIN_AT, System.currentTimeMillis())
            .putBoolean(KEY_ACC_REMEMBER, rememberMe)
            .putString(KEY_ACC_SOURCE, CookieSource.PASSWORD.name)
            .apply()
    }

    /** 手动填入 Cookie（备用方式），支持整段 Cookie 头或仅会话值。 */
    fun saveManualCookie(username: String, rawCookie: String) {
        sp.edit()
            .putString(KEY_ACC_USERNAME, username.trim())
            .putString(KEY_ACC_MANUAL_COOKIE, rawCookie.trim())
            .remove(KEY_ACC_COOKIE)
            .putLong(KEY_ACC_LOGIN_AT, System.currentTimeMillis())
            .putString(KEY_ACC_SOURCE, CookieSource.MANUAL.name)
            .apply()
    }

    /**
     * 需求 5：保存在官网 WebView 里登录后提取到的 Cookie。
     *
     * 复用手动 Cookie 的存储槽位（[cookieHeader] 优先读它），因此下载、收藏、
     * 作者检索等既有链路完全不用改；区别只在来源标记为 [CookieSource.WEBVIEW]。
     *
     * `username` 允许传空：官网有时读不到用户名，此时先落 Cookie、
     * 再用 [setUsername] 补上，避免为了等用户名而把已提取的会话丢掉。
     * 密码全程不经手，这里也只写 Cookie 与用户名。
     */
    fun saveWebCookie(username: String, rawCookie: String) {
        sp.edit()
            .putString(KEY_ACC_USERNAME, username.trim())
            .putString(KEY_ACC_MANUAL_COOKIE, rawCookie.trim())
            .remove(KEY_ACC_COOKIE)
            .putLong(KEY_ACC_LOGIN_AT, System.currentTimeMillis())
            .putString(KEY_ACC_SOURCE, CookieSource.WEBVIEW.name)
            .apply()
    }

    /** 只更新用户名，不动 Cookie 与来源标记（官网登录后补全账号信息用）。 */
    fun setUsername(username: String) =
        sp.edit().putString(KEY_ACC_USERNAME, username.trim()).apply()

    fun clearAccount() {
        sp.edit()
            .remove(KEY_ACC_USERNAME)
            .remove(KEY_ACC_COOKIE)
            .remove(KEY_ACC_MANUAL_COOKIE)
            .remove(KEY_ACC_LOGIN_AT)
            .remove(KEY_ACC_SOURCE)
            .apply()
    }

    /**
     * 当前应随请求发送的 Cookie 头，未登录返回 null。
     * 两种来源都允许存"完整 Cookie 头"（如 `_otwarchive_session=xxx; remember_user_token=yyy`）
     * 或仅存会话值，后者会自动补上 `_otwarchive_session=` 前缀。
     */
    fun cookieHeader(): String? {
        val raw = manualCookie() ?: sessionCookie() ?: return null
        val value = raw.trim()
        if (value.isEmpty()) return null
        return if (value.contains('=')) value else "_otwarchive_session=$value"
    }

    fun isLoggedIn(): Boolean = cookieHeader() != null

    // ------------------------------------------------ v5.0：翻译模板与阅读模式

    /** 需求（v5.0 新增 1）：翻译服务模板，空串表示用默认模板。 */
    fun translateTemplate(): String = sp.getString(KEY_TRANSLATE_TEMPLATE, "").orEmpty()

    fun setTranslateTemplate(template: String) = putOrNull(KEY_TRANSLATE_TEMPLATE, template.trim())

    fun translateTarget(): String =
        sp.getString(KEY_TRANSLATE_TARGET, AppSettings().translateTarget)!!
            .trim().ifEmpty { AppSettings().translateTarget }

    fun setTranslateTarget(target: String) =
        putOrNull(KEY_TRANSLATE_TARGET, target.trim().ifEmpty { AppSettings().translateTarget })

    fun setReaderMode(mode: ReaderMode) = sp.edit().putString(KEY_READER_MODE, mode.name).apply()

    // ---------------------------------------- v5.3：阅读页排版 / 背景主题 / 精细进度

    /** 番茄模式排版：字体、字号、行距、页边距、背景主题；读不出来时回默认。 */
    fun readerTypography(): ReaderTypography = ReaderTypography(
        font = runCatching { ReaderFont.valueOf(sp.getString(KEY_RD_FONT, ReaderFont.SERIF.name)!!) }
            .getOrDefault(ReaderFont.SERIF),
        fontSizeSp = ReaderPlan.clampFontSize(sp.getInt(KEY_RD_FONT_SIZE, 18)),
        lineHeightMul = ReaderPlan.clampLineHeight(sp.getFloat(KEY_RD_LINE_HEIGHT, 1.8f)),
        marginDp = ReaderPlan.clampMargin(sp.getInt(KEY_RD_MARGIN, 20)),
        palette = runCatching {
            ReaderPalette.valueOf(sp.getString(KEY_RD_PALETTE, ReaderPalette.FOLLOW_APP.name)!!)
        }.getOrDefault(ReaderPalette.FOLLOW_APP)
    )

    fun setReaderTypography(t: ReaderTypography) {
        sp.edit()
            .putString(KEY_RD_FONT, t.font.name)
            .putInt(KEY_RD_FONT_SIZE, ReaderPlan.clampFontSize(t.fontSizeSp))
            .putFloat(KEY_RD_LINE_HEIGHT, ReaderPlan.clampLineHeight(t.lineHeightMul))
            .putInt(KEY_RD_MARGIN, ReaderPlan.clampMargin(t.marginDp))
            .putString(KEY_RD_PALETTE, t.palette.name)
            .apply()
    }

    /**
     * 精细阅读进度：作品 -> (章节, 章内滚动比例 0..1)，LRU 上限见 [ReaderPlan.MAX_PROGRESS_ENTRIES]。
     * 与书架的章节级进度（[ShelfBook.readChapters]）并存：书架管展示，这份管续读定位。
     */
    fun readerProgress(workId: String): Pair<Int, Float>? =
        ReaderPlan.decodeProgressRows(sp.getString(KEY_RD_PROGRESS, null))
            .firstOrNull { it.first == workId }
            ?.let { it.second to it.third }

    fun setReaderProgress(workId: String, chapter: Int, offsetFrac: Float) {
        val id = workId.trim()
        if (id.isEmpty()) return
        val next = ReaderPlan.upsertProgress(
            ReaderPlan.decodeProgressRows(sp.getString(KEY_RD_PROGRESS, null)),
            id, chapter, offsetFrac
        )
        sp.edit().putString(KEY_RD_PROGRESS, ReaderPlan.encodeProgressRows(next)).apply()
    }

    // ---------------------------------------- v5.0：书架 / 阅读历史 / 书签落盘

    /** 需求（v5.0 新增 2）：手动加入书架的书目。 */
    fun shelf(): List<ShelfBook> = ShelfStore.decode(sp.getString(KEY_SHELF, null))

    fun setShelf(books: List<ShelfBook>) =
        sp.edit().putString(KEY_SHELF, ShelfStore.encode(books)).apply()

    /** 需求（v5.0 新增 2）：自动记录的阅读历史（同一作品只留最新一条，上限 300）。 */
    fun history(): List<ShelfBook> = ShelfStore.decode(sp.getString(KEY_HISTORY, null))

    fun setHistory(books: List<ShelfBook>) =
        sp.edit().putString(KEY_HISTORY, ShelfStore.encode(books)).apply()

    /** 需求（v5.0 新增 2）：「拉取书签」同步下来的书签（上限 200）。 */
    fun bookmarks(): List<ShelfBook> = ShelfStore.decode(sp.getString(KEY_SHELF_BOOKMARKS, null))

    fun setBookmarks(books: List<ShelfBook>) =
        sp.edit().putString(KEY_SHELF_BOOKMARKS, ShelfStore.encode(books)).apply()

    // ---------------------------------------- v5.1：我的标签 / 我的订阅 / 本地音乐

    /** 「我的标签」：App 内自己维护的 tag 名单，与 AO3 账号书签 tag 无关。 */
    fun myTags(): List<String> = MyTagsStore.decode(sp.getString(KEY_MY_TAGS, null))

    fun setMyTags(tags: List<String>) =
        sp.edit().putString(KEY_MY_TAGS, MyTagsStore.encode(tags)).apply()

    /** 「我的订阅 → 订阅的作品」：连同卡片所需字段一起落盘，离线也能渲染统一卡片。 */
    fun subscribedWorks(): List<WorkItem> =
        SubscriptionsStore.decodeWorks(sp.getString(KEY_SUB_WORKS, null))

    fun setSubscribedWorks(items: List<WorkItem>) =
        sp.edit().putString(KEY_SUB_WORKS, SubscriptionsStore.encodeWorks(items)).apply()

    /** 「我的订阅 → 订阅的作者」（作品列表的字段在 `au_` 子项里，用户名与时间另存）。 */
    fun subscribedAuthors(): List<SubscribedAuthor> =
        SubscriptionsStore.decodeAuthors(sp.getString(KEY_SUB_AUTHORS, null))

    fun setSubscribedAuthors(list: List<SubscribedAuthor>) =
        sp.edit().putString(KEY_SUB_AUTHORS, SubscriptionsStore.encodeAuthors(list)).apply()

    /** 本地音乐：用户选定的音乐文件夹树 Uri（只读遍历用）。 */
    fun musicFolder(): String? = sp.getString(KEY_MUSIC_FOLDER, null)?.takeIf { it.isNotBlank() }

    fun setMusicFolder(uri: String?) = putOrNull(KEY_MUSIC_FOLDER, uri?.trim())

    private fun putOrNull(key: String, value: String?) {
        val editor = sp.edit()
        if (value.isNullOrBlank()) editor.remove(key) else editor.putString(key, value)
        editor.apply()
    }

    private companion object {
        const val FILE_NAME = "aodl_v3_prefs"

        const val KEY_ENABLED_FORMATS = "enabled_formats"
        const val KEY_UNIFIED_SAVE = "unified_save"
        const val KEY_UNIFIED_DIR = "unified_dir"
        const val KEY_DIR_PREFIX = "dir_"

        const val KEY_DOH_ENABLED = "doh_enabled"
        const val KEY_DOH_ENDPOINT = "doh_endpoint"
        const val KEY_DOH_METHOD = "doh_method"
        const val KEY_DOH_FALLBACK = "doh_fallback"

        const val KEY_AUTO_BEAUTIFY = "auto_beautify"
        const val KEY_B_STYLE = "b_style"
        const val KEY_B_FONT = "b_font"
        const val KEY_B_CUSTOM_FONT = "b_custom_font"
        const val KEY_B_FONT_SIZE = "b_font_size"
        const val KEY_B_LINE_HEIGHT = "b_line_height"
        const val KEY_B_MARGIN = "b_margin"
        const val KEY_B_PARA_SPACING = "b_para_spacing"
        const val KEY_B_JUSTIFY = "b_justify"
        const val KEY_B_THEME = "b_theme"
        const val KEY_B_CUSTOM_CSS = "b_custom_css"
        const val KEY_B_KEEP_ORIGINAL = "b_keep_original"

        const val KEY_THEME = "ui_theme"
        const val KEY_LANGUAGE = "ui_language"
        const val KEY_VIEW_ADULT = "view_adult"

        // v4.0：自动命名、按作者分类、并发队列与断点续传
        const val KEY_AUTO_NAME = "auto_name"
        const val KEY_AUTHOR_CLASSIFY = "author_classify"
        const val KEY_CONCURRENCY = "concurrency"
        const val KEY_RETRY_COUNT = "retry_count"
        const val KEY_RESUME_ENABLED = "resume_enabled"

        // v4.0：官网 WebView 登录直连逃生开关（需求 5）
        const val KEY_WEB_DIRECT = "web_direct"

        // v4.0：应用图标选择（需求 4）
        const val KEY_ICON_CHOICE = "icon_choice"
        const val KEY_ICON_BUILTIN = "icon_builtin"

        const val KEY_ACC_USERNAME = "acc_username"
        const val KEY_ACC_COOKIE = "acc_cookie"
        const val KEY_ACC_MANUAL_COOKIE = "acc_manual_cookie"
        const val KEY_ACC_LOGIN_AT = "acc_login_at"
        const val KEY_ACC_REMEMBER = "acc_remember"
        const val KEY_ACC_SOURCE = "acc_source"

        // v5.0：翻译入口与阅读模式（需求 新增 1 / 新增 3）
        const val KEY_TRANSLATE_TEMPLATE = "translate_template"
        const val KEY_TRANSLATE_TARGET = "translate_target"
        const val KEY_READER_MODE = "reader_mode"

        // v5.0：书架 / 阅读历史 / 书签（需求 新增 2 / 新增 3）
        const val KEY_SHELF = "shelf_books"
        const val KEY_HISTORY = "shelf_history"
        const val KEY_SHELF_BOOKMARKS = "shelf_bookmarks"

        // v5.1：我的标签 / 我的订阅 / 本地音乐文件夹
        const val KEY_MY_TAGS = "my_tags"
        const val KEY_SUB_WORKS = "subscribed_works"
        const val KEY_SUB_AUTHORS = "subscribed_authors"
        const val KEY_MUSIC_FOLDER = "music_folder"

        // v5.3：阅读页排版 / 背景主题 / 精细进度
        const val KEY_RD_FONT = "rd_font"
        const val KEY_RD_FONT_SIZE = "rd_font_size"
        const val KEY_RD_LINE_HEIGHT = "rd_line_height"
        const val KEY_RD_MARGIN = "rd_margin"
        const val KEY_RD_PALETTE = "rd_palette"
        const val KEY_RD_PROGRESS = "rd_progress"
    }
}
