package com.tabbit.aodl.data

/**
 * 作品卡片「分级预警四徽章」与分类 tag 的展示规则（neos 主题移植）。
 *
 * 色板取自用户提供的 AO3 站点皮肤 `neos [Site Skin]` 的「Charcoal × Rose」深色
 * 变体（即参考图一的效果，`refs/neos_theme_charcoal-rose.css`）：
 * - 徽章底色 = 各分级/预警/分类对应的 neos 图标色，符号统一白色；
 * - tag 配色 = neos 的 tag 规则（warning 实底深字、relationship 粉底深字、
 *   fandom/character/freeform 浅底描边彩字、统一 #AB6F7D59 描边）。
 *
 * 全部是纯常量与纯函数，不依赖 Android 框架，可离线断言（见 `app/src/test`）。
 */
object WorkBadges {

    /** 单个徽章：显示符号 + neos 底色（ARGB long）+ 无障碍描述用的可读文本。 */
    data class Badge(val symbol: String, val color: Long, val label: String)

    // ------------------------------------------------------- neos tag 色板

    /** `--tag-border`：#AB6F7D59。 */
    const val TAG_BORDER: Long = 0x59AB6F7D

    /** default / fandom tag 文字：#D3C5C8。 */
    const val TAG_TEXT: Long = 0xFFD3C5C8

    /** warning tag 实底：#C93B6A。 */
    const val TAG_BG_WARNING: Long = 0xFFC93B6A

    /** relationship tag 实底：#D96AA9。 */
    const val TAG_BG_RELATIONSHIP: Long = 0xFFD96AA9

    /** 实底 tag 上的深色文字：#111111。 */
    const val TAG_TEXT_DARK: Long = 0xFF111111

    /** character tag 文字：#E077AC。 */
    const val TAG_TEXT_CHARACTER: Long = 0xFFE077AC

    /** freeform tag 文字：#FFB3D8。 */
    const val TAG_TEXT_FREEFORM: Long = 0xFFFFB3D8

    // ------------------------------------------------------- neos 徽章图标色

    private const val GEN: Long = 0xFFFFABDF
    private const val TEEN: Long = 0xFFF59DB3
    private const val MATURE: Long = 0xFFD96AA9
    private const val EXPLICIT: Long = 0xFFC93B6A
    private const val CATEGORY_MULTI: Long = 0xFFE077AC
    private const val FALLBACK: Long = 0xFFAB6F7D

    /** 分级 → 徽章（字母符号沿用 AO3 惯例：G / T / M / E / NR）。 */
    fun ratingBadge(rating: String): Badge = when {
        rating.contains("Explicit", ignoreCase = true) ->
            Badge("E", EXPLICIT, rating.ifBlank { "Explicit" })
        rating.contains("Mature", ignoreCase = true) ->
            Badge("M", MATURE, rating.ifBlank { "Mature" })
        rating.contains("Teen", ignoreCase = true) ->
            Badge("T", TEEN, rating.ifBlank { "Teen And Up Audiences" })
        rating.contains("General", ignoreCase = true) ->
            Badge("G", GEN, rating.ifBlank { "General Audiences" })
        else -> Badge("NR", FALLBACK, rating.ifBlank { "Not Rated" })
    }

    /**
     * 预警 → 徽章。
     *
     * 有具体预警内容（Graphic Depictions Of Violence 等）→ "!"；作者选择不使用
     * 预警 → "!?"（即参考图一中的第二个徽章）；明确无预警 → "✓"；站点没给出 → "?"。
     */
    fun warningBadge(warnings: String): Badge = when {
        warnings.contains("Chose Not To Use", ignoreCase = true) ->
            Badge("!?", MATURE, warnings)
        warnings.contains("No Archive Warnings Apply", ignoreCase = true) ->
            Badge("✓", GEN, warnings)
        warnings.isBlank() ->
            Badge("?", FALLBACK, "No archive warning info")
        else ->
            Badge("!", EXPLICIT, warnings)
    }

    /** 分类 → 徽章（性别符号 + 双向箭头，贴近站点图标的含义）。 */
    fun categoryBadge(categories: String): Badge {
        val symbol = when {
            categories.contains("Multi", ignoreCase = true) -> "✦"
            categories.contains("F/M", ignoreCase = true) -> "♀↔♂"
            categories.contains("M/M", ignoreCase = true) -> "♂↔♂"
            categories.contains("F/F", ignoreCase = true) -> "♀↔♀"
            categories.contains("Gen", ignoreCase = true) -> "○"
            categories.isBlank() || categories.contains("No category", ignoreCase = true) -> "?"
            else -> "✱" // Other
        }
        val color = when {
            categories.contains("F/M", ignoreCase = true) -> MATURE
            categories.contains("M/M", ignoreCase = true) -> TEEN
            categories.contains("F/F", ignoreCase = true) -> EXPLICIT
            categories.contains("Gen", ignoreCase = true) -> GEN
            categories.contains("Multi", ignoreCase = true) -> CATEGORY_MULTI
            else -> FALLBACK
        }
        return Badge(symbol, color, categories.ifBlank { "No category" })
    }

    /** 完结状态 → 徽章：完结 "✓"（参考图一的第四个徽章），连载 "…"。 */
    fun completionBadge(completion: String): Badge =
        if (completion.contains("Complete", ignoreCase = true)) {
            Badge("✓", GEN, completion.ifBlank { "Complete Work" })
        } else {
            Badge("…", EXPLICIT, completion.ifBlank { "Work in Progress" })
        }

    /**
     * 卡片上方固定的四枚徽章：分级 / 预警 / 分类 / 完结。
     *
     * 站点在这四个位置永远各渲染一个符号（缺值时会退成 `rating-notrated` /
     * `warning-choosenotto` / `category-none` 之类的兜底符号），因此卡片的四个
     * 徽章位也必须**永远齐四枚**：任一字段缺失时由对应的映射函数给出兜底徽章，
     * 而不是把这一枚从版式里删掉——否则就会出现「四图标显示不全」的视觉缺口。
     * 顺序与站点一致：分级 → 预警 → 分类 → 完结。
     */
    fun fourBadges(
        rating: String,
        warnings: String,
        categories: String,
        completion: String
    ): List<Badge> = listOf(
        ratingBadge(rating),
        warningBadge(warnings),
        categoryBadge(categories),
        completionBadge(completion)
    )
}
