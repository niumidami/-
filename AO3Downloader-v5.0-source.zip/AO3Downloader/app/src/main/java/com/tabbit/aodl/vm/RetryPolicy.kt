package com.tabbit.aodl.vm

import com.tabbit.aodl.model.AppSettings

/**
 * 重试策略（需求 6）。
 *
 * 从 ViewModel 中拆出来的**纯函数**：线性退避 2s、4s、6s…，上限 15s；
 * 总尝试次数 = 1 次首发 + 用户设置的额外重试次数。
 * 不依赖 Android API，可在 JVM 单元测试里直接断言（见 `app/src/test`）。
 */
internal object RetryPolicy {

    const val BASE_DELAY_SECONDS = 2
    const val MAX_DELAY_SECONDS = 15

    /**
     * 第 [attempt] 次尝试失败后的等待秒数（[attempt] 从 1 开始）。
     *
     * 乘法用 Long：`BASE_DELAY_SECONDS * attempt` 在 attempt 极大时会 32 位溢出成负数，
     * 再经 `coerceIn` 反而变成 1 秒，彻底失去退避效果（单测已断言该边界）。
     */
    fun delaySeconds(attempt: Int): Int =
        (BASE_DELAY_SECONDS.toLong() * attempt.coerceAtLeast(1).toLong())
            .coerceIn(1L, MAX_DELAY_SECONDS.toLong())
            .toInt()

    /** 用户设置额外重试 [retryCount] 次时的总尝试次数，至少 1 次。 */
    fun maxAttempts(retryCount: Int): Int =
        1 + retryCount.coerceIn(0, AppSettings.MAX_RETRY)
}
