package com.tabbit.aodl.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.data.NekoText
import com.tabbit.aodl.model.DownloadFormat
import com.tabbit.aodl.model.DownloadRecord
import com.tabbit.aodl.model.DownloadStatus
import com.tabbit.aodl.model.FolderTarget
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.util.Format
import com.tabbit.aodl.vm.AppViewModel

/**
 * 「我的」页里的下载管理节（v5.1 导航重构：原「管理」一级入口取消后并入）。
 *
 * 分五节：下载汇总 / 记录列表 / 五种格式 / 保存位置 / 运行日志。数据来源是
 * [AppViewModel.download] 里的 `records`：下载引擎在 `SafStore.writeFrom` 的
 * 进度回调中直接写入 `downloaded / total / speedBps`，因此显示的是真实进度而非估算值；
 * 记录由 `DownloadHistory` 持久化，进程重启后仍可查询。
 *
 * 不自带顶栏、也不自己滚动——由外层 [AccountScreen] 的滚动容器承载。
 */
@Composable
fun DownloadManageSections(vm: AppViewModel, onOpenSettings: () -> Unit) {
    val download by vm.download.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val records = download.records

    var confirmClearAll by rememberSaveable { mutableStateOf(false) }
    var confirmClearFinished by rememberSaveable { mutableStateOf(false) }

    val succeeded = records.count { it.status == DownloadStatus.SUCCESS }
    val failed = records.count { it.status == DownloadStatus.FAILED }
    val cancelled = records.count { it.status == DownloadStatus.CANCELLED }
    val retryable = records.any { it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELLED }

    /* ----------------------------------------------------------- 汇总 */
    SectionTitle(
        text = stringResource(R.string.manage_summary_title),
        subtitle = stringResource(R.string.manage_summary_hint)
    )
    SakuraCard {
        if (download.busy) {
            Text(
                text = download.currentTask,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
            Spacer(Modifier.height(8.dp))
            AggregateBar(progress = download.fileProgress)
            Spacer(Modifier.height(8.dp))
        }
        ValueRow(
            title = stringResource(R.string.manage_summary_total),
            value = records.size.toString()
        )
        ValueRow(
            title = stringResource(R.string.manage_summary_running),
            value = "${download.runningCount} / ${download.concurrency}",
            valueColor = if (download.runningCount > 0) MaterialTheme.colorScheme.primary else null
        )
        ValueRow(
            title = stringResource(R.string.manage_summary_queued),
            value = download.queuedCount.toString()
        )
        ValueRow(
            title = stringResource(R.string.manage_summary_success),
            value = succeeded.toString(),
            valueColor = if (succeeded > 0) MaterialTheme.ext.success else null
        )
        ValueRow(
            title = stringResource(R.string.manage_summary_failed),
            value = (failed + cancelled).toString(),
            valueColor = if (failed + cancelled > 0) MaterialTheme.colorScheme.error else null
        )
        ValueRow(
            title = stringResource(R.string.manage_summary_speed),
            value = Format.speed(download.speedBps),
            valueColor = MaterialTheme.colorScheme.primary
        )
        ValueRow(
            title = stringResource(R.string.manage_summary_eta),
            value = Format.duration(download.etaMillis)
        )

        if (retryable) {
            HorizontalDivider(
                color = MaterialTheme.ext.cardBorder,
                thickness = 0.5.dp,
                modifier = Modifier.padding(vertical = 10.dp)
            )
            SecondaryButton(
                text = stringResource(R.string.manage_retry_all),
                onClick = vm::retryFailedRecords,
                enabled = !download.busy,
                modifier = Modifier.fillMaxWidth()
            )
        }

        /* --------------------------------------------------- 列表操作 */
        HorizontalDivider(
            color = MaterialTheme.ext.cardBorder,
            thickness = 0.5.dp,
            modifier = Modifier.padding(vertical = 10.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryButton(
                text = stringResource(R.string.manage_refresh),
                onClick = vm::refreshRecords,
                icon = Icons.Filled.Refresh,
                modifier = Modifier.weight(1f)
            )
            SecondaryButton(
                text = stringResource(R.string.manage_clear_finished),
                onClick = { confirmClearFinished = true },
                enabled = records.any { it.finished },
                icon = Icons.Filled.DoneAll,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        DangerTextButton(
            text = stringResource(R.string.manage_clear_all),
            onClick = { confirmClearAll = true },
            modifier = Modifier.fillMaxWidth()
        )
    }

    /* ----------------------------------------------------------- 列表 */
    SectionTitle(
        text = stringResource(R.string.manage_list_title),
        subtitle = stringResource(R.string.manage_list_hint, DownloadHistoryLimit)
    )
    if (records.isEmpty()) {
        SakuraCard {
            EmptyHint(text = stringResource(R.string.manage_empty))
        }
    } else {
        records.forEachIndexed { index, record ->
            RecordCard(
                record = record,
                busy = download.busy,
                onRetry = { vm.retryRecord(record.recordId) },
                onRemove = { vm.removeRecord(record.recordId) }
            )
            if (index != records.lastIndex) Spacer(Modifier.height(10.dp))
        }
    }

    /* ----------------------------------------------------------- 格式 */
    SectionTitle(
        text = stringResource(R.string.download_formats_title),
        subtitle = stringResource(R.string.download_formats_hint)
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        DownloadFormat.entries.forEach { format ->
            val checked = format in settings.enabledFormats
            FilterChip(
                selected = checked,
                onClick = { vm.toggleFormat(format, !checked) },
                label = { Text(format.displayName, fontSize = 12.sp) },
                shape = RoundedCornerShape(10.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                    selectedLabelColor = MaterialTheme.colorScheme.primary,
                    containerColor = MaterialTheme.ext.card,
                    labelColor = MaterialTheme.ext.textSecondary
                )
            )
        }
    }

    /* ------------------------------------------------------- 保存位置 */
    SectionTitle(text = stringResource(R.string.download_save_title))
    SakuraCard {
        if (settings.unifiedSave) {
            SaveRow(
                title = stringResource(R.string.folder_unified),
                value = vm.folderLabel(FolderTarget.Unified)
            )
        } else {
            DownloadFormat.entries.forEachIndexed { index, format ->
                SaveRow(
                    title = format.displayName,
                    value = vm.folderLabel(FolderTarget.PerFormat(format))
                )
                if (index != DownloadFormat.entries.lastIndex) {
                    HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        SecondaryButton(
            text = stringResource(R.string.download_open_settings),
            onClick = onOpenSettings,
            icon = Icons.Filled.Settings,
            modifier = Modifier.fillMaxWidth()
        )
    }

    /* ------------------------------------------------------- 运行日志 */
    SectionTitle(text = stringResource(R.string.log_title))
    LogConsole(
        logs = logs,
        onClear = vm::clearLogs,
        title = stringResource(R.string.log_subtitle),
        modifier = Modifier.height(300.dp)
    )

    if (confirmClearFinished) {
        ConfirmDialog(
            title = stringResource(R.string.manage_confirm_finished_title),
            body = stringResource(R.string.manage_confirm_finished_body),
            onDismiss = { confirmClearFinished = false },
            onConfirm = {
                confirmClearFinished = false
                vm.clearFinishedRecords()
            }
        )
    }

    if (confirmClearAll) {
        ConfirmDialog(
            title = stringResource(R.string.manage_confirm_clear_title),
            body = stringResource(R.string.manage_confirm_clear_body),
            onDismiss = { confirmClearAll = false },
            onConfirm = {
                confirmClearAll = false
                vm.clearRecords()
            }
        )
    }
}

/** `DownloadHistory.MAX_RECORDS` 的界面副本，避免 UI 直接依赖 data 层常量。 */
private const val DownloadHistoryLimit = 300

@Composable
private fun AggregateBar(progress: Float) {
    LinearProgressIndicator(
        progress = { progress.coerceIn(0f, 1f) },
        modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp)),
        color = MaterialTheme.colorScheme.primary,
        trackColor = MaterialTheme.ext.cardBorder
    )
}

@Composable
private fun SaveRow(title: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.ext.textSecondary,
            modifier = Modifier.width(72.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
            maxLines = 1
        )
    }
}

/** 单条下载记录：标题 / 作者 / 格式 / 状态 / 进度 / 已传与总大小 / 失败原因。 */
@Composable
private fun RecordCard(
    record: DownloadRecord,
    busy: Boolean,
    onRetry: () -> Unit,
    onRemove: () -> Unit
) {
    SakuraCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = record.title.ifBlank { stringResource(R.string.meta_unknown) },
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = listOfNotNull(
                        "#${record.workId}",
                        record.authors.takeIf { it.isNotBlank() }
                    ).joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.ext.textSecondary,
                    maxLines = 1
                )
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                StatusChip(text = record.format.displayName, color = MaterialTheme.ext.textSecondary)
                Spacer(Modifier.height(4.dp))
                StatusChip(text = statusLabel(record.status), color = statusColor(record.status))
            }
        }

        Spacer(Modifier.height(10.dp))

        when {
            record.status == DownloadStatus.RUNNING || record.status == DownloadStatus.QUEUED -> {
                if (record.determinate) {
                    LinearProgressIndicator(
                        progress = { record.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.ext.cardBorder
                    )
                } else {
                    // 服务端未给 Content-Length 时只能用不确定进度条，绝不伪造百分比。
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.ext.cardBorder
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = sizeText(record),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (record.status == DownloadStatus.RUNNING) {
                        Text(
                            text = stringResource(
                                R.string.manage_record_speed_eta,
                                Format.speed(record.speedBps),
                                Format.duration(record.etaMillis)
                            ),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.ext.textSecondary
                        )
                    }
                }
            }

            record.status == DownloadStatus.SUCCESS -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.manage_record_size_done, Format.bytes(record.downloaded)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.success,
                        modifier = Modifier.weight(1f)
                    )
                    if (record.elapsedMillis > 0L) {
                        Text(
                            text = Format.duration(record.elapsedMillis),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.ext.textSecondary
                        )
                    }
                }
            }

            else -> {
                Text(
                    text = if (record.interrupted && record.errorText.isBlank()) {
                        stringResource(R.string.err_interrupted)
                    } else {
                        record.errorText
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    maxLines = 3
                )
                if (record.attempts > 1) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = stringResource(R.string.manage_record_attempts, record.attempts),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.textSecondary
                    )
                }
                if (record.resumedFromBytes > 0L) {
                    Text(
                        text = stringResource(R.string.manage_record_resumed, Format.bytes(record.resumedFromBytes)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.textSecondary
                    )
                }
            }
        }

        if (record.fileName.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = record.fileName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.ext.textSecondary,
                fontSize = 11.sp,
                maxLines = 2
            )
        }

        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (record.status == DownloadStatus.FAILED || record.status == DownloadStatus.CANCELLED) {
                SecondaryButton(
                    text = stringResource(R.string.manage_record_retry),
                    onClick = onRetry,
                    enabled = !busy && record.finished
                )
                Spacer(Modifier.width(8.dp))
            }
            DangerTextButton(
                text = stringResource(R.string.manage_record_remove),
                onClick = onRemove,
                modifier = Modifier.align(Alignment.CenterVertically)
            )
        }
    }
}

@Composable
private fun sizeText(record: DownloadRecord): String {
    val total = if (record.determinate) Format.bytes(record.total) else "?"
    return stringResource(R.string.manage_record_size, Format.bytes(record.downloaded), total)
}

@Composable
private fun statusLabel(status: DownloadStatus): String = when (status) {
    DownloadStatus.QUEUED -> stringResource(R.string.status_queued)
    DownloadStatus.RUNNING -> stringResource(R.string.status_running)
    DownloadStatus.SUCCESS -> stringResource(R.string.status_success)
    DownloadStatus.FAILED -> stringResource(R.string.status_failed)
    DownloadStatus.CANCELLED -> stringResource(R.string.status_cancelled)
}

@Composable
private fun statusColor(status: DownloadStatus): Color = when (status) {
    DownloadStatus.QUEUED -> MaterialTheme.ext.textSecondary
    DownloadStatus.RUNNING -> MaterialTheme.colorScheme.primary
    DownloadStatus.SUCCESS -> MaterialTheme.ext.success
    DownloadStatus.FAILED -> MaterialTheme.colorScheme.error
    DownloadStatus.CANCELLED -> MaterialTheme.ext.warning
}

@Composable
private fun ConfirmDialog(
    title: String,
    body: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleMedium) },
        text = { Text(NekoText.catify(body), style = MaterialTheme.typography.bodyMedium) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(stringResource(R.string.confirm), color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel), color = MaterialTheme.ext.textSecondary)
            }
        },
        containerColor = MaterialTheme.ext.card,
        titleContentColor = MaterialTheme.colorScheme.onSurface,
        textContentColor = MaterialTheme.ext.textSecondary
    )
}

/** 供 [AccountScreen] 内的 `Icon` 调用保持一致性（占位以避免未用导入告警）。 */
private val unusedIconRef: Any? = null