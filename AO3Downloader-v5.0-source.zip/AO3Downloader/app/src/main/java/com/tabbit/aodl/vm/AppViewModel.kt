package com.tabbit.aodl.vm

import android.app.Application
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tabbit.aodl.BuildConfig
import com.tabbit.aodl.R
import com.tabbit.aodl.data.BrowserPlan
import com.tabbit.aodl.data.CopyTarget
import com.tabbit.aodl.data.DirPlan
import com.tabbit.aodl.data.DownloadHistory
import com.tabbit.aodl.data.FileNameBuilder
import com.tabbit.aodl.data.HtmlBeautifier
import com.tabbit.aodl.data.IconImportError
import com.tabbit.aodl.data.IconImportResult
import com.tabbit.aodl.data.IconManager
import com.tabbit.aodl.data.IconPlan
import com.tabbit.aodl.data.LyricParser
import com.tabbit.aodl.data.LyricResolver
import com.tabbit.aodl.data.MusicMetadataLoader
import com.tabbit.aodl.data.MusicScanner
import com.tabbit.aodl.data.MyTagsStore
import com.tabbit.aodl.data.NekoText
import com.tabbit.aodl.data.PartCleanup
import com.tabbit.aodl.data.Prefs
import com.tabbit.aodl.data.ReaderCacheStore
import com.tabbit.aodl.data.ReaderPlan
import com.tabbit.aodl.data.ResumePlan
import com.tabbit.aodl.data.SafError
import com.tabbit.aodl.data.SafStore
import com.tabbit.aodl.data.SafWriteResult
import com.tabbit.aodl.data.ShelfPlan
import com.tabbit.aodl.data.ShortcutResult
import com.tabbit.aodl.data.SubscriptionsStore
import com.tabbit.aodl.data.TranslatePlan
import com.tabbit.aodl.data.WebLoginPlan
import com.tabbit.aodl.data.WorkSearchFilter
import com.tabbit.aodl.data.WorkSearchOptions
import com.tabbit.aodl.data.WorkSearchPaging
import com.tabbit.aodl.model.AccountState
import com.tabbit.aodl.model.AppIcon
import com.tabbit.aodl.model.AppSettings
import com.tabbit.aodl.model.AuthorUiState
import com.tabbit.aodl.model.BeautifySettings
import com.tabbit.aodl.model.BeautifyStyle
import com.tabbit.aodl.model.BookmarkUiState
import com.tabbit.aodl.model.BrowserState
import com.tabbit.aodl.model.CookieSource
import com.tabbit.aodl.model.DohLinkState
import com.tabbit.aodl.model.DohMethod
import com.tabbit.aodl.model.DohState
import com.tabbit.aodl.model.DownloadFormat
import com.tabbit.aodl.model.DownloadRecord
import com.tabbit.aodl.model.DownloadStatus
import com.tabbit.aodl.model.DownloadUiState
import com.tabbit.aodl.model.FolderTarget
import com.tabbit.aodl.model.DownloadTab
import com.tabbit.aodl.model.EntryListKind
import com.tabbit.aodl.model.EntryListUiState
import com.tabbit.aodl.model.IconUiState
import com.tabbit.aodl.model.LanguageMode
import com.tabbit.aodl.model.LocalMusicUiState
import com.tabbit.aodl.model.LocalTrack
import com.tabbit.aodl.model.LyricSource
import com.tabbit.aodl.model.LogEntry
import com.tabbit.aodl.model.LogLevel
import com.tabbit.aodl.model.MyTagsUiState
import com.tabbit.aodl.model.PreviewState
import com.tabbit.aodl.model.ReaderFont
import com.tabbit.aodl.model.ReaderMode
import com.tabbit.aodl.model.ReaderPalette
import com.tabbit.aodl.model.ReaderState
import com.tabbit.aodl.model.ReaderTheme
import com.tabbit.aodl.model.ReaderTypography
import com.tabbit.aodl.model.ShelfBook
import com.tabbit.aodl.model.ShelfTab
import com.tabbit.aodl.model.ShelfUiState
import com.tabbit.aodl.model.SubscribedAuthor
import com.tabbit.aodl.model.SubscriptionsUiState
import com.tabbit.aodl.model.ThemeMode
import com.tabbit.aodl.model.WebLoginState
import com.tabbit.aodl.model.WorkItem
import com.tabbit.aodl.model.WorkMeta
import com.tabbit.aodl.model.WorkSearchUiState
import com.tabbit.aodl.net.Ao3Client
import com.tabbit.aodl.net.Ao3Error
import com.tabbit.aodl.net.Ao3Result
import com.tabbit.aodl.net.Ao3WebProxy
import com.tabbit.aodl.net.DohConfig
import com.tabbit.aodl.net.DohDns
import com.tabbit.aodl.net.DohEvent
import com.tabbit.aodl.net.DownloadPayload
import com.tabbit.aodl.net.LoginFailReason
import com.tabbit.aodl.net.LoginOutcome
import com.tabbit.aodl.ui.theme.isDarkTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

/**
 * 全局 ViewModel：设置、下载流水线、账号、安全 DNS、作者检索与 HTML 美化的唯一编排入口。
 *
 * 所有网络与文件操作都在 [Dispatchers.IO] 上执行，UI 仅消费 StateFlow。
 */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)
    private val history = DownloadHistory(app)
    private val dns = DohDns(
        configProvider = { currentDohConfig() },
        onEvent = { event -> onDohEvent(event) }
    )
    private val client = Ao3Client(prefs, dns)

    /** 需求 4：桌面 alias 切换、自定义图片解码与桌面快捷方式。 */
    private val icons = IconManager(app)

    /** v5.3：阅读页正文的本地缓存（filesDir/reader_cache/，离线兜底 + 加速打开）。 */
    private val readerCache = ReaderCacheStore(app)

    /**
     * 需求 5：官网登录 WebView 的网络代理。
     *
     * WebView 只用系统 DNS，而本应用绕过污染靠的是 [dns]，因此登录页的请求要经它改道到 OkHttp。
     * 设置里的「官网登录直连」是逃生开关：打开后 [Ao3WebProxy.enabled] 置 false，代理整体不生效。
     * 与 [client] 共享同一个 [dns] 实例，连接池各自独立。
     */
    val webProxy: Ao3WebProxy = Ao3WebProxy(
        dns = dns,
        enabled = !prefs.webDirect(),
        onPostFallback = { log(R.string.log_web_post_fallback, level = LogLevel.WARN) }
    )

    private val logSeq = AtomicLong(0)
    private val recordSeq = AtomicLong(0)
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
    private var downloadJob: Job? = null

    @Volatile
    private var cancelRequested = false

    /**
     * 批次内共享的缓存（需求 1 / 需求 2 / 需求 6）。
     *
     * 同一作品的多个格式任务并发时，作品页只解析一次；
     * 作者目录只在首次遇到时创建，之后的任务直接复用已建好的目录 Uri。
     * 两者都在每批下载开始时清空，避免跨批次使用过期的标题或已失效的目录权限。
     */
    private val metaCache = ConcurrentHashMap<String, Ao3Result<WorkMeta>>()
    private val metaLocks = ConcurrentHashMap<String, Mutex>()
    private val preparedDirs = ConcurrentHashMap<String, Uri>()

    /** 当前/最近一批任务的 recordId，聚合统计只在这一批范围内计算。 */
    @Volatile
    private var batchIds: Set<String> = emptySet()

    // ------------------------------------------------------------------ 状态

    private val _settings = MutableStateFlow(prefs.settings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val _download = MutableStateFlow(DownloadUiState())
    val download: StateFlow<DownloadUiState> = _download.asStateFlow()

    private val _author = MutableStateFlow(AuthorUiState())
    val author: StateFlow<AuthorUiState> = _author.asStateFlow()

    /** 「下载」格当前子页（下载/搜索作者）。放在 VM 里而不是界面的 rememberSaveable，切底部 Tab 回来不丢。 */
    private val _downloadTab = MutableStateFlow(DownloadTab.DOWNLOAD)
    val downloadTab: StateFlow<DownloadTab> = _downloadTab.asStateFlow()

    /** v4.6：站点作品搜索结果，与 [_author] 完全独立，互不覆盖。 */
    private val _workSearch = MutableStateFlow(WorkSearchUiState())
    val workSearch: StateFlow<WorkSearchUiState> = _workSearch.asStateFlow()

    private val _account = MutableStateFlow(AccountState())
    val account: StateFlow<AccountState> = _account.asStateFlow()

    private val _doh = MutableStateFlow(
        DohState(
            enabled = prefs.settings().dohEnabled,
            configuredEndpoint = prefs.settings().dohEndpoint,
            linkState = if (prefs.settings().dohEnabled) DohLinkState.UNKNOWN else DohLinkState.DISABLED
        )
    )
    val doh: StateFlow<DohState> = _doh.asStateFlow()

    private val _bookmarks = MutableStateFlow(BookmarkUiState())
    val bookmarks: StateFlow<BookmarkUiState> = _bookmarks.asStateFlow()

    private val _preview = MutableStateFlow(PreviewState())
    val preview: StateFlow<PreviewState> = _preview.asStateFlow()

    /** 语言切换后由 Activity 观察并 recreate。 */
    private val _localeVersion = MutableStateFlow(0)
    val localeVersion: StateFlow<Int> = _localeVersion.asStateFlow()

    /** 需求 4：图标选择与已上传图片，应用内所有图标位都消费它。 */
    private val _icon = MutableStateFlow(IconUiState())
    val icon: StateFlow<IconUiState> = _icon.asStateFlow()

    /** 需求 5：官网登录层的状态机（是否显示、是否正在提取、失败原因、是否完成）。 */
    private val _webLogin = MutableStateFlow(WebLoginState())
    val webLogin: StateFlow<WebLoginState> = _webLogin.asStateFlow()

    /**
     * v5.0：书架页（阅读历史 / 书签 / 书架三栏 + 共用搜索框）。
     *
     * 启动时直接从 prefs 载入三份已持久化的数据，界面无需再拉一次。
     */
    private val _shelf = MutableStateFlow(
        ShelfUiState(
            history = prefs.history(),
            bookmarks = prefs.bookmarks(),
            shelf = prefs.shelf()
        )
    )
    val shelf: StateFlow<ShelfUiState> = _shelf.asStateFlow()

    /** v5.0：内置浏览页（搜索与作品 / tag 入口的落地页）。 */
    private val _browser = MutableStateFlow(BrowserState())
    val browser: StateFlow<BrowserState> = _browser.asStateFlow()

    /** v5.0：阅读页（番茄沉浸模式 / 原站模式，可随时切换）。 */
    private val _reader = MutableStateFlow(ReaderState())
    val reader: StateFlow<ReaderState> = _reader.asStateFlow()

    /** v5.1：「我的标签」弹窗——App 内本地收藏的标签名单（与 AO3 账号收藏标签无关）。 */
    private val _myTags = MutableStateFlow(MyTagsUiState(tags = prefs.myTags()))
    val myTags: StateFlow<MyTagsUiState> = _myTags.asStateFlow()

    /** v5.1：「我的订阅」——本地订阅的作品与作者，启动即载入，订阅作品列表离线可渲染。 */
    private val _subscriptions = MutableStateFlow(
        SubscriptionsUiState(
            works = prefs.subscribedWorks(),
            authors = prefs.subscribedAuthors()
        )
    )
    val subscriptions: StateFlow<SubscriptionsUiState> = _subscriptions.asStateFlow()

    /** v5.1：五类快捷入口共用的列表页（全部作品 / tag / 作者 / 收藏夹 / 订阅名单）。 */
    private val _entryList = MutableStateFlow(EntryListUiState())
    val entryList: StateFlow<EntryListUiState> = _entryList.asStateFlow()

    /** v5.1：本地音乐入口（SAF 选文件夹 + 音频列表；封面 / 歌词 / 桌面歌词后续版本补齐）。 */
    private val _music = MutableStateFlow(LocalMusicUiState())
    val music: StateFlow<LocalMusicUiState> = _music.asStateFlow()

    /** 封面位图缓存（Bitmap 属 Android 类型，不进 LocalMusicUiState）：音轨 uri -> 封面。 */
    private val _musicCovers = MutableStateFlow<Map<String, Bitmap>>(emptyMap())
    val musicCovers: StateFlow<Map<String, Bitmap>> = _musicCovers.asStateFlow()

    private var musicPlayer: MediaPlayer? = null
    private var musicTicker: Job? = null

    /** 正在加载封面的 uri，避免同一行重复触发解码。 */
    private val coverLoading = java.util.Collections.synchronizedSet(mutableSetOf<String>())

    init {
        refreshAccountState()
        log(R.string.log_app_started, BuildConfig.VERSION_NAME)
        val s = _settings.value
        _download.update { it.copy(concurrency = s.concurrency) }
        // 下载记录持久化在独立的 prefs 文件中，启动时异步载入（需求 3）
        viewModelScope.launch(Dispatchers.IO) {
            val loaded = history.load()
            if (loaded.isNotEmpty()) {
                _download.update { state -> if (state.busy) state else withAggregates(state.copy(records = loaded)) }
                log(R.string.log_records_loaded, loaded.size)
            }
        }
        // 图标：解码自定义图片要读磁盘，放到 IO 线程；随后按持久化的选择同步桌面 alias
        viewModelScope.launch(Dispatchers.IO) { reloadIconState() }
        if (s.dohEnabled) {
            log(R.string.log_doh_on, s.dohEndpoint)
            testDohConnection(quiet = true)
        } else {
            log(R.string.log_doh_off)
        }
    }

    // --------------------------------------------------------------- 日志

    private fun log(resId: Int, vararg args: Any?, level: LogLevel = LogLevel.INFO) {
        val message = getApplication<Application>().getString(resId, *args)
        pushLog(message, level)
    }

    private fun pushLog(message: String, level: LogLevel = LogLevel.INFO) {
        val entry = LogEntry(
            seq = logSeq.incrementAndGet(),
            time = timeFormat.format(Date()),
            // 需求（v5.0 新增 1）：所有日志 / 提示文案结尾统一补「喵～」。
            // catify 幂等，已带尾巴的文案不会二次追加，因此这条出口可以覆盖所有
            // 先经 log() 再进日志弹窗的消息，与各 AlertDialog 的拼接不会叠加。
            message = NekoText.catify(message),
            level = level
        )
        _logs.update { (it + entry).takeLast(MAX_LOGS) }
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    // --------------------------------------------------------------- 输入

    fun onInputChange(text: String) {
        val ids = client.parseWorkIds(text)
        _download.update { it.copy(input = text, parsedWorkId = ids.firstOrNull()) }
    }

    /** 系统分享 / 深链进来的文本。 */
    fun handleSharedText(text: String) {
        val ids = client.parseWorkIds(text)
        _download.update { it.copy(input = text, parsedWorkId = ids.firstOrNull()) }
        if (ids.isEmpty()) {
            log(R.string.log_input_empty, level = LogLevel.WARN)
        } else {
            log(R.string.log_input_parsed, ids.size, ids.joinToString(", "))
        }
    }

    fun parsedIds(): List<String> = client.parseWorkIds(_download.value.input)

    // --------------------------------------------------------------- 下载

    /** 批次内的单个下载任务（作品 × 格式）。 */
    private class BatchTask(
        val recordId: String,
        val workId: String,
        val format: DownloadFormat,
        val rootUri: Uri
    )

    /** 单次下载尝试的结果。 */
    private sealed class AttemptResult {
        class Done(val fileName: String, val fileUri: String, val bytes: Long, val resumedFrom: Long) : AttemptResult()
        object Cancelled : AttemptResult()
        class Failed(
            val error: Ao3Error,
            val message: String,
            val retryable: Boolean,
            val rotateDns: Boolean = false
        ) : AttemptResult()
    }

    /**
     * 启动下载流水线（需求 1 / 需求 2 / 需求 6）。
     *
     * 与 v3.0 的区别：
     * - 任务按「作品 × 格式」展开后进队列，由 [Semaphore] 控制并行数，不再严格串行；
     * - 每个任务先预解析作品页取标题与作者，用于命名、分类目录，并在作品不存在或
     *   需要登录时**提前报错**，不在用户目录里留空文件；
     * - 数据先写 `<正式名>.part`，中断后用 `Range` 从断点续传；
     * - 网络类故障按退避策略自动重试，重试前清 DNS 缓存并轮换安全 DNS 端点；
     * - 进度、速度、状态与错误全部写进 [DownloadRecord]，供「管理」页展示并持久化。
     *
     * @param workIds 为空时取输入框解析结果
     * @param formats 为空时取设置中已启用的格式
     */
    fun startDownload(workIds: List<String> = emptyList(), formats: List<DownloadFormat> = emptyList()) {
        if (_download.value.busy) {
            log(R.string.log_already_running, level = LogLevel.WARN)
            return
        }
        val ids = workIds.ifEmpty { parsedIds() }.filter { it.isNotBlank() }.distinct()
        if (ids.isEmpty()) {
            log(R.string.log_input_empty, level = LogLevel.WARN)
            return
        }
        val wantedFormats = formats.ifEmpty { _settings.value.activeFormats }
        if (wantedFormats.isEmpty()) {
            log(R.string.log_no_format_enabled, level = LogLevel.WARN)
            return
        }
        startTasks(ids.flatMap { id -> wantedFormats.map { id to it } })
    }

    /**
     * 按「作品 + 格式」对直接下发任务。
     *
     * 失败重试走这个入口，避免 [startDownload] 的笛卡尔积把 1 个失败任务
     * 放大成「1 个作品 × 全部启用格式」。
     */
    private fun startTasks(requested: List<Pair<String, DownloadFormat>>) {
        if (_download.value.busy) {
            log(R.string.log_already_running, level = LogLevel.WARN)
            return
        }
        val pairs = requested.filter { it.first.isNotBlank() }.distinct()
        if (pairs.isEmpty()) {
            log(R.string.log_input_empty, level = LogLevel.WARN)
            return
        }

        // 目录预检：缺目录或权限失效的格式直接跳过并提示
        val rootOf = HashMap<DownloadFormat, Uri>()
        pairs.map { it.second }.distinct().forEach { format ->
            val dir = _settings.value.dirFor(format)
            val uri = dir?.takeIf { it.isNotBlank() }?.let { runCatching { Uri.parse(it) }.getOrNull() }
            when {
                uri == null -> log(R.string.log_no_folder, format.displayName, level = LogLevel.ERROR)
                !SafStore.isWritable(getApplication(), uri) ->
                    log(R.string.log_folder_unwritable, format.displayName, level = LogLevel.ERROR)
                else -> rootOf[format] = uri
            }
        }
        if (rootOf.isEmpty()) {
            log(R.string.log_no_folder_any, level = LogLevel.ERROR)
            return
        }

        val snapshot = _settings.value
        val concurrency = snapshot.concurrency
            .coerceIn(AppSettings.MIN_CONCURRENCY, AppSettings.MAX_CONCURRENCY)
        val now = System.currentTimeMillis()
        val tasks = ArrayList<BatchTask>(pairs.size)
        val newRecords = ArrayList<DownloadRecord>(pairs.size)
        pairs.forEach { (workId, format) ->
            val rootUri = rootOf[format] ?: return@forEach
            val recordId = newRecordId(workId, format, now)
            tasks += BatchTask(recordId, workId, format, rootUri)
            newRecords += DownloadRecord(
                recordId = recordId,
                workId = workId,
                format = format,
                status = DownloadStatus.QUEUED,
                dirUri = rootUri.toString(),
                createdAt = now,
                updatedAt = now
            )
        }
        if (tasks.isEmpty()) {
            log(R.string.log_no_folder_any, level = LogLevel.ERROR)
            return
        }

        batchIds = tasks.map { it.recordId }.toSet()
        metaCache.clear()
        preparedDirs.clear()
        cancelRequested = false

        _download.update { state ->
            withAggregates(
                state.copy(
                    busy = true,
                    currentTask = "",
                    fileProgress = 0f,
                    speedBps = 0L,
                    etaMillis = null,
                    sessionExpired = false,
                    concurrency = concurrency,
                    records = (newRecords + state.records)
                        .distinctBy { it.recordId }
                        .take(DownloadHistory.MAX_RECORDS)
                )
            )
        }
        persistRecords()

        val context = getApplication<Application>()
        log(R.string.log_queue, tasks.size)
        log(
            R.string.log_concurrency,
            concurrency,
            snapshot.retryCount,
            context.getString(if (snapshot.resumeEnabled) R.string.state_on else R.string.state_off)
        )

        downloadJob = viewModelScope.launch(Dispatchers.IO) {
            val batchStartedAt = System.currentTimeMillis()
            val semaphore = Semaphore(concurrency)
            coroutineScope {
                tasks.forEach { task ->
                    launch { semaphore.withPermit { runTask(task, snapshot) } }
                }
            }
            persistRecords()
            val result = _download.value
            log(
                R.string.log_batch_done,
                result.succeeded,
                result.failed,
                level = if (result.failed > 0) LogLevel.WARN else LogLevel.SUCCESS
            )
            log(R.string.log_batch_elapsed, elapsedText(System.currentTimeMillis() - batchStartedAt))
            _download.update {
                withAggregates(it.copy(busy = false, currentTask = "", speedBps = 0L, etaMillis = null))
            }
        }
    }

    /** 单个任务的完整生命周期：预解析 → 重试循环 → 落盘 → 记录终态。 */
    private suspend fun runTask(task: BatchTask, settings: AppSettings) {
        val context = getApplication<Application>()
        if (cancelRequested) {
            updateRecord(task.recordId, persist = true) {
                it.copy(status = DownloadStatus.CANCELLED, errorText = context.getString(R.string.err_cancelled))
            }
            return
        }
        val startedAt = System.currentTimeMillis()
        updateRecord(task.recordId, persist = true) {
            it.copy(status = DownloadStatus.RUNNING, attempts = 0, errorText = "", speedBps = 0L)
        }
        log(R.string.log_download_start, task.workId, task.format.displayName)

        val maxAttempts = RetryPolicy.maxAttempts(settings.retryCount)
        var attempt = 0
        var done: AttemptResult.Done? = null
        var cancelled = false
        var lastMessage = ""

        try {
            while (attempt < maxAttempts && done == null && !cancelled) {
                attempt++
                if (cancelRequested) {
                    cancelled = true
                    break
                }
                val currentAttempt = attempt
                updateRecord(task.recordId) { it.copy(attempts = currentAttempt, status = DownloadStatus.RUNNING) }
                when (val outcome = attemptOnce(task, settings, currentAttempt)) {
                    is AttemptResult.Done -> done = outcome
                    is AttemptResult.Cancelled -> cancelled = true
                    is AttemptResult.Failed -> {
                        lastMessage = outcome.message
                        updateRecord(task.recordId) { it.copy(errorText = outcome.message) }
                        if (!outcome.retryable || attempt >= maxAttempts || cancelRequested) break
                        if (outcome.rotateDns) {
                            // 需求 6：网络异常时在默认端点与两个备选端点之间轮换
                            dns.clearCache()
                            dns.rotateEndpoint()?.let { endpoint ->
                                log(R.string.log_doh_rotated, endpoint, level = LogLevel.WARN)
                            }
                        }
                        val waitSeconds = retryDelaySeconds(attempt)
                        log(
                            R.string.log_retry,
                            attempt,
                            maxAttempts,
                            waitSeconds,
                            outcome.message,
                            level = LogLevel.WARN
                        )
                        delay(waitSeconds * 1000L)
                    }
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            lastMessage = context.getString(
                R.string.err_unknown,
                "${e.javaClass.simpleName}: ${e.message.orEmpty()}"
            )
        }

        val elapsed = System.currentTimeMillis() - startedAt
        val finished = done
        if (finished != null) {
            updateRecord(task.recordId, persist = true) {
                it.copy(
                    status = DownloadStatus.SUCCESS,
                    fileName = finished.fileName,
                    downloaded = finished.bytes,
                    total = if (it.total > 0L) it.total else finished.bytes,
                    resumedFromBytes = finished.resumedFrom,
                    elapsedMillis = elapsed,
                    speedBps = 0L,
                    errorText = ""
                )
            }
        } else {
            val status = if (cancelled || cancelRequested) DownloadStatus.CANCELLED else DownloadStatus.FAILED
            val message = when (status) {
                DownloadStatus.CANCELLED -> context.getString(R.string.err_cancelled)
                else -> lastMessage.ifBlank { context.getString(R.string.err_unknown, "") }
            }
            updateRecord(task.recordId, persist = true) {
                it.copy(status = status, errorText = message, elapsedMillis = elapsed, speedBps = 0L)
            }
            if (status == DownloadStatus.FAILED) {
                log(
                    R.string.log_download_fail,
                    task.workId,
                    task.format.displayName,
                    message,
                    level = LogLevel.ERROR
                )
            }
        }
        finalizeParts(context, task, finished != null)
    }

    /**
     * 任务收尾：把该任务名下的中间文件收拢干净（v4.2 修复 #2）。
     *
     * - **成功**：`writePayload` 已经清空该正式名下的全部中间文件，这里只做兜底复核；
     * - **失败**（含重试耗尽、内容非法）：断点已无继续价值，全部删除，用户目录里不留 `.part`；
     * - **取消**：收敛为**唯一一份**规范命名的 `.part`，保住续传入口，同时清掉 provider
     *   改名产生的 `xxx.pdf.part.pdf`、`xxx (1).pdf.part` 等重复变体。
     *
     * 进程被强杀时不走这条路径，但残片在写入时就已被规范化命名，下次下载仍能正常续传。
     *
     * **护栏**：若入库的文件名里仍带 `.part`（provider 不支持重命名，成品只能沿用临时名，
     * 日志区已用 `log_rename_failed` 告知用户），则名字模式无法区分成品与残片，
     * 这里直接跳过清理 —— 宁可留一个名字不好看的成品，也绝不冒险删掉用户刚下完的文件。
     */
    private fun finalizeParts(context: Application, task: BatchTask, succeeded: Boolean) {
        val record = _download.value.records.firstOrNull { it.recordId == task.recordId } ?: return
        if (record.dirUri.isBlank() || record.fileName.isBlank()) return
        if (PartCleanup.cleanupIsUnsafe(record.fileName)) return
        val dirUri = Uri.parse(record.dirUri)
        if (succeeded) {
            logCleaned(SafStore.dropParts(context, dirUri, record.fileName))
        } else if (record.status == DownloadStatus.CANCELLED) {
            SafStore.normalizePart(context, dirUri, record.fileName)
        } else {
            logCleaned(SafStore.dropParts(context, dirUri, record.fileName))
        }
    }

    /** 把「清理了哪些残留临时文件」如实写进日志，用户能对着文件管理器逐条核对。 */
    private fun logCleaned(removed: List<String>, level: LogLevel = LogLevel.INFO) {
        if (removed.isEmpty()) return
        log(R.string.log_part_cleaned, removed.size, PartCleanup.describe(removed), level = level)
    }

    /**
     * 一次下载尝试：预解析作品页 → 定位分类目录 → 定文件名 → 探测断点 → 拉流写盘。
     *
     * [AttemptResult.Failed.retryable] 只依据 [Ao3Client.isRetryableError]：
     * 作品不存在、需要登录这类确定性失败不会重试，只有网络层故障与
     * 服务端临时错误（5xx / 429 / 408）才会。
     */
    private suspend fun attemptOnce(task: BatchTask, settings: AppSettings, attempt: Int): AttemptResult {
        val context = getApplication<Application>()

        // 1. 预解析作品页（需求 1、需求 2 的前置步骤）
        val metaResult = loadWorkMeta(task.workId, settings.viewAdult)
        val meta = when (metaResult) {
            is Ao3Result.Ok -> metaResult.value
            is Ao3Result.Err -> {
                if (metaResult.error == Ao3Error.SESSION_EXPIRED ||
                    metaResult.error == Ao3Error.LOGIN_REQUIRED
                ) {
                    _download.update { it.copy(sessionExpired = true) }
                }
                val text = errorText(metaResult.error, metaResult.detail)
                log(R.string.log_meta_fail, task.workId, text, level = LogLevel.ERROR)
                return AttemptResult.Failed(
                    error = metaResult.error,
                    message = text,
                    retryable = client.isRetryableError(metaResult.error, metaResult.detail),
                    rotateDns = metaResult.error == Ao3Error.NETWORK || metaResult.error == Ao3Error.TIMEOUT
                )
            }
        }
        if (attempt == 1) {
            log(
                R.string.log_meta_ok,
                task.workId,
                meta.title.ifBlank { context.getString(R.string.meta_unknown) },
                meta.authorLabel.ifBlank { context.getString(R.string.dir_unknown_author) },
                meta.chapters.ifBlank { "-" },
                meta.words.ifBlank { "-" }
            )
        }
        updateRecord(task.recordId) { it.copy(title = meta.title, authors = meta.authorLabel) }

        // 2. 目标目录：需求 2 开启时为「作者名 / 格式名」两级目录
        val dirUri = resolveDir(context, task, meta, settings)
        updateRecord(task.recordId) { it.copy(dirUri = dirUri.toString()) }

        // 3. 文件名：需求 1 的「作品名 by 作者名.<后缀>」，取不到时回退作品 ID
        val probeName = if (settings.autoName) {
            FileNameBuilder.build(meta, task.workId, task.format).also {
                log(R.string.log_name_generated, it)
            }
        } else {
            lastKnownName(task)
        }

        // 4. 探测本地断点：只有正式名已知时才能定位 `.part`。
        //    按名字模式扫描而不是精确查找——provider 可能把它写成 `xxx.pdf.part.pdf`
        //    或 `xxx (1).pdf.part`，用 findChild(请求名) 会全部落空，续传永远测不到断点
        //    还会再建一份新残片（v4.2 修复 #2）。
        val localPart = if (settings.resumeEnabled && probeName.isNotBlank()) {
            SafStore.findPart(context, dirUri, probeName)
        } else {
            null
        }
        val localBytes = localPart?.bytes ?: 0L
        var resumeFrom = localBytes

        // 5. 打开下载流；需要续传时带 Range 头。
        //    两种情况必须退化成全新下载，且各自只重开一次，避免死循环：
        //    - HTTP 416：作品被重新生成或 .part 已损坏，本地断点起点超出文件长度；
        //    - 206 但起点与请求不一致：响应体无法与本地 .part 对齐，拼接必然错位。
        var reopened = false
        while (true) {
            val payloadResult = client.openDownload(
                workId = task.workId,
                format = task.format,
                viewAdult = settings.viewAdult,
                rangeStart = if (resumeFrom > 0L) resumeFrom else -1L
            )
            // 用 when 穷举 Ao3Result 拿到 Ok 的载荷：Kotlin 不会在
            // `if (x is Err) { ... }` 之后把 x 智能转换为 Ok。
            // 这里不能直接在分支里 `continue`（表达式分支内不允许控制跳转），
            // 因此「断点失效需重来」只置标记，跳出 when 之后再统一处理。
            var rangeReset = false
            val payload: DownloadPayload? = when (payloadResult) {
                is Ao3Result.Err -> {
                    val mismatchedRange =
                        payloadResult.error == Ao3Error.RANGE_INVALID && resumeFrom > 0L && !reopened
                    if (mismatchedRange) {
                        rangeReset = true
                        null
                    } else {
                        val text = errorText(payloadResult.error, payloadResult.detail)
                        if (payloadResult.error == Ao3Error.SESSION_EXPIRED ||
                            payloadResult.error == Ao3Error.LOGIN_REQUIRED
                        ) {
                            _download.update { it.copy(sessionExpired = true) }
                        }
                        return AttemptResult.Failed(
                            error = payloadResult.error,
                            message = text,
                            retryable = client.isRetryableError(payloadResult.error, payloadResult.detail),
                            rotateDns = payloadResult.error == Ao3Error.NETWORK ||
                                payloadResult.error == Ao3Error.TIMEOUT ||
                                payloadResult.error == Ao3Error.TLS
                        )
                    }
                }

                is Ao3Result.Ok -> payloadResult.value
            }
            if (rangeReset || payload == null) {
                // 服务端 416：本地 `.part` 的断点已失效，删掉后从 0 重新下载。
                dropPart(context, dirUri, probeName)
                log(R.string.log_range_invalid, task.workId, formatBytes(resumeFrom), level = LogLevel.WARN)
                resumeFrom = 0L
                reopened = true
                continue
            }
            if (payload.partial && resumeFrom > 0L && payload.rangeStart != resumeFrom) {
                payload.close()
                if (reopened) {
                    return AttemptResult.Failed(
                        error = Ao3Error.RANGE_INVALID,
                        message = errorText(Ao3Error.RANGE_INVALID, "start=${payload.rangeStart} want=$resumeFrom"),
                        retryable = false
                    )
                }
                dropPart(context, dirUri, probeName)
                log(R.string.log_resume_reset, task.workId, level = LogLevel.WARN)
                resumeFrom = 0L
                reopened = true
                continue
            }
            return payload.use { body ->
                writePayload(context, task, settings, meta, dirUri, probeName, resumeFrom, body)
            }
        }
    }

    /**
     * 放弃断点：删除该正式名下的**全部** `.part` 中间文件（v4.2 修复 #2），
     * 让下一次写入从空文件开始。
     *
     * 按名字模式删除，因此 provider 改名过的 `xxx.pdf.part.pdf`、`xxx (1).pdf.part`
     * 也能被清掉——旧实现用 `findChild(请求名)` 定位，删不掉这些变体，残片只会越积越多。
     */
    private fun dropPart(context: Application, dirUri: Uri, finalName: String) {
        if (finalName.isBlank()) return
        SafStore.dropParts(context, dirUri, finalName)
    }

    /**
     * 把响应流写进 `.part` 临时文件，完成后重命名为正式名。
     *
     * 全程只用 [SafStore.writeFrom] 内部的 64 KiB 缓冲区，不把文件读进内存；
     * 进度回调把「已传字节 / 总字节 / 瞬时速度」实时写进下载记录。
     */
    private fun writePayload(
        context: Application,
        task: BatchTask,
        settings: AppSettings,
        meta: WorkMeta,
        dirUri: Uri,
        probeName: String,
        probeBytes: Long,
        body: DownloadPayload
    ): AttemptResult {
        val finalName = when {
            settings.autoName && probeName.isNotBlank() -> probeName
            body.suggestedFileName.isNotBlank() -> SafStore.sanitize(body.suggestedFileName)
            else -> FileNameBuilder.build(meta, task.workId, task.format, body.suggestedFileName)
        }
        val partName = FileNameBuilder.partName(finalName)

        // 续传判定收敛在纯函数 ResumePlan 中：只有 206 且起点一致才接着写，否则截断重写
        val plan = ResumePlan.decide(
            partial = body.partial,
            confirmedStart = body.rangeStart,
            probeBytes = probeBytes,
            contentLength = body.contentLength,
            fullLength = body.fullLength
        )
        var resumeFrom = plan.resumeFrom
        val total = plan.total
        when {
            resumeFrom > 0L -> log(
                R.string.log_resume_start,
                task.workId,
                formatBytes(resumeFrom),
                formatBytes(total)
            )
            probeBytes > 0L -> log(R.string.log_resume_reset, task.workId, level = LogLevel.WARN)
        }

        // 盘上的中间文件一律按「名字模式」定位（v4.2 修复 #2）：
        // provider 可能把它写成 `xxx.pdf.part.pdf` 或 `xxx (1).pdf.part`，
        // 用精确名 findChild 会漏掉，既测不到断点，也删不掉残片。
        val existingPart = SafStore.findPart(context, dirUri, finalName)
        var partUri: Uri
        var output: OutputStream?
        if (resumeFrom > 0L && existingPart != null) {
            // 续传前先把名字收敛回规范的 `.part`，避免用户目录里出现 `xxx.pdf.part.pdf`
            partUri = SafStore.normalizePart(context, dirUri, finalName) ?: existingPart.uri
            output = SafStore.openAppend(context, partUri)
            if (output == null) {
                // 个别 provider 不支持追加模式，只能截断重写
                resumeFrom = 0L
                log(R.string.log_resume_reset, task.workId, level = LogLevel.WARN)
                output = SafStore.openWrite(context, partUri)
            }
        } else {
            resumeFrom = 0L
            if (existingPart != null) {
                partUri = existingPart.uri
                output = SafStore.openWrite(context, partUri)
            } else {
                val created = SafStore.createFile(context, dirUri, partName, task.format.mime)
                if (created == null) {
                    return AttemptResult.Failed(
                        error = Ao3Error.WRITE,
                        message = context.getString(R.string.err_create_file),
                        retryable = false
                    )
                }
                partUri = created.first
                // provider 可能按 MIME 追加扩展名（`.part` → `.part.pdf`）：立刻改名收敛回
                // 规范形式，之后断点探测、续传与清理都只认规范名，不会再堆出第二种写法。
                if (created.second != partName) {
                    SafStore.renameIn(context, dirUri, partUri, partName)?.let { partUri = it }
                }
                output = SafStore.openWrite(context, partUri)
            }
        }
        if (output == null) {
            return AttemptResult.Failed(
                error = Ao3Error.WRITE,
                message = context.getString(R.string.err_open_stream),
                retryable = false
            )
        }
        val partLabel = SafStore.actualName(context, partUri) ?: partName

        val baseOffset = resumeFrom
        updateRecord(task.recordId) {
            it.copy(
                fileName = finalName,
                dirUri = dirUri.toString(),
                total = total,
                downloaded = baseOffset,
                resumedFromBytes = baseOffset,
                speedBps = 0L
            )
        }

        val writeResult = SafStore.writeFrom(
            source = body.body.source(),
            output = output,
            totalLength = total,
            baseOffset = baseOffset,
            format = task.format
        ) { written, expected, speed ->
            updateRecord(task.recordId) { record ->
                record.copy(
                    downloaded = written,
                    total = if (expected > 0L) expected else record.total,
                    speedBps = speed
                )
            }
            isActiveSafe()
        }

        return when (writeResult) {
            is SafWriteResult.Ok -> {
                val target = SafStore.uniqueChildName(context, dirUri, finalName)
                val renamed = SafStore.renameIn(context, dirUri, partUri, target)
                val storedName: String
                val storedUri: Uri
                if (renamed != null) {
                    storedName = target
                    storedUri = renamed
                    // 下载成功：该正式名下的中间文件必须清零（v4.2 修复 #2）。
                    // provider 改名过的 `xxx.pdf.part.pdf` 之类变体也在这里被扫掉。
                    SafStore.dropParts(context, dirUri, finalName)
                } else {
                    // 个别 provider 不支持重命名：内容已完整，成品只能继续以 `.part` 形式留在盘上。
                    // 必须按 Uri 明确保住这一份（不能按大小挑，旧版留下的超长残片可能更大），
                    // 其余变体清掉，并如实上报盘上的真实名字。
                    logCleaned(
                        SafStore.deletePartsExcept(context, dirUri, finalName, keep = partUri),
                        level = LogLevel.WARN
                    )
                    storedUri = partUri
                    storedName = SafStore.actualName(context, partUri) ?: partLabel
                    log(R.string.log_rename_failed, storedName, level = LogLevel.WARN)
                }
                log(R.string.log_download_ok, storedName, formatBytes(writeResult.bytes), level = LogLevel.SUCCESS)
                if (task.format == DownloadFormat.HTML && settings.autoBeautify && renamed != null) {
                    beautifyFile(storedUri, storedName, dirUri)
                }
                AttemptResult.Done(storedName, storedUri.toString(), writeResult.bytes, baseOffset)
            }

            is SafWriteResult.Err -> when (writeResult.reason) {
                SafError.CANCELLED -> {
                    // 保留唯一一份规范命名的 `.part`：这正是断点续传的入口，下次下载接着写
                    SafStore.normalizePart(context, dirUri, finalName)
                    AttemptResult.Cancelled
                }

                SafError.INVALID_CONTENT -> {
                    // 收到的不是该格式的内容（登录页/拦截页等），残片没有任何续传价值，
                    // 必须删掉——否则会被当成断点，下次续传拼出更坏的文件。
                    val removed = SafStore.dropParts(context, dirUri, finalName)
                    logCleaned(removed, level = LogLevel.WARN)
                    AttemptResult.Failed(
                        error = Ao3Error.PARSE,
                        message = context.getString(
                            R.string.err_content_invalid,
                            task.format.displayName,
                            writeResult.detail
                        ),
                        retryable = false
                    )
                }

                SafError.INCOMPLETE -> {
                    // 响应体被提前结束：保留残片交给上层重试/续传，绝不当成"下载成功"
                    AttemptResult.Failed(
                        error = Ao3Error.NETWORK,
                        message = context.getString(R.string.err_incomplete, writeResult.detail),
                        retryable = true,
                        rotateDns = true
                    )
                }

                else -> {
                    val message = when (writeResult.reason) {
                        SafError.NO_FOLDER, SafError.NOT_WRITABLE, SafError.CREATE_FAILED ->
                            context.getString(R.string.err_create_file)
                        else -> context.getString(R.string.err_write, writeResult.detail)
                    }
                    AttemptResult.Failed(error = Ao3Error.WRITE, message = message, retryable = true)
                }
            }
        }
    }

    /**
     * 取作品页预解析结果。
     *
     * 同一作品的多个格式任务并发时只请求一次（[metaLocks] 做互斥）；
     * 成功结果与确定性失败都会缓存，网络类失败不缓存，重试时会重新拉取。
     */
    private suspend fun loadWorkMeta(workId: String, viewAdult: Boolean): Ao3Result<WorkMeta> {
        cachedMeta(workId)?.let { return it }
        val mutex = metaLocks.computeIfAbsent(workId) { Mutex() }
        return mutex.withLock {
            cachedMeta(workId)?.let { return@withLock it }
            log(R.string.log_meta_fetch, workId)
            val result = client.fetchWorkMeta(workId, viewAdult)
            val cacheable = when (result) {
                is Ao3Result.Ok -> true
                is Ao3Result.Err -> !client.isRetryableError(result.error, result.detail)
            }
            if (cacheable) metaCache[workId] = result
            result
        }
    }

    private fun cachedMeta(workId: String): Ao3Result<WorkMeta>? {
        val cached = metaCache[workId] ?: return null
        if (cached is Ao3Result.Ok &&
            System.currentTimeMillis() - cached.value.fetchedAt >= META_TTL_MILLIS
        ) {
            return null
        }
        return cached
    }

    /**
     * 解析任务的目标目录（需求 2）。
     *
     * 优先级：`dirFor(format)` 先按「统一保存位置」开关定出根目录
     * （开 = 统一目录，关 = 该格式自己的目录），本函数再在根目录下建
     * 「作者名」一级目录；[SafStore.ensureSubDir] 是「先查后建、建完复核」，
     * 因此已存在同名作者目录时直接复用并向其中追加文件，绝不重复创建。
     *
     * 二级格式目录：统一保存时用户只选了一个根目录，一次建齐
     * HTML / PDF / MOBI / EPUB / AZW3 五个；分格式保存时每个格式的根目录
     * 只建当前这一个格式，避免在每个根目录下留下四个空目录。
     * 关闭按作者分类但多格式共用同一根目录时，同样会补上格式目录，
     * 否则五种格式会全部混进同一个文件夹（v4.0 缺陷，判定见 [DirPlan.needsFormatLevel]）。
     *
     * **缓存键必须是「根目录 + 作者名 + 格式」三者**：v4.0 只用了前两者，
     * 于是同一作者下载多种格式时，先解析出来的目标目录会被后面所有格式直接复用，
     * HTML / MOBI / AZW3 / EPUB / PDF 全部落进同一个格式目录（用户实测的缺陷）。
     *
     * 目录创建失败（权限被撤销等）时退回上一级并如实告警，不让整批下载失败。
     *
     * 「建几级、建哪些」的判定全部收在 [DirPlan] 里（纯函数，单测已覆盖四种组合），
     * 本函数只负责把判定结果交给 SAF 执行。
     */
    private fun resolveDir(context: Application, task: BatchTask, meta: WorkMeta, settings: AppSettings): Uri {
        val fallback = context.getString(R.string.dir_unknown_author)
        val authorSegment = DirPlan.authorSegment(settings.authorClassify, meta.authorLabel, fallback)
        val authorName = authorSegment?.let { FileNameBuilder.dirName(it.first, it.second) }
        val formatLevel = DirPlan.needsFormatLevel(settings.authorClassify, settings.unifiedSave)

        val cacheKey = dirCacheKey(task, authorName, formatLevel)
        preparedDirs[cacheKey]?.let { return it }

        val baseUri = if (authorSegment == null) {
            task.rootUri
        } else {
            val created = SafStore.ensureSubDir(context, task.rootUri, authorSegment.first, authorSegment.second)
            if (created == null) {
                log(R.string.log_dir_failed, authorName.orEmpty(), level = LogLevel.WARN)
                return task.rootUri
            }
            created
        }

        // 建齐该模式下应存在的格式目录，并直接采用本次创建/命中的那个 Uri——
        // 不再事后重新查找一遍，避免查不到时静默退回上一级、把各格式的文件又混到一起。
        var target: Uri? = null
        DirPlan.formatSegments(settings.authorClassify, settings.unifiedSave, task.format).forEach { format ->
            val dir = SafStore.ensureSubDir(context, baseUri, format.name, format.name)
            if (format == task.format) target = dir
        }
        if (formatLevel && target == null) {
            log(R.string.log_format_dir_failed, task.format.name, level = LogLevel.WARN)
        }
        val resolved = target ?: baseUri
        preparedDirs[cacheKey] = resolved
        log(
            R.string.log_dir_created,
            authorName ?: baseUri.lastPathSegment.orEmpty(),
            if (formatLevel) task.format.name else task.format.displayName
        )
        return resolved
    }

    /**
     * 目录缓存键：根目录 + 作者名 + 格式（纯函数在 [DirPlan.cacheKey] 里，单测已覆盖）。
     *
     * 之所以必须带格式：同一作者在一次批量下载里会同时拉 HTML / MOBI / EPUB / AZW3 / PDF，
     * 若只按「根目录 + 作者名」缓存，第一个格式解析出的目标目录会被其余格式直接复用，
     * 结果是五种格式的文件全部落进同一个文件夹（用户实测到的缺陷）。
     */
    private fun dirCacheKey(task: BatchTask, authorName: String?, formatLevel: Boolean): String =
        DirPlan.cacheKey(task.rootUri.toString(), authorName, formatLevel, task.format)

    /** 自动命名关闭时，用同一作品+格式的历史文件名来定位 `.part`，否则首次尝试无法续传。 */
    private fun lastKnownName(task: BatchTask): String = _download.value.records
        .firstOrNull {
            it.recordId != task.recordId &&
                it.workId == task.workId &&
                it.format == task.format &&
                it.fileName.isNotBlank()
        }
        ?.fileName
        .orEmpty()

    private fun newRecordId(workId: String, format: DownloadFormat, now: Long): String =
        "$workId-${format.ext}-$now-${recordSeq.incrementAndGet()}"

    /** 线性退避：2s、4s、6s…，上限 15s。规则见 [RetryPolicy]。 */
    private fun retryDelaySeconds(attempt: Int): Int = RetryPolicy.delaySeconds(attempt)

    private fun elapsedText(millis: Long): String {
        val totalSeconds = (millis / 1000L).coerceAtLeast(0L)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return if (minutes > 0) "${minutes}m ${seconds}s" else "${seconds}s"
    }

    private fun isActiveSafe(): Boolean = !cancelRequested

    fun cancelDownload() {
        cancelRequested = true
        val context = getApplication<Application>()
        val message = context.getString(R.string.err_cancelled)
        val ids = batchIds
        // 先把未完成记录改成"已取消"并落盘，再取消协程：job.cancel() 之后子协程不再有机会执行
        _download.update { state ->
            withAggregates(
                state.copy(
                    busy = false,
                    currentTask = "",
                    speedBps = 0L,
                    etaMillis = null,
                    records = state.records.map { record ->
                        if (record.finished || record.recordId !in ids) {
                            record
                        } else {
                            record.copy(
                                status = DownloadStatus.CANCELLED,
                                errorText = message,
                                speedBps = 0L,
                                updatedAt = System.currentTimeMillis()
                            )
                        }
                    }
                )
            )
        }
        persistRecords()
        val keptParts = _download.value.records.count {
            it.recordId in ids && it.status == DownloadStatus.CANCELLED && it.downloaded > 0L
        }
        if (keptParts > 0) log(R.string.log_part_kept, keptParts, level = LogLevel.WARN)
        downloadJob?.cancel()
        downloadJob = null
        log(R.string.log_cancelled, level = LogLevel.WARN)
    }

    // --------------------------------------------- 下载记录（「管理」页数据源）

    /** 刷新：下载进行中时内存态已是最新，只在空闲时从持久化重新载入。 */
    fun refreshRecords() {
        if (_download.value.busy) {
            log(R.string.log_records_busy)
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val loaded = history.load()
            _download.update { withAggregates(it.copy(records = loaded)) }
            log(R.string.log_records_loaded, loaded.size)
        }
    }

    /** 清空全部记录；进行中的任务保留在内存里，避免界面显示"查无此任务"。 */
    fun clearRecords() {
        viewModelScope.launch(Dispatchers.IO) {
            history.clear()
            _download.update { state ->
                withAggregates(state.copy(records = state.records.filterNot { it.finished }))
            }
            persistRecords()
            log(R.string.log_records_cleared, level = LogLevel.WARN)
        }
    }

    /** 只清除已结束（成功 / 失败 / 取消）的记录。 */
    fun clearFinishedRecords() {
        viewModelScope.launch(Dispatchers.IO) {
            val (removed, kept) = history.removeFinished()
            var merged = kept
            _download.update { state ->
                val unfinished = state.records.filterNot { it.finished }
                merged = (unfinished + kept)
                    .distinctBy { it.recordId }
                    .sortedByDescending { it.createdAt }
                withAggregates(state.copy(records = merged))
            }
            history.saveAll(merged)
            log(R.string.log_records_removed_finished, removed)
        }
    }

    fun removeRecord(recordId: String) {
        val record = _download.value.records.firstOrNull { it.recordId == recordId }
        if (record != null && !record.finished) {
            log(R.string.log_record_running, level = LogLevel.WARN)
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            history.remove(setOf(recordId))
            _download.update { state ->
                withAggregates(state.copy(records = state.records.filterNot { it.recordId == recordId }))
            }
            val label = record?.title?.ifBlank { record.workId } ?: recordId
            log(R.string.log_record_removed, label)
        }
    }

    /** 单条失败 / 取消记录重试；`.part` 仍在时会自动续传。 */
    fun retryRecord(recordId: String) {
        val record = _download.value.records.firstOrNull { it.recordId == recordId } ?: return
        if (!record.finished) return
        if (_download.value.busy) {
            log(R.string.log_already_running, level = LogLevel.WARN)
            return
        }
        log(R.string.log_record_retry, record.workId, record.format.displayName)
        startTasks(listOf(record.workId to record.format))
    }

    /** 一键重试全部失败 / 取消的记录。 */
    fun retryFailedRecords() {
        if (_download.value.busy) {
            log(R.string.log_already_running, level = LogLevel.WARN)
            return
        }
        val pending = _download.value.records.filter {
            it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELLED
        }
        if (pending.isEmpty()) {
            log(R.string.log_no_failed_record, level = LogLevel.WARN)
            return
        }
        log(R.string.log_record_retry_batch, pending.size)
        startTasks(pending.map { it.workId to it.format })
    }

    // ------------------------------------------------------- 记录状态聚合

    /**
     * 把记录列表换算成界面需要的聚合字段。
     *
     * 统计范围严格限定在当前批次 [batchIds]，历史记录不会污染
     * 「共 N 个任务 / 成功 M / 失败 K」；进度、速度、剩余时间只取进行中的任务，
     * 数值全部来自 [SafStore.writeFrom] 的真实回调，没有估算填充。
     */
    private fun withAggregates(state: DownloadUiState): DownloadUiState {
        val ids = batchIds
        val batch = if (ids.isEmpty()) emptyList() else state.records.filter { it.recordId in ids }
        val running = batch.filter { it.status == DownloadStatus.RUNNING }
        val measurable = batch.filter { it.total > 0L }
        val progress = when {
            measurable.isNotEmpty() -> (measurable.sumOf { it.downloaded }.toFloat() /
                measurable.sumOf { it.total }).coerceIn(0f, 1f)
            batch.isNotEmpty() -> batch.count { it.status == DownloadStatus.SUCCESS }.toFloat() / batch.size
            else -> 0f
        }
        val context = getApplication<Application>()
        val currentTask = when {
            running.isEmpty() -> ""
            running.size == 1 -> context.getString(
                R.string.task_current,
                running[0].title.ifBlank { running[0].workId },
                running[0].format.displayName
            )
            else -> context.getString(R.string.task_parallel, running.size)
        }
        return state.copy(
            totalTasks = batch.size,
            finishedTasks = batch.count { it.finished },
            succeeded = batch.count { it.status == DownloadStatus.SUCCESS },
            failed = batch.count {
                it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELLED
            },
            fileProgress = progress,
            speedBps = running.sumOf { it.speedBps },
            etaMillis = running.mapNotNull { it.etaMillis }.maxOrNull(),
            currentTask = currentTask
        )
    }

    /** 更新单条记录并重算聚合字段；[persist] 为 true 时同步写入持久化存储。 */
    private fun updateRecord(
        recordId: String,
        persist: Boolean = false,
        transform: (DownloadRecord) -> DownloadRecord
    ) {
        _download.update { state ->
            val index = state.records.indexOfFirst { it.recordId == recordId }
            if (index < 0) return@update state
            val records = state.records.toMutableList()
            records[index] = transform(records[index]).copy(updatedAt = System.currentTimeMillis())
            withAggregates(state.copy(records = records))
        }
        if (persist) persistRecords()
    }

    private fun persistRecords() {
        runCatching { history.saveAll(_download.value.records) }
    }

    // ----------------------------------------------------------- 保存位置

    /** 目录选择器返回后调用。 */
    fun onFolderPicked(target: FolderTarget, uri: Uri?) {
        if (uri == null) return
        val context = getApplication<Application>()
        val granted = SafStore.takePersistablePermission(context, uri)
        val label = targetLabel(target)
        if (!granted) {
            log(R.string.log_folder_permission_denied, label, level = LogLevel.WARN)
        }
        when (target) {
            FolderTarget.Unified -> prefs.setUnifiedDir(uri.toString())
            is FolderTarget.PerFormat -> prefs.setFormatDir(target.format, uri.toString())
            // 音乐文件夹走自己的持久化与扫描流程，不进下载目录设置
            FolderTarget.Music -> {
                onMusicFolderPicked(uri)
                return
            }
        }
        refreshSettings()
        val name = SafStore.displayPath(uri) ?: SafStore.displayName(context, uri).orEmpty()
        log(R.string.log_folder_set, label, name, level = LogLevel.SUCCESS)
    }

    private fun targetLabel(target: FolderTarget): String {
        val context = getApplication<Application>()
        return when (target) {
            FolderTarget.Unified -> context.getString(R.string.folder_unified)
            is FolderTarget.PerFormat -> target.format.displayName
            FolderTarget.Music -> context.getString(R.string.music_title)
        }
    }

    fun clearFolder(target: FolderTarget) {
        when (target) {
            FolderTarget.Unified -> prefs.setUnifiedDir(null)
            is FolderTarget.PerFormat -> prefs.setFormatDir(target.format, null)
            FolderTarget.Music -> {
                prefs.setMusicFolder(null)
                _music.update { it.copy(folderLabel = null, tracks = emptyList()) }
            }
        }
        refreshSettings()
    }

    fun setUnifiedSave(enabled: Boolean) {
        prefs.setUnifiedSave(enabled)
        refreshSettings()
        log(if (enabled) R.string.log_unified_on else R.string.log_unified_off)
    }

    // --------------------------------------------------------------- 设置

    fun refreshSettings() {
        _settings.value = prefs.settings()
        _doh.update {
            it.copy(
                enabled = _settings.value.dohEnabled,
                configuredEndpoint = _settings.value.dohEndpoint,
                linkState = if (_settings.value.dohEnabled) it.linkState else DohLinkState.DISABLED
            )
        }
    }

    fun toggleFormat(format: DownloadFormat, enabled: Boolean) {
        val current = prefs.settings().enabledFormats.toMutableSet()
        if (enabled) current += format else current -= format
        prefs.setEnabledFormats(current)
        refreshSettings()
    }

    fun setThemeMode(mode: ThemeMode) {
        prefs.setThemeMode(mode)
        refreshSettings()
    }

    fun setLanguageMode(mode: LanguageMode) {
        prefs.setLanguageMode(mode)
        refreshSettings()
        _localeVersion.update { it + 1 }
        log(R.string.log_language_changed, mode.name)
    }

    fun setViewAdult(enabled: Boolean) {
        prefs.setViewAdult(enabled)
        refreshSettings()
    }

    /** 需求 1：自动按「作品名 by 作者名」命名，关闭时沿用服务端文件名。 */
    fun setAutoName(enabled: Boolean) {
        prefs.setAutoName(enabled)
        refreshSettings()
        log(if (enabled) R.string.log_auto_name_on else R.string.log_auto_name_off)
    }

    /** 需求 2：按作者分类保存，关闭时直接写到所选根目录。 */
    fun setAuthorClassify(enabled: Boolean) {
        prefs.setAuthorClassify(enabled)
        refreshSettings()
        log(if (enabled) R.string.log_author_classify_on else R.string.log_author_classify_off)
    }

    /** 需求 6：并行下载数。 */
    fun setConcurrency(value: Int) {
        val bounded = value.coerceIn(AppSettings.MIN_CONCURRENCY, AppSettings.MAX_CONCURRENCY)
        prefs.setConcurrency(bounded)
        refreshSettings()
        _download.update { it.copy(concurrency = bounded) }
        log(R.string.log_concurrency_changed, bounded)
    }

    /** 需求 6：单个任务的额外重试次数（0 表示不重试）。 */
    fun setRetryCount(value: Int) {
        val bounded = value.coerceIn(0, AppSettings.MAX_RETRY)
        prefs.setRetryCount(bounded)
        refreshSettings()
        log(R.string.log_retry_changed, bounded)
    }

    /** 需求 6：断点续传开关；关闭后不再探测 `.part`，每次都是完整重下。 */
    fun setResumeEnabled(enabled: Boolean) {
        prefs.setResumeEnabled(enabled)
        refreshSettings()
        log(if (enabled) R.string.log_resume_on else R.string.log_resume_off)
    }

    fun setAutoBeautify(enabled: Boolean) {
        prefs.setAutoBeautify(enabled)
        refreshSettings()
    }

    fun updateBeautify(transform: (BeautifySettings) -> BeautifySettings) {
        prefs.setBeautify(transform(prefs.beautify()))
        refreshSettings()
    }

    fun setBeautifyFont(font: ReaderFont) = updateBeautify { it.copy(font = font, customFontFamily = "") }

    fun setBeautifyTheme(theme: ReaderTheme) = updateBeautify { it.copy(theme = theme) }

    fun setBeautifyStyle(style: BeautifyStyle) = updateBeautify { it.copy(style = style) }

    // ----------------------------------------------------- 应用图标（需求 4）

    /**
     * 按持久化的选择重算图标状态，并把 4 个桌面 alias 的启用状态同步一遍。
     *
     * 判定全部交给 [IconPlan]（纯函数，有离线断言）：自定义图片文件被清掉、
     * 选项名与枚举对不上、甚至 alias 列表被裁剪，都会回退到某套内置图标，
     * 不会出现「零个启用入口」或「多个启用入口」。归一化后的值会写回 Prefs，
     * 顺便修掉历史脏数据。
     */
    private fun reloadIconState() {
        val known = AppIcon.knownNames()
        val fallback = AppIcon.DEFAULT.name
        val hasCustom = icons.hasCustom()
        val decision = IconPlan.decide(
            rawChoice = prefs.iconChoice(),
            rawBuiltin = prefs.iconBuiltin(),
            known = known,
            fallback = fallback,
            hasCustomImage = hasCustom
        )
        prefs.setIconChoice(decision.choice, decision.builtin)
        val bitmap = if (decision.useCustom) icons.customIcon() else null
        val enabled = icons.applyLauncherIcon(decision.choice, decision.builtin, hasCustom)
        _icon.value = IconUiState(
            choice = decision.choice,
            activeIcon = AppIcon.fromName(decision.builtin),
            hasCustom = hasCustom,
            customBitmap = bitmap,
            importing = false,
            shortcutSupported = icons.shortcutSupported()
        )
        if (enabled.size != 1) {
            log(
                R.string.log_icon_alias_warn,
                if (enabled.isEmpty()) "-" else enabled.joinToString(", "),
                level = LogLevel.WARN
            )
        }
    }

    /** 当前图标在界面上显示的名字。 */
    private fun iconLabel(): String {
        val state = _icon.value
        val app = getApplication<Application>()
        return if (state.useCustom) {
            app.getString(R.string.icon_custom)
        } else {
            app.getString(state.activeIcon.labelRes)
        }
    }

    /**
     * 选择图标：传内置图标名（如 `NIGHT`）切换到那套图标并真实换掉桌面图标；
     * 传 [AppIcon.CUSTOM_CHOICE] 则改用已上传的图片渲染应用内图标位。
     */
    fun setIconChoice(picked: String) {
        val known = AppIcon.knownNames()
        val fallback = AppIcon.DEFAULT.name
        val wantsCustom = AppIcon.CUSTOM_CHOICE.equals(picked.trim(), ignoreCase = true)
        if (wantsCustom && !icons.hasCustom()) {
            log(R.string.err_icon_not_uploaded, level = LogLevel.WARN)
            return
        }
        val nextBuiltin = IconPlan.nextBuiltin(picked, prefs.iconBuiltin(), known, fallback)
        val choice = if (wantsCustom) AppIcon.CUSTOM_CHOICE else nextBuiltin
        prefs.setIconChoice(choice, nextBuiltin)
        reloadIconState()
        log(R.string.log_icon_changed, iconLabel(), _icon.value.activeIcon.aliasSimple)
    }

    /**
     * 从 SAF Uri 导入用户上传的图片：采样解码 -> 居中裁成正方形 -> 缩放落盘 ->
     * 立即切到自定义渲染。导入成功后自动把选择改为 [AppIcon.CUSTOM_CHOICE]，
     * 用户不需要再点一次。
     */
    fun importCustomIcon(uri: Uri?) {
        if (uri == null) return
        _icon.update { it.copy(importing = true) }
        viewModelScope.launch(Dispatchers.IO) {
            when (val result = icons.importCustom(uri)) {
                is IconImportResult.Ok -> {
                    prefs.setIconChoice(AppIcon.CUSTOM_CHOICE, prefs.iconBuiltin())
                    reloadIconState()
                    log(R.string.log_icon_imported, result.sizePx, result.sizePx)
                }
                is IconImportResult.Failed -> {
                    _icon.update { it.copy(importing = false) }
                    log(iconImportErrorRes(result.reason), level = LogLevel.ERROR)
                }
            }
        }
    }

    /** 删除已上传的图片并回到内置图标；已固定的桌面快捷方式不会被移除。 */
    fun clearCustomIcon() {
        viewModelScope.launch(Dispatchers.IO) {
            icons.clearCustom()
            val known = AppIcon.knownNames()
            val fallback = AppIcon.DEFAULT.name
            val builtin = IconPlan.nextBuiltin(prefs.iconChoice(), prefs.iconBuiltin(), known, fallback)
            prefs.setIconChoice(builtin, builtin)
            reloadIconState()
            log(R.string.log_icon_cleared)
        }
    }

    /**
     * 用当前上传的图片请求固定一个桌面快捷方式。
     *
     * 快捷方式的 Intent 显式指向**当前启用的那个 alias**，
     * 否则 alias 被禁用后系统解析不到入口，图标会变成点不动的死链。
     */
    fun createDesktopShortcut() {
        val state = _icon.value
        if (!state.hasCustom) {
            log(R.string.err_icon_not_uploaded, level = LogLevel.WARN)
            return
        }
        val label = getApplication<Application>().getString(R.string.app_name)
        val builtinName = state.activeIcon.name
        viewModelScope.launch(Dispatchers.IO) {
            when (icons.createShortcut(label, icons.customIcon(), builtinName)) {
                ShortcutResult.OK -> log(R.string.log_icon_shortcut_ok)
                ShortcutResult.UNSUPPORTED ->
                    log(R.string.log_icon_shortcut_unsupported, level = LogLevel.WARN)
                ShortcutResult.FAILED ->
                    log(R.string.log_icon_shortcut_failed, level = LogLevel.ERROR)
            }
        }
    }

    private fun iconImportErrorRes(reason: IconImportError): Int = when (reason) {
        IconImportError.NO_ACCESS -> R.string.err_icon_no_access
        IconImportError.NOT_IMAGE -> R.string.err_icon_not_image
        IconImportError.WRITE_FAILED -> R.string.err_icon_write_failed
    }

    // ----------------------------------------------------------- 安全 DNS

    private fun currentDohConfig(): DohConfig {
        val s = prefs.settings()
        return DohConfig(
            enabled = s.dohEnabled,
            endpoint = s.dohEndpoint,
            method = s.dohMethod,
            fallbackEnabled = s.dohFallbackEnabled,
            dohHosts = DohConfig.DEFAULT_DOH_HOSTS
        )
    }

    fun setDohEnabled(enabled: Boolean) {
        prefs.setDohEnabled(enabled)
        refreshSettings()
        dns.clearCache()
        if (enabled) {
            log(R.string.log_doh_on, _settings.value.dohEndpoint)
            testDohConnection(quiet = true)
        } else {
            _doh.update { it.copy(linkState = DohLinkState.DISABLED, message = "", resolvedIps = emptyList()) }
            log(R.string.log_doh_off, level = LogLevel.WARN)
        }
    }

    fun setDohEndpoint(endpoint: String) {
        val normalized = endpoint.trim().ifBlank { AppSettings.DEFAULT_DOH_ENDPOINT }
        prefs.setDohEndpoint(normalized)
        refreshSettings()
        dns.clearCache()
        _doh.update { it.copy(configuredEndpoint = normalized, linkState = DohLinkState.UNKNOWN, activeEndpoint = null) }
        log(R.string.log_doh_endpoint_changed, normalized)
    }

    fun setDohMethod(method: DohMethod) {
        prefs.setDohMethod(method)
        refreshSettings()
        dns.clearCache()
    }

    fun setDohFallbackEnabled(enabled: Boolean) {
        prefs.setDohFallbackEnabled(enabled)
        refreshSettings()
    }

    fun resetDohEndpoint() = setDohEndpoint(AppSettings.DEFAULT_DOH_ENDPOINT)

    /** 设置页"测试连接"。 */
    fun testDohConnection(quiet: Boolean = false) {
        val s = _settings.value
        if (!s.dohEnabled) return
        _doh.update { it.copy(linkState = DohLinkState.TESTING) }
        viewModelScope.launch(Dispatchers.IO) {
            val result = dns.testConnection(
                endpoint = s.dohEndpoint,
                method = s.dohMethod,
                fallbackEnabled = s.dohFallbackEnabled
            )
            _doh.update {
                it.copy(
                    linkState = if (result.ok) DohLinkState.CONNECTED else DohLinkState.FAILED,
                    activeEndpoint = if (result.ok) result.endpoint else it.activeEndpoint,
                    resolvedIps = result.ips,
                    latencyMs = result.latencyMs,
                    usedFallback = result.usedFallbackEndpoint,
                    queryCount = dns.stats(),
                    systemFallbackCount = dns.systemFallbacks(),
                    message = if (result.ok) "" else result.error
                )
            }
            if (result.ok) {
                log(
                    R.string.log_doh_test_ok,
                    result.endpoint,
                    result.ips.joinToString(", "),
                    result.latencyMs,
                    level = if (quiet) LogLevel.INFO else LogLevel.SUCCESS
                )
                if (result.usedFallbackEndpoint) {
                    log(R.string.log_doh_fallback_endpoint, result.endpoint, level = LogLevel.WARN)
                }
            } else if (!quiet) {
                log(R.string.log_doh_test_fail, result.error, level = LogLevel.ERROR)
            }
        }
    }

    private fun onDohEvent(event: DohEvent) {
        when (event) {
            is DohEvent.Resolved -> {
                _doh.update {
                    it.copy(
                        linkState = DohLinkState.CONNECTED,
                        activeEndpoint = event.endpoint,
                        resolvedIps = event.ips,
                        latencyMs = event.latencyMs,
                        usedFallback = event.usedFallbackEndpoint,
                        queryCount = dns.stats(),
                        message = ""
                    )
                }
                log(
                    R.string.log_doh_resolved,
                    event.host,
                    event.ips.joinToString(", "),
                    event.ttlSeconds,
                    event.latencyMs
                )
                if (event.usedFallbackEndpoint) {
                    log(R.string.log_doh_fallback_endpoint, event.endpoint, level = LogLevel.WARN)
                }
            }
            is DohEvent.EndpointFailed -> {
                log(R.string.log_doh_endpoint_failed, event.endpoint, event.reason, level = LogLevel.WARN)
            }
            is DohEvent.SystemFallback -> {
                _doh.update {
                    it.copy(
                        linkState = DohLinkState.FAILED,
                        message = event.reason,
                        systemFallbackCount = dns.systemFallbacks()
                    )
                }
                log(R.string.log_doh_system_fallback, event.reason, level = LogLevel.ERROR)
            }
        }
    }

    // --------------------------------------------------------------- 账号

    fun refreshAccountState() {
        val cookie = prefs.cookieHeader().orEmpty()
        _account.update {
            AccountState(
                username = prefs.username(),
                loggedIn = cookie.isNotBlank(),
                loginAt = prefs.loginAt(),
                rememberMe = prefs.rememberMe(),
                cookieSource = prefs.cookieSource(),
                cookiePreview = maskCookie(cookie),
                lastCheckAt = it.lastCheckAt,
                lastCheckOk = it.lastCheckOk,
                busy = false,
                message = ""
            )
        }
    }

    private fun maskCookie(cookie: String): String {
        if (cookie.isBlank()) return ""
        return cookie.split("; ").joinToString("; ") { part ->
            val name = part.substringBefore('=')
            val value = part.substringAfter('=', "")
            if (value.length <= 8) part else "$name=${value.take(4)}…${value.takeLast(4)}"
        }
    }

    /** 账号密码登录；密码只用于本次请求，成功后不落盘。 */
    fun login(username: String, password: String, rememberMe: Boolean) {
        if (_account.value.busy) return
        _account.update { it.copy(busy = true, message = "") }
        viewModelScope.launch(Dispatchers.IO) {
            val outcome = client.login(username, password, rememberMe)
            when (outcome) {
                is LoginOutcome.Success -> {
                    refreshAccountState()
                    log(R.string.log_login_ok, outcome.username, level = LogLevel.SUCCESS)
                    verifySession(silent = true)
                    loadBookmarks(reset = true)
                }
                is LoginOutcome.Failed -> {
                    val text = loginFailText(outcome.reason, outcome.detail)
                    _account.update { it.copy(message = text) }
                    log(R.string.log_login_fail, text, level = LogLevel.ERROR)
                }
            }
            _account.update { it.copy(busy = false) }
        }
    }

    private fun loginFailText(reason: LoginFailReason, detail: String): String {
        val context = getApplication<Application>()
        return when (reason) {
            LoginFailReason.CREDENTIALS -> context.getString(R.string.login_fail_credentials)
            LoginFailReason.NETWORK -> context.getString(R.string.login_fail_network, detail)
            LoginFailReason.NO_TOKEN -> context.getString(R.string.login_fail_no_token)
            LoginFailReason.NO_COOKIE -> context.getString(R.string.login_fail_no_cookie)
            LoginFailReason.BLOCKED -> context.getString(R.string.login_fail_blocked, detail)
            LoginFailReason.UNKNOWN -> context.getString(R.string.err_unknown, detail)
        }
    }

    /** 手动填入 Cookie（备用登录方式）。 */
    fun applyManualCookie(username: String, rawCookie: String) {
        if (rawCookie.isBlank()) {
            _account.update { it.copy(message = getApplication<Application>().getString(R.string.login_fail_no_cookie)) }
            return
        }
        prefs.saveManualCookie(username.trim(), rawCookie.trim())
        refreshAccountState()
        log(R.string.log_manual_cookie_ok, prefs.username(), level = LogLevel.SUCCESS)
        viewModelScope.launch(Dispatchers.IO) {
            verifySession(silent = false)
            loadBookmarks(reset = true)
        }
    }

    // ------------------------------------------- 官网登录取 Cookie（需求 5）

    /**
     * 打开官网登录层。
     *
     * 每次都重置成干净状态，避免上一次的失败提示或「补用户名」弹框残留。
     * 用户在官网页面里自己输入账号密码（含验证码、两步验证），本应用不读取也不保存密码。
     */
    fun openWebLogin() {
        _webLogin.value = WebLoginState(visible = true)
        log(R.string.log_web_opened)
    }

    /** 关闭登录层并回到账号页，账号状态按已落盘的 Cookie 重新计算。 */
    fun closeWebLogin() {
        _webLogin.value = WebLoginState()
        refreshAccountState()
    }

    /** 用户主动放弃本次登录；不改动既有账号。 */
    fun cancelWebLogin() {
        _webLogin.value = WebLoginState()
        log(R.string.log_web_cancelled, level = LogLevel.WARN)
    }

    /** 清掉失败提示，配合界面重新载入官网登录页。 */
    fun reloadWebLogin() {
        _webLogin.update { it.copy(failed = false, message = "") }
    }

    /**
     * 校验并落盘从 `CookieManager.getCookie(BASE_URL)` 取回的 Cookie 串。
     *
     * 该 API 本身已按域名过滤，这里再做两步校验：归一化去掉空段与重复名，
     * 然后确认含会话凭据（`_otwarchive_session` 或 `remember_user_token`），
     * 否则说明用户还没真正登录成功，不能覆盖既有账号。
     *
     * Cookie 先落盘、再去官网取用户名：即便取名字失败（网络抖动或页面结构变化），
     * 登录态也已经保住，只是需要用户手填一次用户名。
     */
    fun extractWebCookie(rawCookieHeader: String?) {
        if (_webLogin.value.busy) return
        val context = getApplication<Application>()
        val normalized = WebLoginPlan.normalizeCookies(rawCookieHeader)
        val count = WebLoginPlan.cookieCount(normalized)
        if (!WebLoginPlan.isUsable(normalized)) {
            _webLogin.update {
                it.copy(
                    busy = false,
                    failed = true,
                    cookieCount = count,
                    message = context.getString(R.string.web_err_no_cookie)
                )
            }
            log(R.string.log_web_no_cookie, count, level = LogLevel.WARN)
            return
        }
        _webLogin.update {
            it.copy(busy = true, failed = false, message = "", cookieCount = count)
        }
        prefs.saveWebCookie("", normalized)
        refreshAccountState()
        viewModelScope.launch(Dispatchers.IO) {
            when (val result = client.fetchLoggedInUsername()) {
                is Ao3Result.Ok -> {
                    val name = result.value
                    prefs.setUsername(name)
                    refreshAccountState()
                    _webLogin.update {
                        it.copy(busy = false, done = true, failed = false, username = name, message = "")
                    }
                    log(R.string.log_web_cookie_ok, name, count, level = LogLevel.SUCCESS)
                    verifySession(silent = true)
                    loadBookmarks(reset = true)
                }
                is Ao3Result.Err -> {
                    refreshAccountState()
                    _webLogin.update { it.copy(busy = false, needsUsername = true, message = "") }
                    log(R.string.log_web_cookie_need_name, count, level = LogLevel.WARN)
                }
            }
        }
    }

    /** 官网页面读不到用户名时由用户手填；Cookie 已落盘，这里只补用户名。 */
    fun submitWebUsername(rawName: String) {
        val context = getApplication<Application>()
        val name = rawName.trim()
        if (name.isEmpty()) {
            _webLogin.update {
                it.copy(failed = true, message = context.getString(R.string.web_err_username_blank))
            }
            return
        }
        prefs.setUsername(name)
        refreshAccountState()
        _webLogin.update {
            it.copy(
                busy = false,
                needsUsername = false,
                failed = false,
                done = true,
                username = name,
                message = ""
            )
        }
        log(R.string.log_web_username_saved, name, level = LogLevel.SUCCESS)
        viewModelScope.launch(Dispatchers.IO) {
            verifySession(silent = true)
            loadBookmarks(reset = true)
        }
    }

    /** 逃生开关：打开后官网登录不再经安全 DNS 代理，由 WebView 自己直连（网络未受污染时可用）。 */
    fun setWebDirect(enabled: Boolean) {
        prefs.setWebDirect(enabled)
        webProxy.enabled = !enabled
        refreshSettings()
        log(
            if (enabled) R.string.log_web_direct_on else R.string.log_web_direct_off,
            level = LogLevel.WARN
        )
    }

    /** 校验会话是否有效；结果写入账号状态（"Session 有效期"）。 */
    fun verifySession(silent: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = client.verifySession()
            _account.update {
                it.copy(
                    lastCheckAt = System.currentTimeMillis(),
                    lastCheckOk = ok,
                    message = when (ok) {
                        true -> ""
                        false -> getApplication<Application>().getString(R.string.err_session_expired)
                        null -> it.message
                    }
                )
            }
            when (ok) {
                true -> if (!silent) log(R.string.log_session_valid, prefs.username(), level = LogLevel.SUCCESS)
                false -> {
                    _download.update { it.copy(sessionExpired = true) }
                    log(R.string.log_session_expired, level = LogLevel.ERROR)
                }
                null -> if (!silent) log(R.string.log_session_unverified, level = LogLevel.WARN)
            }
        }
    }

    fun logout() {
        client.logout()
        refreshAccountState()
        _bookmarks.value = BookmarkUiState()
        _download.update { it.copy(sessionExpired = false) }
        log(R.string.log_logout, level = LogLevel.WARN)
    }

    /** 收藏列表：/users/<username>/bookmarks。 */
    fun loadBookmarks(reset: Boolean = false) {
        val username = prefs.username()
        if (username.isBlank() || !prefs.isLoggedIn()) return
        val page = if (reset) 1 else _bookmarks.value.page + 1
        _bookmarks.update { it.copy(loading = true, error = "") }
        viewModelScope.launch(Dispatchers.IO) {
            when (val result = client.fetchBookmarks(username, page)) {
                is Ao3Result.Ok -> {
                    val value = result.value
                    _bookmarks.update { state ->
                        val merged = if (reset) value.works else state.items + value.works
                        state.copy(
                            loading = false,
                            items = merged,
                            page = page,
                            hasMore = value.hasMore,
                            error = ""
                        )
                    }
                    log(R.string.log_bookmarks_ok, _bookmarks.value.items.size)
                }
                is Ao3Result.Err -> {
                    _bookmarks.update {
                        it.copy(loading = false, error = errorText(result.error, result.detail))
                    }
                    log(R.string.log_bookmarks_fail, errorText(result.error, result.detail), level = LogLevel.WARN)
                }
            }
        }
    }

    // ----------------------------------------------------------- 搜索作者

    fun onAuthorInputChange(text: String) {
        _author.update { it.copy(usernameInput = text) }
    }

    fun searchAuthor(usernameOverride: String? = null) {
        val name = (usernameOverride ?: _author.value.usernameInput).trim()
        if (name.isEmpty()) return
        if (_author.value.loading) return
        _author.update { AuthorUiState(usernameInput = name, username = name, loading = true) }
        log(R.string.log_author_fetch, name, 1)
        fetchAuthorPage(name, page = 1, append = false)
    }

    fun loadMoreAuthorWorks() {
        val state = _author.value
        if (!state.hasMore || state.loadingMore || state.loading || state.username.isEmpty()) return
        _author.update { it.copy(loadingMore = true) }
        fetchAuthorPage(state.username, state.page + 1, append = true)
    }

    private fun fetchAuthorPage(username: String, page: Int, append: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            when (val result = client.fetchAuthorWorks(username, page)) {
                is Ao3Result.Ok -> {
                    val value = result.value
                    _author.update { state ->
                        val merged = if (append) state.works + value.works else value.works
                        state.copy(
                            loading = false,
                            loadingMore = false,
                            works = merged,
                            page = page,
                            hasMore = value.hasMore,
                            error = "",
                            selectedCount = merged.count { it.selected }
                        )
                    }
                    val more = if (value.hasMore) "→" else ""
                    log(R.string.log_author_ok, value.works.size, page, more,
                        level = if (value.works.isEmpty()) LogLevel.WARN else LogLevel.SUCCESS)
                    if (!append && value.works.isEmpty()) {
                        log(R.string.log_author_empty, level = LogLevel.WARN)
                    }
                }
                is Ao3Result.Err -> {
                    val text = errorText(result.error, result.detail)
                    _author.update { it.copy(loading = false, loadingMore = false, error = text) }
                    log(R.string.log_author_fail, text, level = LogLevel.ERROR)
                }
            }
        }
    }

    fun toggleWorkSelected(id: String) {
        _author.update { state ->
            val works = state.works.map { if (it.id == id) it.copy(selected = !it.selected) else it }
            state.copy(works = works, selectedCount = works.count { it.selected })
        }
    }

    fun setAllSelected(selected: Boolean) {
        _author.update { state ->
            val works = state.works.map { if (it.downloadable) it.copy(selected = selected) else it }
            state.copy(works = works, selectedCount = works.count { it.selected })
        }
    }

    /** 自选下载：仅下载勾选的作品。 */
    fun downloadSelectedWorks() {
        val ids = _author.value.works.filter { it.selected && it.downloadable }.map { it.id }
        if (ids.isEmpty()) {
            log(R.string.log_none_selected, level = LogLevel.WARN)
            return
        }
        startDownload(workIds = ids)
    }

    /** 一键下载全部：包含尚未翻页加载的作品，先补齐列表再下载。 */
    fun downloadAllAuthorWorks(maxPages: Int = 50) {
        val state = _author.value
        if (state.username.isEmpty() || state.works.isEmpty()) {
            log(R.string.log_author_not_loaded, level = LogLevel.WARN)
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _author.update { it.copy(busy = true) }
            var page = state.page
            var hasMore = state.hasMore
            val all = state.works.toMutableList()
            while (hasMore && page < maxPages) {
                page++
                val result = client.fetchAuthorWorks(state.username, page)
                when (result) {
                    is Ao3Result.Err -> {
                        log(R.string.log_author_fail, errorText(result.error, result.detail), level = LogLevel.WARN)
                        break
                    }
                    is Ao3Result.Ok -> {
                        all += result.value.works
                        hasMore = result.value.hasMore
                        _author.update { it.copy(works = all.toList(), page = page, hasMore = hasMore) }
                    }
                }
            }
            _author.update { it.copy(busy = false) }
            val ids = all.filter { it.downloadable }.map { it.id }.distinct()
            log(R.string.log_download_all, ids.size)
            withContext(Dispatchers.Main) { startDownload(workIds = ids) }
        }
    }

    // ------------------------------------------------- 搜索作品（站点搜索）

    /**
     * 切换「下载」格内的子页（下载 / 搜索作者）。
     *
     * 两区状态各自独立，切换只改当前子页，不清空对方的输入与结果。
     */
    fun setDownloadTab(tab: DownloadTab) {
        if (_downloadTab.value == tab) return
        _downloadTab.value = tab
    }

    fun onSearchQueryChange(text: String) {
        _workSearch.update { it.copy(queryInput = text) }
    }

    /**
     * 发起站点作品搜索。
     *
     * 用 [WorkSearchUiState.copy] 在旧状态上改词重搜：筛选条件与候选项都保留
     * （v5.1 用户设好的筛选不应因为换关键词被清掉），只把结果与翻页状态归位到第一页。
     */
    fun searchWorks(queryOverride: String? = null) {
        val keyword = (queryOverride ?: _workSearch.value.queryInput).trim()
        if (keyword.isEmpty()) return
        if (_workSearch.value.loading) return
        _workSearch.update {
            it.copy(
                queryInput = keyword,
                query = keyword,
                loading = true,
                loadingMore = false,
                page = 1,
                error = ""
            )
        }
        log(R.string.log_work_search_fetch, keyword, 1)
        fetchSearchPage(keyword, page = 1, append = false)
    }

    /** 加载下一页搜索结果，按作品编号去重后追加到已有结果后面。 */
    fun loadMoreSearchWorks() {
        val state = _workSearch.value
        if (!state.hasMore || state.loadingMore || state.loading || state.query.isEmpty()) return
        _workSearch.update { it.copy(loadingMore = true) }
        fetchSearchPage(state.query, state.page + 1, append = true)
    }

    private fun fetchSearchPage(query: String, page: Int, append: Boolean) {
        val filters = _workSearch.value.filters
        viewModelScope.launch(Dispatchers.IO) {
            when (val result = client.searchWorks(query, page, filters)) {
                is Ao3Result.Ok -> {
                    val value = result.value
                    _workSearch.update { state ->
                        // 翻页可能带回重复条目（站点搜索的分页在结果变动时会漂移），按 id 去重
                        val merged = if (append) {
                            val seen = state.works.map { it.id }.toMutableSet()
                            state.works + value.works.filter { seen.add(it.id) }
                        } else {
                            value.works
                        }
                        val label = value.totalLabel.ifBlank { state.totalLabel }
                        state.copy(
                            loading = false,
                            loadingMore = false,
                            works = merged,
                            page = page,
                            hasMore = value.hasMore,
                            totalLabel = label,
                            totalCount = WorkSearchPaging.parseFoundCount(label),
                            error = "",
                            selectedCount = merged.count { it.selected }
                        )
                    }
                    val more = if (value.hasMore) "→" else ""
                    log(R.string.log_work_search_ok, value.works.size, page, more,
                        level = if (value.works.isEmpty()) LogLevel.WARN else LogLevel.SUCCESS)
                    if (!append && value.works.isEmpty()) {
                        log(R.string.log_work_search_empty, level = LogLevel.WARN)
                    }
                }
                is Ao3Result.Err -> {
                    val text = errorText(result.error, result.detail)
                    _workSearch.update { it.copy(loading = false, loadingMore = false, error = text) }
                    log(R.string.log_work_search_fail, text, level = LogLevel.ERROR)
                }
            }
        }
    }

    /* ------------------------------------------------------ 结果页筛选（v5.1） */

    /** 打开筛选面板：先亮出面板，再异步向站点拉一次真实候选项覆盖内置兜底表。 */
    fun openSearchFilter() {
        if (_workSearch.value.filterPanelOpen) return
        _workSearch.update { it.copy(filterPanelOpen = true, filterLoading = true) }
        refreshSearchFilterOptions()
    }

    /** 关闭筛选面板（不改动已生效的筛选）。 */
    fun closeSearchFilter() {
        _workSearch.update { it.copy(filterPanelOpen = false) }
    }

    /** 应用筛选条件：写回状态、关面板，并从第 1 页重新搜索当前关键词。 */
    fun applySearchFilters(filter: WorkSearchFilter) {
        _workSearch.update {
            it.copy(filters = filter, filterPanelOpen = false, page = 1, error = "")
        }
        val keyword = _workSearch.value.query.trim()
        val count = filter.activeCount()
        log(R.string.log_filter_apply, count)
        if (keyword.isEmpty()) return
        _workSearch.update { it.copy(loading = true, loadingMore = false) }
        fetchSearchPage(keyword, page = 1, append = false)
    }

    /** 一键清空筛选条件（不触发重搜，等用户在面板里再点「应用筛选」）。 */
    fun resetSearchFilters() {
        _workSearch.update { it.copy(filters = WorkSearchFilter()) }
    }

    /** 跳到指定页（分页条点击）。页码与当前页相同且已有结果时不重复请求。 */
    fun goToSearchPage(page: Int) {
        val state = _workSearch.value
        if (page < 1 || state.loading || state.loadingMore) return
        if (page == state.page && state.works.isNotEmpty()) return
        val keyword = state.query.trim()
        if (keyword.isEmpty()) return
        _workSearch.update { it.copy(loading = true, loadingMore = false, error = "") }
        fetchSearchPage(keyword, page = page, append = false)
    }

    /** 拉取站点筛选项并合并到内置兜底表；失败只记日志，面板继续用兜底表。 */
    private fun refreshSearchFilterOptions() {
        viewModelScope.launch(Dispatchers.IO) {
            when (val result = client.fetchSearchFormOptions()) {
                is Ao3Result.Ok -> {
                    _workSearch.update {
                        it.copy(
                            filterOptions = WorkSearchOptions.merge(result.value),
                            filterLoading = false
                        )
                    }
                    log(R.string.log_filter_options_ok, level = LogLevel.SUCCESS)
                }
                is Ao3Result.Err -> {
                    _workSearch.update { it.copy(filterLoading = false) }
                    log(
                        R.string.log_filter_options_fail,
                        errorText(result.error, result.detail),
                        level = LogLevel.WARN
                    )
                }
            }
        }
    }

    /** 勾选/取消勾选搜索结果里的单条作品（批量下载用）。 */
    fun toggleSearchWorkSelected(id: String) {
        _workSearch.update { state ->
            val works = state.works.map { if (it.id == id) it.copy(selected = !it.selected) else it }
            state.copy(works = works, selectedCount = works.count { it.selected })
        }
    }

    /**
     * 全选/取消全选搜索结果。
     *
     * 作用于**完整结果集**而不是当前显示的六条：折叠只是渲染层的收敛，
     * 用户点「全选」时的预期是"这批搜到的都要"，收起状态下勾选也不会丢。
     */
    fun setSearchAllSelected(selected: Boolean) {
        _workSearch.update { state ->
            val works = state.works.map { if (it.downloadable) it.copy(selected = selected) else it }
            state.copy(works = works, selectedCount = works.count { it.selected })
        }
    }

    /** 下载搜索结果中已勾选的作品。 */
    fun downloadSelectedSearchWorks() {
        val ids = _workSearch.value.works.filter { it.selected && it.downloadable }.map { it.id }.distinct()
        if (ids.isEmpty()) {
            log(R.string.log_none_selected, level = LogLevel.WARN)
            return
        }
        startDownload(workIds = ids)
    }

    /** 搜索结果里单条作品的下载入口。 */
    fun downloadSearchWork(item: WorkItem) {
        if (!item.downloadable) {
            log(R.string.log_not_downloadable, level = LogLevel.WARN)
            return
        }
        startDownload(workIds = listOf(item.id))
    }

    /**
     * 收藏条目复制留痕（v4.6 新增）。
     *
     * 剪贴板写入在界面层完成，这里只负责把"复制了什么"写进日志面板，方便用户
     * 事后回看。复制内容是作品作者名与编号，都是 AO3 上的公开元数据，
     * 不涉及账号 Cookie 或密码。
     */
    fun noteCopied(target: CopyTarget, value: String) {
        val text = value.trim()
        if (text.isEmpty()) return
        val resId = when (target) {
            CopyTarget.AUTHOR -> R.string.log_copied_author
            CopyTarget.ID -> R.string.log_copied_id
            CopyTarget.BOTH -> R.string.log_copied_both
        }
        // 直接记录界面写进剪贴板的原文（编号已带 `#` 前缀），不再二次加工
        log(resId, text, level = LogLevel.SUCCESS)
    }

    /** 从收藏列表下载单条作品。 */
    fun downloadBookmark(item: WorkItem) {
        if (!item.downloadable) {
            log(R.string.log_not_downloadable, level = LogLevel.WARN)
            return
        }
        startDownload(workIds = listOf(item.id))
    }

    // -------------------------------------------------------- HTML 美化

    /**
     * 对已下载的 HTML 文件执行美化，另存新文件（默认保留原文件）。
     *
     * @param dirUri 文件所在目录；下载流水线调用时传入已解析的分类目录。
     *   按作者分类保存后文件位于两级子目录中，[treeUriOfFile] 只能匹配配置目录的
     *   直接子文件，因此必须由调用方显式给出，否则美化结果会退化成覆盖原文件。
     */
    fun beautifyFile(fileUri: Uri, fileName: String, dirUri: Uri? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            val settingsSnapshot = prefs.beautify()
            val html = SafStore.readText(context, fileUri)
            if (html.isNullOrBlank()) {
                log(R.string.log_beautify_fail, context.getString(R.string.err_read_file), level = LogLevel.ERROR)
                return@launch
            }
            if (html.length > MAX_BEAUTIFY_CHARS) {
                log(R.string.log_beautify_skip, context.getString(R.string.err_too_large), level = LogLevel.WARN)
                return@launch
            }
            val beautified = HtmlBeautifier.beautify(html, settingsSnapshot, _settings.value.theme.isDarkTheme())
            val targetDir = dirUri ?: treeUriOfFile(context, fileUri)
            if (targetDir == null) {
                // 无法定位所在目录时，直接在原文件上覆盖写入
                val result = SafStore.writeText(context, fileUri, beautified)
                if (result is SafWriteResult.Ok) {
                    log(R.string.log_beautify_ok, fileName, level = LogLevel.SUCCESS)
                } else {
                    log(R.string.log_beautify_fail, fileName, level = LogLevel.ERROR)
                }
                return@launch
            }
            val target = HtmlBeautifier.targetFileName(fileName)
            val created = SafStore.createFile(context, targetDir, target, "text/html", overwrite = true)
            if (created == null) {
                log(R.string.log_beautify_fail, context.getString(R.string.err_create_file), level = LogLevel.ERROR)
                return@launch
            }
            val writeResult = SafStore.writeText(context, created.first, beautified)
            if (writeResult is SafWriteResult.Ok) {
                log(R.string.log_beautify_ok, created.second, level = LogLevel.SUCCESS)
                if (!settingsSnapshot.keepOriginal) {
                    if (SafStore.delete(context, fileUri)) {
                        log(R.string.log_original_removed, fileName)
                    }
                }
                if (_preview.value.visible) {
                    _preview.update { it.copy(html = beautified, original = false, title = created.second) }
                }
            } else {
                log(R.string.log_beautify_fail, fileName, level = LogLevel.ERROR)
            }
        }
    }

    /** 由文件 Uri 反推其所在目录树 Uri（用于把美化结果写到同一文件夹）。 */
    private fun treeUriOfFile(context: Application, fileUri: Uri): Uri? {
        val candidates = buildList {
            _settings.value.unifiedDir?.let { add(it) }
            DownloadFormat.entries.forEach { f -> _settings.value.formatDirs[f]?.let { add(it) } }
        }
        candidates.forEach { candidate ->
            val tree = runCatching { Uri.parse(candidate) }.getOrNull() ?: return@forEach
            val dir = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, tree) ?: return@forEach
            val name = fileUri.lastPathSegment?.substringAfterLast('/')
            if (name != null && dir.findFile(name) != null) return tree
        }
        return null
    }

    /** 设置页示例预览：无需下载文件即可查看美化效果。 */
    fun previewSample() {
        val context = getApplication<Application>()
        val settingsSnapshot = prefs.beautify()
        val html = HtmlBeautifier.sampleDocument(
            settings = settingsSnapshot,
            appDark = _settings.value.theme.isDarkTheme(),
            title = context.getString(R.string.preview_sample_title),
            author = context.getString(R.string.preview_sample_author),
            notes = context.getString(R.string.preview_sample_notes),
            metaLine = context.getString(R.string.preview_sample_meta),
            summary = context.getString(R.string.preview_sample_summary),
            paragraphs = listOf(
                context.getString(R.string.preview_sample_p1),
                context.getString(R.string.preview_sample_p2)
            )
        )
        _preview.value = PreviewState(
            visible = true,
            title = context.getString(R.string.preview_title_sample),
            html = html,
            original = false
        )
    }

    /** 预览已下载的 HTML 文件（美化后 / 原样）。 */
    fun previewFile(fileUri: Uri, fileName: String, beautified: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            val html = SafStore.readText(context, fileUri)
            if (html.isNullOrBlank()) {
                log(R.string.log_preview_fail, context.getString(R.string.err_read_file), level = LogLevel.WARN)
                return@launch
            }
            val content = if (beautified) {
                HtmlBeautifier.beautify(html, prefs.beautify(), _settings.value.theme.isDarkTheme())
            } else {
                html
            }
            _preview.value = PreviewState(visible = true, title = fileName, html = content, original = !beautified)
        }
    }

    fun closePreview() {
        _preview.update { it.copy(visible = false, html = "") }
    }

    // --------------------------------------------------------------- 工具

    fun errorText(error: Ao3Error, detail: String): String {
        val context = getApplication<Application>()
        return when (error) {
            Ao3Error.NETWORK -> context.getString(R.string.err_network, detail)
            Ao3Error.TIMEOUT -> context.getString(R.string.err_timeout)
            Ao3Error.TLS -> context.getString(R.string.err_tls, detail)
            Ao3Error.HTTP -> context.getString(R.string.err_http, detail)
            Ao3Error.NOT_FOUND -> context.getString(R.string.err_not_found)
            Ao3Error.LOGIN_REQUIRED -> context.getString(R.string.err_login_required)
            Ao3Error.SESSION_EXPIRED -> context.getString(R.string.err_session_expired)
            Ao3Error.UNEXPECTED_HTML -> context.getString(R.string.err_unexpected_html)
            Ao3Error.RANGE_INVALID -> context.getString(R.string.err_range_invalid, detail)
            Ao3Error.PARSE -> context.getString(R.string.err_parse, detail)
            Ao3Error.WRITE -> context.getString(R.string.err_write, detail)
            Ao3Error.NO_FOLDER -> context.getString(R.string.err_no_folder)
            Ao3Error.CANCELLED -> context.getString(R.string.err_cancelled)
            Ao3Error.UNKNOWN -> context.getString(R.string.err_unknown, detail)
        }
    }

    fun folderLabel(target: FolderTarget): String {
        val context = getApplication<Application>()
        val uriString = when (target) {
            FolderTarget.Unified -> _settings.value.unifiedDir
            is FolderTarget.PerFormat -> _settings.value.formatDirs[target.format]
            FolderTarget.Music -> prefs.musicFolder()
        }
        if (uriString.isNullOrBlank()) return context.getString(R.string.folder_not_set)
        val uri = runCatching { Uri.parse(uriString) }.getOrNull() ?: return context.getString(R.string.folder_not_set)
        val path = SafStore.displayPath(uri)
        val name = SafStore.displayName(context, uri)
        return when {
            !SafStore.isWritable(context, uri) -> context.getString(R.string.folder_unavailable)
            !path.isNullOrBlank() -> path
            !name.isNullOrBlank() -> name
            else -> context.getString(R.string.folder_selected)
        }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        var value = bytes.toDouble()
        var index = 0
        while (value >= 1024 && index < units.size - 1) {
            value /= 1024
            index++
        }
        return if (index == 0) "${value.toInt()} ${units[index]}" else "%.2f %s".format(value, units[index])
    }

    // ==================================================== v5.0：翻译入口

    /** 当前生效的翻译模板：设置为空时回退默认模板（免密钥 Google 网页翻译代理）。 */
    fun translateTemplate(): String =
        _settings.value.translateTemplate.trim().ifEmpty { TranslatePlan.DEFAULT_TEMPLATE }

    fun translateTarget(): String =
        _settings.value.translateTarget.trim().ifEmpty { TranslatePlan.DEFAULT_TARGET }

    /** 设置页写入翻译模板；空串表示恢复默认。 */
    fun setTranslateTemplate(template: String) {
        prefs.setTranslateTemplate(template)
        refreshSettings()
        log(R.string.log_translate_template, translateTemplate())
    }

    fun setTranslateTarget(target: String) {
        prefs.setTranslateTarget(target)
        refreshSettings()
        log(R.string.log_translate_target, translateTarget())
    }

    /** 设置页与阅读页共用：写默认阅读模式并同步当前阅读页。 */
    fun setReaderMode(mode: ReaderMode) {
        prefs.setReaderMode(mode)
        refreshSettings()
        if (_reader.value.visible) _reader.update { it.copy(mode = mode) }
    }

    // ==================================================== v5.0：内置浏览页

    /** 在浏览页打开站点路径或完整地址（搜索入口、作品、tag、收藏夹都走这里）。 */
    fun openBrowser(pathOrUrl: String) {
        val url = BrowserPlan.absolute(pathOrUrl)
        if (url.isBlank()) return
        _browser.value = BrowserState(visible = true, url = url, loading = true, progress = 0)
        log(R.string.log_browser_open, url)
    }

    fun openBrowserWork(workId: String) = openBrowser(BrowserPlan.workPath(workId))

    /** 卡片上的作者名可点：落到该 pseud 的作品列表。 */
    fun openBrowserAuthor(username: String) = openBrowser(BrowserPlan.authorPath(username))

    fun openBrowserSearchWorks(query: String) = openBrowser(BrowserPlan.searchWorksPath(query))

    fun openBrowserTag(tag: String) = openBrowser(BrowserPlan.tagPath(tag))

    fun openBrowserBookmarks() = openBrowser(BrowserPlan.bookmarksPath(_account.value.username))

    fun openBrowserAllWorks() = openBrowser(BrowserPlan.PATH_ALL_WORKS)

    fun openBrowserRecent() = openBrowser(BrowserPlan.PATH_RECENT)

    fun openBrowserHotTags() = openBrowser(BrowserPlan.PATH_HOT_TAGS)

    /** 需求 5：四个快捷入口，全部落到内置浏览页。 */
    fun openBrowserEntry(path: String, label: String) {
        log(R.string.log_search_entry, label)
        openBrowser(path)
    }

    fun closeBrowser() {
        _browser.value = BrowserState()
    }

    /* ---- 以下回调由浏览页 WebView 驱动，状态机与界面一一对应 ---- */

    fun onBrowserProgress(progress: Int) {
        _browser.update { it.copy(progress = progress.coerceIn(0, 100), loading = progress < 100) }
    }

    fun onBrowserNavigated(canBack: Boolean, canForward: Boolean) {
        _browser.update { it.copy(canGoBack = canBack, canGoForward = canForward) }
    }

    /** WebView 回传的页面地址（跟随站内跳转，保留译文标记）。 */
    fun onBrowserUrl(url: String) {
        if (url.isBlank()) return
        _browser.update { it.copy(url = url) }
    }

    fun onBrowserTitle(title: String) {
        if (title.isBlank()) return
        _browser.update { it.copy(title = title.trim()) }
    }

    fun onBrowserFinished() {
        _browser.update { it.copy(loading = false, progress = 100, error = "") }
        val state = _browser.value
        // 作品页加载完成即记一条阅读历史（浏览也算读过），字段取 WebView 标题
        val id = state.workId
        if (id != null) {
            touchHistory(id, state.title, "", "", "")
        }
    }

    fun onBrowserError(message: String) {
        _browser.update { it.copy(loading = false, error = message) }
    }

    /** 「译 中文」：按模板拼译文地址，记住原文便于一键返回。 */
    fun browserTranslate() {
        val state = _browser.value
        if (state.url.isBlank()) return
        val source = state.originalUrl.ifBlank { state.url }
        val translated = TranslatePlan.buildUrl(translateTemplate(), source, translateTarget())
        if (translated.isBlank()) return
        _browser.update {
            it.copy(
                url = translated,
                originalUrl = source,
                translated = true,
                loading = true,
                progress = 0,
                error = ""
            )
        }
        log(R.string.log_browser_translate, translated)
    }

    /** 「返回原文」：回到译文之前那条地址，不发新请求。 */
    fun browserReturnOriginal() {
        val state = _browser.value
        if (state.originalUrl.isBlank()) return
        _browser.update {
            it.copy(url = state.originalUrl, translated = false, loading = true, progress = 0, error = "")
        }
        log(R.string.log_browser_original, state.originalUrl)
    }

    fun browserAddToShelf() {
        val state = _browser.value
        val id = state.workId ?: return
        addToShelf(ShelfBook(workId = id, title = state.title))
    }

    fun browserDownload() {
        val id = _browser.value.workId ?: return
        startDownload(workIds = listOf(id))
    }

    fun browserRead() {
        val state = _browser.value
        val id = state.workId ?: return
        openReader(id, state.title)
    }

    // ==================================================== v5.0：书架

    fun setShelfTab(tab: ShelfTab) {
        if (_shelf.value.tab != tab) _shelf.update { it.copy(tab = tab) }
    }

    fun onShelfQueryChange(text: String) {
        _shelf.update { it.copy(query = text) }
    }

    fun clearHistory() {
        prefs.setHistory(emptyList())
        _shelf.update { it.copy(history = emptyList()) }
        log(R.string.log_history_cleared)
    }

    /** 搜索结果卡片「加入书架」。 */
    fun addToShelfFrom(item: WorkItem) = addToShelf(
        ShelfBook(
            workId = item.id,
            title = item.title,
            authors = item.authors,
            tags = item.tags,
            chapters = item.chapters,
            updated = item.updated,
            restricted = item.restricted
        )
    )

    fun addToShelf(book: ShelfBook) {
        val key = book.workId.trim()
        if (key.isEmpty()) return
        if (ShelfPlan.onShelf(_shelf.value.shelf, key)) {
            log(R.string.log_shelf_exists, book.label)
            return
        }
        val next = ShelfPlan.addToShelf(_shelf.value.shelf, book)
        prefs.setShelf(next)
        _shelf.update { it.copy(shelf = next) }
        log(R.string.log_shelf_added, book.label)
    }

    fun removeFromShelf(workId: String) {
        val key = workId.trim()
        val target = _shelf.value.shelf.firstOrNull { it.workId == key } ?: return
        val next = ShelfPlan.removeFromShelf(_shelf.value.shelf, key)
        prefs.setShelf(next)
        _shelf.update { it.copy(shelf = next) }
        log(R.string.log_shelf_removed, target.label)
    }

    /** 记一条阅读历史（同作品只留最新一条、上限 300），并同步标题等站点字段。 */
    private fun touchHistory(
        workId: String,
        title: String,
        authors: String,
        tags: String,
        chapters: String
    ) {
        val id = workId.trim()
        if (id.isEmpty()) return
        val entry = ShelfBook(
            workId = id,
            title = title,
            authors = authors,
            tags = tags,
            chapters = chapters
        )
        val next = ShelfPlan.recordHistory(_shelf.value.history, entry)
        prefs.setHistory(next)
        _shelf.update { it.copy(history = next) }
    }

    /** 把「已读到第几章」写回书架与历史里已有的同作品条目。 */
    private fun writeProgress(workId: String, readChapters: Int) {
        val shelf = ShelfPlan.withProgress(_shelf.value.shelf, workId, readChapters)
        val history = ShelfPlan.withProgress(_shelf.value.history, workId, readChapters)
        prefs.setShelf(shelf)
        prefs.setHistory(history)
        _shelf.update { it.copy(shelf = shelf, history = history) }
    }

    /**
     * 需求 3：「拉取书签」——登录后从 AO3 账号书签同步，去重后截到上限 200。
     *
     * 未登录直接提示；网络失败只在书架页消息位与日志里说明，不清空已有书签。
     */
    fun syncBookmarks() {
        val account = _account.value
        val context = getApplication<Application>()
        if (!account.loggedIn || account.username.isBlank()) {
            _shelf.update { it.copy(message = context.getString(R.string.shelf_need_login)) }
            log(R.string.log_shelf_login_required, level = LogLevel.WARN)
            return
        }
        if (_shelf.value.syncing) return
        _shelf.update { it.copy(syncing = true, message = "") }
        viewModelScope.launch(Dispatchers.IO) {
            val collected = mutableListOf<ShelfBook>()
            var page = 1
            var failure: String? = null
            while (page <= MAX_BOOKMARK_PAGES) {
                when (val result = client.fetchBookmarks(account.username, page)) {
                    is Ao3Result.Ok -> {
                        collected += result.value.works.map { it.toShelfBook() }
                        if (!result.value.hasMore) break
                        page++
                    }
                    is Ao3Result.Err -> {
                        failure = errorText(result.error, result.detail)
                        break
                    }
                }
            }
            if (failure != null) {
                _shelf.update { it.copy(syncing = false, message = failure) }
                log(R.string.log_shelf_bookmarks_fail, failure, level = LogLevel.WARN)
                return@launch
            }
            val merged = ShelfPlan.syncBookmarks(_shelf.value.bookmarks, collected)
            val capped = merged.take(ShelfPlan.BOOKMARK_LIMIT)
            prefs.setBookmarks(capped)
            val message = if (collected.size > capped.size) {
                context.getString(R.string.shelf_bookmarks_capped, ShelfPlan.BOOKMARK_LIMIT)
            } else {
                context.getString(R.string.shelf_bookmarks_ok, capped.size)
            }
            _shelf.update { it.copy(bookmarks = capped, syncing = false, message = message) }
            log(R.string.log_shelf_bookmarks_ok, capped.size)
        }
    }

    private fun WorkItem.toShelfBook(): ShelfBook = ShelfBook(
        workId = id,
        title = title,
        authors = authors,
        tags = tags,
        chapters = chapters,
        updated = updated,
        restricted = restricted
    )

    // ==================================================== v5.0：阅读页

    /**
     * 打开阅读页。
     *
     * 两种模式共用一次正文抓取：番茄模式渲染纯文本逐章翻页，原站模式把同一作品的
     * 官网页面交给 WebView 照原样渲染；无论哪种模式，章节数与已读进度都写回书架。
     *
     * v5.3 起正文带本地缓存：命中时先离线展示（新鲜缓存 7 天内不再联网，过期缓存
     * 先展示再后台静默刷新）；未命中才走 loading 抓取，成功后写缓存。
     * 续读定位优先用精细进度（章节 + 章内滚动比例），其次书架的章节级进度。
     */
    fun openReader(workId: String, title: String = "", authors: String = "") {
        val id = workId.trim()
        if (id.isEmpty()) return
        val existing = _shelf.value.history.firstOrNull { it.workId == id }
            ?: _shelf.value.shelf.firstOrNull { it.workId == id }
        val saved = prefs.readerProgress(id)
        val startIndex = (saved?.first ?: ((existing?.readChapters ?: 1) - 1)).coerceAtLeast(0)
        _reader.value = ReaderState(
            visible = true,
            mode = _settings.value.readerMode,
            workId = id,
            title = title.ifBlank { existing?.title.orEmpty() },
            authors = authors.ifBlank { existing?.authors.orEmpty() },
            chapterIndex = startIndex,
            offsetFrac = saved?.second ?: 0f,
            typography = prefs.readerTypography(),
            loading = true
        )
        log(R.string.log_reader_open, _reader.value.title.ifBlank { "#$id" }, id)
        touchHistory(id, _reader.value.title, _reader.value.authors, "", existing?.chapters.orEmpty())
        viewModelScope.launch(Dispatchers.IO) {
            val cached = readerCache.load(id)
            if (cached != null) {
                applyReaderContent(
                    id = id,
                    title = cached.first.title,
                    authors = cached.first.authors,
                    summary = cached.first.summary,
                    chaptersLabel = cached.first.chaptersLabel,
                    chapters = cached.first.chapters,
                    fromCache = true
                )
                log(R.string.log_reader_cache, _reader.value.title.ifBlank { "#$id" }, id)
                // 新鲜缓存直接离线读完；过期缓存继续走联网静默刷新
                if (readerCache.isFresh(cached.second)) return@launch
            }
            when (val result = client.fetchWorkContent(id, _settings.value.viewAdult)) {
                is Ao3Result.Ok -> {
                    val content = result.value
                    applyReaderContent(
                        id = id,
                        title = content.meta.title,
                        authors = content.meta.authorLabel,
                        summary = content.summary,
                        chaptersLabel = content.meta.chapters,
                        chapters = content.chapters,
                        fromCache = false
                    )
                    readerCache.save(
                        ReaderPlan.CachedContent(
                            workId = id,
                            title = content.meta.title,
                            authors = content.meta.authorLabel,
                            summary = content.summary,
                            chaptersLabel = content.meta.chapters,
                            chapters = content.chapters
                        )
                    )
                    val current = _reader.value
                    val read = current.readChapters
                    writeProgress(id, read)
                    log(R.string.log_reader_ok, current.totalChapters)
                    log(R.string.log_reader_progress, current.title.ifBlank { "#$id" }, read, current.totalChapters)
                }
                is Ao3Result.Err -> {
                    val detail = errorText(result.error, result.detail)
                    // 已有缓存兜底时只提示刷新失败，不清空正在展示的正文
                    if (cached == null) {
                        _reader.update { it.copy(loading = false, error = detail) }
                    } else {
                        _reader.update { it.copy(loading = false) }
                    }
                    log(R.string.log_reader_fail, detail, level = LogLevel.WARN)
                }
            }
        }
    }

    /** 把一份正文（网络抓取或缓存解码）回填到阅读状态；用户已切到别的作品时丢弃。 */
    private fun applyReaderContent(
        id: String,
        title: String,
        authors: String,
        summary: String,
        chaptersLabel: String,
        chapters: List<com.tabbit.aodl.model.Chapter>,
        fromCache: Boolean
    ) {
        val total = chapters.size
        _reader.update { state ->
            if (state.workId != id) return@update state
            val index = state.chapterIndex.coerceIn(0, (total - 1).coerceAtLeast(0))
            state.copy(
                title = title.ifBlank { state.title },
                authors = authors.ifBlank { state.authors },
                summary = summary,
                chapters = chapters,
                chapterIndex = index,
                // 章节数变化导致下标被夹回时，章内位置一并作废
                offsetFrac = if (index != state.chapterIndex) 0f else state.offsetFrac,
                loading = false,
                error = "",
                fromCache = fromCache
            )
        }
        if (chaptersLabel.isNotBlank()) {
            val current = _reader.value
            if (current.workId == id) touchHistory(id, current.title, current.authors, "", chaptersLabel)
        }
    }

    fun closeReader() {
        _reader.value = ReaderState()
    }

    fun readerGoToChapter(index: Int) {
        val state = _reader.value
        if (state.chapters.isEmpty()) return
        val target = index.coerceIn(0, state.chapters.size - 1)
        if (target == state.chapterIndex && !state.catalogOpen) return
        _reader.update { it.copy(chapterIndex = target, offsetFrac = 0f, catalogOpen = false) }
        prefs.setReaderProgress(state.workId, target, 0f)
        writeProgress(state.workId, target + 1)
        log(R.string.log_reader_progress, state.title.ifBlank { "#${state.workId}" }, target + 1, state.chapters.size)
    }

    fun readerPrevChapter() = readerGoToChapter(_reader.value.chapterIndex - 1)

    fun readerNextChapter() = readerGoToChapter(_reader.value.chapterIndex + 1)

    /** 目录抽屉开关（与设置面板互斥）。 */
    fun toggleReaderCatalog() {
        _reader.update { it.copy(catalogOpen = !it.catalogOpen, settingsOpen = false) }
    }

    /** 阅读设置面板开关（与目录抽屉互斥）。 */
    fun toggleReaderSettings() {
        _reader.update { it.copy(settingsOpen = !it.settingsOpen, catalogOpen = false) }
    }

    fun setReaderFont(font: ReaderFont) = updateReaderTypography { it.copy(font = font) }

    fun setReaderFontSize(sp: Int) =
        updateReaderTypography { it.copy(fontSizeSp = ReaderPlan.clampFontSize(sp)) }

    fun setReaderLineHeight(mul: Float) =
        updateReaderTypography { it.copy(lineHeightMul = ReaderPlan.clampLineHeight(mul)) }

    fun setReaderMargin(dp: Int) =
        updateReaderTypography { it.copy(marginDp = ReaderPlan.clampMargin(dp)) }

    fun setReaderPalette(palette: ReaderPalette) = updateReaderTypography { it.copy(palette = palette) }

    /** 排版设置同时落盘与回填状态：换一部作品、重启 App 都保持同样的版式。 */
    private fun updateReaderTypography(transform: (ReaderTypography) -> ReaderTypography) {
        val next = transform(_reader.value.typography)
        prefs.setReaderTypography(next)
        _reader.update { it.copy(typography = next) }
    }

    /**
     * 章内滚动进度（0..1）由界面节流上报；写盘并与书架章节级进度保持一致。
     * 变化小于千分之一时跳过，避免滚动动画期间反复写 SharedPreferences。
     */
    fun readerSaveOffset(frac: Float) {
        val state = _reader.value
        if (!state.visible || state.workId.isBlank() || state.chapters.isEmpty()) return
        val clamped = frac.coerceIn(0f, 1f)
        if (abs(clamped - state.offsetFrac) < 0.001f) return
        _reader.update { it.copy(offsetFrac = clamped) }
        prefs.setReaderProgress(state.workId, state.chapterIndex, clamped)
    }

    // ==================================================== v5.1：我的标签（本地收藏）

    fun openMyTagsDialog() {
        _myTags.update { it.copy(visible = true, message = "") }
    }

    fun closeMyTagsDialog() {
        _myTags.update { it.copy(visible = false, input = "", message = "") }
    }

    fun onMyTagInput(text: String) {
        _myTags.update { it.copy(input = text, message = "") }
    }

    /** 新增本地标签：去重（忽略大小写），成功后清空输入框。 */
    fun addMyTag() {
        val value = _myTags.value.input.trim()
        if (value.isEmpty()) return
        val context = getApplication<Application>()
        if (MyTagsStore.contains(_myTags.value.tags, value)) {
            _myTags.update { it.copy(message = context.getString(R.string.my_tags_exists, value)) }
            return
        }
        val updated = MyTagsStore.add(_myTags.value.tags, value)
        prefs.setMyTags(updated)
        _myTags.update { it.copy(tags = updated, input = "", message = context.getString(R.string.my_tags_added, value)) }
        log(R.string.my_tags_added, value, level = LogLevel.SUCCESS)
    }

    fun removeMyTag(tag: String) {
        val updated = MyTagsStore.remove(_myTags.value.tags, tag)
        prefs.setMyTags(updated)
        _myTags.update { it.copy(tags = updated, message = getApplication<Application>().getString(R.string.my_tags_removed, tag)) }
        log(R.string.my_tags_removed, tag)
    }

    /** 弹窗单选一个标签：关弹窗，进入该 tag 的作品列表（统一卡片格式）。 */
    fun openMyTag(tag: String) {
        val value = tag.trim()
        if (value.isEmpty()) return
        closeMyTagsDialog()
        openTagWorksList(value)
    }

    // ==================================================== v5.1：我的订阅（本地名单）

    fun openSubscriptionsPanel() {
        _subscriptions.update { it.copy(panelOpen = true, message = "") }
    }

    fun closeSubscriptionsPanel() {
        _subscriptions.update { it.copy(panelOpen = false, authorInput = "", message = "") }
    }

    fun onSubscribedAuthorInput(text: String) {
        _subscriptions.update { it.copy(authorInput = text, message = "") }
    }

    /** 在订阅面板里直接按用户名订阅作者。 */
    fun subscribeAuthorFromInput() {
        val name = _subscriptions.value.authorInput.trim()
        if (name.isEmpty()) return
        val context = getApplication<Application>()
        if (SubscriptionsStore.containsAuthor(_subscriptions.value.authors, name)) {
            _subscriptions.update { it.copy(message = context.getString(R.string.subs_author_exists, name)) }
            return
        }
        val updated = SubscriptionsStore.addAuthor(_subscriptions.value.authors, name, System.currentTimeMillis())
        prefs.setSubscribedAuthors(updated)
        _subscriptions.update {
            it.copy(authors = updated, authorInput = "", message = context.getString(R.string.subs_author_added, name))
        }
        refreshEntryListIf(EntryListKind.SUBSCRIBED_AUTHORS)
        log(R.string.subs_author_added, name, level = LogLevel.SUCCESS)
    }

    /** 卡片上的「订阅 / 已订阅」：切换作品订阅态并落盘。 */
    fun toggleSubscribeWork(item: WorkItem) {
        val current = _subscriptions.value.works
        val subscribed = SubscriptionsStore.containsWork(current, item.id)
        val updated = if (subscribed) {
            SubscriptionsStore.removeWork(current, item.id)
        } else {
            SubscriptionsStore.addWork(current, item)
        }
        prefs.setSubscribedWorks(updated)
        _subscriptions.update { it.copy(works = updated) }
        refreshEntryListIf(EntryListKind.SUBSCRIBED_WORKS)
        val label = item.title.ifBlank { "#${item.id}" }
        log(
            if (subscribed) R.string.subs_work_removed else R.string.subs_work_added,
            label,
            level = if (subscribed) LogLevel.INFO else LogLevel.SUCCESS
        )
    }

    /** 订阅 / 取消订阅作者（作者作品列表头部按钮与订阅列表行内删除共用）。 */
    fun toggleSubscribeAuthor(username: String) {
        val name = username.trim()
        if (name.isEmpty()) return
        val current = _subscriptions.value.authors
        val subscribed = SubscriptionsStore.containsAuthor(current, name)
        val updated = if (subscribed) {
            SubscriptionsStore.removeAuthor(current, name)
        } else {
            SubscriptionsStore.addAuthor(current, name, System.currentTimeMillis())
        }
        prefs.setSubscribedAuthors(updated)
        _subscriptions.update { it.copy(authors = updated) }
        refreshEntryListIf(EntryListKind.SUBSCRIBED_AUTHORS)
        log(
            if (subscribed) R.string.subs_author_removed else R.string.subs_author_added,
            name,
            level = if (subscribed) LogLevel.INFO else LogLevel.SUCCESS
        )
    }

    /** 本地名单变化后，若对应订阅列表正开着就原地刷新内容。 */
    private fun refreshEntryListIf(kind: EntryListKind) {
        val state = _entryList.value
        if (!state.visible || state.kind != kind) return
        when (kind) {
            EntryListKind.SUBSCRIBED_WORKS -> _entryList.update { it.copy(works = _subscriptions.value.works) }
            EntryListKind.SUBSCRIBED_AUTHORS -> _entryList.update { it.copy(authors = _subscriptions.value.authors) }
            else -> Unit
        }
    }

    // ==================================================== v5.1：五类入口列表

    fun openSiteWorksList() {
        log(R.string.log_search_entry, getApplication<Application>().getString(R.string.search_entry_all))
        openEntryList(
            kind = EntryListKind.ALL_WORKS,
            title = getApplication<Application>().getString(R.string.entry_title_all)
        )
    }

    fun openBookmarksList() {
        log(R.string.log_search_entry, getApplication<Application>().getString(R.string.search_entry_bookmarks))
        openEntryList(
            kind = EntryListKind.BOOKMARKS,
            title = getApplication<Application>().getString(R.string.entry_title_bookmarks)
        )
    }

    fun openTagWorksList(tag: String) {
        val value = tag.trim()
        if (value.isEmpty()) return
        log(R.string.log_search_entry, getApplication<Application>().getString(R.string.entry_title_tag, value))
        openEntryList(
            kind = EntryListKind.TAG_WORKS,
            title = getApplication<Application>().getString(R.string.entry_title_tag, value),
            tag = value
        )
    }

    fun openAuthorWorksList(username: String) {
        val name = username.trim()
        if (name.isEmpty()) return
        log(R.string.log_search_entry, getApplication<Application>().getString(R.string.entry_title_author, name))
        openEntryList(
            kind = EntryListKind.AUTHOR_WORKS,
            title = getApplication<Application>().getString(R.string.entry_title_author, name),
            author = name
        )
    }

    /** 「订阅的作品」一栏：直接读本地名单，离线可用，不请求站点。 */
    fun openSubscribedWorks() {
        closeSubscriptionsPanel()
        _entryList.value = EntryListUiState(
            visible = true,
            kind = EntryListKind.SUBSCRIBED_WORKS,
            title = getApplication<Application>().getString(R.string.entry_title_sub_works),
            works = _subscriptions.value.works
        )
    }

    /** 「订阅的作者」一栏：本地名单 + 用户名输入订阅。 */
    fun openSubscribedAuthors() {
        closeSubscriptionsPanel()
        _entryList.value = EntryListUiState(
            visible = true,
            kind = EntryListKind.SUBSCRIBED_AUTHORS,
            title = getApplication<Application>().getString(R.string.entry_title_sub_authors),
            authors = _subscriptions.value.authors
        )
    }

    private fun openEntryList(
        kind: EntryListKind,
        title: String,
        tag: String = "",
        author: String = ""
    ) {
        _entryList.value = EntryListUiState(
            visible = true,
            kind = kind,
            title = title,
            tag = tag,
            author = author,
            loading = true
        )
        loadEntryPage(page = 1, append = false)
    }

    fun closeEntryList() {
        _entryList.value = EntryListUiState()
    }

    /** 列表底部「加载下一页」。 */
    fun loadMoreEntryList() {
        val state = _entryList.value
        if (!state.paged || !state.hasMore || state.loading || state.loadingMore) return
        _entryList.update { it.copy(loadingMore = true) }
        loadEntryPage(state.page + 1, append = true)
    }

    /** 分页条跳页：与当前页相同且已有结果时不重复请求。 */
    fun goToEntryPage(page: Int) {
        val state = _entryList.value
        if (!state.paged || page < 1 || state.loading || state.loadingMore) return
        if (page == state.page && state.works.isNotEmpty()) return
        _entryList.update { it.copy(loading = true, error = "") }
        loadEntryPage(page, append = false)
    }

    /**
     * 按列表类型取一页数据：
     * 全部作品 / tag / 作者走站点作品列表，收藏夹走书签列表（未登录给「去登录」），
     * 订阅两类是本地数据，不经过这里。
     */
    private fun loadEntryPage(page: Int, append: Boolean) {
        val state = _entryList.value
        if (state.kind == EntryListKind.BOOKMARKS) {
            val account = _account.value
            if (!account.loggedIn || account.username.isBlank()) {
                _entryList.update {
                    it.copy(loading = false, loadingMore = false, needsLogin = true, works = emptyList())
                }
                return
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            val result = when (state.kind) {
                EntryListKind.ALL_WORKS -> client.fetchSiteWorks(page)
                EntryListKind.TAG_WORKS -> client.fetchTagWorks(state.tag, page)
                EntryListKind.AUTHOR_WORKS -> client.fetchAuthorWorks(state.author, page)
                EntryListKind.BOOKMARKS -> client.fetchBookmarkListing(_account.value.username, page)
                else -> return@launch
            }
            when (result) {
                is Ao3Result.Ok -> {
                    val value = result.value
                    _entryList.update { current ->
                        val merged = if (append) {
                            val seen = current.works.map { it.id }.toMutableSet()
                            current.works + value.works.filter { seen.add(it.id) }
                        } else {
                            value.works
                        }
                        val label = value.totalLabel.ifBlank { current.totalLabel }
                        current.copy(
                            loading = false,
                            loadingMore = false,
                            works = merged,
                            page = page,
                            hasMore = value.hasMore,
                            totalLabel = label,
                            needsLogin = false,
                            error = ""
                        )
                    }
                }
                is Ao3Result.Err -> {
                    val text = errorText(result.error, result.detail)
                    _entryList.update { it.copy(loading = false, loadingMore = false, error = text) }
                    log(R.string.log_work_search_fail, text, level = LogLevel.ERROR)
                }
            }
        }
    }

    // ==================================================== v5.1：本地音乐入口

    /** 打开本地音乐页：已选过文件夹直接扫描，未选过提示先选文件夹。 */
    fun openLocalMusic() {
        val folder = prefs.musicFolder()
        _music.update {
            it.copy(
                visible = true,
                message = if (folder == null) {
                    getApplication<Application>().getString(R.string.music_no_folder)
                } else {
                    ""
                }
            )
        }
        if (folder != null) scanMusicFolder()
    }

    /** 关闭页面但保留播放与桌面歌词状态：离开页面音乐照播，歌词条仍在。 */
    fun closeLocalMusic() {
        _music.update { it.copy(visible = false, detail = null) }
    }

    /** SAF 选完音乐文件夹：持久化权限 + 记录地址 + 立即扫描。 */
    fun onMusicFolderPicked(uri: Uri) {
        val context = getApplication<Application>()
        SafStore.takePersistablePermission(context, uri)
        prefs.setMusicFolder(uri.toString())
        val name = SafStore.displayPath(uri) ?: SafStore.displayName(context, uri).orEmpty()
        log(R.string.log_music_folder, name, level = LogLevel.SUCCESS)
        _music.update { it.copy(visible = true, message = "") }
        scanMusicFolder()
    }

    /** 递归扫描已选文件夹（最多下钻两层子目录），按 [MusicScanner] 规则筛选音频。 */
    private fun scanMusicFolder() {
        val context = getApplication<Application>()
        val uriString = prefs.musicFolder()
        if (uriString.isNullOrBlank()) {
            _music.update {
                it.copy(loading = false, tracks = emptyList(), message = context.getString(R.string.music_no_folder))
            }
            return
        }
        _music.update { it.copy(loading = true, message = "") }
        viewModelScope.launch(Dispatchers.IO) {
            val treeUri = Uri.parse(uriString)
            val root = runCatching { DocumentFile.fromTreeUri(context, treeUri) }.getOrNull()
            val found = mutableListOf<LocalTrack>()

            fun walk(dir: DocumentFile, depth: Int) {
                if (depth > 2) return
                val children = dir.listFiles()
                val names = children.mapNotNull { it.name }
                children.forEach { file ->
                    if (file.isDirectory) {
                        walk(file, depth + 1)
                    } else {
                        val name = file.name ?: return@forEach
                        if (MusicScanner.isAudioFile(name)) {
                            // 同目录兄弟文件里找同名歌词与封面，规则由 LyricResolver 裁决
                            val lyricName = LyricResolver.findExternalLyric(name, names)
                            val coverName = LyricResolver.findExternalCover(name, names)
                            found += LocalTrack(
                                title = MusicScanner.displayTitle(name),
                                fileName = name,
                                uri = file.uri.toString(),
                                sizeBytes = file.length(),
                                lyricUri = children.firstOrNull { it.name == lyricName }?.uri?.toString(),
                                coverUri = children.firstOrNull { it.name == coverName }?.uri?.toString()
                            )
                        }
                    }
                }
            }

            if (root != null) walk(root, 0)
            val sorted = MusicScanner.sortByTitle(found) { it.title }
            val label = SafStore.displayPath(treeUri) ?: SafStore.displayName(context, treeUri)
            _music.update {
                it.copy(
                    loading = false,
                    tracks = sorted,
                    folderLabel = label,
                    message = if (sorted.isEmpty()) context.getString(R.string.music_empty) else ""
                )
            }
            log(
                R.string.log_music_scan,
                sorted.size,
                level = if (sorted.isEmpty()) LogLevel.WARN else LogLevel.SUCCESS
            )
        }
    }

    // ==================================================== v5.2：音乐播放 / 封面 / 歌词

    /** 点列表行：同一首切换播放/暂停，否则换歌并从头播放。 */
    fun playTrack(track: LocalTrack) {
        if (_music.value.current?.uri == track.uri && musicPlayer != null) {
            togglePlayPause()
            return
        }
        releasePlayer()
        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val player = MediaPlayer()
            val ready = runCatching {
                player.setDataSource(context, Uri.parse(track.uri))
                player.prepare()
            }.isSuccess
            if (!ready) {
                runCatching { player.release() }
                _music.update { it.copy(message = context.getString(R.string.music_play_failed)) }
                return@launch
            }
            player.setOnCompletionListener { onMusicCompleted() }
            musicPlayer = player
            player.start()
            _music.update {
                it.copy(
                    current = track,
                    playing = true,
                    positionMs = 0L,
                    durationMs = player.duration.toLong(),
                    currentLyrics = emptyList(),
                    message = ""
                )
            }
            startMusicTicker()
            ensureCover(track)
            // 歌词后台加载，完成后桌面歌词条即可随进度高亮
            val (lyrics, _) = loadLyrics(context, track)
            _music.update {
                if (it.current?.uri == track.uri) it.copy(currentLyrics = lyrics) else it
            }
        }
    }

    fun togglePlayPause() {
        val player = musicPlayer ?: return
        runCatching {
            if (player.isPlaying) {
                player.pause()
                _music.update { it.copy(playing = false) }
            } else {
                player.start()
                _music.update { it.copy(playing = true) }
                startMusicTicker()
            }
        }
    }

    /** 停止并释放播放器，同时收起桌面歌词条（没有可展示的歌曲）。 */
    fun stopTrack() {
        releasePlayer()
        _music.update {
            it.copy(
                current = null,
                playing = false,
                positionMs = 0L,
                durationMs = 0L,
                currentLyrics = emptyList(),
                lyricBar = false
            )
        }
    }

    private fun onMusicCompleted() {
        _music.update { it.copy(playing = false, positionMs = 0L) }
    }

    private fun releasePlayer() {
        musicTicker?.cancel()
        musicTicker = null
        runCatching { musicPlayer?.release() }
        musicPlayer = null
    }

    /** 播放进度轮询：驱动桌面歌词条与详情页的高亮行。 */
    private fun startMusicTicker() {
        if (musicTicker?.isActive == true) return
        musicTicker = viewModelScope.launch {
            while (true) {
                val player = musicPlayer ?: break
                if (runCatching { player.isPlaying }.getOrDefault(false)) {
                    val pos = runCatching { player.currentPosition.toLong() }.getOrDefault(0L)
                    _music.update { it.copy(positionMs = pos) }
                }
                delay(400)
            }
        }
    }

    /** 详情层：打开某首歌的封面与歌词（不改变播放状态）。 */
    fun openTrackDetail(track: LocalTrack) {
        _music.update {
            it.copy(detail = track, detailLyrics = emptyList(), detailLyricSource = LyricSource.NONE)
        }
        ensureCover(track)
        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val (lyrics, source) = loadLyrics(context, track)
            _music.update {
                if (it.detail?.uri == track.uri) {
                    it.copy(detailLyrics = lyrics, detailLyricSource = source)
                } else it
            }
        }
    }

    fun closeTrackDetail() {
        _music.update { it.copy(detail = null) }
    }

    /** 桌面歌词条开关；仅在有当前歌曲时允许打开。 */
    fun toggleLyricBar() {
        _music.update { state ->
            val target = !state.lyricBar
            state.copy(lyricBar = target && state.current != null)
        }
    }

    /** 列表行封面懒加载：已缓存或加载中则跳过。 */
    fun ensureCover(track: LocalTrack) {
        if (_musicCovers.value.containsKey(track.uri)) return
        if (!coverLoading.add(track.uri)) return
        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val bitmap = loadCover(context, track)
            if (bitmap != null) {
                _musicCovers.update { covers ->
                    val trimmed = if (covers.size >= MAX_COVERS) covers - covers.keys.first() else covers
                    trimmed + (track.uri to bitmap)
                }
            }
            coverLoading.remove(track.uri)
        }
    }

    /** 歌词：同名 .lrc 优先，其次内嵌 USLT 标签，再退化到「无歌词」。 */
    private suspend fun loadLyrics(
        context: Application,
        track: LocalTrack
    ): Pair<List<LyricParser.LyricLine>, LyricSource> = withContext(Dispatchers.IO) {
        track.lyricUri
            ?.let { MusicMetadataLoader.loadSidecarLyrics(context, Uri.parse(it)) }
            ?.let { LyricParser.parse(it) }
            ?.takeIf { it.isNotEmpty() }
            ?.let { return@withContext it to LyricSource.EXTERNAL }
        MusicMetadataLoader.loadEmbeddedLyrics(context, Uri.parse(track.uri))
            ?.let { LyricParser.parse(it) }
            ?.takeIf { it.isNotEmpty() }
            ?.let { return@withContext it to LyricSource.EMBEDDED }
        emptyList<LyricParser.LyricLine>() to LyricSource.NONE
    }

    /** 封面：内嵌图片优先，其次同名 / 通用封面文件。 */
    private fun loadCover(context: Application, track: LocalTrack): Bitmap? {
        MusicMetadataLoader.loadEmbeddedCover(context, Uri.parse(track.uri))?.let { return it }
        return track.coverUri?.let { MusicMetadataLoader.loadImageFile(context, Uri.parse(it)) }
    }

    override fun onCleared() {
        downloadJob?.cancel()
        releasePlayer()
        super.onCleared()
    }

    private companion object {
        const val MAX_LOGS = 400
        const val MAX_BEAUTIFY_CHARS = 8_000_000

        /** 封面位图缓存上限：超出后丢弃最早的一张。 */
        const val MAX_COVERS = 60

        /** 「拉取书签」最多翻多少页（每页约 20 条，覆盖上限 200 即可）。 */
        const val MAX_BOOKMARK_PAGES = 12

        /** 作品页预解析结果的缓存有效期；同批多格式任务共享一次解析。 */
        const val META_TTL_MILLIS = 10 * 60 * 1000L
    }
}
