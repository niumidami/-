package com.tabbit.aodl.data

import com.tabbit.aodl.model.BeautifySettings
import com.tabbit.aodl.model.BeautifyStyle
import com.tabbit.aodl.model.ReaderTheme

/**
 * HTML 美化器：按用户设置生成 CSS，并注入到已下载的 AO3 HTML 文档 `<head>` 中。
 *
 * AO3 导出的 HTML 自带 workskin 样式，因此这里对排版类属性使用 `!important`
 * 并配合更高优先级的选择器（`body#workskin`、`.userstuff`），保证用户设置确实生效。
 * 原始文件默认保留，美化结果另存为 `原名.beautified.html`。
 */
object HtmlBeautifier {

    private const val STYLE_ID = "aodl-beautify"
    private const val VIEWPORT = "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"

    /** 目标阅读主题是否为暗色。 */
    fun isDark(theme: ReaderTheme, appDark: Boolean): Boolean = when (theme) {
        ReaderTheme.LIGHT -> false
        ReaderTheme.DARK -> true
        ReaderTheme.FOLLOW_APP -> appDark
    }

    /** 生成注入用 CSS。 */
    fun buildCss(settings: BeautifySettings, dark: Boolean): String {
        val bg = if (dark) "#1E1117" else "#FDF7F9"
        val surface = if (dark) "#2A1A23" else "#FFFFFF"
        val fg = if (dark) "#F8F0F3" else "#2B2027"
        val muted = if (dark) "#A08090" else "#8A6E7C"
        val accent = if (dark) "#F48FB1" else "#B3446B"
        val border = if (dark) "#3A2530" else "#EAD9E1"

        val family = settings.customFontFamily.takeIf { it.isNotBlank() } ?: settings.font.cssFamily
        val fontSize = settings.fontSizeSp.coerceIn(10, 40)
        val smallSize = "%.1f".format(fontSize * 0.85f)
        val lineHeight = settings.lineHeight.coerceIn(1.0f, 3.5f)
        val margin = settings.marginDp.coerceIn(0, 80)
        val paraSpacing = settings.paragraphSpacingEm.coerceIn(0f, 4f)
        val align = if (settings.justify) "justify" else "start"

        return buildString {
            appendLine(":root {")
            appendLine("  --aodl-bg: $bg;")
            appendLine("  --aodl-surface: $surface;")
            appendLine("  --aodl-fg: $fg;")
            appendLine("  --aodl-muted: $muted;")
            appendLine("  --aodl-accent: $accent;")
            appendLine("  --aodl-border: $border;")
            appendLine("}")
            appendLine("html, body {")
            appendLine("  background: var(--aodl-bg) !important;")
            appendLine("  color: var(--aodl-fg) !important;")
            appendLine("  margin: 0 !important;")
            appendLine("  padding: 0 !important;")
            appendLine("}")
            appendLine("body, body#workskin, body.work {")
            appendLine("  font-family: $family !important;")
            appendLine("  font-size: ${fontSize}sp !important;")
            appendLine("  line-height: $lineHeight !important;")
            appendLine("  padding: ${margin}px ${margin}px ${margin * 3}px !important;")
            appendLine("  text-align: $align !important;")
            appendLine("  word-break: break-word;")
            appendLine("  -webkit-text-size-adjust: 100%;")
            appendLine("}")
            appendLine("#workskin, .work, div[role=\"article\"], #chapters, .chapter {")
            appendLine("  background: transparent !important;")
            appendLine("  color: inherit !important;")
            appendLine("  font-family: $family !important;")
            appendLine("  font-size: ${fontSize}sp !important;")
            appendLine("  line-height: $lineHeight !important;")
            appendLine("  max-width: 46em;")
            appendLine("  margin: 0 auto;")
            appendLine("}")
            appendLine(".userstuff, .userstuff p, .userstuff div {")
            appendLine("  font-family: $family !important;")
            appendLine("  font-size: ${fontSize}sp !important;")
            appendLine("  line-height: $lineHeight !important;")
            appendLine("  color: inherit !important;")
            appendLine("}")
            appendLine(".userstuff p, #chapters p {")
            appendLine("  margin: 0 0 ${paraSpacing}em 0 !important;")
            appendLine("  text-indent: 0 !important;")
            appendLine("}")
            appendLine("h1, h2, h3, h4, h5, h6, .heading {")
            appendLine("  color: var(--aodl-accent) !important;")
            appendLine("  font-family: $family !important;")
            appendLine("  line-height: 1.35 !important;")
            appendLine("  margin: 1.2em 0 0.5em !important;")
            appendLine("}")
            appendLine("a, a:link, a:visited {")
            appendLine("  color: var(--aodl-accent) !important;")
            appendLine("  text-decoration: none;")
            appendLine("}")
            appendLine("blockquote, .userstuff blockquote, .notes, .summary {")
            appendLine("  background: var(--aodl-surface) !important;")
            appendLine("  border-left: 3px solid var(--aodl-accent) !important;")
            appendLine("  color: var(--aodl-fg) !important;")
            appendLine("  margin: 1em 0 !important;")
            appendLine("  padding: 0.8em 1em !important;")
            appendLine("  border-radius: 6px;")
            appendLine("}")
            appendLine(".preface, .meta, dl.tags, .work .header, #workskin .preface .title {")
            appendLine("  color: var(--aodl-muted) !important;")
            appendLine("  font-size: ${smallSize}sp !important;")
            appendLine("}")
            appendLine("hr {")
            appendLine("  border: 0;")
            appendLine("  border-top: 1px solid var(--aodl-border) !important;")
            appendLine("  margin: 2em auto;")
            appendLine("  width: 60%;")
            appendLine("}")
            appendLine("img { max-width: 100% !important; height: auto !important; }")
            appendLine("table { border-collapse: collapse; max-width: 100%; }")
            appendLine("td, th { border: 1px solid var(--aodl-border); padding: 0.35em 0.6em; }")
            appendLine("::selection { background: rgba(244, 143, 177, 0.35); }")
            if (settings.customCss.isNotBlank()) {
                appendLine("/* ---- 用户自定义 CSS ---- */")
                appendLine(settings.customCss.trim())
            }
        }
    }

    /** 注入样式，返回美化后的完整 HTML。DOCUMENT 风格转交 [DocBeautifier] 重建版式。 */
    fun beautify(html: String, settings: BeautifySettings, appDark: Boolean): String {
        if (settings.style == BeautifyStyle.DOCUMENT) {
            return DocBeautifier.beautify(html, settings.customCss)
        }
        val css = buildCss(settings, isDark(settings.theme, appDark))
        val styleBlock = "<style id=\"$STYLE_ID\">\n$css\n</style>"
        val hasViewport = Regex("""name\s*=\s*["']viewport""", RegexOption.IGNORE_CASE).containsMatchIn(html)
        val inject = (if (hasViewport) "" else VIEWPORT) + styleBlock

        val headClose = Regex("</head>", RegexOption.IGNORE_CASE).find(html)
        if (headClose != null) {
            val start = headClose.range.first
            return html.substring(0, start) + inject + html.substring(start)
        }

        val htmlOpen = Regex("<html[^>]*>", RegexOption.IGNORE_CASE).find(html)
        if (htmlOpen != null) {
            val insertAt = htmlOpen.range.last + 1
            return html.substring(0, insertAt) + "<head>$inject</head>" + html.substring(insertAt)
        }

        // 片段级 HTML：包一层完整文档
        return buildString {
            append("<!DOCTYPE html><html lang=\"zh\"><head>")
            append("<meta charset=\"utf-8\">")
            append(inject)
            append("</head><body id=\"workskin\"><div class=\"userstuff\">")
            append(html)
            append("</div></body></html>")
        }
    }

    /** 美化结果文件名：`原标题.beautified.html`。 */
    fun targetFileName(originalName: String): String {
        val name = originalName.trim().ifEmpty { "work.html" }
        val base = if (name.contains('.')) name.substringBeforeLast('.') else name
        return "$base.beautified.html"
    }

    /** 设置页预览用的示例文档（无需已下载文件即可看到效果）。 */
    fun sampleDocument(
        settings: BeautifySettings,
        appDark: Boolean,
        title: String,
        author: String,
        notes: String,
        metaLine: String,
        summary: String,
        paragraphs: List<String>
    ): String {
        if (settings.style == BeautifyStyle.DOCUMENT) {
            return DocBeautifier.sampleDocument(
                title = title,
                author = author,
                summary = summary,
                notes = notes,
                paragraph1 = paragraphs.getOrElse(0) { "" },
                paragraph2 = paragraphs.getOrElse(1) { "" }
            )
        }
        val body = buildString {
            appendLine("<h2 class=\"title heading\">$title</h2>")
            appendLine("<div class=\"meta\">$metaLine</div>")
            appendLine("<blockquote class=\"summary\"><p>$summary</p></blockquote>")
            appendLine("<hr>")
            appendLine("<div id=\"chapters\" class=\"chapter\" role=\"article\">")
            paragraphs.forEach { appendLine("<p>$it</p>") }
            appendLine("</div>")
        }
        val fragment = "<div class=\"userstuff\">$body</div>"
        return "<!DOCTYPE html><html lang=\"zh\"><head><meta charset=\"utf-8\">$VIEWPORT</head>" +
            "<body id=\"workskin\">$fragment</body></html>"
            .let { beautify(it, settings, appDark) }
    }
}
