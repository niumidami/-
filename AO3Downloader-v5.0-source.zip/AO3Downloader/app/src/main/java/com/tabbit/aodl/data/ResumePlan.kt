package com.tabbit.aodl.data

/**
 * 断点续传决策（需求 6）。
 *
 * 从 ViewModel 中拆出来的**纯函数**：给定服务端响应特征与本地 `.part` 大小，
 * 决定「从第几个字节继续写」和「完整文件有多大」，不触碰任何 Android API，
 * 因此可以在 JVM 单元测试里穷举组合直接断言（见 `app/src/test`）。
 *
 * 只有服务端**确实以 206 返回、且确认的起点与我们请求的一致**时才算续传成功；
 * 其余情况一律按全新下载处理（`resumeFrom = 0`），由调用方截断重写 `.part`，
 * 绝不会出现「本地前半段 + 服务端后半段」的错位拼接。
 *
 * @param partial 服务端是否以 `206 Partial Content` 响应
 * @param confirmedStart 206 时 `Content-Range` 中服务端确认的起始字节
 * @param probeBytes 本地 `.part` 文件的实际大小（0 表示没有断点）
 * @param contentLength 响应体长度（`Content-Length`），未知为 -1
 * @param fullLength `Content-Range` 中的完整文件长度，未知为 -1
 */
internal object ResumePlan {

    /** [resumeFrom] 为 0 表示从头写；[total] 为 0 表示总长未知（界面显示不确定进度）。 */
    data class Decision(val resumeFrom: Long, val total: Long)

    fun decide(
        partial: Boolean,
        confirmedStart: Long,
        probeBytes: Long,
        contentLength: Long,
        fullLength: Long
    ): Decision {
        val resumeFrom =
            if (partial && probeBytes > 0L && confirmedStart == probeBytes) probeBytes else 0L
        val total = when {
            // 续传：完整长度以 Content-Range 为准，缺失时用「已有字节 + 本次响应体长度」
            resumeFrom > 0L && fullLength > 0L -> fullLength
            resumeFrom > 0L && contentLength > 0L -> resumeFrom + contentLength
            // 全新下载：即将写入的就是整个响应体，其长度才是真实总长
            contentLength > 0L -> contentLength
            fullLength > 0L -> fullLength
            else -> 0L
        }
        return Decision(resumeFrom, total)
    }
}
