package com.tabbit.aodl.data

import android.content.Context
import java.io.File

/**
 * 阅读页正文本地缓存（v5.3，配合 [ReaderPlan] 使用）。
 *
 * 每部作品一个文本文件，落在应用私有目录 `filesDir/reader_cache/`（其他应用不可读），
 * 内容经 [RecordCodec] 转义后以 UTF-8 落盘。新鲜度直接看文件的 lastModified，
 * 不占用正文空间另记时间戳；所有读写异常都吞掉返回 null / 静默失败，
 * 缓存永远只是加速与离线兜底，绝不影响正常联网链路。
 */
class ReaderCacheStore(context: Context) {

    private val dir: File = File(context.filesDir, DIR_NAME)

    /** 命中返回（内容, 写入时间）；文件缺失或内容解码失败返回 null。 */
    fun load(workId: String): Pair<ReaderPlan.CachedContent, Long>? {
        val file = File(dir, ReaderPlan.cacheFileName(workId))
        if (!file.isFile) return null
        val raw = runCatching { file.readText(Charsets.UTF_8) }.getOrNull() ?: return null
        val content = ReaderPlan.decodeCache(raw) ?: return null
        if (content.workId != workId) return null
        return content to file.lastModified()
    }

    /** 缓存是否在新鲜期内（7 天内直接离线用，不再请求网络）。 */
    fun isFresh(cachedAt: Long, now: Long = System.currentTimeMillis()): Boolean =
        ReaderPlan.isFresh(cachedAt, now)

    /** 写入一册缓存，随后按 LRU 淘汰超上限的旧缓存。 */
    fun save(content: ReaderPlan.CachedContent) {
        runCatching {
            dir.mkdirs()
            File(dir, ReaderPlan.cacheFileName(content.workId))
                .writeText(ReaderPlan.encodeCache(content), Charsets.UTF_8)
            prune()
        }
    }

    /** 超出 [ReaderPlan.MAX_CACHE_WORKS] 后按写入时间从旧到新删除。 */
    private fun prune() {
        val files = dir.listFiles()
            ?.filter { it.isFile }
            ?.map { it.name to it.lastModified() }
            ?: return
        ReaderPlan.pruneFiles(files).forEach { name ->
            runCatching { File(dir, name).delete() }
        }
    }

    private companion object {
        const val DIR_NAME = "reader_cache"
    }
}
