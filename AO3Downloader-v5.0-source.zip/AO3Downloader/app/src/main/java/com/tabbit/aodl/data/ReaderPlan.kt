package com.tabbit.aodl.data

import com.tabbit.aodl.model.Chapter
import java.util.Locale
import kotlin.math.roundToInt

/**
 * 阅读页排版引擎（v5.3，参照 Legado 的阅读页能力）。
 *
 * 本对象只放不依赖 Android 的纯规则，界面与 ViewModel 只负责调用：
 * - 排版参数夹取：字号 / 行距 / 页边距的上下限与取整；
 * - 段落切分：把抓回来的章节纯文本切成渲染用的段落列表；
 * - 目录：章节列表抽成「下标 + 标题」对；
 * - 精细进度：作品 -> (章节, 章内滚动比例) 的编解码与 LRU 更新；
 * - 正文本地缓存：内容编解码（经 [RecordCodec] 转义）、缓存文件名、
 *   新鲜度判定与超上限清理名单。
 */
object ReaderPlan {

    /* ------------------------------------------------ 排版参数边界 */

    const val MIN_FONT_SIZE = 16
    const val MAX_FONT_SIZE = 30
    const val MIN_LINE_HEIGHT = 1.2f
    const val MAX_LINE_HEIGHT = 2.4f
    const val MIN_MARGIN = 8
    const val MAX_MARGIN = 40

    /** 精细进度（作品 -> 章节+滚动比例）的持久化条数上限。 */
    const val MAX_PROGRESS_ENTRIES = 200

    /** 正文本地缓存的作品数上限（超出后按写入时间淘汰最旧）。 */
    const val MAX_CACHE_WORKS = 30

    /** 缓存新鲜期：7 天内不再请求网络，直接离线阅读。 */
    const val CACHE_TTL_MILLIS = 7L * 24 * 60 * 60 * 1000

    fun clampFontSize(sp: Int): Int = sp.coerceIn(MIN_FONT_SIZE, MAX_FONT_SIZE)

    /** 行距夹取后保留一位小数（四舍五入），避免滑杆浮点误差越攒越多。 */
    fun clampLineHeight(mul: Float): Float =
        (mul.coerceIn(MIN_LINE_HEIGHT, MAX_LINE_HEIGHT) * 10).roundToInt() / 10f

    fun clampMargin(dp: Int): Int = dp.coerceIn(MIN_MARGIN, MAX_MARGIN)

    /* ------------------------------------------------ 段落与目录 */

    /**
     * 章节纯文本 -> 段落列表。
     *
     * CRLF 先归一成 LF；优先按空行切（书源常见段间空行）；若整篇只有一段
     * 但含多个单换行（抓取的某些站点文本如此），退化为按单换行切。
     * 每段去首尾空白，空段丢弃。
     */
    fun splitParagraphs(text: String): List<String> {
        val normalized = text.replace("\r\n", "\n").replace('\r', '\n')
        val byBlank = normalized.split(Regex("\n\\s*\n"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        if (byBlank.size > 1) return byBlank
        return normalized.split('\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }

    /** 目录条目：章节下标 + 去空白后的标题（可能为空串，由界面本地化兜底）。 */
    fun outline(chapters: List<Chapter>): List<Pair<Int, String>> =
        chapters.mapIndexed { index, chapter -> index to chapter.title.trim() }

    /* ------------------------------------------------ 精细进度编解码 */

    /**
     * 单行进度行列表 -> 落盘串；一行 = 作品号 + FIELD + 章节 + FIELD + 滚动比例。
     * 列表顺序即 LRU 顺序（末尾为最近），由 [upsertProgress] 维护。
     */
    fun encodeProgressRows(rows: List<Triple<String, Int, Float>>): String =
        rows.joinToString(RecordCodec.ROW.toString()) { (workId, chapter, frac) ->
            RecordCodec.encodeRow(listOf(workId, chapter.toString(), formatFrac(frac)))
        }

    /** 解码进度行；坏行跳过，比例夹到 0..1。 */
    fun decodeProgressRows(raw: String?): List<Triple<String, Int, Float>> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(RecordCodec.ROW).mapNotNull { row ->
            val fields = RecordCodec.decodeRow(row) ?: return@mapNotNull null
            if (fields.size < 3) return@mapNotNull null
            val workId = fields[0]
            if (workId.isBlank()) return@mapNotNull null
            val chapter = fields[1].toIntOrNull()?.takeIf { it >= 0 } ?: return@mapNotNull null
            val frac = fields[2].toFloatOrNull() ?: return@mapNotNull null
            Triple(workId, chapter, frac.coerceIn(0f, 1f))
        }
    }

    /** LRU 更新：同作品移除旧条目后追加到末尾；超上限从最旧开始丢。 */
    fun upsertProgress(
        rows: List<Triple<String, Int, Float>>,
        workId: String,
        chapter: Int,
        offsetFrac: Float,
        max: Int = MAX_PROGRESS_ENTRIES
    ): List<Triple<String, Int, Float>> {
        if (workId.isBlank()) return rows
        val next = rows.filter { it.first != workId } +
            Triple(workId, chapter.coerceAtLeast(0), offsetFrac.coerceIn(0f, 1f))
        return if (next.size <= max) next else next.takeLast(max)
    }

    /** 比例固定四位小数、US  locale，避免逗号小数点串行。 */
    private fun formatFrac(frac: Float): String =
        String.format(Locale.US, "%.4f", frac.coerceIn(0f, 1f))

    /* ------------------------------------------------ 正文本地缓存 */

    /** 缓存文件名：只留字母数字与 `-` `_`，兜底名 "work"。 */
    fun cacheFileName(workId: String): String {
        val safe = workId.trim().filter { it.isLetterOrDigit() || it == '-' || it == '_' }
        return (safe.ifBlank { "work" }) + ".txt"
    }

    /** 缓存是否仍在新鲜期内（[cachedAt] 为文件写入时间）。 */
    fun isFresh(cachedAt: Long, now: Long, ttlMillis: Long = CACHE_TTL_MILLIS): Boolean =
        cachedAt > 0L && now - cachedAt in 0 until ttlMillis

    /**
     * 缓存清理名单：输入（文件名, 写入时间），返回应删除的文件名。
     * 按写入时间从新到旧保留前 [max] 个，其余全删。
     */
    fun pruneFiles(files: List<Pair<String, Long>>, max: Int = MAX_CACHE_WORKS): List<String> =
        files.sortedByDescending { it.second }.drop(max).map { it.first }

    /** 缓存的一整部作品内容（对应 [com.tabbit.aodl.model.WorkContent] 的可持久化子集）。 */
    data class CachedContent(
        val workId: String,
        val title: String,
        val authors: String,
        val summary: String,
        /** AO3 原始章节串，如 `12/15`，用于同步书架展示。 */
        val chaptersLabel: String,
        val chapters: List<Chapter>
    )

    /**
     * 内容 -> 落盘串：首行为元信息，其后每章一行（下标 + 标题 + 正文）。
     * 全部经 [RecordCodec] 转义，正文里的换行与控制字符不会破坏行结构。
     */
    fun encodeCache(content: CachedContent): String {
        val header = RecordCodec.encodeRow(
            listOf(content.workId, content.title, content.authors, content.summary, content.chaptersLabel)
        )
        val rows = content.chapters.map { chapter ->
            RecordCodec.encodeRow(listOf(chapter.index.toString(), chapter.title, chapter.text))
        }
        return (listOf(header) + rows).joinToString(RecordCodec.ROW.toString())
    }

    /** 解码缓存；元信息缺字段、章节为空或整体为空都判无效。 */
    fun decodeCache(raw: String): CachedContent? {
        if (raw.isBlank()) return null
        val rows = raw.split(RecordCodec.ROW)
        val head = RecordCodec.decodeRow(rows.first()) ?: return null
        if (head.size < 5 || head[0].isBlank()) return null
        val chapters = rows.drop(1).mapNotNull { row ->
            val fields = RecordCodec.decodeRow(row) ?: return@mapNotNull null
            if (fields.size < 3) return@mapNotNull null
            val index = fields[0].toIntOrNull() ?: return@mapNotNull null
            Chapter(index = index, title = fields[1], text = fields[2])
        }
        if (chapters.isEmpty()) return null
        return CachedContent(
            workId = head[0],
            title = head[1],
            authors = head[2],
            summary = head[3],
            chaptersLabel = head[4],
            chapters = chapters.sortedBy { it.index }
        )
    }
}
