package com.tabbit.aodl.util

/**
 * 与语言无关的数值格式化（v4.0 新增）。
 *
 * 刻意不依赖 `android.text.format.Formatter` 与 `String.format(locale)`：
 * 下载管理页、运行日志都要显示大小/速度/剩余时间，统一走这里可以避免
 * 「同一个文件在两个页面显示成 1.2 MB 与 1,2 MB」这类不一致。
 * 纯 JVM 实现，可在单元测试中直接断言。
 */
object Format {

    private val UNITS = arrayOf("B", "KB", "MB", "GB", "TB")

    /** 字节数转可读大小；非正数统一显示 `0 B`。 */
    fun bytes(value: Long): String {
        if (value <= 0L) return "0 B"
        var number = value.toDouble()
        var index = 0
        while (number >= 1024 && index < UNITS.size - 1) {
            number /= 1024
            index++
        }
        return if (index == 0) "${number.toInt()} ${UNITS[index]}"
        else "%.2f %s".format(number, UNITS[index])
    }

    /** 速度：`bytes()` 结果追加 `/s`。 */
    fun speed(bytesPerSecond: Long): String = if (bytesPerSecond <= 0L) "--" else "${bytes(bytesPerSecond)}/s"

    /**
     * 毫秒转 `mm:ss` / `h:mm:ss`；负数与 null 返回 `--`。
     *
     * 超过 99 小时按 `99+` 显示，避免长任务把剩余时间撑破一行。
     */
    fun duration(millis: Long?): String {
        if (millis == null || millis < 0L) return "--"
        val totalSeconds = millis / 1000L
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0L) {
            val shown = if (hours > 99L) "99+" else hours.toString()
            "$shown:%02d:%02d".format(minutes, seconds)
        } else {
            "%02d:%02d".format(minutes, seconds)
        }
    }
}
