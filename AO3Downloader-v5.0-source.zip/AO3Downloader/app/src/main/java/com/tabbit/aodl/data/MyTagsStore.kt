package com.tabbit.aodl.data

/**
 * 「我的标签」本地收藏名单（v5.1）。
 *
 * 与 AO3 账号里的书签 tag **完全无关**：不读账号收藏标签，只在 App 内自己维护一份
 * tag 名单，供首页快捷入口「我的标签」弹窗单选后进入该 tag 的作品列表。
 *
 * 纯函数：新增去重（忽略大小写）、删除忽略大小写、上限 [MAX] 条，可直接跑 JVM 单测。
 */
object MyTagsStore {

    /** 本地标签名单上限。 */
    const val MAX = 100

    fun decode(raw: String?): List<String> =
        if (raw.isNullOrBlank()) {
            emptyList()
        } else {
            raw.split(RecordCodec.ROW).mapNotNull { row ->
                row.takeIf { it.isNotBlank() }?.let { RecordCodec.unescape(it).trim() }
            }.filter { it.isNotBlank() }
                // 去重口径与 add/contains 一致：忽略大小写，保留先出现的那一条
                .distinctBy { it.lowercase() }
                .take(MAX)
        }

    fun encode(tags: List<String>): String =
        tags.map { it.trim() }
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase() }
            .take(MAX)
            .joinToString(RecordCodec.ROW.toString()) { RecordCodec.escape(it) }

    /** 新增标签：空串忽略，已存在（忽略大小写）时原样返回，避免重复条目。 */
    fun add(tags: List<String>, tag: String): List<String> {
        val value = tag.trim()
        if (value.isEmpty()) return tags
        if (tags.any { it.equals(value, ignoreCase = true) }) return tags
        return (tags + value).take(MAX)
    }

    /** 删除标签：忽略大小写与首尾空白。 */
    fun remove(tags: List<String>, tag: String): List<String> {
        val value = tag.trim()
        return tags.filterNot { it.equals(value, ignoreCase = true) }
    }

    fun contains(tags: List<String>, tag: String): Boolean =
        tags.any { it.equals(tag.trim(), ignoreCase = true) }
}