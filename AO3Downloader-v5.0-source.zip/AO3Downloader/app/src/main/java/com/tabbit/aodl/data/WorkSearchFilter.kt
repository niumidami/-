package com.tabbit.aodl.data

/**
 * 站点筛选面板里的一个候选项：提交值 + 展示名。
 *
 * 分级 / 内容预警 / 配对用的是 AO3 canonical tag 的 **id**（站点表单提交的就是 id），
 * 语言用 `Language#short`，排序用 `WorkSearchForm::SORT_OPTIONS` 的列名。
 */
data class FilterOption(val value: String, val label: String)

/**
 * 从站点 `/works/search` 表单解析出来的真实候选项（含线上 id）。
 *
 * 打开筛选面板时若联网会先向站点拉一次表单解析成这个结构去覆盖内置默认值，
 * 因此即使内置常量与线上有出入，也以站点为准。
 */
data class SearchFormOptions(
    val ratings: List<FilterOption> = emptyList(),
    val warnings: List<FilterOption> = emptyList(),
    val categories: List<FilterOption> = emptyList(),
    val languages: List<FilterOption> = emptyList(),
    val sorts: List<FilterOption> = emptyList()
) {
    fun isEmpty(): Boolean =
        ratings.isEmpty() && warnings.isEmpty() && categories.isEmpty() &&
            languages.isEmpty() && sorts.isEmpty()
}

/**
 * AO3 站点作品搜索的筛选条件（v5.1 新增）。
 *
 * 字段对齐 otwarchive `app/models/search/work_search_form.rb` 的 `ATTRIBUTES`，
 * 拼出的查询串形如 `work_search[title]=…&work_search[rating_ids]=12`，与
 * `app/views/works/_search_form.html.erb`（`form_for @search, as: :work_search`，
 * GET 提交到 `search_works_path`）实际发出的参数完全一致。
 *
 * 纯数据 + 纯函数，不依赖 Android，可离线单测。
 */
data class WorkSearchFilter(
    /** 标题。 */
    val title: String = "",
    /** 作者（站点字段名是 `creators`）。 */
    val creators: String = "",
    /** 更新日期，接受区间表达式，如 `> 2 weeks ago`、`> 2024-01-01`、`2024-01-01 - 2024-06-30`。 */
    val revisedAt: String = "",
    /** 起始日期（`date_from`，格式 yyyy-MM-dd）。 */
    val dateFrom: String = "",
    /** 结束日期（`date_to`，格式 yyyy-MM-dd）。 */
    val dateTo: String = "",
    /** 完结状态：null 不限 / true 只要完结（T） / false 只要连载（F）。 */
    val complete: Boolean? = null,
    /** 交叉作品：null 不限 / false 排除交叉（F） / true 只看交叉（T）。 */
    val crossover: Boolean? = null,
    /** 仅单章作品（提交 `single_chapter=1`）。 */
    val singleChapter: Boolean = false,
    /** 字数，区间表达式如 `>1000`、`1000-5000`。 */
    val wordCount: String = "",
    /** 作品语言，收 `Language#short`（`en` / `zh` / `ja` …）。 */
    val language: String = "",
    /** 原作 / Fandom，按名称过滤（这几项站点就是名称字段，不是 id）。 */
    val fandomNames: String = "",
    /** 分级：站点 `rating_ids` 是下拉单选。 */
    val ratingId: String = "",
    /** 内容预警：站点 `archive_warning_ids[]` 复选。 */
    val warningIds: Set<String> = emptySet(),
    /** 配对 / 类别：站点 `category_ids[]` 复选。 */
    val categoryIds: Set<String> = emptySet(),
    val characterNames: String = "",
    val relationshipNames: String = "",
    /** 附加标签（站点字段名 `freeform_names`）。 */
    val freeformNames: String = "",
    val hits: String = "",
    val kudos: String = "",
    val comments: String = "",
    val bookmarks: String = "",
    /** 排序字段，取 `WorkSearchForm::SORT_OPTIONS` 的列名。 */
    val sortColumn: String = "",
    /** 排序方向：`asc` / `desc`。 */
    val sortDirection: String = ""
) {

    fun isEmpty(): Boolean = this == WorkSearchFilter()

    /**
     * 生效的筛选条件数（用于在「筛选」入口上显示角标）。
     *
     * 排序不算筛选条件，只影响结果顺序，因此不计入。
     */
    fun activeCount(): Int {
        var n = 0
        if (title.isNotBlank()) n++
        if (creators.isNotBlank()) n++
        if (revisedAt.isNotBlank()) n++
        if (dateFrom.isNotBlank() || dateTo.isNotBlank()) n++
        if (complete != null) n++
        if (crossover != null) n++
        if (singleChapter) n++
        if (wordCount.isNotBlank()) n++
        if (language.isNotBlank()) n++
        if (fandomNames.isNotBlank()) n++
        if (ratingId.isNotBlank()) n++
        if (warningIds.isNotEmpty()) n++
        if (categoryIds.isNotEmpty()) n++
        if (characterNames.isNotBlank()) n++
        if (relationshipNames.isNotBlank()) n++
        if (freeformNames.isNotBlank()) n++
        if (hits.isNotBlank()) n++
        if (kudos.isNotBlank()) n++
        if (comments.isNotBlank()) n++
        if (bookmarks.isNotBlank()) n++
        return n
    }

    /**
     * 拼成站点搜索参数序列（`work_search[...]` 前缀）。
     *
     * 关键词 `query` 与页码 `page` 不在这里产出：关键词由搜索框按当前动作传入、
     * 页码由翻页动作单独附上，两者都不属于「筛选面板」的状态。
     * 空值一律不产出参数——站点 `WorkSearchForm#process_options` 也会把空值删掉，
     * 少发参数与发空参数结果一致，但前者 URL 更短。
     */
    fun toQueryPairs(): List<Pair<String, String>> {
        val pairs = mutableListOf<Pair<String, String>>()

        fun put(field: String, value: String) {
            val text = value.trim()
            if (text.isNotEmpty()) pairs += "work_search[$field]" to text
        }

        put("title", title)
        put("creators", creators)
        put("revised_at", revisedAt)
        put("date_from", dateFrom)
        put("date_to", dateTo)
        complete?.let { pairs += "work_search[complete]" to if (it) "T" else "F" }
        crossover?.let { pairs += "work_search[crossover]" to if (it) "T" else "F" }
        if (singleChapter) pairs += "work_search[single_chapter]" to "1"
        put("word_count", wordCount)
        put("language_id", language)
        put("fandom_names", fandomNames)
        put("rating_ids", ratingId)
        warningIds.sorted().forEach { pairs += "work_search[archive_warning_ids][]" to it }
        categoryIds.sorted().forEach { pairs += "work_search[category_ids][]" to it }
        put("character_names", characterNames)
        put("relationship_names", relationshipNames)
        put("freeform_names", freeformNames)
        put("hits", hits)
        put("kudos_count", kudos)
        put("comments_count", comments)
        put("bookmarks_count", bookmarks)
        put("sort_column", sortColumn)
        put("sort_direction", sortDirection)

        return pairs
    }
}

/**
 * 内置的候选项默认值。
 *
 * 分级 / 内容预警 / 配对取 AO3 线上 canonical tag 的 id（站点表单提交 id，不是名称），
 * 语言取 `Language#short`，排序取 `WorkSearchForm::SORT_OPTIONS`。
 * 这些都只是**离线兜底**：打开筛选面板时会先拉一次站点真实表单覆盖它们，
 * 若网络不可用或解析不到才回落到这里的取值。
 */
object WorkSearchOptions {

    val RATINGS = listOf(
        FilterOption("9", "Not Rated"),
        FilterOption("10", "General Audiences"),
        FilterOption("11", "Teen And Up Audiences"),
        FilterOption("12", "Mature"),
        FilterOption("13", "Explicit")
    )

    val WARNINGS = listOf(
        FilterOption("14", "Creator Chose Not To Use Archive Warnings"),
        FilterOption("16", "No Archive Warnings Apply"),
        FilterOption("17", "Graphic Depictions Of Violence"),
        FilterOption("18", "Major Character Death"),
        FilterOption("19", "Rape/Non-Con"),
        FilterOption("20", "Underage")
    )

    val CATEGORIES = listOf(
        FilterOption("21", "Gen"),
        FilterOption("22", "F/M"),
        FilterOption("23", "M/M"),
        FilterOption("24", "Other"),
        FilterOption("116", "F/F"),
        FilterOption("2246", "Multi")
    )

    /** 常见语言兜底表（站点完整语言表以在线拉取为准）。 */
    val LANGUAGES = listOf(
        FilterOption("en", "English"),
        FilterOption("zh", "中文"),
        FilterOption("ja", "日本語"),
        FilterOption("ko", "한국어"),
        FilterOption("es", "Español"),
        FilterOption("fr", "Français"),
        FilterOption("de", "Deutsch"),
        FilterOption("ru", "Русский"),
        FilterOption("pt", "Português"),
        FilterOption("it", "Italiano"),
        FilterOption("nl", "Nederlands"),
        FilterOption("pl", "Polski"),
        FilterOption("tr", "Türkçe"),
        FilterOption("vi", "Tiếng Việt"),
        FilterOption("th", "ไทย"),
        FilterOption("id", "Bahasa Indonesia"),
        FilterOption("fil", "Filipino"),
        FilterOption("ar", "العربية"),
        FilterOption("he", "עברית"),
        FilterOption("hi", "हिन्दी"),
        FilterOption("uk", "Українська"),
        FilterOption("cs", "Čeština"),
        FilterOption("sv", "Svenska"),
        FilterOption("no", "Norsk"),
        FilterOption("da", "Dansk"),
        FilterOption("fi", "Suomi"),
        FilterOption("el", "Ελληνικά"),
        FilterOption("hu", "Magyar"),
        FilterOption("ro", "Română"),
        FilterOption("bg", "Български"),
        FilterOption("sr", "Српски"),
        FilterOption("hr", "Hrvatski"),
        FilterOption("sk", "Slovenčina"),
        FilterOption("sl", "Slovenščina"),
        FilterOption("lt", "Lietuvių"),
        FilterOption("lv", "Latviešu"),
        FilterOption("et", "Eesti"),
        FilterOption("fa", "فارسی"),
        FilterOption("ms", "Bahasa Melayu"),
        FilterOption("bn", "বাংলা"),
        FilterOption("ca", "Català"),
        FilterOption("gl", "Galego"),
        FilterOption("is", "Íslenska"),
        FilterOption("sq", "Shqip"),
        FilterOption("hy", "Հայերեն"),
        FilterOption("ka", "ქართული"),
        FilterOption("az", "Azərbaycan"),
        FilterOption("kk", "Қазақша"),
        FilterOption("mn", "Монгол"),
        FilterOption("uz", "Oʻzbekcha"),
        FilterOption("ta", "தமிழ்"),
        FilterOption("te", "తెలుగు"),
        FilterOption("ml", "മലയാളം"),
        FilterOption("ur", "اردو")
    )

    val SORTS = listOf(
        FilterOption("_score", "Best Match"),
        FilterOption("authors_to_sort_on", "Creator"),
        FilterOption("title_to_sort_on", "Title"),
        FilterOption("created_at", "Date Posted"),
        FilterOption("revised_at", "Date Updated"),
        FilterOption("word_count", "Word Count"),
        FilterOption("hits", "Hits"),
        FilterOption("kudos_count", "Kudos"),
        FilterOption("comments_count", "Comments"),
        FilterOption("bookmarks_count", "Bookmarks")
    )

    /** 用在线拉到的候选项覆盖内置默认值；在线项为空时保留内置项。 */
    fun merge(online: SearchFormOptions): SearchFormOptions = SearchFormOptions(
        ratings = online.ratings.ifEmpty { RATINGS },
        warnings = online.warnings.ifEmpty { WARNINGS },
        categories = online.categories.ifEmpty { CATEGORIES },
        languages = online.languages.ifEmpty { LANGUAGES },
        sorts = online.sorts.ifEmpty { SORTS }
    )
}

/** 本地默认候选项（离线时用）。 */
object WorkSearchDefaults {
    val options = SearchFormOptions(
        ratings = WorkSearchOptions.RATINGS,
        warnings = WorkSearchOptions.WARNINGS,
        categories = WorkSearchOptions.CATEGORIES,
        languages = WorkSearchOptions.LANGUAGES,
        sorts = WorkSearchOptions.SORTS
    )
}

/**
 * 搜索结果的翻页口径（纯函数，可离线单测）。
 *
 * AO3 的搜索结果页由 `will_paginate` 渲染，每页 20 条；命中条数写在
 * `h3.heading`（如 `1,234 Found`）。这里把这些规则收敛成几个纯函数。
 */
object WorkSearchPaging {

    /** 站点每页条数（`will_paginate` 默认 20）。 */
    const val PER_PAGE = 20

    /** AO3 搜索结果的分页上限（站点最多翻到 500 页）。 */
    const val MAX_PAGES = 500

    private val NUMBER = Regex("""[\d][\d,]*""")

    /**
     * 从站点标题里取出命中条数的数字。
     *
     * 标题形如 `1,234 Found`、`Found 1,234 works`、`没有找到` —— 取第一段
     * 「数字（允许千分位逗号）」解析成 Int，取不到返回 0。
     */
    fun parseFoundCount(label: String): Int {
        val hit = NUMBER.find(label)?.value ?: return 0
        return hit.replace(",", "").toIntOrNull() ?: 0
    }

    /** 总页数：命中 0 条算 0 页，其余向上取整，并封顶到站点上限。 */
    fun pageCount(total: Int): Int {
        if (total <= 0) return 0
        return ((total + PER_PAGE - 1) / PER_PAGE).coerceAtMost(MAX_PAGES)
    }

    /**
     * 分页条要显示的页码窗口：首页、末页、当前页 ±[around]，
     * 中间被跳过的段落用 `null` 占位（渲染成省略号）。
     */
    fun pageWindow(current: Int, pages: Int, around: Int = 2): List<Int?> {
        if (pages <= 0) return emptyList()
        val keep = mutableSetOf(1, pages, current)
        for (d in 1..around) {
            if (current - d >= 1) keep += current - d
            if (current + d <= pages) keep += current + d
        }
        val sorted = keep.filter { it in 1..pages }.sorted()
        val out = mutableListOf<Int?>()
        var previous = 0
        for (page in sorted) {
            if (previous != 0 && page - previous > 1) out += null
            out += page
            previous = page
        }
        return out
    }
}