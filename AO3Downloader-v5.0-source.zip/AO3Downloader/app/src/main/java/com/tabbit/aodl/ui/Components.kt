package com.tabbit.aodl.ui

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.tabbit.aodl.R
import com.tabbit.aodl.data.BookmarkCopy
import com.tabbit.aodl.data.CopyTarget
import com.tabbit.aodl.model.IconUiState
import com.tabbit.aodl.model.LogEntry
import com.tabbit.aodl.model.LogLevel
import com.tabbit.aodl.model.WorkItem
import com.tabbit.aodl.model.WorkKind
import com.tabbit.aodl.ui.theme.ext

/* ------------------------------------------------------------- 容器与标题 */

@Composable
fun SakuraCard(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val ext = MaterialTheme.ext
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ext.card),
        border = BorderStroke(1.dp, ext.cardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(contentPadding), content = content)
    }
}

@Composable
fun SectionTitle(text: String, subtitle: String? = null) {
    Column(modifier = Modifier.padding(top = 18.dp, bottom = 8.dp)) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
        )
        if (!subtitle.isNullOrBlank()) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.ext.textSecondary
            )
        }
    }
}

/**
 * 可折叠的设置分组卡片：点击头部（标题行任意位置或右侧箭头）展开/收起正文。
 *
 * 收起时只保留标题、副标题与一行当前状态摘要，正文完全退出组合，
 * 设置页首屏因此只剩一列紧凑的分组列表；展开后先画一条分隔线再接正文。
 * 展开状态用 `rememberSaveable` 按 [stateKey] 存档，旋转/重建后保持用户的选择。
 * 分组内的 `rememberSaveable` 输入框内容（如自定义 CSS）在折叠再展开后不会丢失。
 */
@Composable
fun GroupCard(
    title: String,
    stateKey: String,
    subtitle: String? = null,
    summary: String? = null,
    initiallyExpanded: Boolean = false,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by rememberSaveable(stateKey) { mutableStateOf(initiallyExpanded) }
    val ext = MaterialTheme.ext
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ext.card),
        border = BorderStroke(1.dp, ext.cardBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (!subtitle.isNullOrBlank()) {
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = ext.textSecondary
                        )
                    }
                    if (!expanded && !summary.isNullOrBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = summary,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                        )
                    }
                }
                Icon(
                    imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }
            if (expanded) {
                Spacer(Modifier.height(10.dp))
                HorizontalDivider(color = ext.cardBorder, thickness = 0.5.dp)
                content()
            }
        }
    }
}

/* ------------------------------------------------------- 应用图标位（需求 4） */

/**
 * 应用内统一的图标位。
 *
 * 选中「自定义图片」时渲染用户上传并居中裁剪后的位图，否则渲染当前那套内置图标；
 * 两者都按 `Crop` 铺满同一个圆角方块，所以顶栏、Tab、管理页、关于页在切换前后
 * 尺寸与形状完全一致，不会跳动。位图已在 `IconManager` 里按 256px 缓存，
 * 小尺寸绘制不会触发重复解码。
 */
@Composable
fun AppLogo(
    icon: IconUiState,
    size: Dp,
    modifier: Modifier = Modifier,
    contentDescription: String? = null,
    cornerRatio: Float = 0.24f
) {
    val bitmap = icon.customBitmap
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * cornerRatio))
            .background(MaterialTheme.ext.card)
    ) {
        if (icon.useCustom && bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            val logo = rememberResourceBitmap(resId = icon.activeIcon.logoRes, size = size)
            if (logo != null) {
                Image(
                    bitmap = logo,
                    contentDescription = contentDescription,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // 解码失败兜底：绝不向上抛异常，退成占位图标（v4.3 启动闪退的硬护栏）。
                Icon(
                    Icons.Filled.Image,
                    contentDescription = contentDescription,
                    tint = MaterialTheme.ext.textSecondary,
                    modifier = Modifier.align(Alignment.Center).size(size * 0.6f)
                )
            }
        }
    }
}

/**
 * 把任意 drawable 资源（位图 / 矢量 / 自适应图标）栅格化为 [ImageBitmap]。
 *
 * 这里刻意不用 `painterResource`：它只支持 VectorDrawable 与位图资源，遇到
 * `drawable-anydpi-v26` 下的 `<adaptive-icon>` XML 会在渲染首帧抛
 * IllegalArgumentException——这正是 v4.3「打开即闪退」的根因（应用图标被换成
 * 自适应图标后，顶栏与底部导航的 AppLogo 一渲染就崩，API ≥ 26 必现）。
 * 改用 ContextCompat 解码 + Canvas 栅格化后，任何 drawable 类型都能安全绘制；
 * 解码或绘制失败一律返回 null，由调用方退回占位图标，保证永不崩溃。
 */
@Composable
private fun rememberResourceBitmap(@DrawableRes resId: Int, size: Dp): ImageBitmap? {
    val context = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx().coerceAtLeast(1) }
    return remember(resId, px) {
        runCatching {
            val drawable = ContextCompat.getDrawable(context, resId) ?: return@runCatching null
            val bitmap = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val canvas = AndroidCanvas(bitmap)
            drawable.setBounds(0, 0, px, px)
            drawable.draw(canvas)
            bitmap.asImageBitmap()
        }.getOrNull()
    }
}

/** 顶栏标题：图标位 + 标题文字，整体仍由 `CenterAlignedTopAppBar` 居中。 */
@Composable
fun ScreenTitle(icon: IconUiState, text: String, logoSize: Dp = 26.dp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        AppLogo(icon = icon, size = logoSize, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/* ----------------------------------------------------------------- 按钮 */

/** 樱花粉渐变主按钮。 */
@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    loading: Boolean = false
) {
    val ext = MaterialTheme.ext
    Button(
        onClick = onClick,
        enabled = enabled && !loading,
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            contentColor = Color.White,
            disabledContainerColor = Color.Transparent,
            disabledContentColor = ext.textSecondary
        ),
        contentPadding = PaddingValues(0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(14.dp))
                .background(if (enabled) ext.buttonBrush else SolidColor(ext.cardBorder)),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (loading) {
                    CatLoading(size = 26.dp)
                    Spacer(Modifier.width(10.dp))
                } else if (icon != null) {
                    Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                }
                Text(text = text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(44.dp),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, fontSize = 13.sp)
    }
}

@Composable
fun DangerTextButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.error,
        style = MaterialTheme.typography.labelLarge,
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    )
}

/* ------------------------------------------------------------ 设置项行 */

@Composable
fun SwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    subtitle: String? = null,
    enabled: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.ext.textSecondary
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.ext.textSecondary
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                checkedBorderColor = MaterialTheme.colorScheme.primary,
                uncheckedThumbColor = MaterialTheme.ext.textSecondary,
                uncheckedTrackColor = MaterialTheme.ext.cardBorder,
                uncheckedBorderColor = MaterialTheme.ext.cardBorder
            )
        )
    }
}

@Composable
fun ClickableRow(
    title: String,
    onClick: () -> Unit,
    subtitle: String? = null,
    trailing: String? = null,
    icon: ImageVector? = null,
    enabled: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(10.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.ext.textSecondary
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.ext.textSecondary
                )
            }
        }
        if (!trailing.isNullOrBlank()) {
            Text(
                text = trailing,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1
            )
        }
    }
}

@Composable
fun ValueRow(title: String, value: String, valueColor: Color? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.ext.textSecondary,
            modifier = Modifier.width(110.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = valueColor ?: MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
    }
}

/** 单选分段控件（DoH 方式、阅读主题、界面主题、语言等）。 */
@Composable
fun <T> SegmentedRow(
    options: List<Pair<String, T>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { (label, value) ->
            val active = value == selected
            val shape = RoundedCornerShape(10.dp)
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(shape)
                    .clickable { onSelect(value) },
                shape = shape,
                color = if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f) else MaterialTheme.ext.logBackground,
                border = BorderStroke(
                    1.dp,
                    if (active) MaterialTheme.colorScheme.primary else MaterialTheme.ext.cardBorder
                )
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 9.dp)) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.ext.textSecondary,
                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    valueText: String,
    onValueChange: (Float) -> Unit,
    steps: Int = 0
) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Text(
                valueText,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )
        }
        Slider(
            value = value.coerceIn(valueRange.start, valueRange.endInclusive),
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.ext.cardBorder
            )
        )
    }
}

/* ------------------------------------------------------------- 输入框 */

@Composable
fun SakuraTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    singleLine: Boolean = true,
    password: Boolean = false,
    numberOnly: Boolean = false,
    isError: Boolean = false,
    supportingText: String? = null,
    imeAction: ImeAction = ImeAction.Done,
    trailing: @Composable (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label, fontSize = 13.sp) },
        placeholder = { Text(placeholder, fontSize = 13.sp, color = MaterialTheme.ext.textSecondary) },
        singleLine = singleLine,
        isError = isError,
        textStyle = MaterialTheme.typography.bodyMedium,
        supportingText = supportingText?.let { { Text(it, fontSize = 11.sp) } },
        keyboardOptions = KeyboardOptions(
            imeAction = imeAction,
            keyboardType = if (numberOnly) KeyboardType.Number else KeyboardType.Text
        ),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        trailingIcon = trailing,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = MaterialTheme.colorScheme.onSurface,
            unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.ext.cardBorder,
            cursorColor = MaterialTheme.colorScheme.primary,
            focusedLabelColor = MaterialTheme.colorScheme.primary,
            unfocusedLabelColor = MaterialTheme.ext.textSecondary,
            focusedContainerColor = MaterialTheme.ext.logBackground,
            unfocusedContainerColor = MaterialTheme.ext.logBackground
        )
    )
}

/* --------------------------------------------------------- 状态与进度 */

@Composable
fun StatusChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.16f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 11.sp, color = color, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun DownloadProgress(
    currentTask: String,
    fileProgress: Float,
    finished: Int,
    total: Int,
    succeeded: Int,
    failed: Int
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = currentTask,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
                maxLines = 1
            )
            Text(
                text = "$finished / $total",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { fileProgress.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.ext.cardBorder
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatusChip(text = "OK $succeeded", color = MaterialTheme.ext.success)
            if (failed > 0) StatusChip(text = "FAIL $failed", color = MaterialTheme.colorScheme.error)
        }
    }
}

/* ------------------------------------------------------------ 日志控制台 */

@Composable
fun LogConsole(
    logs: List<LogEntry>,
    modifier: Modifier = Modifier,
    onClear: () -> Unit,
    title: String
) {
    val ext = MaterialTheme.ext
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ext.logBackground)
            .border(1.dp, ext.cardBorder, RoundedCornerShape(14.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 4.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = ext.textSecondary,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "${logs.size}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            IconButton(onClick = onClear, modifier = Modifier.size(30.dp)) {
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = null,
                    tint = ext.textSecondary,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
        if (logs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "— —",
                    color = ext.textSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp, max = 260.dp)
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                reverseLayout = true,
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(logs.asReversed(), key = { it.seq }) { entry ->
                    Row(verticalAlignment = Alignment.Top) {
                        Text(
                            text = entry.time,
                            color = ext.textSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            modifier = Modifier.width(58.dp)
                        )
                        Text(
                            text = entry.message,
                            color = logColor(entry.level),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun logColor(level: LogLevel): Color = when (level) {
    LogLevel.INFO -> MaterialTheme.colorScheme.onSurface
    LogLevel.SUCCESS -> MaterialTheme.ext.success
    LogLevel.WARN -> MaterialTheme.ext.warning
    LogLevel.ERROR -> MaterialTheme.colorScheme.error
}

/* -------------------------------------------------------------- 空状态 */

@Composable
fun EmptyHint(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.ext.textSecondary
        )
    }
}

/* ------------------------------------------------------- 作品条目附加信息 */

/** 非普通作品条目（系列 / 外部链接 / 已删除）的类型标签。 */
@Composable
internal fun kindLabel(kind: WorkKind): String = when (kind) {
    WorkKind.SERIES -> stringResource(R.string.author_kind_series)
    WorkKind.EXTERNAL -> stringResource(R.string.author_kind_external)
    WorkKind.DELETED -> stringResource(R.string.author_kind_deleted)
    WorkKind.WORK -> ""
}

/**
 * 收藏列表条目（我的账号页使用）。
 *
 * v4.6 起支持复制：作者名、作品编号可分别复制，也可一次性复制成 `作者名 #编号`。
 * 复制内容全部取自条目已有字段（[BookmarkCopy] 负责取值与拼装），不额外发请求；
 * 真正写剪贴板由调用方通过 [onCopy] 完成，本组件不直接依赖 ClipboardManager，
 * 方便预览与后续替换实现。
 */
@Composable
fun BookmarkRow(
    item: WorkItem,
    onDownload: () -> Unit,
    onCopy: (CopyTarget) -> Unit
) {
    val ext = MaterialTheme.ext
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title.ifBlank { "#${item.id}" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                val meta = buildList {
                    if (item.authors.isNotBlank()) add(item.authors)
                    if (item.words.isNotBlank()) add(item.words)
                    if (item.updated.isNotBlank()) add(item.updated)
                }
                if (meta.isNotEmpty()) {
                    Text(
                        text = meta.joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = ext.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (item.kind != WorkKind.WORK) {
                    Text(
                        text = kindLabel(item.kind),
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            if (item.downloadable) {
                SecondaryButton(
                    text = stringResource(R.string.account_bookmarks_download),
                    onClick = onDownload,
                    icon = Icons.Filled.Download
                )
            }
        }

        Spacer(Modifier.height(6.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CopyChip(
                label = stringResource(R.string.bookmark_copy_author),
                enabled = BookmarkCopy.enabled(CopyTarget.AUTHOR, item.authors, item.id),
                onClick = { onCopy(CopyTarget.AUTHOR) }
            )
            CopyChip(
                label = stringResource(R.string.bookmark_copy_id),
                enabled = BookmarkCopy.enabled(CopyTarget.ID, item.authors, item.id),
                onClick = { onCopy(CopyTarget.ID) }
            )
            CopyChip(
                label = stringResource(R.string.bookmark_copy_both),
                enabled = BookmarkCopy.enabled(CopyTarget.BOTH, item.authors, item.id),
                onClick = { onCopy(CopyTarget.BOTH) }
            )
        }

        Spacer(Modifier.height(6.dp))
        HorizontalDivider(color = ext.cardBorder, thickness = 0.5.dp)
    }
}

/**
 * 条目上的小号复制按钮，无内容可复制时置灰而不是隐藏，避免行高跳动。
 *
 * [copied] 为 true 时短暂切换成对勾图标与成功色，给用户一个即时的"已复制"反馈，
 * 由调用方负责在一段时间后把它改回 false。
 */
@Composable
internal fun CopyChip(label: String, enabled: Boolean, copied: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    val contentColor = when {
        copied -> MaterialTheme.ext.success
        enabled -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.ext.textSecondary.copy(alpha = 0.5f)
    }
    Row(
        modifier = Modifier
            .clip(shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
            contentDescription = null,
            tint = contentColor,
            modifier = Modifier.size(12.dp)
        )
        Spacer(Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = contentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

