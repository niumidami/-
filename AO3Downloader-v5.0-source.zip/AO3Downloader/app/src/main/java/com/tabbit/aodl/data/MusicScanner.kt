package com.tabbit.aodl.data

/**
 * 本地音乐扫描规则（v5.1）。
 *
 * 纯对象：只判断「文件名是不是音频」「展示名怎么取」，不碰 Android 与文件系统，
 * 可离线跑 JVM 单测。DocumentFile 的目录遍历放在 ViewModel 侧，命中规则由这里裁决。
 */
object MusicScanner {

    /** 支持的音频扩展名（小写，不含点）。 */
    private val AUDIO_EXTENSIONS = setOf(
        "mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "ape", "wma", "mka"
    )

    /** 按扩展名判断是否为音频文件；目录与无扩展名一律不算。 */
    fun isAudioFile(name: String?): Boolean {
        if (name.isNullOrBlank()) return false
        val dot = name.lastIndexOf('.')
        if (dot <= 0 || dot == name.length - 1) return false
        return name.substring(dot + 1).lowercase() in AUDIO_EXTENSIONS
    }

    /** 文件名去掉扩展名作为展示名；取不到扩展名时原样返回。 */
    fun displayTitle(fileName: String): String {
        val dot = fileName.lastIndexOf('.')
        return if (dot > 0) fileName.substring(0, dot) else fileName
    }

    /** 扫描结果排序：按展示名自然排序（忽略大小写），保持稳定输出。 */
    fun <T> sortByTitle(items: List<T>, titleOf: (T) -> String): List<T> =
        items.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { titleOf(it) })

    /** 文件大小的展示文案（B / KB / MB / GB），列表行用。 */
    fun formatSize(bytes: Long): String = when {
        bytes <= 0L -> ""
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "%.1f KB".format(bytes / 1024.0)
        bytes < 1024L * 1024L * 1024L -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
        else -> "%.2f GB".format(bytes / (1024.0 * 1024.0 * 1024.0))
    }
}
