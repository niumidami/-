package com.tabbit.aodl.net

import com.tabbit.aodl.data.BrowserPlan
import com.tabbit.aodl.data.Prefs
import com.tabbit.aodl.data.SearchFormOptions
import com.tabbit.aodl.data.WorkSearchFilter
import com.tabbit.aodl.model.DownloadFormat
import com.tabbit.aodl.model.WorkContent
import com.tabbit.aodl.model.WorkItem
import com.tabbit.aodl.model.WorkKind
import com.tabbit.aodl.model.WorkMeta
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.io.Closeable
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException

/** 统一错误分类，界面文案由 ViewModel 按本地化资源生成。 */
enum class Ao3Error {
    NETWORK,
    TIMEOUT,
    TLS,
    HTTP,
    NOT_FOUND,
    LOGIN_REQUIRED,
    SESSION_EXPIRED,
    UNEXPECTED_HTML,
    PARSE,
    WRITE,
    NO_FOLDER,
    /** 服务端返回 416：本地 `.part` 的断点起点已失效，应删除后重新下载（v4.0）。 */
    RANGE_INVALID,
    CANCELLED,
    UNKNOWN
}

sealed class Ao3Result<out T> {
    data class Ok<out T>(val value: T) : Ao3Result<T>()
    data class Err(val error: Ao3Error, val detail: String = "") : Ao3Result<Nothing>()
}

data class AuthorPage(
    val works: List<WorkItem>,
    val page: Int,
    val hasMore: Boolean,
    val totalLabel: String
)

enum class LoginFailReason { NETWORK, CREDENTIALS, NO_TOKEN, NO_COOKIE, BLOCKED, UNKNOWN }

sealed class LoginOutcome {
    data class Success(val username: String, val rememberMe: Boolean) : LoginOutcome()
    data class Failed(val reason: LoginFailReason, val detail: String) : LoginOutcome()
}

/**
 * 下载响应载荷，调用方负责 [close]。
 *
 * 断点续传（v4.0）相关字段：
 * - [partial]：服务端以 `206 Partial Content` 确认了 `Range` 请求；
 * - [rangeStart]：206 时服务端确认的起始字节偏移，写入进度按它累加；
 * - [fullLength]：完整文件大小，206 时取 `Content-Range` 的总长，未知为 -1；
 * - [acceptsRanges]：服务端是否声明 `Accept-Ranges: bytes`。
 */
class DownloadPayload(
    private val response: Response,
    val suggestedFileName: String,
    val contentLength: Long,
    val partial: Boolean = false,
    val rangeStart: Long = 0L,
    val fullLength: Long = -1L,
    val acceptsRanges: Boolean = false
) : Closeable {
    val body: ResponseBody get() = response.body!!
    override fun close() = response.close()
}

/** `Content-Range: bytes <start>-<end>/<total>` 的解析结果，无法解析时三项均为 -1。 */
internal data class ContentRange(val start: Long, val end: Long, val total: Long) {
    val valid: Boolean get() = start >= 0 && total > 0
}

/**
 * AO3 站点访问层。
 *
 * - 所有请求默认经过 [DohDns]（仅对 archiveofourown.org 生效），从而绕过本地 DNS 污染；
 * - 登录后由 [Prefs.cookieHeader] 提供 Cookie 头，应用级拦截器保证重定向后依旧携带；
 * - HTML 解析规则对齐 otwarchive 官方模板：
 *   作品列表 `app/views/works/index.html.erb` + `_work_blurb.html.erb` + `_work_module.html.erb`，
 *   登录表单 `app/views/users/sessions/_passwd.html.erb`，
 *   收藏列表 `app/views/bookmarks/_bookmark_blurb.html.erb`。
 */
class Ao3Client(
    private val prefs: Prefs,
    private val dns: DohDns
) {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(dns)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(180, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .addInterceptor { chain ->
                val builder = chain.request().newBuilder()
                    .header("User-Agent", USER_AGENT)
                    .header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
                prefs.cookieHeader()?.let { builder.header("Cookie", it) }
                chain.proceed(builder.build())
            }
            .build()
    }

    /** 登录 POST 需要读取 302 上的 Set-Cookie，因此单独关闭重定向跟随。 */
    private val noRedirectClient: OkHttpClient by lazy {
        client.newBuilder()
            .followRedirects(false)
            .followSslRedirects(false)
            .build()
    }

    val loggedIn: Boolean get() = prefs.cookieHeader() != null

    // ------------------------------------------------------------- 作品编号

    /** 从编号、作品链接或整段分享文本中解析作品编号。 */
    fun parseWorkId(raw: String): String? {
        val text = raw.trim()
        if (text.isEmpty()) return null
        WORK_URL_REGEX.find(text)?.let { m ->
            m.groupValues.firstOrNull { it.isNotBlank() }?.let { return it }
        }
        if (text.length <= 12 && text.all { it.isDigit() }) return text
        PLAIN_DIGITS_REGEX.find(text)?.let { m ->
            m.groupValues.firstOrNull { it.isNotBlank() }?.let { return it }
        }
        return null
    }

    /** 支持一次粘贴多个编号/链接（逗号、空格、分号或换行分隔）。 */
    fun parseWorkIds(raw: String): List<String> {
        val tokens = raw.split(Regex("[,;\\s]+")).filter { it.isNotBlank() }
        val ids = LinkedHashSet<String>()
        tokens.forEach { token -> parseWorkId(token)?.let { ids += it } }
        if (ids.isEmpty()) parseWorkId(raw)?.let { ids += it }
        return ids.toList()
    }

    fun workPageUrl(workId: String): String = "$BASE_URL/works/$workId"

    // ----------------------------------------------------------------- 登录

    /**
     * 账号密码登录：
     * 1. GET /users/login 取 authenticity_token；
     * 2. POST 表单（user_login[login] / user_login[password] / user_login[remember_me] / commit）；
     * 3. 从 302 响应的 Set-Cookie 中收集会话 Cookie 并持久化。
     * 密码仅存在于本次调用的内存中。
     */
    fun login(username: String, password: String, rememberMe: Boolean): LoginOutcome {
        val name = username.trim()
        if (name.isEmpty() || password.isEmpty()) {
            return LoginOutcome.Failed(LoginFailReason.UNKNOWN, "empty credentials")
        }

        val tokenResult = runCatching { fetchAuthenticityToken() }
            .getOrElse { return LoginOutcome.Failed(classifyNetwork(it), it.message.orEmpty()) }
        val token = tokenResult.getOrNull()
            ?: return LoginOutcome.Failed(LoginFailReason.NO_TOKEN, tokenResult.exceptionOrNull()?.message.orEmpty())

        val form = FormBody.Builder()
            .add("utf8", "✓")
            .add("authenticity_token", token)
            .add("user_login[login]", name)
            .add("user_login[password]", password)
            .add("user_login[remember_me]", if (rememberMe) "1" else "0")
            .add("commit", "Log In")
            .build()

        val request = Request.Builder()
            .url("$BASE_URL/users/login")
            .header("User-Agent", USER_AGENT)
            .header("Origin", BASE_URL)
            .header("Referer", "$BASE_URL/users/login")
            .post(form)
            .build()

        return try {
            noRedirectClient.newCall(request).execute().use { response ->
                val cookieHeader = collectCookies(response)
                when {
                    cookieHeader != null -> {
                        prefs.savePasswordSession(name, cookieHeader, rememberMe)
                        LoginOutcome.Success(name, rememberMe)
                    }
                    response.code in 300..399 -> LoginOutcome.Failed(LoginFailReason.NO_COOKIE, "HTTP ${response.code}")
                    else -> {
                        val reason = extractLoginError(response)
                        if (reason != null) {
                            LoginOutcome.Failed(LoginFailReason.CREDENTIALS, reason)
                        } else {
                            LoginOutcome.Failed(LoginFailReason.UNKNOWN, "HTTP ${response.code}")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            LoginOutcome.Failed(classifyNetwork(e), e.message.orEmpty())
        }
    }

    /** 读取登录页并提取 CSRF token。 */
    private fun fetchAuthenticityToken(): Result<String?> {
        val request = Request.Builder()
            .url("$BASE_URL/users/login")
            .header("User-Agent", USER_AGENT)
            .get()
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return Result.success(null)
                val html = response.body?.string().orEmpty()
                val doc = Jsoup.parse(html)
                val token = doc.selectFirst("input[name=authenticity_token]")?.attr("value")
                    ?.takeIf { it.isNotBlank() }
                    ?: metaCsrfToken(doc)
                    ?: AUTH_TOKEN_REGEX.find(html)?.groupValues?.firstOrNull { it.isNotBlank() }
                    ?: META_CSRF_REGEX.find(html)?.groupValues?.firstOrNull { it.isNotBlank() }
                Result.success(token)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Rails 常把 CSRF token 同时放在 meta[name=csrf-token] 中，作为隐藏域缺失时的兜底。 */
    private fun metaCsrfToken(doc: Document): String? =
        doc.selectFirst("meta[name=csrf-token]")?.attr("content")?.takeIf { it.isNotBlank() }

    /** 收集响应中的 Set-Cookie，拼成可直接发送的 Cookie 头。 */
    private fun collectCookies(response: Response): String? {
        val pairs = response.headers("Set-Cookie").mapNotNull { raw ->
            val first = raw.substringBefore(';').trim()
            val name = first.substringBefore('=')
            if (first.contains('=') && name.isNotBlank() && !name.startsWith("#")) first else null
        }.distinctBy { it.substringBefore('=') }
        val hasSession = pairs.any { it.startsWith("$SESSION_COOKIE=") || it.startsWith("$REMEMBER_COOKIE=") }
        return if (hasSession) pairs.joinToString("; ") else null
    }

    private fun extractLoginError(response: Response): String? {
        return try {
            val body = response.body?.string().orEmpty()
            if (body.isEmpty()) return null
            val doc = Jsoup.parse(body)
            val error = doc.selectFirst("#errorExplanation, .flash.error, .error-messages, form .error")
            error?.text()?.takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    /** 校验当前会话是否仍然有效（返回 true=已登录，false=已过期，null=网络不可判）。 */
    fun verifySession(): Boolean? {
        if (!loggedIn) return false
        val request = Request.Builder()
            .url("$BASE_URL/")
            .header("User-Agent", USER_AGENT)
            .get()
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val html = response.body?.string().orEmpty()
                val doc = Jsoup.parse(html)
                val logout = doc.selectFirst("a[href*=/users/logout], a[href*=/users/sign_out]")
                if (logout != null) return true
                val greeting = doc.selectFirst("#greeting, #header .user")?.text().orEmpty()
                val username = prefs.username()
                if (username.isNotEmpty() && greeting.contains(username, ignoreCase = true)) true else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun logout() = prefs.clearAccount()

    /**
     * 用当前 Cookie 取回登录用户名（需求 5：官网 WebView 登录后自动补全账号信息）。
     */
    fun fetchLoggedInUsername(): Ao3Result<String> {
        val request = Request.Builder()
            .url("$BASE_URL/")
            .header("User-Agent", USER_AGENT)
            .get()
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return Ao3Result.Err(Ao3Error.HTTP, "HTTP ${response.code}")
                val html = response.body?.string().orEmpty()
                if (html.isBlank()) return Ao3Result.Err(Ao3Error.PARSE, "empty html")
                val doc = Jsoup.parse(html, "$BASE_URL/")
                val name = parseLoggedInUsername(doc)
                if (name.isNullOrBlank()) {
                    Ao3Result.Err(Ao3Error.PARSE, "username not found")
                } else {
                    Ao3Result.Ok(name)
                }
            }
        } catch (e: Exception) {
            Ao3Result.Err(classifyNetworkError(e), e.message.orEmpty())
        }
    }

    // ----------------------------------------------------------- 作品页预解析

    /**
     * 下载前预解析作品页（需求 1 与需求 2 的前置步骤）。
     *
     * 作用有三个：
     * 1. 取标题与作者，生成「作品名 by 作者名.<后缀>」文件名与作者目录名；
     * 2. 取章节数、字数用于日志与下载记录展示；
     * 3. 提前识别"作品不存在 / 需要登录 / 会话过期"，
     *    避免在用户目录里留下空文件或半截文件。
     */
    fun fetchWorkMeta(workId: String, viewAdult: Boolean): Ao3Result<WorkMeta> {
        val id = workId.trim()
        if (id.isEmpty()) return Ao3Result.Err(Ao3Error.PARSE, "empty work id")
        val url = if (viewAdult) "$BASE_URL/works/$id?view_adult=true" else "$BASE_URL/works/$id"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "text/html,application/xhtml+xml")
            .get()
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                val path = response.request.url.encodedPath
                if (path.contains("/users/login") || path.contains("/users/sign_in")) {
                    return Ao3Result.Err(
                        if (loggedIn) Ao3Error.SESSION_EXPIRED else Ao3Error.LOGIN_REQUIRED,
                        "redirected to login"
                    )
                }
                when (response.code) {
                    404 -> return Ao3Result.Err(Ao3Error.NOT_FOUND, "HTTP 404")
                    401, 403 -> return Ao3Result.Err(Ao3Error.LOGIN_REQUIRED, "HTTP ${response.code}")
                }
                if (!response.isSuccessful) return Ao3Result.Err(Ao3Error.HTTP, "HTTP ${response.code}")
                val html = response.body?.string().orEmpty()
                if (html.isBlank()) return Ao3Result.Err(Ao3Error.PARSE, "empty html")
                val doc = Jsoup.parse(html, response.request.url.toString())
                restrictedGate(doc)?.let { reason ->
                    return Ao3Result.Err(
                        if (loggedIn) Ao3Error.SESSION_EXPIRED else Ao3Error.LOGIN_REQUIRED,
                        reason
                    )
                }
                val meta = parseWorkMeta(doc, id)
                // 既拿不到标题也认不出作品页结构，说明页面已改版或返回了别的内容：提前报错
                if (!meta.nameable && meta.authors.isEmpty() && !looksLikeWorkPage(doc)) {
                    return Ao3Result.Err(Ao3Error.UNEXPECTED_HTML, "work page structure changed")
                }
                Ao3Result.Ok(meta)
            }
        } catch (e: Exception) {
            Ao3Result.Err(classifyNetworkError(e), e.message.orEmpty())
        }
    }

    /**
     * 阅读模式（v5.0 新增 3）：抓取作品页并解析成逐章正文。
     *
     * 与 [fetchWorkMeta] 共用同一套「登录墙 / 404 / 结构变化」判定，
     * 区别只是成功后要拿到排版用的整篇正文与简介。
     */
    fun fetchWorkContent(workId: String, viewAdult: Boolean): Ao3Result<WorkContent> {
        val id = workId.trim()
        if (id.isEmpty()) return Ao3Result.Err(Ao3Error.PARSE, "empty work id")
        val url = if (viewAdult) "$BASE_URL/works/$id?view_adult=true" else "$BASE_URL/works/$id"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "text/html,application/xhtml+xml")
            .get()
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                val path = response.request.url.encodedPath
                if (path.contains("/users/login") || path.contains("/users/sign_in")) {
                    return Ao3Result.Err(
                        if (loggedIn) Ao3Error.SESSION_EXPIRED else Ao3Error.LOGIN_REQUIRED,
                        "redirected to login"
                    )
                }
                when (response.code) {
                    404 -> return Ao3Result.Err(Ao3Error.NOT_FOUND, "HTTP 404")
                    401, 403 -> return Ao3Result.Err(Ao3Error.LOGIN_REQUIRED, "HTTP ${response.code}")
                }
                if (!response.isSuccessful) return Ao3Result.Err(Ao3Error.HTTP, "HTTP ${response.code}")
                val html = response.body?.string().orEmpty()
                if (html.isBlank()) return Ao3Result.Err(Ao3Error.PARSE, "empty html")
                val doc = Jsoup.parse(html, response.request.url.toString())
                restrictedGate(doc)?.let { reason ->
                    return Ao3Result.Err(
                        if (loggedIn) Ao3Error.SESSION_EXPIRED else Ao3Error.LOGIN_REQUIRED,
                        reason
                    )
                }
                val content = parseWorkContent(doc, id)
                if (content.chapters.isEmpty()) {
                    return Ao3Result.Err(Ao3Error.UNEXPECTED_HTML, "no readable text")
                }
                Ao3Result.Ok(content)
            }
        } catch (e: Exception) {
            Ao3Result.Err(classifyNetworkError(e), e.message.orEmpty())
        }
    }

    // --------------------------------------------------------------- 下载

    /**
     * 打开官方下载接口的响应流：`GET /downloads/<作品编号>/work.<格式后缀>`。
     * 调用方读取 [DownloadPayload.body] 并负责 close。
     *
     * @param rangeStart 大于 0 时发送 `Range: bytes=<rangeStart>-` 请求断点续传；
     *   服务端不支持时按普通 200 返回，调用方据此判断需要截断重写。
     */
    fun openDownload(
        workId: String,
        format: DownloadFormat,
        viewAdult: Boolean,
        rangeStart: Long = -1L
    ): Ao3Result<DownloadPayload> {
        // 请求构造收敛在纯函数 downloadRequest 中，便于离线断言 URL / Range / 编码头
        val request = downloadRequest(
            workId = workId,
            format = format,
            viewAdult = viewAdult,
            loggedIn = loggedIn,
            referer = workPageUrl(workId),
            rangeStart = rangeStart
        )

        return try {
            val response = client.newCall(request).execute()
            buildPayload(response, format)
        } catch (e: Exception) {
            Ao3Result.Err(classifyNetworkError(e), e.message.orEmpty())
        }
    }

    private fun buildPayload(response: Response, format: DownloadFormat): Ao3Result<DownloadPayload> {
        val finalPath = response.request.url.encodedPath
        val code = response.code

        if (finalPath.contains("/users/login") || finalPath.contains("/users/sign_in")) {
            response.close()
            return Ao3Result.Err(Ao3Error.SESSION_EXPIRED, "redirected to login")
        }
        if (code == 401 || code == 403) {
            response.close()
            return Ao3Result.Err(Ao3Error.LOGIN_REQUIRED, "HTTP $code")
        }
        if (code == 404) {
            response.close()
            return Ao3Result.Err(Ao3Error.NOT_FOUND, "HTTP 404")
        }
        if (code == 416) {
            // 断点起点超出文件长度：本地 .part 已损坏或作品被重新生成，删除后重新下载
            val range = response.header("Content-Range").orEmpty()
            response.close()
            return Ao3Result.Err(Ao3Error.RANGE_INVALID, "HTTP 416 $range")
        }
        if (!response.isSuccessful) {
            response.close()
            return Ao3Result.Err(Ao3Error.HTTP, "HTTP $code")
        }

        val body = response.body
        if (body == null) {
            response.close()
            return Ao3Result.Err(Ao3Error.UNKNOWN, "empty body")
        }

        val contentType = body.contentType()?.toString().orEmpty()
        val looksLikeHtml = contentType.contains("text/html", ignoreCase = true)
        if (looksLikeHtml && format != DownloadFormat.HTML) {
            // 受限作品/登录失效时，AO3 会返回 HTML 提示页而不是二进制文件
            val head = try {
                body.source().peek().request(2048)
                body.source().peek().readUtf8(2048)
            } catch (_: Exception) {
                ""
            }
            response.close()
            val expired = head.contains("/users/login", true) ||
                head.contains("restricted", true) ||
                head.contains("Log in", true) ||
                head.contains("over 18", true)
            return Ao3Result.Err(
                if (expired && loggedIn) Ao3Error.SESSION_EXPIRED
                else if (expired) Ao3Error.LOGIN_REQUIRED
                else Ao3Error.UNEXPECTED_HTML,
                "content-type=$contentType"
            )
        }

        val name = suggestedFileName(response, format)
        val length = body.contentLength()
        val partial = code == 206
        val range = parseContentRange(response.header("Content-Range"))
        val full = when {
            partial && range.total > 0 -> range.total
            length >= 0 -> length
            else -> -1L
        }
        return Ao3Result.Ok(
            DownloadPayload(
                response = response,
                suggestedFileName = name,
                contentLength = length,
                partial = partial,
                rangeStart = if (partial && range.start >= 0) range.start else 0L,
                fullLength = full,
                acceptsRanges = response.header("Accept-Ranges")?.equals("bytes", ignoreCase = true) == true
            )
        )
    }

    /**
     * 是否值得自动重试（需求 6）。判定规则见纯函数 [isRetryable]。
     */
    fun isRetryableError(error: Ao3Error, detail: String = ""): Boolean = isRetryable(error, detail)

    private fun suggestedFileName(response: Response, format: DownloadFormat): String {
        val disposition = response.header("Content-Disposition").orEmpty()
        val star = CONTENT_DISPOSITION_STAR_REGEX.find(disposition)?.groupValues?.get(1)
        if (!star.isNullOrBlank()) {
            runCatching {
                java.net.URLDecoder.decode(star, "UTF-8").substringAfterLast('/')
            }.getOrNull()?.takeIf { it.isNotBlank() }?.let { return sanitize(it, format) }
        }
        val plain = CONTENT_DISPOSITION_REGEX.find(disposition)?.groupValues?.get(1)
        if (!plain.isNullOrBlank()) return sanitize(plain.substringAfterLast('/'), format)
        val pathName = response.request.url.pathSegments.lastOrNull()?.substringAfterLast('/')
        if (!pathName.isNullOrBlank() && pathName.contains('.')) return sanitize(pathName, format)
        return "AO3-work.${format.ext}"
    }

    private fun sanitize(raw: String, format: DownloadFormat): String {
        val base = raw.trim().substringAfterLast('/')
            .replace(Regex("[\\\\/:*?\"<>|\\x00-\\x1F]"), "_")
            .trim()
        if (base.isEmpty()) return "AO3-work.${format.ext}"
        return if (base.substringAfterLast('.', "").equals(format.ext, ignoreCase = true)) {
            base
        } else {
            "$base.${format.ext}"
        }
    }

    // --------------------------------------------------------- 作者作品列表

    /** 抓取 `/users/<username>/works?page=<n>`。 */
    fun fetchAuthorWorks(username: String, page: Int): Ao3Result<AuthorPage> =
        fetchListing(
            listingRequest("$BASE_URL/users/${encode(username)}/works", page),
            page,
            listingMode = LISTING_WORKS
        )

    /** 抓取 `/users/<username>/bookmarks?page=<n>`（我的账号页收藏列表）。 */
    fun fetchBookmarks(username: String, page: Int): Ao3Result<AuthorPage> =
        fetchListing(
            listingRequest("$BASE_URL/users/${encode(username)}/bookmarks", page),
            page,
            listingMode = LISTING_BOOKMARKS
        )

    /* ------------------------------------------- v5.1：首页快捷入口的五类列表 */

    /**
     * 「全部作品」入口：站点作品索引 `/works?page=<n>`。
     *
     * 与作者作品列表同一套 `li.work.blurb` 结构，复用 [parseWorkList]，
     * 因此入口列表的卡片字段（分级预警、tag、统计行、编号）与搜索页口径完全一致。
     */
    fun fetchSiteWorks(page: Int): Ao3Result<AuthorPage> =
        fetchListing(listingRequest("$BASE_URL/works", page), page, listingMode = LISTING_WORKS)

    /**
     * 「我的标签」入口：`/tags/<slug>/works?page=<n>`。
     *
     * slug 由 [com.tabbit.aodl.data.BrowserPlan.tagSlug] 统一生成（空格转下划线），
     * 与浏览页跳转用的地址规则一致；tag 为空时不发请求。
     */
    fun fetchTagWorks(tag: String, page: Int): Ao3Result<AuthorPage> {
        val slug = BrowserPlan.tagSlug(tag)
        if (slug.isEmpty() || tag.isBlank()) {
            return Ao3Result.Err(Ao3Error.PARSE, "empty tag")
        }
        return fetchListing(
            listingRequest("$BASE_URL/tags/$slug/works", page),
            page,
            listingMode = LISTING_WORKS
        )
    }

    /**
     * 「收藏夹」入口：已登录走账号书签页，未登录回退到全站公开书签
     * （与浏览页 `BrowserPlan.bookmarksPath` 同一套规则）。
     */
    fun fetchBookmarkListing(username: String?, page: Int): Ao3Result<AuthorPage> {
        val name = username?.trim().orEmpty()
        val base = if (name.isEmpty()) "$BASE_URL/bookmarks" else "$BASE_URL/users/${encode(name)}/bookmarks"
        return fetchListing(listingRequest(base, page), page, listingMode = LISTING_BOOKMARKS)
    }

    /**
     * 站点作品搜索（v4.6 新增）：`GET /works/search?work_search[query]=<关键词>&commit=Search&page=<n>`。
     *
     * 搜索结果页 `app/views/works/search_results.html.erb` 渲染的是
     * `<ol class="work index group">` + `_work_blurb.html.erb`，与作者作品列表
     * **同一套条目结构**，因此复用 [parseWorkList]，条目字段口径完全一致。
     * 关键词为空时直接返回错误，不发起无意义请求。
     */
    /**
     * 站点作品搜索（v4.6 新增，v5.1 支持筛选）：
     * `GET /works/search?work_search[query]=<关键词>&work_search[<字段>]=<值>&commit=Search&page=<n>`。
     *
     * 搜索结果页 `app/views/works/search_results.html.erb` 渲染的是
     * `<ol class="work index group">` + `_work_blurb.html.erb`，与作者作品列表
     * **同一套条目结构**，因此复用 [parseWorkList]，条目字段口径完全一致。
     * [filter] 产出的 `work_search[...]` 参数与站点表单同名同义（见
     * `com.tabbit.aodl.data.WorkSearchFilter#toQueryPairs`）。关键词与筛选都为空时不发起请求。
     */
    fun searchWorks(
        query: String,
        page: Int,
        filter: WorkSearchFilter = WorkSearchFilter()
    ): Ao3Result<AuthorPage> {
        val keyword = query.trim()
        val extra = filter.toQueryPairs()
        if (keyword.isEmpty() && extra.isEmpty()) {
            return Ao3Result.Err(Ao3Error.PARSE, "empty search query")
        }
        return fetchListing(
            searchRequest(keyword, page, extraParams = extra),
            page,
            listingMode = LISTING_SEARCH
        )
    }

    /**
     * 拉取站点 `/works/search` 表单，解析出分级 / 预警 / 配对 / 语言 / 排序的真实候选项。
     *
     * 站点把 canonical tag 的 id 放在生产库里、仓库里没有硬编码，所以面板候选项
     * 以这次在线拉取为准；拉不到或解析为空时由
     * [com.tabbit.aodl.data.WorkSearchOptions.merge] 回落到内置兜底表。
     */
    fun fetchSearchFormOptions(): Ao3Result<SearchFormOptions> {
        val url = "$BASE_URL/works/search"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "text/html,application/xhtml+xml")
            .get()
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                if (response.code == 404) return Ao3Result.Err(Ao3Error.NOT_FOUND, "HTTP 404 $url")
                if (!response.isSuccessful) return Ao3Result.Err(Ao3Error.HTTP, "HTTP ${response.code}")
                val html = response.body?.string().orEmpty()
                if (html.isBlank()) return Ao3Result.Err(Ao3Error.PARSE, "empty html")
                Ao3Result.Ok(parseSearchFormOptions(Jsoup.parse(html, url)))
            }
        } catch (e: Exception) {
            Ao3Result.Err(classifyNetworkError(e), e.message.orEmpty())
        }
    }

    /** 普通列表页请求（作者作品列表 / 收藏列表），`page > 1` 时附 `?page=<n>`。 */
    private fun listingRequest(urlBase: String, page: Int): Request {
        val url = if (page > 1) "$urlBase?page=$page" else urlBase
        return Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .get()
            .build()
    }

    private fun fetchListing(request: Request, page: Int, listingMode: Int): Ao3Result<AuthorPage> {
        val url = request.url.toString()
        return try {
            client.newCall(request).execute().use { response ->
                if (response.code == 404) return Ao3Result.Err(Ao3Error.NOT_FOUND, "HTTP 404 $url")
                if (!response.isSuccessful) return Ao3Result.Err(Ao3Error.HTTP, "HTTP ${response.code}")
                val html = response.body?.string().orEmpty()
                if (html.isBlank()) return Ao3Result.Err(Ao3Error.PARSE, "empty html")
                val doc = Jsoup.parse(html, url)
                val items = when (listingMode) {
                    LISTING_BOOKMARKS -> parseBookmarks(doc)
                    // 作者作品列表与站点搜索结果共用 _work_blurb 结构，走同一个纯函数解析器
                    else -> parseWorkList(doc)
                }
                Ao3Result.Ok(
                    AuthorPage(
                        works = items,
                        page = page,
                        hasMore = hasNextPage(doc, page),
                        totalLabel = listingLabel(doc, listingMode)
                    )
                )
            }
        } catch (e: Exception) {
            Ao3Result.Err(classifyNetworkError(e), e.message.orEmpty())
        }
    }

    /**
     * 列表页标题。
     *
     * 搜索结果页的层级是 `h2.heading`（"Search Results"）→ `h4.heading`（"You searched for: …"）
     * → `h3.heading`（"N Found"），命中条数在 `h3.heading`；其余列表页直接取第一个标题。
     */
    private fun listingLabel(doc: Document, listingMode: Int): String {
        if (listingMode == LISTING_SEARCH) {
            doc.selectFirst("h3.heading")?.text()?.takeIf { it.isNotBlank() }?.let { return it }
        }
        return doc.selectFirst("h2.heading, h3.heading")?.text().orEmpty()
    }

    private fun parseBookmarks(doc: Document): List<WorkItem> {
        val elements = doc.select("ol.bookmark.index > li[id^=bookmark_]").ifEmpty {
            doc.select("li[id^=bookmark_]")
        }
        return elements.mapNotNull { li ->
            if (li.selectFirst("p.message") != null) return@mapNotNull null // 被收藏对象已删除
            val workLink = li.selectFirst("h4.heading a[href*=/works/]") ?: li.selectFirst("a[href*=/works/]")
            val seriesLink = li.selectFirst("h4.heading a[href*=/series/]") ?: li.selectFirst("a[href*=/series/]")
            val externalLink = li.selectFirst("h4.heading a[href^=http]")
            when {
                workLink != null -> {
                    val href = workLink.attr("href")
                    val id = href.substringAfter("/works/", "").substringBefore('?').substringBefore('/')
                    if (id.isEmpty()) return@mapNotNull null
                    WorkItem(
                        id = id,
                        title = workLink.text().ifBlank { "work #$id" },
                        authors = li.select("h4.heading a[href*=/users/]").joinToString(", ") { it.text() },
                        words = li.selectFirst("dd.words")?.text().orEmpty(),
                        chapters = li.selectFirst("dd.chapters")?.text().orEmpty(),
                        updated = updatedOf(li),
                        fandoms = li.select("h5.fandoms a").joinToString(", ") { it.text() },
                        tags = workTagsOf(li),
                        restricted = li.selectFirst("img[alt=(Restricted)], img[title=Restricted]") != null,
                        kind = WorkKind.WORK
                    )
                }
                seriesLink != null -> WorkItem(
                    id = seriesLink.attr("href").substringAfter("/series/", "").substringBefore('?'),
                    title = seriesLink.text(),
                    authors = li.select("h4.heading a[href*=/users/]").joinToString(", ") { it.text() },
                    updated = updatedOf(li),
                    kind = WorkKind.SERIES
                )
                externalLink != null -> WorkItem(
                    id = externalLink.attr("href"),
                    title = externalLink.text(),
                    updated = updatedOf(li),
                    kind = WorkKind.EXTERNAL
                )
                else -> null
            }
        }
    }

    /**
     * 分页判定（作者列表与站点搜索共用）。
     *
     * - 作品列表页用 `pagy_nav` 渲染 `<ol class="pagination actions pagy">`，
     *   下一页是 `<li class="next"><a href="?page=N">…</a></li>`；到最后一页时
     *   `li.next` 内只剩 `<span class="disabled">`，因此用 `a[href]` 精确区分；
     * - 搜索结果页 `app/views/works/search_results.html.erb` 用 `will_paginate`，
     *   其默认标记是 `<div class="pagination">` 内的 `<a rel="next" class="next_page">`
     *   与末页 `<em class="current">`，故一并匹配 `a[rel=next][href]`。
     */
    private fun hasNextPage(doc: Document, currentPage: Int): Boolean {
        val next = doc.selectFirst(
            "ol.pagination li.next > a[href], ol.pagination a[rel=next], " +
                ".pagination li.next > a[href], nav.pagy_nav a.next, " +
                ".pagination a.next_page[href], a[rel=next][href]"
        )
        if (next != null && next.attr("href").isNotBlank()) return true
        val pager = doc.selectFirst("ol.pagination, .pagination, nav.pagy_nav")
        val scope = pager?.html() ?: doc.html()
        val pages = PAGE_REGEX.findAll(scope).mapNotNull { it.groupValues[1].toIntOrNull() }
        return pages.any { it > currentPage }
    }

    // --------------------------------------------------------------- 工具

    private fun encode(segment: String): String =
        java.net.URLEncoder.encode(segment.trim(), "UTF-8").replace("+", "%20")

    private fun classifyNetwork(e: Throwable): LoginFailReason = when (e) {
        is SocketTimeoutException -> LoginFailReason.NETWORK
        is UnknownHostException -> LoginFailReason.NETWORK
        is SSLException -> LoginFailReason.NETWORK
        is IOException -> LoginFailReason.NETWORK
        else -> LoginFailReason.UNKNOWN
    }

    fun classifyNetworkError(e: Throwable): Ao3Error = when (e) {
        is SocketTimeoutException -> Ao3Error.TIMEOUT
        is SSLException -> Ao3Error.TLS
        is UnknownHostException -> Ao3Error.NETWORK
        is IOException -> Ao3Error.NETWORK
        else -> Ao3Error.UNKNOWN
    }

    fun errorDetail(e: Throwable): String = "${e.javaClass.simpleName}: ${e.message.orEmpty()}"

    companion object {
        const val BASE_URL = "https://archiveofourown.org"
        const val SESSION_COOKIE = "_otwarchive_session"
        const val REMEMBER_COOKIE = "remember_user_token"

        internal const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; AO3Downloader/4.6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

        private const val LISTING_WORKS = 0
        private const val LISTING_BOOKMARKS = 1

        /** 站点搜索结果页（`works/search_results.html.erb`）：条目结构与作品列表一致。 */
        private const val LISTING_SEARCH = 2

        private val WORK_URL_REGEX = Regex("""archiveofourown\.org/works/(\d{2,})|/works/(\d{2,})""")
        private val PLAIN_DIGITS_REGEX = Regex("""(\d{3,})""")
        private val PAGE_REGEX = Regex("""[?&]page=(\d+)""")
        private val AUTH_TOKEN_REGEX =
            Regex("""name="authenticity_token"[^>]*?value="([^"]+)"|value="([^"]+)"[^>]*?name="authenticity_token"""")
        private val META_CSRF_REGEX =
            Regex("""name="csrf-token"[^>]*?content="([^"]+)"|content="([^"]+)"[^>]*?name="csrf-token"""")
        private val CONTENT_DISPOSITION_REGEX = Regex("""filename="([^"]+)"""", RegexOption.IGNORE_CASE)
        private val CONTENT_DISPOSITION_STAR_REGEX =
            Regex("""filename\*=(?:UTF-8|utf-8)''([^;]+)""", RegexOption.IGNORE_CASE)
    }
}
