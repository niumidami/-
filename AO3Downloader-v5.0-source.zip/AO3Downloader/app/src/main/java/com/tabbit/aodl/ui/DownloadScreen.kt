package com.tabbit.aodl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel

/**
 * 下载子页（「下载」格内的第一段）：输入编号/链接、启动下载、查看当前任务进度。
 *
 * v5.1 导航重构：五种格式、保存位置与运行日志三节已迁入「我的」页
 * （见 [DownloadManageSections]），这里只保留发起下载所必需的内容。
 */
@Composable
fun DownloadPane(
    vm: AppViewModel,
    onGoAccount: () -> Unit
) {
    val download by vm.download.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val account by vm.account.collectAsStateWithLifecycle()

    val parsedIds = vm.parsedIds()
    val bannerShape = RoundedCornerShape(12.dp)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 24.dp)
    ) {
        /* ------------------------------------------------ 登录状态提示 */
        val bannerText = when {
            download.sessionExpired -> stringResource(R.string.download_session_expired)
            !account.loggedIn -> stringResource(R.string.download_not_logged_in)
            else -> null
        }
        if (bannerText != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .clip(bannerShape)
                    .background(MaterialTheme.ext.warning.copy(alpha = 0.12f))
                    .border(1.dp, MaterialTheme.ext.warning.copy(alpha = 0.45f), bannerShape)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Filled.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.ext.warning,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = bannerText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = stringResource(R.string.download_go_account),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onGoAccount)
                        .padding(start = 8.dp, top = 4.dp, bottom = 4.dp)
                )
            }
        }

        /* ------------------------------------------------------- 输入 */
        SakuraTextField(
            value = download.input,
            onValueChange = vm::onInputChange,
            label = stringResource(R.string.download_input_label),
            placeholder = stringResource(R.string.download_input_placeholder),
            supportingText = when {
                download.input.isBlank() -> stringResource(R.string.download_tip)
                parsedIds.isEmpty() -> stringResource(R.string.download_not_parsed)
                else -> stringResource(R.string.download_parsed_hint, parsedIds.joinToString(", "))
            },
            isError = download.input.isNotBlank() && parsedIds.isEmpty()
        )

        Spacer(Modifier.height(14.dp))

        /* ------------------------------------------------- 下载进度区 */
        if (download.busy) {
            SakuraCard {
                DownloadProgress(
                    currentTask = download.currentTask,
                    fileProgress = download.fileProgress,
                    finished = download.finishedTasks,
                    total = download.totalTasks,
                    succeeded = download.succeeded,
                    failed = download.failed
                )
                Spacer(Modifier.height(12.dp))
                SecondaryButton(
                    text = stringResource(R.string.download_cancel),
                    onClick = vm::cancelDownload,
                    icon = Icons.Filled.Stop,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            GradientButton(
                text = stringResource(R.string.download_button),
                onClick = { vm.startDownload() },
                enabled = parsedIds.isNotEmpty() && settings.activeFormats.isNotEmpty(),
                icon = Icons.Filled.PlayArrow
            )
        }

        if (settings.activeFormats.isEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.download_no_format_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.ext.warning
            )
        }
    }
}