package com.tabbit.aodl.data

/**
 * 图标选择结果的归一化描述（需求 4）。
 *
 * @property choice     归一化后的选择值：某个内置图标名，或 [IconPlan.CUSTOM]。
 * @property builtin    归一化后的「最后一次选中的内置图标名」。桌面 alias 永远由它决定，
 *                      这样切到自定义图片时桌面不会莫名跳回出厂图标。
 * @property useCustom  应用内图标位是否渲染用户上传的图片。
 */
internal data class IconDecision(
    val choice: String,
    val builtin: String,
    val useCustom: Boolean
)

/**
 * 图标选择的纯逻辑，不依赖任何 Android 类型，便于离线断言。
 *
 * 三条规则：
 * 1. **桌面 alias 有且仅有一个启用**，且始终对应某个内置图标；
 * 2. **自定义图片只影响应用内图标位与桌面快捷方式**，因为图片存在应用私有目录，
 *    无法写进 APK 的 `android:icon`；
 * 3. **持久化值不可信时一律回退**：图片文件被清掉、选项名对不上枚举、
 *    甚至枚举被裁剪，都不应让应用出现「零个可启动入口」或崩溃。
 */
internal object IconPlan {

    /** 代表「使用用户上传的图片」的选择值。 */
    const val CUSTOM = "CUSTOM"

    /**
     * 把持久化的原始值归一成一份可执行的决定。
     *
     * @param known           当前可用的内置图标名（顺序即展示顺序）。
     * @param fallback        [known] 为空或全部对不上时使用的名字。
     * @param hasCustomImage  应用私有目录里是否真的存在已上传的图片。
     */
    fun decide(
        rawChoice: String?,
        rawBuiltin: String?,
        known: List<String>,
        fallback: String,
        hasCustomImage: Boolean
    ): IconDecision {
        val safeKnown = known.filter { it.isNotBlank() }.ifEmpty { listOf(fallback) }
        val safeFallback = safeKnown.firstOrNull { it == fallback } ?: safeKnown.first()
        val builtin = normalize(rawBuiltin, safeKnown, safeFallback)
        val wantsCustom = CUSTOM.equals(rawChoice?.trim(), ignoreCase = true)
        val choice = when {
            // 选了自定义但图片已不存在：静默回退到最后一次选中的内置图标
            wantsCustom && hasCustomImage -> CUSTOM
            else -> normalize(rawChoice, safeKnown, builtin)
        }
        return IconDecision(choice = choice, builtin = builtin, useCustom = choice == CUSTOM)
    }

    /**
     * 全量开关表：按 [known] 的顺序给出「alias 名 -> 是否启用」，
     * 其中**有且仅有一个** true，对应 [IconDecision.builtin]。
     * 调用方必须把表里所有项都写一遍，否则可能残留多个启用项。
     */
    fun enabledStates(known: List<String>, decision: IconDecision): List<Pair<String, Boolean>> {
        val safeKnown = known.filter { it.isNotBlank() }.ifEmpty { listOf(decision.builtin) }
        val active = safeKnown.firstOrNull { it == decision.builtin } ?: safeKnown.first()
        return safeKnown.map { it to (it == active) }
    }

    /**
     * 用户在设置里点选某个图标后，「最后一次选中的内置图标」应该变成什么。
     * 点选自定义图片时保持原值不变，桌面 alias 因此不受影响。
     */
    fun nextBuiltin(picked: String?, currentBuiltin: String?, known: List<String>, fallback: String): String {
        val safeKnown = known.filter { it.isNotBlank() }.ifEmpty { listOf(fallback) }
        val safeFallback = safeKnown.firstOrNull { it == fallback } ?: safeKnown.first()
        return if (CUSTOM.equals(picked?.trim(), ignoreCase = true)) {
            normalize(currentBuiltin, safeKnown, safeFallback)
        } else {
            normalize(picked, safeKnown, safeFallback)
        }
    }

    /**
     * `BitmapFactory.Options.inSampleSize`：只能是 2 的幂，且采样后**两条边都仍不小于**
     * [targetPx]，保证后续还能居中裁出完整的正方形。非法输入返回 1（不缩放）。
     */
    fun sampleSize(srcWidth: Int, srcHeight: Int, targetPx: Int): Int {
        if (srcWidth <= 0 || srcHeight <= 0 || targetPx <= 0) return 1
        var sample = 1
        while (srcWidth / (sample * 2) >= targetPx && srcHeight / (sample * 2) >= targetPx) {
            sample *= 2
        }
        return sample
    }

    /**
     * 居中裁剪的起点与边长 `(x, y, size)`，把任意长宽比的图片切成最大内接正方形。
     * 非法输入返回 null。
     */
    fun centerCrop(srcWidth: Int, srcHeight: Int): Triple<Int, Int, Int>? {
        if (srcWidth <= 0 || srcHeight <= 0) return null
        val size = minOf(srcWidth, srcHeight)
        return Triple((srcWidth - size) / 2, (srcHeight - size) / 2, size)
    }

    /** 严格匹配（忽略大小写与首尾空白）；匹配不上就回退，绝不返回未知名字。 */
    private fun normalize(raw: String?, known: List<String>, fallback: String): String {
        val value = raw?.trim().orEmpty()
        if (value.isEmpty()) return fallback
        return known.firstOrNull { it.equals(value, ignoreCase = true) } ?: fallback
    }
}
