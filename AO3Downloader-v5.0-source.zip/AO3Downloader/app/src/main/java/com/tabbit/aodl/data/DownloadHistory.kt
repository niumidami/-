package com.tabbit.aodl.data

import android.content.Context
import android.content.SharedPreferences
import com.tabbit.aodl.model.DownloadFormat
import com.tabbit.aodl.model.DownloadRecord
import com.tabbit.aodl.model.DownloadStatus
import org.json.JSONArray
import org.json.JSONObject

/**
 * 下载记录持久化（需求 3）。
 *
 * 存在应用私有的 `SharedPreferences aodl_v4_history` 中，序列化为一个 JSON 数组：
 * - 进程被杀或设备重启后，「管理」页仍能查到历史记录；
 * - 上限 [MAX_RECORDS] 条，超限丢弃最旧的，避免 prefs 文件无限膨胀；
 * - 只记录作品编号、标题、作者、文件名、目录 Uri、状态与字节数，
 *   **不记录 Cookie、密码等任何凭据**。
 *
 * 读写都在 `Dispatchers.IO` 上调用；写入通过 [lock] 串行化，避免并发任务互相覆盖。
 */
class DownloadHistory(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    private val lock = Any()

    /**
     * 读取全部记录（新 → 旧）。
     *
     * 上次进程结束时仍处于 QUEUED/RUNNING 的记录一律归一为 FAILED：
     * 它们不可能还在进行，界面若显示"下载中"就是假状态。
     */
    fun load(): List<DownloadRecord> {
        val raw = sp.getString(KEY_RECORDS, null)
        if (raw.isNullOrBlank()) return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        val list = ArrayList<DownloadRecord>(array.length())
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            deserialize(obj)?.let { record ->
                val unfinished = record.status == DownloadStatus.QUEUED || record.status == DownloadStatus.RUNNING
                list += if (unfinished) record.copy(status = DownloadStatus.FAILED, interrupted = true) else record
            }
        }
        return list.sortedByDescending { it.createdAt }
    }

    /** 合并写入一条记录：同 recordId 覆盖，其余保留；返回合并后的完整列表（新 → 旧）。 */
    fun upsert(record: DownloadRecord): List<DownloadRecord> = synchronized(lock) {
        val merged = LinkedHashMap<String, DownloadRecord>()
        merged[record.recordId] = record
        load().forEach { if (!merged.containsKey(it.recordId)) merged[it.recordId] = it }
        val list = merged.values.sortedByDescending { it.createdAt }.take(MAX_RECORDS)
        write(list)
        list
    }

    /** 批量覆盖写入（整批队列状态刷新时使用）。 */
    fun saveAll(records: List<DownloadRecord>) = synchronized(lock) {
        write(records.sortedByDescending { it.createdAt }.take(MAX_RECORDS))
    }

    /** 删除指定记录，返回删除后的列表。 */
    fun remove(recordIds: Set<String>): List<DownloadRecord> = synchronized(lock) {
        val list = load().filterNot { it.recordId in recordIds }
        write(list)
        list
    }

    /** 清除已结束（成功/失败/取消）的记录，返回 (删除条数, 剩余列表)。 */
    fun removeFinished(): Pair<Int, List<DownloadRecord>> = synchronized(lock) {
        val all = load()
        val kept = all.filterNot { it.finished }
        write(kept)
        (all.size - kept.size) to kept
    }

    fun clear() = synchronized(lock) {
        sp.edit().remove(KEY_RECORDS).apply()
    }

    private fun write(records: List<DownloadRecord>) {
        val array = JSONArray()
        records.forEach { array.put(serialize(it)) }
        sp.edit().putString(KEY_RECORDS, array.toString()).apply()
    }

    private fun serialize(record: DownloadRecord): JSONObject = JSONObject().apply {
        put(K_RID, record.recordId)
        put(K_WID, record.workId)
        put(K_FORMAT, record.format.name)
        put(K_TITLE, record.title)
        put(K_AUTHORS, record.authors)
        put(K_STATUS, record.status.name)
        put(K_DOWNLOADED, record.downloaded)
        put(K_TOTAL, record.total)
        put(K_FILE, record.fileName)
        put(K_DIR, record.dirUri)
        put(K_ERROR, record.errorText)
        put(K_ATTEMPTS, record.attempts)
        put(K_RESUMED, record.resumedFromBytes)
        put(K_ELAPSED, record.elapsedMillis)
        put(K_CREATED, record.createdAt)
        put(K_UPDATED, record.updatedAt)
    }

    private fun deserialize(obj: JSONObject): DownloadRecord? {
        val rid = obj.optString(K_RID, "")
        if (rid.isBlank()) return null
        val format = DownloadFormat.fromName(obj.optString(K_FORMAT, "")) ?: return null
        val status = runCatching { DownloadStatus.valueOf(obj.optString(K_STATUS, "")) }
            .getOrDefault(DownloadStatus.FAILED)
        return DownloadRecord(
            recordId = rid,
            workId = obj.optString(K_WID, ""),
            format = format,
            title = obj.optString(K_TITLE, ""),
            authors = obj.optString(K_AUTHORS, ""),
            status = status,
            downloaded = obj.optLong(K_DOWNLOADED, 0L),
            total = obj.optLong(K_TOTAL, 0L),
            // 速度是瞬时值，重启后没有意义，一律从 0 重新采样
            speedBps = 0L,
            fileName = obj.optString(K_FILE, ""),
            dirUri = obj.optString(K_DIR, ""),
            errorText = obj.optString(K_ERROR, ""),
            attempts = obj.optInt(K_ATTEMPTS, 0),
            resumedFromBytes = obj.optLong(K_RESUMED, 0L),
            elapsedMillis = obj.optLong(K_ELAPSED, 0L),
            createdAt = obj.optLong(K_CREATED, 0L),
            updatedAt = obj.optLong(K_UPDATED, 0L)
        )
    }

    companion object {
        const val MAX_RECORDS = 300

        private const val FILE_NAME = "aodl_v4_history"
        private const val KEY_RECORDS = "records"

        private const val K_RID = "rid"
        private const val K_WID = "wid"
        private const val K_FORMAT = "fmt"
        private const val K_TITLE = "title"
        private const val K_AUTHORS = "authors"
        private const val K_STATUS = "status"
        private const val K_DOWNLOADED = "downloaded"
        private const val K_TOTAL = "total"
        private const val K_FILE = "file"
        private const val K_DIR = "dir"
        private const val K_ERROR = "error"
        private const val K_ATTEMPTS = "attempts"
        private const val K_RESUMED = "resumed"
        private const val K_ELAPSED = "elapsed"
        private const val K_CREATED = "createdAt"
        private const val K_UPDATED = "updatedAt"
    }
}
