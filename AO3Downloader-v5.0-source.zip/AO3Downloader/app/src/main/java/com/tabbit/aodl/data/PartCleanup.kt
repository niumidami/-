package com.tabbit.aodl.data

/**
 * 临时（`.part`）文件的识别规则（v4.2 修复 #2）。
 *
 * ### 为什么不能再按「请求时的名字」去找 `.part`
 *
 * 下载中途文件先写成 `作品名 by 作者名.pdf.part`，完成后才重命名成正式名。
 * 但 SAF provider 不保证沿用请求的显示名：遇到重名会改名成 `xxx (1)`，
 * 部分实现（含 OEM 存储提供者）还会按 MIME 再补一次扩展名，于是盘上出现
 * `作品名 by 作者名.pdf.part.pdf` —— 正是用户截图里那个打不开的中间文件。
 *
 * 旧实现处处用 `findChild(请求名)` 定位 `.part`，一旦 provider 改了名就全都落空：
 * 断点探测测不到、`dropPart` 删不掉、续传还会**再建一个新 `.part`**，
 * 于是残片越积越多，且互相无法对齐。这里改为一律按**名字模式**识别，
 * 与 provider 实际采用的写法无关。
 *
 * ### 判定规则（全部要求名字里带 `.part`，绝不误删成品）
 *
 * | 盘上名字 | 正式名 | 判定 |
 * | --- | --- | --- |
 * | `x.pdf.part` | `x.pdf` | 中间文件 |
 * | `x.pdf.part.pdf` | `x.pdf` | 中间文件（provider 追加了扩展名） |
 * | `x (1).pdf.part` | `x.pdf` | 中间文件（provider 改了重名） |
 * | `x (1).pdf.part.pdf` | `x.pdf` | 中间文件（两者叠加） |
 * | `x.pdf.part (1)` | `x.pdf` | 中间文件（重名序号加在 `.part` 之后） |
 * | `x.pdf` | `x.pdf` | 成品，不动 |
 * | `x.pdf.part` | `x.pdf.part` | 成品，不动（provider 不支持重命名，成品仍叫 `.part`，见 [cleanupIsUnsafe]） |
 * | `x.pdf.partition` | `x.pdf` | 成品，不动（`.part` 只是词的一部分） |
 * | `x2.pdf.part` | `x.pdf` | 不属于本次目标，不动 |
 *
 * 作品名自身含 `.part` 时（正式名 `x.part.pdf`）也按**最后一个** `.part` 切分，
 * 中间文件 `x.part.pdf.part` 依然能被正确识别。
 *
 * 本文件不依赖 Android API，可在纯 JVM 下断言（见 `PartCleanupTest`）。
 */
internal object PartCleanup {

    /** provider 的「重名改名」写法：`主干 (序号)扩展名`（扩展名可缺省）。 */
    private val NUMBERED = Regex("^(.*) \\((\\d+)\\)(\\.[^.]*)?$")

    /**
     * [childName] 是否是 [finalName] 这份下载的中间文件。
     *
     * 只有名字里出现 `.part` 才可能命中，因此永远不会把已完成的成品判成中间文件。
     */
    fun isIntermediateOf(childName: String, finalName: String): Boolean {
        if (finalName.isBlank() || childName.isBlank()) return false
        // 用 lastIndexOf：作品名本身含 ".part"（例如《x.part》→ 正式名 `x.part.pdf`）时，
        // 只有最后一个 ".part" 才是我们追加的那个后缀。
        val marker = childName.lastIndexOf(FileNameBuilder.PART_SUFFIX)
        if (marker < 0) return false
        // `.part` 之前的全部内容才是「主干」，之后只能是 provider 追加的扩展名或重名序号，
        // 否则说明这是另一个词（例如 `x.pdf.partition` 是成品，绝不能当中间文件删掉）。
        if (!isProviderTail(childName, marker + FileNameBuilder.PART_SUFFIX.length)) return false
        val stem = childName.substring(0, marker)
        if (stem == finalName) return true
        return stripNumbered(stem) == finalName
    }

    /** `.part` 之后的部分是否只可能是 provider 追加的扩展名（`.pdf`）或重名序号（` (1)`）。 */
    private fun isProviderTail(childName: String, tailStart: Int): Boolean {
        if (tailStart >= childName.length) return true
        return when (childName[tailStart]) {
            '.', ' ' -> true
            else -> false
        }
    }

    /** 该中间文件收敛后的规范名字（续传探测与清理都以它为准）。 */
    fun canonicalName(finalName: String): String = FileNameBuilder.partName(finalName)

    /**
     * 按名字模式清理是否**不安全**：已入库的文件名里仍带 `.part`。
     *
     * 出现这种情况说明 provider 不支持重命名，成品只能继续叫 `xxx.pdf.part`
     * （`writePayload` 已用 `log_rename_failed` 如实告知用户）。此时
     * [intermediatesOf] 无法区分「成品」与「残片」—— 二者是同一个名字，
     * 任何按名字模式的删除都可能把刚下完的文件删掉，因此收尾必须整体跳过清理。
     *
     * 目前 [isIntermediateOf] 恰好不会命中自己（`x.pdf.part` 的主干是 `x.pdf`），
     * 但那只是巧合而非契约，这里补上显式护栏。
     */
    fun cleanupIsUnsafe(storedName: String): Boolean =
        storedName.contains(FileNameBuilder.PART_SUFFIX)

    /** 从候选子项里挑出属于 [finalName] 的中间文件。 */
    fun intermediatesOf(childNames: List<String>, finalName: String): List<String> =
        childNames.filter { isIntermediateOf(it, finalName) }

    /** 去掉 provider 追加的「 (序号)」，还原成 `主干扩展名`。 */
    private fun stripNumbered(stem: String): String {
        val match = NUMBERED.matchEntire(stem) ?: return stem
        // group(1) 主干、group(3) 扩展名（可能为空）
        return match.groupValues[1] + match.groupValues[3]
    }

    /**
     * 一次「中间文件收敛」的完整决策（纯函数，可离线断言）。
     *
     * 收尾只有两种：
     * - [keepForResume] = false：下载成功 / 断点作废 / 内容非法 / 任务失败 → **全部删除**，
     *   用户目录里不留任何 `.part`；
     * - [keepForResume] = true：用户取消或下载中断 → 只留**最大**的那一份（最值得续传），
     *   其余变体全删，并把留下的那份改名回规范的 `finalName.part`，
     *   这样下次下载 [intermediatesOf] 能稳定命中，不会再堆出第二种写法。
     *
     * @param children 目录下的全部子项名字（成品与无关文件都可以传进来，不会被选中）
     * @param sizeOf 取某个名字的字节数
     */
    fun planCleanup(
        children: List<String>,
        finalName: String,
        sizeOf: (String) -> Long,
        keepForResume: Boolean
    ): CleanupPlan {
        // 护栏：正式名里仍带 `.part`（provider 不支持重命名）时，名字模式无法区分成品与残片，
        // 一律不做任何决策，交给上层如实保留现场。
        if (cleanupIsUnsafe(finalName)) return CleanupPlan.EMPTY
        val intermediates = intermediatesOf(children, finalName)
        if (intermediates.isEmpty()) return CleanupPlan.EMPTY
        if (!keepForResume) return CleanupPlan(keep = null, delete = intermediates, renameTo = null)

        // 多份残留时保留最大的那份：它是最接近完成、最值得续传的
        val keep = intermediates.maxByOrNull { sizeOf(it) } ?: return CleanupPlan.EMPTY
        val canonical = canonicalName(finalName)
        return CleanupPlan(
            keep = keep,
            delete = intermediates.filter { it != keep },
            renameTo = if (keep == canonical) null else canonical
        )
    }

    /** 给日志用的可读描述：例如 `x.pdf.part.pdf` → `x.pdf.part.pdf`（保留原样，便于用户对照）。 */
    fun describe(names: List<String>): String =
        when (names.size) {
            0 -> ""
            1, 2, 3 -> names.joinToString(", ")
            else -> names.take(3).joinToString(", ") + " …"
        }
}

/**
 * [PartCleanup.planCleanup] 的结果：保留哪一份、删掉哪些、是否改名回规范形式。
 *
 * [renameTo] 为 null 表示留下的那份已经是规范名，不需要改名。
 */
internal data class CleanupPlan(
    val keep: String?,
    val delete: List<String>,
    val renameTo: String?
) {
    companion object {
        val EMPTY = CleanupPlan(keep = null, delete = emptyList(), renameTo = null)
    }

    /** 目录里本来就没有中间文件。 */
    val isNothingToDo: Boolean get() = keep == null && delete.isEmpty()
}