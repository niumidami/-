package com.tabbit.aodl.data

import com.tabbit.aodl.model.DownloadFormat

/**
 * 保存目录规划（需求 2）中的**纯决策部分**。
 *
 * 从 `AppViewModel.resolveDir` 里拆出来，不依赖任何 Android API，
 * 因此「统一保存开 / 关」× 「按作者分类开 / 关」四种组合下的目录层级
 * 都能在 JVM 单元测试里直接断言（见 `app/src/test/java/com/tabbit/aodl/data/DirPlanTest.kt`）。
 *
 * 真实建目录仍由 [SafStore.ensureSubDir] 负责：先查后建、建完复核，
 * 已存在同名目录时直接复用并向其中追加文件，绝不重复创建。
 *
 * ### 为什么「按作者分类」关闭时也要建格式目录（v4.1 修复）
 *
 * v4.0 只在「按作者分类」开启时才建格式目录，于是当用户**关闭作者分类**、
 * 又让五种格式共用一个根目录（开启「统一保存位置」，或把五种格式都指向
 * 同一个文件夹）时，五种格式的文件会全部落进**同一个文件夹**里。
 *
 * 修正后的判定是「根目录是否已经按格式分开」：
 * - 分格式保存（每种格式各有自己的根目录）→ 根目录本身就是格式隔离，不再套一层；
 * - 统一保存（多格式共用一个根目录）→ 必须补一层格式目录，否则全部混在一起。
 *
 * 该判定与「按作者分类」是否开启无关，见 [needsFormatLevel]。
 */
internal object DirPlan {

    /**
     * 是否需要在根目录（或作者目录）下再建一层「格式名」目录。
     *
     * 只要「按作者分类」开启，或多种格式共用同一个根目录，就需要格式层；
     * 仅当每种格式各自拥有独立根目录、且不按作者分类时才不需要——
     * 此时用户选的那个根目录本身就是该格式的专属目录。
     */
    fun needsFormatLevel(authorClassify: Boolean, unifiedSave: Boolean): Boolean =
        authorClassify || unifiedSave

    /**
     * 一级目录（作者名）的 `(原始名, 回退名)`；关闭按作者分类时返回 null，
     * 表示文件直接落在用户所选的根目录（与 v3.0 行为一致）。
     */
    fun authorSegment(
        authorClassify: Boolean,
        authorLabel: String,
        authorFallback: String
    ): Pair<String, String>? =
        if (!authorClassify) null else FileNameBuilder.dirName(authorLabel, authorFallback) to authorFallback

    /**
     * 作者目录下要一次建齐的二级格式目录。
     *
     * - 统一保存：用户只选了一个根目录，五种格式全部写进同一棵目录树，
     *   因此一次建齐 HTML / PDF / MOBI / EPUB / AZW3（避免后续格式各自补建时
     *   相互覆盖或漏建）；
     * - 分格式保存：每种格式各有自己的根目录，只建当前格式这一个，
     *   否则每个根目录下都会多出四个永远为空的目录。
     *
     * 不需要格式层时返回空列表（文件直接写在根目录 / 作者目录里）。
     */
    fun formatSegments(
        authorClassify: Boolean,
        unifiedSave: Boolean,
        taskFormat: DownloadFormat
    ): List<DownloadFormat> = when {
        !needsFormatLevel(authorClassify, unifiedSave) -> emptyList()
        unifiedSave -> DownloadFormat.entries.toList()
        else -> listOf(taskFormat)
    }

    /** 目标二级目录名；不需要格式层时返回 null（直接写在上一级目录里）。 */
    fun targetFormatDir(
        authorClassify: Boolean,
        unifiedSave: Boolean,
        taskFormat: DownloadFormat
    ): String? = if (needsFormatLevel(authorClassify, unifiedSave)) taskFormat.name else null

    /**
     * 已解析目录的缓存键：**根目录 + 作者名 + 格式**，三段用控制字符分隔。
     *
     * v4.0 只用了前两段，于是同一作者下载多种格式时，先解析出来的目标目录
     * 会被后面所有格式复用，HTML / MOBI / AZW3 / EPUB / PDF 全部落进同一个文件夹
     * ——这是用户实测到的缺陷，因此把键的构造也放在这里，用单测钉死。
     *
     * 作者名与格式名都经过 [FileNameBuilder] 清洗（控制字符会被替换为 `_`），
     * 因此 `\u0000` 不可能出现在任何一段里，拼出的键不会互相串味。
     * 缺失作者层与缺失格式层时分别写入 `\u0001` 占位，保证
     * 「不建作者目录」与「作者名恰好为空」两种情形也不会共用同一个键。
     */
    fun cacheKey(
        rootUri: String,
        authorName: String?,
        formatLevel: Boolean,
        taskFormat: DownloadFormat
    ): String = buildString {
        append(rootUri)
        append('\u0000')
        append(authorName ?: "\u0001")
        append('\u0000')
        append(if (formatLevel) taskFormat.name else "\u0001")
    }
}