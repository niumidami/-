package com.tabbit.aodl.net

import android.util.Base64
import com.tabbit.aodl.model.AppSettings
import com.tabbit.aodl.model.DohMethod
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** DoH 运行配置，由 ViewModel 按当前设置实时提供。 */
data class DohConfig(
    val enabled: Boolean = true,
    val endpoint: String = AppSettings.DEFAULT_DOH_ENDPOINT,
    val method: DohMethod = DohMethod.AUTO,
    val fallbackEnabled: Boolean = true,
    /** 仅这些主域及其子域走 DoH，其余域名交给系统 DNS。 */
val dohHosts: Set<String> = DEFAULT_DOH_HOSTS
) {
    companion object {
        val DEFAULT_DOH_HOSTS = setOf("archiveofourown.org")
    }
}

/** DoH 运行事件，用于界面状态指示与运行日志。 */
sealed class DohEvent {
    data class Resolved(
        val endpoint: String,
        val host: String,
        val ips: List<String>,
        val ttlSeconds: Long,
        val latencyMs: Long,
        val usedFallbackEndpoint: Boolean
    ) : DohEvent()

    data class EndpointFailed(val endpoint: String, val host: String, val reason: String) : DohEvent()

    data class SystemFallback(val host: String, val reason: String) : DohEvent()
}

/** 手动"测试连接"的结果。 */
data class DohTestResult(
    val ok: Boolean,
    val endpoint: String,
    val ips: List<String>,
    val ttlSeconds: Long,
    val latencyMs: Long,
    val method: DohMethod,
    val usedFallbackEndpoint: Boolean,
    val error: String
)

/**
 * DNS-over-HTTPS 解析器（OkHttp [Dns] 实现）。
 *
 * 设计要点：
 * 1. 只对 [DohConfig.dohHosts] 内的主域及其子域使用 DoH，其他域名走系统 DNS；
 * 2. DoH 客户端自身强制使用 [Dns.SYSTEM]，避免"解析 DoH 服务器又要走 DoH"的递归；
 * 3. 同时支持 RFC 8484 的 GET（?dns= base64url）与 POST（application/dns-message）两种方式；
 * 4. 结果按响应中的 TTL 缓存；
 * 5. 指定端点失败时依次尝试公共备用端点，全部失败则回退系统 DNS 并向上层报告。
 */
class DohDns(
    private val configProvider: () -> DohConfig,
    private val onEvent: (DohEvent) -> Unit = {}
) : Dns {

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .dns(Dns.SYSTEM)
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private class CacheEntry(val addresses: List<InetAddress>, val expireAt: Long)

    private val cache = ConcurrentHashMap<String, CacheEntry>()
    private val queryCount = AtomicInteger(0)
    private val systemFallbackCount = AtomicInteger(0)

    /** 最近一次成功使用的端点，供设置页显示"当前生效地址"。 */
    @Volatile
    var activeEndpoint: String? = null
        private set

    /** 最近一次成功解析到的 IP，供设置页状态指示。 */
    @Volatile
    var lastResolvedIps: List<String> = emptyList()
        private set

    @Volatile
    var lastLatencyMs: Long = 0L
        private set

    fun stats(): Int = queryCount.get()

    fun systemFallbacks(): Int = systemFallbackCount.get()

    fun clearCache() = cache.clear()

    // ------------------------------------------------- 端点自动切换（需求 6）

    /**
     * 运行期端点覆盖值。
     *
     * 下载遇到网络类失败时由 [rotateEndpoint] 写入，使后续解析优先尝试另一个公共端点，
     * 而不去改动用户在设置里配置的地址；用户改设置或点"重置"时清空。
     */
    @Volatile
    var endpointOverride: String? = null
        private set

    /**
     * 在「用户配置端点 + 两个公共备选端点」之间轮转，返回切换后的端点。
     * 只有一个候选时返回 null（无可切换）。同时清空缓存，强制下次重新解析。
     */
    fun rotateEndpoint(): String? {
        val candidates = candidateEndpoints(configProvider().endpoint, includeFallbacks = true)
        if (candidates.size < 2) return null
        val current = (endpointOverride ?: configProvider().endpoint).trim().removeSuffix("/")
        val index = candidates.indexOf(current)
        val next = candidates[(index + 1).mod(candidates.size)]
        endpointOverride = next
        cache.clear()
        return next
    }

    fun resetEndpointOverride() {
        endpointOverride = null
        cache.clear()
    }

    /** 候选端点去重列表；[endpointOverride] 存在时排在最前。 */
    private fun candidateEndpoints(configured: String, includeFallbacks: Boolean): List<String> {
        val primary = configured.trim().removeSuffix("/")
        val list = mutableListOf<String>()
        endpointOverride?.takeIf { it.isNotBlank() }?.let { list += it.removeSuffix("/") }
        if (primary.isNotBlank()) list += primary
        if (includeFallbacks) {
            AppSettings.FALLBACK_DOH_ENDPOINTS.forEach { candidate ->
                val normalized = candidate.removeSuffix("/")
                if (normalized !in list) list += normalized
            }
        }
        return list.distinct()
    }

    // ------------------------------------------------------------------ Dns

    override fun lookup(hostname: String): List<InetAddress> {
        val config = configProvider()
        val host = hostname.lowercase()

        if (!config.enabled || !shouldUseDoh(host, config)) {
            return Dns.SYSTEM.lookup(hostname)
        }

        cache[host]?.takeIf { it.expireAt > System.currentTimeMillis() }?.let { entry ->
            queryCount.incrementAndGet()
            return entry.addresses
        }

        var lastError = ""
        val endpoints = endpointsInOrder(config)
        endpoints.forEachIndexed { index, endpoint ->
            try {
                val answer = resolve(endpoint, config.method, host)
                if (answer.addresses.isNotEmpty()) {
                    val ttl = answer.ttlSeconds.coerceIn(MIN_TTL_SECONDS, MAX_TTL_SECONDS)
                    cache[host] = CacheEntry(answer.addresses, System.currentTimeMillis() + ttl * 1000L)
                    activeEndpoint = endpoint
                    lastResolvedIps = answer.addresses.map { it.hostAddress ?: "" }
                    lastLatencyMs = answer.latencyMs
                    queryCount.incrementAndGet()
                    onEvent(
                        DohEvent.Resolved(
                            endpoint = endpoint,
                            host = host,
                            ips = lastResolvedIps,
                            ttlSeconds = ttl,
                            latencyMs = answer.latencyMs,
                            usedFallbackEndpoint = index > 0
                        )
                    )
                    return answer.addresses
                }
                lastError = "empty_answer"
            } catch (e: Exception) {
                lastError = e.message?.take(160) ?: e.javaClass.simpleName
                onEvent(DohEvent.EndpointFailed(endpoint, host, lastError))
            }
        }

        // 全部端点失败：回退系统 DNS，并让界面/日志知道发生了降级
        systemFallbackCount.incrementAndGet()
        onEvent(DohEvent.SystemFallback(host, lastError))
        return Dns.SYSTEM.lookup(hostname)
    }

    private fun shouldUseDoh(host: String, config: DohConfig): Boolean =
        config.dohHosts.any { host == it || host.endsWith(".$it") }

    private fun endpointsInOrder(config: DohConfig): List<String> =
        candidateEndpoints(config.endpoint, includeFallbacks = config.fallbackEnabled)

    // ------------------------------------------------------------ 手动测试

    /**
     * 设置页"测试连接"用：按当前配置真实解析一次目标域名，返回状态与耗时。
     * 失败时依次尝试备用端点，并把最终生效端点回报给调用方。
     */
    fun testConnection(
        endpoint: String,
        method: DohMethod,
        fallbackEnabled: Boolean,
        host: String = "archiveofourown.org"
    ): DohTestResult {
        // 手动测试是用户的显式动作：先丢掉下载失败时留下的运行期覆盖值，保证测的就是页面上填的地址
        endpointOverride = null
        val primary = endpoint.trim().removeSuffix("/")
        val candidates = candidateEndpoints(primary, includeFallbacks = fallbackEnabled)
        var lastError = "no endpoint"
        candidates.forEachIndexed { index, ep ->
            try {
                val answer = resolve(ep, method, host)
                if (answer.addresses.isNotEmpty()) {
                    val ips = answer.addresses.map { it.hostAddress ?: "" }
                    activeEndpoint = ep
                    lastResolvedIps = ips
                    lastLatencyMs = answer.latencyMs
                    cache[host] = CacheEntry(
                        answer.addresses,
                        System.currentTimeMillis() + answer.ttlSeconds.coerceIn(MIN_TTL_SECONDS, MAX_TTL_SECONDS) * 1000L
                    )
                    return DohTestResult(
                        ok = true,
                        endpoint = ep,
                        ips = ips,
                        ttlSeconds = answer.ttlSeconds,
                        latencyMs = answer.latencyMs,
                        method = answer.usedMethod,
                        usedFallbackEndpoint = index > 0,
                        error = ""
                    )
                }
                lastError = "empty_answer"
            } catch (e: Exception) {
                lastError = "${e.javaClass.simpleName}: ${e.message?.take(160)}"
            }
        }
        return DohTestResult(
            ok = false,
            endpoint = primary,
            ips = emptyList(),
            ttlSeconds = 0,
            latencyMs = 0,
            method = method,
            usedFallbackEndpoint = false,
            error = lastError
        )
    }

    // ------------------------------------------------------------ RFC 8484

    private class Answer(
        val addresses: List<InetAddress>,
        val ttlSeconds: Long,
        val latencyMs: Long,
        val usedMethod: DohMethod
    )

    /** 先查 A 记录，无结果时再查 AAAA；两者皆空返回空列表。 */
    private fun resolve(endpoint: String, method: DohMethod, host: String): Answer {
        val started = System.currentTimeMillis()
        val methods = when (method) {
            DohMethod.GET -> listOf(DohMethod.GET)
            DohMethod.POST -> listOf(DohMethod.POST)
            DohMethod.AUTO -> listOf(DohMethod.POST, DohMethod.GET)
        }

        var lastFailure: Exception? = null
        for (m in methods) {
            for (type in intArrayOf(TYPE_A, TYPE_AAAA)) {
                try {
                    val query = buildQuery(host, type)
                    val raw = exchange(endpoint, m, query)
                    val parsed = parseResponse(raw, type)
                    if (parsed.addresses.isNotEmpty()) {
                        return Answer(
                            addresses = parsed.addresses,
                            ttlSeconds = parsed.ttlSeconds,
                            latencyMs = System.currentTimeMillis() - started,
                            usedMethod = m
                        )
                    }
                } catch (e: Exception) {
                    lastFailure = e
                }
            }
        }
        throw lastFailure ?: IOException("DoH resolve failed for $host")
    }

    private fun exchange(endpoint: String, method: DohMethod, query: ByteArray): ByteArray {
        val dnsMessage = "application/dns-message".toMediaType()
        val request = when (method) {
            DohMethod.GET -> {
                val b64 = Base64.encodeToString(query, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
                Request.Builder()
                    .url("$endpoint?dns=$b64")
                    .header("Accept", "application/dns-message")
                    .get()
                    .build()
            }
            DohMethod.POST -> Request.Builder()
                .url(endpoint)
                .header("Accept", "application/dns-message")
                .post(query.toRequestBody(dnsMessage, 0, query.size))
                .build()
            DohMethod.AUTO -> error("AUTO is expanded before exchange")
        }

        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("DoH HTTP ${response.code}")
            }
            val body = response.body?.bytes() ?: throw IOException("DoH empty body")
            if (body.size < DNS_HEADER_SIZE) throw IOException("DoH body too short: ${body.size}")
            return body
        }
    }

    // ------------------------------------------------- DNS wireformat 编解码

    /** 构造 DNS 查询报文（RD=1，单条 question）。 */
    internal fun buildQuery(name: String, type: Int, id: Int = 0x414F): ByteArray {
        val out = ByteArrayOutputStream(64)
        out.write((id shr 8) and 0xFF)
        out.write(id and 0xFF)
        out.write(0x01) // flags: RD
        out.write(0x00)
        out.write(0x00); out.write(0x01) // QDCOUNT = 1
        out.write(0x00); out.write(0x00) // ANCOUNT
        out.write(0x00); out.write(0x00) // NSCOUNT
        out.write(0x00); out.write(0x00) // ARCOUNT
        val trimmed = name.trim().removeSuffix(".")
        require(trimmed.isNotEmpty()) { "empty host name" }
        trimmed.split('.').forEach { label ->
            val bytes = label.toByteArray(Charsets.UTF_8)
            require(bytes.size in 1..63) { "invalid dns label: $label" }
            out.write(bytes.size)
            out.write(bytes)
        }
        out.write(0) // root label
        out.write((type shr 8) and 0xFF)
        out.write(type and 0xFF)
        out.write(0x00); out.write(0x01) // QCLASS = IN
        return out.toByteArray()
    }

    internal class Parsed(val addresses: List<InetAddress>, val ttlSeconds: Long)

    /** 解析 DNS 响应，取出目标类型的 A/AAAA 记录与最小 TTL。 */
    internal fun parseResponse(data: ByteArray, wantType: Int): Parsed {
        if (data.size < DNS_HEADER_SIZE) throw IOException("dns message too short")
        val flags = ((data[2].toInt() and 0xFF) shl 8) or (data[3].toInt() and 0xFF)
        val rcode = flags and 0x000F
        if (rcode != 0) throw IOException("dns rcode=$rcode")
        val truncated = (flags and 0x0200) != 0
        if (truncated) throw IOException("dns response truncated (TC=1)")

        val anCount = u16(data, 6)
        var pos = skipName(data, 12) + 4 // 跳过 question 的 QTYPE/QCLASS

        val addresses = mutableListOf<InetAddress>()
        var minTtl = Long.MAX_VALUE
        repeat(anCount) {
            pos = skipName(data, pos)
            if (pos + 10 > data.size) throw IOException("dns answer overflow")
            val type = u16(data, pos); pos += 2
            pos += 2 // class
            val ttl = u32(data, pos); pos += 4
            val rdLength = u16(data, pos); pos += 2
            if (pos + rdLength > data.size) throw IOException("dns rdata overflow")
            if (type == wantType && (rdLength == 4 || rdLength == 16)) {
                addresses += InetAddress.getByAddress(data.copyOfRange(pos, pos + rdLength))
                if (ttl > 0) minTtl = minOf(minTtl, ttl)
            }
            pos += rdLength
        }
        return Parsed(addresses, if (minTtl == Long.MAX_VALUE) DEFAULT_TTL_SECONDS else minTtl)
    }

    /** 跳过（可能被压缩的）域名，返回其后一位的偏移。 */
    private fun skipName(data: ByteArray, start: Int): Int {
        var pos = start
        var jumps = 0
        while (pos < data.size) {
            val len = data[pos].toInt() and 0xFF
            if (len == 0) return pos + 1
            if (len and 0xC0 == 0xC0) {
                // 压缩指针：两字节，指针后即为该 name 结束
                if (pos + 1 >= data.size) throw IOException("dns compression overflow")
                if (++jumps > MAX_POINTER_JUMPS) throw IOException("dns compression loop")
                return pos + 2
            }
            if (len > 63) throw IOException("dns label too long: $len")
            pos += 1 + len
        }
        throw IOException("dns name overflow")
    }

    private fun u16(data: ByteArray, pos: Int): Int =
        ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)

    private fun u32(data: ByteArray, pos: Int): Long =
        ((data[pos].toLong() and 0xFF) shl 24) or
            ((data[pos + 1].toLong() and 0xFF) shl 16) or
            ((data[pos + 2].toLong() and 0xFF) shl 8) or
            (data[pos + 3].toLong() and 0xFF)

    private companion object {
        const val TYPE_A = 1
        const val TYPE_AAAA = 28
        const val DNS_HEADER_SIZE = 12
        const val MIN_TTL_SECONDS = 30L
        const val MAX_TTL_SECONDS = 86_400L
        const val DEFAULT_TTL_SECONDS = 300L
        const val MAX_POINTER_JUMPS = 16
    }
}
