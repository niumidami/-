package com.tabbit.aodl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tabbit.aodl.R
import com.tabbit.aodl.data.FilterOption
import com.tabbit.aodl.data.SearchFormOptions
import com.tabbit.aodl.data.WorkSearchFilter
import com.tabbit.aodl.ui.theme.ext

/**
 * 搜索结果页的筛选面板（v5.1）。
 *
 * 字段四组完全对齐 otwarchive `app/views/works/_search_form.html.erb` 的
 * Work Info / Work Tags / Work Stats / Search 四段：作品信息（标题、作者、日期、
 * 完结、交叉、单章、字数）、作品标签（分级、预警、配对、原作、角色、关系、自由标签）、
 * 作品统计（浏览、获赞、评论、书签）、搜索与排序（排序字段、排序方向）。
 *
 * 候选项（分级 / 预警 / 配对 / 语言 / 排序）来自 [options]：打开面板时若联网会先用
 * 站点真实表单覆盖过，离线则用内置兜底表，因此这里只负责渲染与收集草稿。
 * 草稿在面板关闭前不动已生效的筛选，点「应用筛选」才回传。
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
internal fun SearchFilterSheet(
    options: SearchFormOptions,
    initial: WorkSearchFilter,
    loading: Boolean,
    onDismiss: () -> Unit,
    onApply: (WorkSearchFilter) -> Unit,
    onReset: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var draft by remember(initial) { mutableStateOf(initial) }
    val scroll = rememberScrollState()
    val any = stringResource(R.string.filter_any)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.filter_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (loading) {
                    Text(
                        text = stringResource(R.string.filter_options_loading),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.textSecondary
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
                    .verticalScroll(scroll)
            ) {
                /* ------------------------------------------------ 作品信息 */
                FilterSection(stringResource(R.string.filter_section_info))
                SakuraTextField(
                    value = draft.title,
                    onValueChange = { draft = draft.copy(title = it) },
                    label = stringResource(R.string.filter_title_field)
                )
                Spacer(Modifier.height(10.dp))
                SakuraTextField(
                    value = draft.creators,
                    onValueChange = { draft = draft.copy(creators = it) },
                    label = stringResource(R.string.filter_creators)
                )
                Spacer(Modifier.height(10.dp))
                SakuraTextField(
                    value = draft.revisedAt,
                    onValueChange = { draft = draft.copy(revisedAt = it) },
                    label = stringResource(R.string.filter_revised_at)
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SakuraTextField(
                        value = draft.dateFrom,
                        onValueChange = { draft = draft.copy(dateFrom = it) },
                        label = stringResource(R.string.filter_date_from),
                        modifier = Modifier.weight(1f)
                    )
                    SakuraTextField(
                        value = draft.dateTo,
                        onValueChange = { draft = draft.copy(dateTo = it) },
                        label = stringResource(R.string.filter_date_to),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(16.dp))
                FieldLabel(stringResource(R.string.filter_complete))
                SegmentedRow(
                    options = listOf(
                        any to null,
                        stringResource(R.string.filter_complete_only) to true,
                        stringResource(R.string.filter_complete_wip) to false
                    ),
                    selected = draft.complete,
                    onSelect = { draft = draft.copy(complete = it) }
                )

                Spacer(Modifier.height(16.dp))
                FieldLabel(stringResource(R.string.filter_crossover))
                SegmentedRow(
                    options = listOf(
                        stringResource(R.string.filter_crossover_include) to null,
                        stringResource(R.string.filter_crossover_exclude) to false,
                        stringResource(R.string.filter_crossover_only) to true
                    ),
                    selected = draft.crossover,
                    onSelect = { draft = draft.copy(crossover = it) }
                )

                Spacer(Modifier.height(6.dp))
                SwitchRow(
                    title = stringResource(R.string.filter_single_chapter),
                    checked = draft.singleChapter,
                    onCheckedChange = { draft = draft.copy(singleChapter = it) }
                )
                SakuraTextField(
                    value = draft.wordCount,
                    onValueChange = { draft = draft.copy(wordCount = it) },
                    label = stringResource(R.string.filter_word_count)
                )

                /* ------------------------------------------------ 作品标签 */
                FilterSection(stringResource(R.string.filter_section_tags))
                FieldLabel(stringResource(R.string.filter_rating))
                FilterChips(
                    options = listOf(FilterOption("", any)) + options.ratings,
                    selected = setOf(draft.ratingId),
                    onToggle = { draft = draft.copy(ratingId = if (draft.ratingId == it) "" else it) }
                )
                Spacer(Modifier.height(14.dp))
                FieldLabel(stringResource(R.string.filter_warnings))
                FilterChips(
                    options = options.warnings,
                    selected = draft.warningIds,
                    onToggle = { draft = draft.copy(warningIds = draft.warningIds.toggle(it)) }
                )
                Spacer(Modifier.height(14.dp))
                FieldLabel(stringResource(R.string.filter_categories))
                FilterChips(
                    options = options.categories,
                    selected = draft.categoryIds,
                    onToggle = { draft = draft.copy(categoryIds = draft.categoryIds.toggle(it)) }
                )
                Spacer(Modifier.height(14.dp))
                SakuraTextField(
                    value = draft.fandomNames,
                    onValueChange = { draft = draft.copy(fandomNames = it) },
                    label = stringResource(R.string.filter_fandom)
                )
                Spacer(Modifier.height(10.dp))
                SakuraTextField(
                    value = draft.characterNames,
                    onValueChange = { draft = draft.copy(characterNames = it) },
                    label = stringResource(R.string.filter_characters)
                )
                Spacer(Modifier.height(10.dp))
                SakuraTextField(
                    value = draft.relationshipNames,
                    onValueChange = { draft = draft.copy(relationshipNames = it) },
                    label = stringResource(R.string.filter_relationships)
                )
                Spacer(Modifier.height(10.dp))
                SakuraTextField(
                    value = draft.freeformNames,
                    onValueChange = { draft = draft.copy(freeformNames = it) },
                    label = stringResource(R.string.filter_freeform)
                )

                /* ------------------------------------------------ 作品统计 */
                FilterSection(stringResource(R.string.filter_section_stats))
                SakuraTextField(
                    value = draft.hits,
                    onValueChange = { draft = draft.copy(hits = it) },
                    label = stringResource(R.string.filter_hits)
                )
                Spacer(Modifier.height(10.dp))
                SakuraTextField(
                    value = draft.kudos,
                    onValueChange = { draft = draft.copy(kudos = it) },
                    label = stringResource(R.string.filter_kudos)
                )
                Spacer(Modifier.height(10.dp))
                SakuraTextField(
                    value = draft.comments,
                    onValueChange = { draft = draft.copy(comments = it) },
                    label = stringResource(R.string.filter_comments)
                )
                Spacer(Modifier.height(10.dp))
                SakuraTextField(
                    value = draft.bookmarks,
                    onValueChange = { draft = draft.copy(bookmarks = it) },
                    label = stringResource(R.string.filter_bookmarks)
                )

                /* ------------------------------------------------ 搜索与排序 */
                FilterSection(stringResource(R.string.filter_section_search))
                FieldLabel(stringResource(R.string.filter_language))
                FilterChips(
                    options = listOf(FilterOption("", any)) + options.languages,
                    selected = setOf(draft.language),
                    onToggle = { draft = draft.copy(language = if (draft.language == it) "" else it) }
                )
                Spacer(Modifier.height(14.dp))
                FieldLabel(stringResource(R.string.filter_sort_column))
                FilterChips(
                    options = listOf(FilterOption("", any)) + options.sorts,
                    selected = setOf(draft.sortColumn),
                    onToggle = { draft = draft.copy(sortColumn = if (draft.sortColumn == it) "" else it) }
                )
                Spacer(Modifier.height(16.dp))
                FieldLabel(stringResource(R.string.filter_sort_direction))
                SegmentedRow(
                    options = listOf(
                        stringResource(R.string.filter_sort_asc) to "asc",
                        stringResource(R.string.filter_sort_desc) to "desc"
                    ),
                    selected = draft.sortDirection,
                    onSelect = { draft = draft.copy(sortDirection = it) }
                )
                Spacer(Modifier.height(8.dp))
            }

            GradientButton(
                text = stringResource(R.string.filter_apply),
                onClick = { onApply(draft) },
                modifier = Modifier.padding(top = 12.dp)
            )
            Spacer(Modifier.height(10.dp))
            SecondaryButton(
                text = stringResource(R.string.filter_reset),
                onClick = {
                    draft = WorkSearchFilter()
                    onReset()
                },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun FilterSection(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 18.dp, bottom = 10.dp)
    )
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.ext.textSecondary,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

/** 小胶囊多/单选组：选中态用主色描边+浅底，可横向换行不裁切。 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FilterChips(
    options: List<FilterOption>,
    selected: Set<String>,
    onToggle: (String) -> Unit
) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { option ->
            FilterChip(
                label = option.label,
                selected = option.value in selected,
                onClick = { onToggle(option.value) }
            )
        }
    }
}

@Composable
private fun FilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .clip(shape)
            .background(
                if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.ext.logBackground
            )
            .border(
                1.dp,
                if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.ext.cardBorder,
                shape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.ext.textSecondary
        )
    }
}

/** 复选切换：已存在则移除，否则加入。 */
private fun Set<String>.toggle(value: String): Set<String> =
    if (value in this) this - value else this + value