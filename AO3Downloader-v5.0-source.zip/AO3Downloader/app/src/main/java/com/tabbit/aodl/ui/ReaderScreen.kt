package com.tabbit.aodl.ui

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.data.BrowserPlan
import com.tabbit.aodl.data.ReaderPlan
import com.tabbit.aodl.model.Chapter
import com.tabbit.aodl.model.ReaderFont
import com.tabbit.aodl.model.ReaderMode
import com.tabbit.aodl.model.ReaderPalette
import com.tabbit.aodl.model.ReaderState
import com.tabbit.aodl.model.ReaderTypography
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first

/**
 * 需求（v5.0 新增 3）：阅读页，两种可切换模式。
 *
 * - 番茄模式（[ReaderMode.TOMATO]）：把正文抽成纯文本，按解析后的段落渲染，
 *   不依赖原站页面结构；v5.3 起参照 Legado 补齐目录抽屉、翻页动画、
 *   字体 / 字号 / 行距 / 页边距调节、背景主题、章内进度记忆与本地缓存标记；
 * - 原站模式（[ReaderMode.SITE]）：直接把 AO3 官网页面交给 WebView 照原样渲染。
 *
 * 两种模式共用同一份章节数据，因此已读进度（写回书架与历史）在任一模式下都成立；
 * 切换模式不重新抓取正文，只换渲染方式。
 */
@Composable
fun ReaderScreen(vm: AppViewModel, onClose: () -> Unit) {
    val state by vm.reader.collectAsStateWithLifecycle()
    val ext = MaterialTheme.ext

    /* 背景主题只在番茄模式下接管整页配色；跟随应用时用 MaterialTheme。 */
    val themed = state.mode == ReaderMode.TOMATO && state.typography.palette != ReaderPalette.FOLLOW_APP
    val pageBg = if (themed) Color(state.typography.palette.backgroundArgb) else MaterialTheme.colorScheme.background
    val onPage = if (themed) Color(state.typography.palette.textArgb) else MaterialTheme.colorScheme.onBackground
    val secondary = if (themed) Color(state.typography.palette.secondaryArgb) else ext.textSecondary
    val divider = if (themed) secondary.copy(alpha = 0.35f) else ext.cardBorder

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(pageBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            /* ------------------------------------------------------ 顶栏 */
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.browser_close),
                        tint = onPage
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = state.title.ifBlank { stringResource(R.string.reader_title) },
                        color = onPage,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (state.totalChapters > 0) {
                        Text(
                            text = stringResource(
                                R.string.reader_progress_label,
                                state.readChapters,
                                state.totalChapters
                            ),
                            fontSize = 10.sp,
                            color = secondary
                        )
                    }
                }
                if (state.fromCache) {
                    StatusChip(
                        text = stringResource(R.string.reader_from_cache),
                        color = ext.warning
                    )
                }
                if (state.mode == ReaderMode.TOMATO && state.totalChapters > 0) {
                    IconButton(onClick = vm::toggleReaderCatalog) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.List,
                            contentDescription = stringResource(R.string.reader_catalog),
                            tint = onPage
                        )
                    }
                    IconButton(onClick = vm::toggleReaderSettings) {
                        Icon(
                            imageVector = Icons.Filled.Tune,
                            contentDescription = stringResource(R.string.reader_settings),
                            tint = onPage
                        )
                    }
                }
            }

            /* ------------------------------------------------- 模式切换 */
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
            ) {
                SegmentedRow(
                    options = listOf(
                        stringResource(R.string.reader_mode_tomato) to ReaderMode.TOMATO,
                        stringResource(R.string.reader_mode_site) to ReaderMode.SITE
                    ),
                    selected = state.mode,
                    onSelect = vm::setReaderMode,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(6.dp))
            Text(
                text = if (state.mode == ReaderMode.TOMATO) {
                    stringResource(R.string.reader_tomato_hint)
                } else {
                    stringResource(R.string.reader_site_hint)
                },
                fontSize = 10.sp,
                color = secondary,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(Modifier.height(6.dp))
            HorizontalDivider(color = divider)

            /* ------------------------------------------------------ 正文 */
            when {
                state.loading -> Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 48.dp),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CatLoading(size = 72.dp)
                        Spacer(Modifier.height(8.dp))
                        Text(stringResource(R.string.reader_loading), fontSize = 13.sp, color = secondary)
                    }
                }

                state.error.isNotBlank() -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyHint(text = state.error, modifier = Modifier.padding(24.dp))
                }

                state.mode == ReaderMode.TOMATO -> TomatoReader(
                    vm = vm,
                    state = state,
                    onPage = onPage,
                    secondary = secondary,
                    divider = divider
                )

                else -> SiteReader(vm, workId = state.workId)
            }
        }

        /* 番茄模式的两块浮层：目录抽屉与阅读设置面板（互斥，由 ViewModel 保证） */
        if (state.mode == ReaderMode.TOMATO) {
            ReaderCatalogOverlay(state = state, vm = vm)
            ReaderSettingsOverlay(state = state, vm = vm)
        }
    }
}

/** 番茄式沉浸阅读：逐章纯文本，左右滑动翻页动画，底部上一章 / 下一章。 */
@Composable
private fun TomatoReader(
    vm: AppViewModel,
    state: ReaderState,
    onPage: Color,
    secondary: Color,
    divider: Color
) {
    val chapter = state.current
    if (chapter == null || chapter.empty) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            EmptyHint(text = stringResource(R.string.reader_empty), modifier = Modifier.padding(24.dp))
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = state.chapterIndex,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            transitionSpec = {
                if (targetState > initialState) {
                    (slideInHorizontally { it } + fadeIn()) togetherWith
                        (slideOutHorizontally { -it } + fadeOut())
                } else {
                    (slideInHorizontally { -it } + fadeIn()) togetherWith
                        (slideOutHorizontally { it } + fadeOut())
                }
            },
            label = "chapterSlide"
        ) { index ->
            val current = state.chapters.getOrNull(index)
            if (current == null) {
                Box(modifier = Modifier.fillMaxSize())
            } else {
                ChapterPage(
                    vm = vm,
                    state = state,
                    chapter = current,
                    typo = state.typography,
                    onPage = onPage,
                    secondary = secondary
                )
            }
        }

        HorizontalDivider(color = divider)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { vm.readerPrevChapter() }, enabled = state.hasPrev) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                Text(
                    text = stringResource(R.string.reader_prev_chapter),
                    modifier = Modifier.padding(start = 4.dp),
                    fontSize = 13.sp
                )
            }
            Spacer(Modifier.weight(1f))
            Text(
                text = stringResource(R.string.reader_chapter_index, state.chapterIndex + 1),
                fontSize = 12.sp,
                color = secondary
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { vm.readerNextChapter() }, enabled = state.hasNext) {
                Text(
                    text = stringResource(R.string.reader_next_chapter),
                    modifier = Modifier.padding(end = 4.dp),
                    fontSize = 13.sp
                )
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
            }
        }
    }
}

/**
 * 单章正文页：按 [ReaderTypography] 排版（字体 / 字号 / 行距 / 页边距），
 * 段落由 [ReaderPlan.splitParagraphs] 从纯文本切出，与原站页面结构无关。
 *
 * 打开时按 [ReaderState.offsetFrac] 恢复上次读到的位置；滚动进度经 600ms
 * 节流后上报 ViewModel 落盘（进度记忆）。
 */
@Composable
private fun ChapterPage(
    vm: AppViewModel,
    state: ReaderState,
    chapter: Chapter,
    typo: ReaderTypography,
    onPage: Color,
    secondary: Color
) {
    val scroll = rememberScrollState()
    val paragraphs = remember(chapter.text) { ReaderPlan.splitParagraphs(chapter.text) }
    val fontFamily = remember(typo.font) {
        when (typo.font) {
            ReaderFont.SERIF -> FontFamily.Serif
            ReaderFont.SANS -> FontFamily.SansSerif
            ReaderFont.MONO -> FontFamily.Monospace
        }
    }

    /* 进度恢复：等内容布局完成（maxValue > 0）再跳，短章无需恢复时自然挂起 */
    LaunchedEffect(chapter.index) {
        val frac = state.offsetFrac
        if (frac > 0f) {
            snapshotFlow { scroll.maxValue }.first { it > 0 }
            scroll.scrollTo((scroll.maxValue * frac).toInt())
        }
    }

    /* 滚动进度节流上报；ViewModel 内部还有 0.001 的变化阈值兜底 */
    LaunchedEffect(chapter.index) {
        snapshotFlow {
            if (scroll.maxValue <= 0) 0f else scroll.value.toFloat() / scroll.maxValue.toFloat()
        }.collectLatest { frac ->
            delay(600)
            vm.readerSaveOffset(frac)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(horizontal = typo.marginDp.dp, vertical = 14.dp)
    ) {
        Text(
            text = chapter.title.ifBlank { stringResource(R.string.reader_chapter_plain, chapter.index + 1) },
            fontSize = (typo.fontSizeSp + 4).sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = fontFamily,
            color = onPage
        )
        Spacer(Modifier.height(12.dp))
        paragraphs.forEach { paragraph ->
            Text(
                text = paragraph,
                fontSize = typo.fontSizeSp.sp,
                lineHeight = (typo.fontSizeSp * typo.lineHeightMul).sp,
                fontFamily = fontFamily,
                color = onPage
            )
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text(
            text = stringResource(R.string.reader_chapter_index, chapter.index + 1),
            fontSize = 11.sp,
            color = secondary,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(12.dp))
    }
}

/** 目录抽屉：底部浮层列出全部章节，当前章高亮，点选跳转。 */
@Composable
private fun BoxScope.ReaderCatalogOverlay(state: ReaderState, vm: AppViewModel) {
    OverlayScrim(visible = state.catalogOpen, onClick = vm::toggleReaderCatalog)
    AnimatedVisibility(
        visible = state.catalogOpen,
        modifier = Modifier.align(Alignment.BottomCenter),
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut()
    ) {
        val ext = MaterialTheme.ext
        val outline = remember(state.chapters) { ReaderPlan.outline(state.chapters) }
        val listState = rememberLazyListState()
        LaunchedEffect(state.catalogOpen) {
            if (state.catalogOpen && outline.isNotEmpty()) {
                listState.scrollToItem((state.chapterIndex - 2).coerceAtLeast(0))
            }
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.66f)
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .background(ext.card)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.reader_catalog) + " · ${state.totalChapters}",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = vm::toggleReaderCatalog) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = stringResource(R.string.action_close),
                        tint = ext.textSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            HorizontalDivider(color = ext.cardBorder)
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 6.dp)
            ) {
                items(outline, key = { it.first }) { (index, title) ->
                    val current = index == state.chapterIndex
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { vm.readerGoToChapter(index) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.reader_chapter_plain, index + 1),
                            fontSize = 12.sp,
                            color = if (current) MaterialTheme.colorScheme.primary else ext.textSecondary,
                            modifier = Modifier.width(64.dp)
                        )
                        Text(
                            text = title.ifBlank { stringResource(R.string.reader_chapter_plain, index + 1) },
                            fontSize = 14.sp,
                            color = if (current) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            },
                            fontWeight = if (current) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

/** 阅读设置面板：字体 / 字号 / 行距 / 页边距滑杆与背景主题分段控件。 */
@Composable
private fun BoxScope.ReaderSettingsOverlay(state: ReaderState, vm: AppViewModel) {
    OverlayScrim(visible = state.settingsOpen, onClick = vm::toggleReaderSettings)
    AnimatedVisibility(
        visible = state.settingsOpen,
        modifier = Modifier.align(Alignment.BottomCenter),
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut()
    ) {
        val ext = MaterialTheme.ext
        val typo = state.typography
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .background(ext.card)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.reader_settings),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = vm::toggleReaderSettings) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = stringResource(R.string.action_close),
                        tint = ext.textSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Text(stringResource(R.string.settings_beautify_font), style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            SegmentedRow(
                options = listOf(
                    stringResource(R.string.font_serif) to ReaderFont.SERIF,
                    stringResource(R.string.font_sans) to ReaderFont.SANS,
                    stringResource(R.string.font_mono) to ReaderFont.MONO
                ),
                selected = typo.font,
                onSelect = vm::setReaderFont
            )

            SliderRow(
                label = stringResource(R.string.settings_beautify_size),
                value = typo.fontSizeSp.toFloat(),
                valueRange = ReaderPlan.MIN_FONT_SIZE.toFloat()..ReaderPlan.MAX_FONT_SIZE.toFloat(),
                valueText = stringResource(R.string.settings_value_sp, typo.fontSizeSp),
                steps = ReaderPlan.MAX_FONT_SIZE - ReaderPlan.MIN_FONT_SIZE - 1,
                onValueChange = { vm.setReaderFontSize(it.toInt()) }
            )
            SliderRow(
                label = stringResource(R.string.settings_beautify_line),
                value = typo.lineHeightMul,
                valueRange = ReaderPlan.MIN_LINE_HEIGHT..ReaderPlan.MAX_LINE_HEIGHT,
                valueText = stringResource(R.string.settings_value_x, "%.1f".format(typo.lineHeightMul)),
                steps = 11,
                onValueChange = { vm.setReaderLineHeight(it) }
            )
            SliderRow(
                label = stringResource(R.string.settings_beautify_margin),
                value = typo.marginDp.toFloat(),
                valueRange = ReaderPlan.MIN_MARGIN.toFloat()..ReaderPlan.MAX_MARGIN.toFloat(),
                valueText = stringResource(R.string.settings_value_dp, typo.marginDp),
                steps = ReaderPlan.MAX_MARGIN - ReaderPlan.MIN_MARGIN - 1,
                onValueChange = { vm.setReaderMargin(it.toInt()) }
            )

            Spacer(Modifier.height(4.dp))
            Text(stringResource(R.string.reader_background), style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            SegmentedRow(
                options = listOf(
                    stringResource(R.string.reader_theme_follow) to ReaderPalette.FOLLOW_APP,
                    stringResource(R.string.reader_theme_paper) to ReaderPalette.PAPER,
                    stringResource(R.string.reader_theme_sepia) to ReaderPalette.SEPIA,
                    stringResource(R.string.reader_theme_night) to ReaderPalette.NIGHT
                ),
                selected = typo.palette,
                onSelect = vm::setReaderPalette
            )
            Spacer(Modifier.height(18.dp))
        }
    }
}

/** 浮层背后的半透明遮罩：点击即关闭浮层，不带点击涟漪。 */
@Composable
private fun BoxScope.OverlayScrim(visible: Boolean, onClick: () -> Unit) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.35f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClick
                )
        )
    }
}

/** 原站模式：把作品官网页面交给 WebView 照原样渲染，走安全 DNS 代理。 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun SiteReader(vm: AppViewModel, workId: String) {
    val cookieManager = remember { CookieManager.getInstance() }
    val proxy = vm.webProxy
    val url = remember(workId) { BrowserPlan.workUrl(workId) }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(AndroidColor.WHITE)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                cookieManager.setAcceptCookie(true)
                cookieManager.setAcceptThirdPartyCookies(this, true)
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? = proxy.intercept(request, cookieManager)
                }
                loadUrl(url)
            }
        }
    )
}
