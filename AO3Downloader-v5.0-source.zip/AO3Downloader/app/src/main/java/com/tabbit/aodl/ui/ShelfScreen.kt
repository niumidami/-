package com.tabbit.aodl.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.data.NekoText
import com.tabbit.aodl.data.ShelfPlan
import com.tabbit.aodl.model.ShelfBook
import com.tabbit.aodl.model.ShelfTab
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel

/**
 * 需求（v5.0 新增 2 / 3）：书架页。
 *
 * 阅读历史 / 书签 / 书架三栏各自独立，共用一个搜索框（标题 / 作者 / tag / 作品编号
 * 任一命中即匹配，数据本身不丢）。书架栏用番茄小说式双列网格：左侧是按标题哈希
 * 取色的渐变封面块加首字，右侧是书名、作者、已读进度条与分组标签；点击进阅读，
 * 长按移出书架。
 */
@Composable
fun ShelfScreen(vm: AppViewModel) {
    val state by vm.shelf.collectAsStateWithLifecycle()
    val ext = MaterialTheme.ext

    val visible = when (state.tab) {
        ShelfTab.HISTORY -> ShelfPlan.filter(state.history, state.query)
        ShelfTab.BOOKMARKS -> ShelfPlan.filter(state.bookmarks, state.query)
        ShelfTab.SHELF -> ShelfPlan.filter(state.shelf, state.query)
    }
    val total = when (state.tab) {
        ShelfTab.HISTORY -> state.history.size
        ShelfTab.BOOKMARKS -> state.bookmarks.size
        ShelfTab.SHELF -> state.shelf.size
    }

    var pendingRemove by remember { mutableStateOf<ShelfBook?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        /* ------------------------------------------------------ 标题行 */
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ScreenTitle(icon = vm.icon.collectAsStateWithLifecycle().value, text = stringResource(R.string.shelf_title))
            Spacer(Modifier.weight(1f))
            if (state.tab == ShelfTab.HISTORY && state.history.isNotEmpty()) {
                TextButton(onClick = { vm.clearHistory() }) {
                    Icon(Icons.Filled.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text(
                        text = stringResource(R.string.shelf_clear_history),
                        modifier = Modifier.padding(start = 4.dp),
                        fontSize = 13.sp
                    )
                }
            }
            if (state.tab == ShelfTab.BOOKMARKS) {
                TextButton(onClick = { vm.syncBookmarks() }, enabled = !state.syncing) {
                    Icon(Icons.Filled.Bookmarks, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text(
                        text = stringResource(R.string.shelf_pull_bookmarks),
                        modifier = Modifier.padding(start = 4.dp),
                        fontSize = 13.sp
                    )
                }
            }
        }

        /* ------------------------------------------------- 三栏 + 搜索框 */
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            SegmentedRow(
                options = listOf(
                    stringResource(R.string.shelf_tab_history) to ShelfTab.HISTORY,
                    stringResource(R.string.shelf_tab_bookmarks) to ShelfTab.BOOKMARKS,
                    stringResource(R.string.shelf_tab_shelf) to ShelfTab.SHELF
                ),
                selected = state.tab,
                onSelect = vm::setShelfTab
            )
            Spacer(Modifier.height(10.dp))
            SakuraTextField(
                value = state.query,
                onValueChange = vm::onShelfQueryChange,
                label = stringResource(R.string.shelf_search_hint),
                placeholder = stringResource(R.string.shelf_search_hint)
            )
            if (state.message.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = NekoText.catify(state.message),
                    fontSize = 12.sp,
                    color = ext.textSecondary
                )
            }
            Spacer(Modifier.height(10.dp))
        }

        if (state.syncing) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CatLoading(size = 72.dp)
                    Spacer(Modifier.height(8.dp))
                    Text(stringResource(R.string.shelf_pulling), fontSize = 13.sp, color = ext.textSecondary)
                }
            }
        } else if (visible.isEmpty()) {
            EmptyHint(
                text = when {
                    total > 0 && state.query.isNotBlank() -> stringResource(R.string.shelf_empty_search)
                    state.tab == ShelfTab.HISTORY -> stringResource(R.string.shelf_empty_history)
                    state.tab == ShelfTab.BOOKMARKS -> stringResource(R.string.shelf_empty_bookmarks)
                    else -> stringResource(R.string.shelf_empty_shelf)
                },
                modifier = Modifier.padding(24.dp)
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(visible, key = { it.workId }) { book ->
                    ShelfBookCell(
                        book = book,
                        onClick = { vm.openReader(book.workId, book.title, book.authors) },
                        onLongClick = { if (state.tab == ShelfTab.SHELF) pendingRemove = book }
                    )
                }
            }
        }
    }

    val removing = pendingRemove
    if (removing != null) {
        AlertDialog(
            onDismissRequest = { pendingRemove = null },
            title = { Text(stringResource(R.string.shelf_action_remove)) },
            text = { Text(NekoText.catify(removing.label)) },
            confirmButton = {
                TextButton(onClick = {
                    vm.removeFromShelf(removing.workId)
                    pendingRemove = null
                }) { Text(stringResource(R.string.shelf_action_remove)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingRemove = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

/**
 * 网格单元：左边渐变封面块（按标题哈希取色 + 首字），右边书名 / 作者 / 进度 / 分组。
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ShelfBookCell(
    book: ShelfBook,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val ext = MaterialTheme.ext
    val shape = RoundedCornerShape(14.dp)
    val cover = ShelfPlan.coverOf(book.title, book.workId)
    val totalChapters = ShelfPlan.chaptersTotal(book.chapters)
    val progress = ShelfPlan.progress(book.readChapters, totalChapters)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(ext.card)
            .border(1.dp, ext.cardBorder, shape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .width(44.dp)
                .aspectRatio(0.7f)
                .clip(RoundedCornerShape(8.dp))
                .background(Brush.linearGradient(listOf(Color(cover.first), Color(cover.second)))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = ShelfPlan.initial(book.title),
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.width(8.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = book.label,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (book.authors.isNotBlank()) {
                Text(
                    text = book.authors,
                    fontSize = 10.sp,
                    color = ext.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = if (totalChapters > 0) {
                    stringResource(R.string.shelf_read_progress, book.readChapters.coerceAtMost(totalChapters), totalChapters)
                } else {
                    stringResource(R.string.shelf_read_unknown, book.chapters.ifBlank { "?" })
                },
                fontSize = 10.sp,
                color = ext.textSecondary
            )
            Spacer(Modifier.height(3.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
            )
            if (ShelfPlan.hasGroup(book)) {
                Spacer(Modifier.height(5.dp))
                Text(
                    text = "${stringResource(R.string.shelf_group_label)}：${book.group}",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}