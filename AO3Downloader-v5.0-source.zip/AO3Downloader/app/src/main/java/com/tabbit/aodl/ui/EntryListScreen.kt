package com.tabbit.aodl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PersonAddAlt
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.data.WorkSearchPaging
import com.tabbit.aodl.model.EntryListKind
import com.tabbit.aodl.model.EntryListUiState
import com.tabbit.aodl.model.SubscribedAuthor
import com.tabbit.aodl.model.SubscriptionsUiState
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel

/**
 * 首页五类快捷入口共用的列表页（v5.1）。
 *
 * 作品类列表（全部作品 / tag / 作者 / 收藏夹 / 订阅的作品）统一渲染 [WorkCard]：
 * 分级四徽章、配对与标签胶囊、统计行、`#编号` 一应俱全，且**不含任何下载控件**；
 * 每张卡片右下角带「订阅 / 已订阅」入口，数据落 App 内本地名单。
 *
 * 订阅的作者列表是本地数据：顶部输入框可直接按用户名订阅，点作者行进入其作品列表。
 * 收藏夹未登录时给「去登录」入口；联网列表底部是仿 AO3 的分页条与「加载下一页」。
 */
@Composable
fun EntryListScreen(vm: AppViewModel) {
    val state by vm.entryList.collectAsStateWithLifecycle()
    val subs by vm.subscriptions.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            /* -------------------------------- 顶栏：返回 + 标题 + 命中数 */
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::closeEntryList) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.action_back),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = state.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (state.totalLabel.isNotBlank()) {
                    Text(
                        text = state.totalLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.textSecondary,
                        maxLines = 1
                    )
                    Spacer(Modifier.width(12.dp))
                }
            }

            when {
                state.needsLogin -> LoginNeeded(onGoLogin = vm::openWebLogin)
                state.kind == EntryListKind.SUBSCRIBED_AUTHORS -> AuthorList(vm = vm, state = state, subs = subs)
                else -> WorkList(
                    vm = vm,
                    state = state,
                    subs = subs,
                    onCopy = { target, item -> copyWorkField(vm, clipboard, target, item) }
                )
            }
        }
    }
}

/* ---------------------------------------------------- 作品类列表 */

@Composable
private fun WorkList(
    vm: AppViewModel,
    state: EntryListUiState,
    subs: SubscriptionsUiState,
    onCopy: (com.tabbit.aodl.data.CopyTarget, com.tabbit.aodl.model.WorkItem) -> Unit
) {
    val subscribedIds = subs.works.mapTo(HashSet()) { it.id }
    // 总页数：优先按命中条数算；解析不到时退回「已翻到第 N 页且还有下一页」的保守口径
    val found = WorkSearchPaging.parseFoundCount(state.totalLabel)
    val pages = WorkSearchPaging.pageCount(found).let { counted ->
        if (counted > 1) counted else if (state.hasMore) state.page + 1 else counted
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // 作者作品列表头部：订阅该作者（本地名单，双向同步见账号同步模块）
        if (state.kind == EntryListKind.AUTHOR_WORKS && state.author.isNotBlank()) {
            val subscribedAuthor = subs.authors.any { it.username.equals(state.author, ignoreCase = true) }
            Row(modifier = Modifier.padding(horizontal = 16.dp)) {
                SecondaryButton(
                    text = stringResource(
                        if (subscribedAuthor) R.string.entry_author_subscribed else R.string.entry_subscribe_author
                    ),
                    onClick = { vm.toggleSubscribeAuthor(state.author) },
                    icon = if (subscribedAuthor) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder
                )
            }
        }
        if (state.error.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                ErrorBanner(text = state.error, shape = RoundedCornerShape(14.dp))
            }
        }

        when {
            state.loading && state.works.isEmpty() -> CenterLoading()

            state.works.isEmpty() -> EmptyHint(text = stringResource(R.string.entry_empty))

            else -> LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
            ) {
                items(state.works, key = { it.id + "|" + it.title }) { item ->
                    WorkCard(
                        item = item,
                        showDownload = false,
                        subscribed = item.id in subscribedIds,
                        onToggleSubscribe = { vm.toggleSubscribeWork(item) },
                        onCopy = { target -> onCopy(target, item) },
                        onOpenWork = { vm.openBrowserWork(item.id) },
                        onOpenAuthor = { vm.openAuthorWorksList(it) },
                        onOpenTag = { vm.openTagWorksList(it) },
                        onAddShelf = { vm.addToShelfFrom(item) }
                    )
                }
                if (state.paged) {
                    item {
                        PagedFooter(
                            state = state,
                            pages = pages,
                            onLoadMore = vm::loadMoreEntryList,
                            onGo = vm::goToEntryPage
                        )
                    }
                }
            }
        }
    }
}

/** 联网列表的底部：加载下一页按钮 + 仿 AO3 分页条。 */
@Composable
private fun PagedFooter(
    state: EntryListUiState,
    pages: Int,
    onLoadMore: () -> Unit,
    onGo: (Int) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (state.loadingMore) {
            CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                color = MaterialTheme.colorScheme.primary,
                strokeWidth = 2.dp
            )
        } else if (state.hasMore) {
            SecondaryButton(
                text = stringResource(R.string.entry_load_more),
                onClick = onLoadMore
            )
        }
        if (pages > 1) {
            Spacer(Modifier.height(6.dp))
            PagerBar(current = state.page, pages = pages, onGo = onGo)
        }
    }
}

/* ---------------------------------------------------- 订阅的作者列表 */

@Composable
private fun AuthorList(
    vm: AppViewModel,
    state: EntryListUiState,
    subs: SubscriptionsUiState
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // 顶部输入框：按用户名直接订阅作者
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SakuraTextField(
                value = subs.authorInput,
                onValueChange = vm::onSubscribedAuthorInput,
                label = stringResource(R.string.subs_author_input_label),
                placeholder = stringResource(R.string.subs_author_input_placeholder),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(10.dp))
            SecondaryButton(
                text = stringResource(R.string.subs_author_add),
                onClick = vm::subscribeAuthorFromInput,
                enabled = subs.authorInput.isNotBlank(),
                icon = Icons.Filled.PersonAddAlt
            )
        }
        if (subs.message.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = subs.message,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.ext.textSecondary,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        if (state.authors.isEmpty()) {
            EmptyHint(text = stringResource(R.string.subs_authors_empty))
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
            ) {
                items(state.authors, key = { it.username.lowercase() }) { author ->
                    SubscribedAuthorRow(
                        author = author,
                        onOpen = { vm.openAuthorWorksList(author.username) },
                        onRemove = { vm.toggleSubscribeAuthor(author.username) }
                    )
                }
            }
        }
    }
}

/** 订阅作者行：点名字进入该作者的作品列表，右侧可取消订阅。 */
@Composable
private fun SubscribedAuthorRow(
    author: SubscribedAuthor,
    onOpen: () -> Unit,
    onRemove: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.ext.card)
            .clickable(onClick = onOpen)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.Favorite,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = author.username,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.ext.textSecondary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(4.dp))
        DangerTextButton(
            text = stringResource(R.string.subs_author_remove),
            onClick = onRemove
        )
    }
}

/* ---------------------------------------------------- 收藏夹未登录 */

@Composable
private fun LoginNeeded(onGoLogin: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stringResource(R.string.entry_need_login),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.ext.textSecondary
        )
        Spacer(Modifier.height(16.dp))
        GradientButton(
            text = stringResource(R.string.entry_go_login),
            onClick = onGoLogin,
            modifier = Modifier.width(160.dp)
        )
    }
}
