package com.tabbit.aodl.data

import java.net.URLEncoder

/**
 * 需求（v5.0 新增 1）：浏览页「译 中文」按钮的地址拼装。
 *
 * 默认模板调用 Google 网页翻译代理，不需要任何密钥；用户可在设置里换成任意
 * 支持 URL 传参的翻译服务。
 *
 * 支持的占位符：
 * - `{path}`  站点路径（含查询串），已按 URL 规则编码，如 `%2Fworks%2F123`
 * - `{url}`   完整地址，已编码，可直接作为查询参数值
 * - `{to}`    目标语言，默认 `zh-CN`
 * 另补两个便于自定义服务的原文占位符（不影响上面三个的口径）：
 * - `{pathRaw}` / `{urlRaw}` 未编码的原文
 *
 * 编码与不编码分开两套，是因为 `{url}` 直接拼在查询串里必须编码，
 * 而 `{pathRaw}` 拼在路径里时不能编码。纯函数，可离线断言。
 */
object TranslatePlan {

    const val DEFAULT_TEMPLATE = "https://translate.google.com/translate?sl=auto&hl=zh-CN&tl={to}&u={url}"

    const val DEFAULT_TARGET = "zh-CN"

    private val PLACEHOLDER = Regex("\\{(urlRaw|url|pathRaw|path|to)\\}")

    /** 按模板生成译文地址；模板为空时回落默认模板，目标语言为空时回落 zh-CN。 */
    fun buildUrl(
        template: String,
        pageUrl: String,
        target: String = DEFAULT_TARGET
    ): String {
        val tpl = template.trim().ifEmpty { DEFAULT_TEMPLATE }
        val lang = target.trim().ifEmpty { DEFAULT_TARGET }
        val url = pageUrl.trim()
        val path = pathOf(url)
        return PLACEHOLDER.replace(tpl) { match ->
            when (match.groupValues[1]) {
                "url" -> encode(url)
                "urlRaw" -> url
                "path" -> encode(path)
                "pathRaw" -> path
                else -> lang
            }
        }
    }

    /** 模板里是否包含 `{to}`，用于设置页提示"目标语言会对该模板生效"。 */
    fun usesTarget(template: String): Boolean = PLACEHOLDER.containsMatchIn(template.trim().ifEmpty { DEFAULT_TEMPLATE }) &&
        (template.trim().ifEmpty { DEFAULT_TEMPLATE }).contains("{to}")

    /** 取地址中的站点路径（含查询串，去掉锚点）。 */
    fun pathOf(pageUrl: String): String {
        val value = pageUrl.trim()
        val schemeAt = value.indexOf("://")
        val rest = if (schemeAt >= 0) value.substring(schemeAt + 3) else value
        val slashAt = rest.indexOf('/')
        val pathAndQuery = if (slashAt >= 0) rest.substring(slashAt) else "/"
        return pathAndQuery.substringBefore('#')
    }

    /** 显示用的模板主机名，设置页摘要用。 */
    fun hostOf(template: String): String {
        val tpl = template.trim().ifEmpty { DEFAULT_TEMPLATE }
        val schemeAt = tpl.indexOf("://")
        val rest = if (schemeAt >= 0) tpl.substring(schemeAt + 3) else tpl
        return rest.substringBefore('/').substringBefore('?')
    }

    fun isDefault(template: String): Boolean = template.trim().ifEmpty { DEFAULT_TEMPLATE } == DEFAULT_TEMPLATE

    /**
     * 同一条页面地址是否已经被翻译过一次（避免重复套模板）。
     *
     * 只做保守判断：当前地址的主机与模板主机相同即认为「已在译文视图里」。
     */
    fun looksTranslated(currentUrl: String?, template: String): Boolean {
        val host = hostOf(template)
        val value = currentUrl?.trim().orEmpty()
        return host.isNotEmpty() && value.contains(host)
    }

    fun encode(raw: String): String =
        URLEncoder.encode(raw, "UTF-8").replace("+", "%20")
}