package com.tabbit.aodl.data

/**
 * 需求（v5.0 新增 1）：软件内所有消息弹窗、提示文案的结尾统一追加「喵～」。
 *
 * 放在纯函数层，便于离线断言：
 * 1. 只负责在文案末尾补一个固定后缀，不改动正文内容；
 * 2. 已经以该后缀结尾的文案不会被重复追加——日志与弹窗可能被多层加工，
 *    重复拼接会出现「喵～喵～」；
 * 3. 空文案保持空（不为空提示造出一个孤零零的后缀）。
 */
object NekoText {

    /** 统一后缀。与 `strings.xml` 的 `neko_suffix` 保持一致。 */
    const val SUFFIX = "喵～"

    fun catify(text: String?): String {
        val value = text.orEmpty().trimEnd()
        if (value.isEmpty()) return ""
        return if (value.endsWith(SUFFIX)) value else value + SUFFIX
    }

    fun alreadyCatified(text: String?): Boolean = text.orEmpty().trimEnd().endsWith(SUFFIX)
}