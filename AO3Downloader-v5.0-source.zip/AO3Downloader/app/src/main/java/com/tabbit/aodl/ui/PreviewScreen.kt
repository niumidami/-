package com.tabbit.aodl.ui

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.tabbit.aodl.R
import com.tabbit.aodl.model.PreviewState
import com.tabbit.aodl.ui.theme.ext

/**
 * 全屏 HTML 预览层。
 *
 * 用 WebView 直接渲染 [PreviewState.html]（美化版或原始版），
 * 顶部显示文件名与「美化版 / 原始版」标记，左侧返回箭头关闭预览。
 * 关闭 JS、禁止文件与外链访问，只做本地字符串渲染，
 * 避免作品内嵌脚本或远程资源带来的风险。
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewScreen(
    state: PreviewState,
    onClose: () -> Unit
) {
    val ext = MaterialTheme.ext
    val html = state.html
    var failed by remember(html) { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // ---------------------------------------------------------- 顶栏
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.preview_close),
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Text(
                    text = state.title.ifBlank { stringResource(R.string.preview_title_sample) },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp),
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                StatusChip(
                    text = if (state.original) {
                        stringResource(R.string.preview_badge_original)
                    } else {
                        stringResource(R.string.preview_badge_beautified)
                    },
                    color = if (state.original) {
                        ext.textSecondary
                    } else {
                        MaterialTheme.colorScheme.primary
                    }
                )
            }

            HorizontalDivider(color = ext.cardBorder)

            // ---------------------------------------------------------- 正文
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(ext.logBackground),
                contentAlignment = Alignment.Center
            ) {
                if (failed) {
                    EmptyHint(
                        text = stringResource(R.string.err_read_file),
                        modifier = Modifier.padding(24.dp)
                    )
                } else {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { context ->
                            WebView(context).apply {
                                setBackgroundColor(AndroidColor.TRANSPARENT)
                                settings.javaScriptEnabled = false
                                settings.allowFileAccess = false
                                settings.allowContentAccess = false
                                settings.domStorageEnabled = false
                                settings.builtInZoomControls = true
                                settings.displayZoomControls = false
                                settings.useWideViewPort = true
                                settings.loadWithOverviewMode = true
                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(
                                        view: WebView?,
                                        url: String?
                                    ): Boolean = true

                                    @Suppress("DEPRECATION")
                                    override fun onReceivedError(
                                        view: WebView?,
                                        errorCode: Int,
                                        description: String?,
                                        failingUrl: String?
                                    ) {
                                        super.onReceivedError(view, errorCode, description, failingUrl)
                                        failed = true
                                    }
                                }
                            }
                        },
                        update = { webView ->
                            webView.setBackgroundColor(AndroidColor.TRANSPARENT)
                            webView.loadDataWithBaseURL(
                                null,
                                html,
                                "text/html",
                                "UTF-8",
                                null
                            )
                        },
                        onRelease = { webView ->
                            webView.stopLoading()
                            webView.destroy()
                        }
                    )
                }
            }
        }
    }
}
