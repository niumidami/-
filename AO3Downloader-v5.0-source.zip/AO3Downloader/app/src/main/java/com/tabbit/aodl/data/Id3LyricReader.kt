package com.tabbit.aodl.data

/**
 * ID3v2 内嵌歌词（USLT 帧）读取规则（v5.2）。
 *
 * 纯对象：只对字节数组做结构化解析，可离线跑 JVM 单测。
 * 支持 ID3v2.3 / v2.4 的 USLT 帧，识别四种文本编码
 * （ISO-8859-1 / UTF-16 带 BOM / UTF-16BE / UTF-8）与标签级反同步（unsynchronisation）。
 * 任何结构性异常都返回 null，由调用方退化到其它歌词来源。
 */
object Id3LyricReader {

    private const val HEADER_SIZE = 10

    /** 从文件头字节中提取 USLT 歌词文本；不是 ID3 或没有歌词帧时返回 null。 */
    fun readEmbeddedLyrics(bytes: ByteArray): String? {
        if (bytes.size < HEADER_SIZE) return null
        if (bytes[0] != 'I'.code.toByte() || bytes[1] != 'D'.code.toByte() || bytes[2] != '3'.code.toByte()) return null
        val major = bytes[3].toInt() and 0xFF
        if (major != 3 && major != 4) return null
        val flags = bytes[5].toInt() and 0xFF
        val tagSize = synchsafe(bytes, 6)
        if (tagSize <= 0 || HEADER_SIZE + tagSize > bytes.size) return null

        var body = bytes.copyOfRange(HEADER_SIZE, HEADER_SIZE + tagSize)
        if (flags and 0x80 != 0) body = removeUnsync(body)

        var offset = 0
        if (flags and 0x40 != 0) {
            // 扩展头：v2.3 是「4 字节总大小（不含自身）」，v2.4 是同步安全整数（含自身）
            if (body.size < 4) return null
            offset = if (major == 3) 4 + be32(body, 0) else synchsafe(body, 0)
            if (offset < 0 || offset >= body.size) return null
        }

        while (offset + FRAME_HEADER_SIZE <= body.size) {
            if (body[offset] == 0.toByte()) break // 填充区
            val id = String(body, offset, 4, Charsets.ISO_8859_1)
            if (!id.all { it in 'A'..'Z' || it in '0'..'9' }) break
            val size = if (major == 4) synchsafe(body, offset + 4) else be32(body, offset + 4)
            if (size <= 0 || offset + FRAME_HEADER_SIZE + size > body.size) break
            if (id == FRAME_USLT) return decodeUslt(body, offset + FRAME_HEADER_SIZE, size)
            offset += FRAME_HEADER_SIZE + size
        }
        return null
    }

    /**
     * 解析 USLT 帧体：1 字节编码 + 3 字节语言 + 内容描述（按编码终止）+ 歌词正文。
     */
    private fun decodeUslt(frame: ByteArray, start: Int, size: Int): String? {
        val end = start + size
        if (size < 6 || end > frame.size) return null
        val encoding = frame[start].toInt() and 0xFF
        val twoByteTerminator = encoding == 1 || encoding == 2
        val charset = when (encoding) {
            0 -> Charsets.ISO_8859_1
            1 -> Charsets.UTF_16 // BOM 决定字节序
            2 -> Charsets.UTF_16BE
            3 -> Charsets.UTF_8
            else -> return null
        }

        var cursor = start + 4 // 跳过编码字节与 3 字节语言码
        cursor = if (twoByteTerminator) {
            var i = cursor
            while (i + 1 < end && !(frame[i] == 0.toByte() && frame[i + 1] == 0.toByte())) i += 2
            i + 2
        } else {
            var i = cursor
            while (i < end && frame[i] != 0.toByte()) i++
            i + 1
        }
        if (cursor >= end) return null

        val text = runCatching { String(frame, cursor, end - cursor, charset) }.getOrNull() ?: return null
        return text.trim('\u0000').trim().ifBlank { null }
    }

    /** 同步安全整数：4 字节，每字节只用低 7 位。 */
    private fun synchsafe(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0x7F shl 21) or
            (b[off + 1].toInt() and 0x7F shl 14) or
            (b[off + 2].toInt() and 0x7F shl 7) or
            (b[off + 3].toInt() and 0x7F)

    /** 普通大端 32 位整数（v2.3 帧大小）。 */
    private fun be32(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF shl 24) or
            (b[off + 1].toInt() and 0xFF shl 16) or
            (b[off + 2].toInt() and 0xFF shl 8) or
            (b[off + 3].toInt() and 0xFF)

    /** 反同步还原：去掉 0xFF 后面插入的 0x00。 */
    private fun removeUnsync(b: ByteArray): ByteArray {
        val out = java.io.ByteArrayOutputStream(b.size)
        var i = 0
        while (i < b.size) {
            out.write(b[i].toInt())
            if (b[i] == 0xFF.toByte() && i + 1 < b.size && b[i + 1] == 0.toByte()) i++
            i++
        }
        return out.toByteArray()
    }

    private const val FRAME_HEADER_SIZE = 10
    private const val FRAME_USLT = "USLT"
}
