package com.tabbit.aodl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.tabbit.aodl.R
import com.tabbit.aodl.model.MyTagsUiState
import com.tabbit.aodl.model.SubscriptionsUiState
import com.tabbit.aodl.ui.theme.ext

/**
 * 「我的标签」弹窗（v5.1）。
 *
 * App 内本地收藏的标签名单（**不读 AO3 账号的收藏标签**）：可新增、删除，
 * 点选任意一个标签即进入该 tag 的作品列表（统一卡片格式）。
 */
@Composable
fun MyTagsDialog(
    state: MyTagsUiState,
    onDismiss: () -> Unit,
    onInput: (String) -> Unit,
    onAdd: () -> Unit,
    onRemove: (String) -> Unit,
    onOpen: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.my_tags_title),
                style = MaterialTheme.typography.titleMedium
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = stringResource(R.string.my_tags_pick_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.ext.textSecondary
                )
                Spacer(Modifier.height(10.dp))

                if (state.tags.isEmpty()) {
                    Text(
                        text = stringResource(R.string.my_tags_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.ext.textSecondary
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(state.tags, key = { it.lowercase() }) { tag ->
                            MyTagRow(tag = tag, onOpen = { onOpen(tag) }, onRemove = { onRemove(tag) })
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SakuraTextField(
                        value = state.input,
                        onValueChange = onInput,
                        label = stringResource(R.string.my_tags_input_label),
                        placeholder = stringResource(R.string.my_tags_input_placeholder),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    SecondaryButton(
                        text = stringResource(R.string.my_tags_add),
                        onClick = onAdd,
                        enabled = state.input.isNotBlank(),
                        icon = Icons.Filled.Add
                    )
                }
                if (state.message.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = state.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.ext.textSecondary
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.action_close))
            }
        }
    )
}

/** 单个本地标签行：点击进入该 tag 的作品列表，右侧删除。 */
@Composable
private fun MyTagRow(tag: String, onOpen: () -> Unit, onRemove: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.ext.logBackground)
            .clickable(onClick = onOpen)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.LocalOffer,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(14.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = tag,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.ext.textSecondary,
            modifier = Modifier.size(16.dp)
        )
        IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
            Icon(
                Icons.Filled.Close,
                contentDescription = stringResource(R.string.my_tags_remove),
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

/**
 * 「我的订阅」面板（v5.1）：分「订阅的作品 / 订阅的作者」两栏，各自可点击进入对应列表。
 */
@Composable
fun SubscriptionsDialog(
    state: SubscriptionsUiState,
    onDismiss: () -> Unit,
    onOpenWorks: () -> Unit,
    onOpenAuthors: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.subs_title),
                style = MaterialTheme.typography.titleMedium
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SubscriptionEntry(
                    label = stringResource(R.string.subs_works),
                    count = stringResource(R.string.subs_count_works, state.works.size),
                    onClick = onOpenWorks
                )
                SubscriptionEntry(
                    label = stringResource(R.string.subs_authors),
                    count = stringResource(R.string.subs_count_authors, state.authors.size),
                    onClick = onOpenAuthors
                )
                Text(
                    text = stringResource(R.string.subs_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.ext.textSecondary
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.action_close))
            }
        }
    )
}

/** 订阅面板里的一栏入口：图标 + 名称 + 数量，整行可点。 */
@Composable
private fun SubscriptionEntry(label: String, count: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.ext.logBackground)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.Favorite,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = count,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.ext.textSecondary
        )
        Spacer(Modifier.width(6.dp))
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.ext.textSecondary,
            modifier = Modifier.size(18.dp)
        )
    }
}
