package com.tabbit.aodl.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddToHomeScreen
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.BuildConfig
import com.tabbit.aodl.R
import com.tabbit.aodl.data.NekoText
import com.tabbit.aodl.data.TranslatePlan
import com.tabbit.aodl.model.AppIcon
import com.tabbit.aodl.model.AppSettings
import com.tabbit.aodl.model.DohLinkState
import com.tabbit.aodl.model.DohMethod
import com.tabbit.aodl.model.DohState
import com.tabbit.aodl.model.DownloadFormat
import com.tabbit.aodl.model.FolderTarget
import com.tabbit.aodl.model.IconUiState
import com.tabbit.aodl.model.LanguageMode
import com.tabbit.aodl.model.ReaderFont
import com.tabbit.aodl.model.BeautifyStyle
import com.tabbit.aodl.model.ReaderMode
import com.tabbit.aodl.model.ReaderTheme
import com.tabbit.aodl.model.ThemeMode
import com.tabbit.aodl.net.DohConfig
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel

/**
 * 设置页：各主题分区收进可折叠的 [GroupCard]，点击卡片头部展开/收起。
 * 默认只展开「下载格式」一组，其余收起并显示一行当前状态摘要。
 *
 * 目录选择由 [AppRoot] 持有的 ActivityResultLauncher 触发，本页只负责发起请求。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    vm: AppViewModel,
    onBack: () -> Unit,
    onPickFolder: (FolderTarget) -> Unit
) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val doh by vm.doh.collectAsStateWithLifecycle()
    val icon by vm.icon.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        CenterAlignedTopAppBar(
            title = {
                ScreenTitle(
                    icon = icon,
                    text = stringResource(R.string.screen_settings_title),
                    logoSize = 24.dp
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.cancel),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            },
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
                titleContentColor = MaterialTheme.colorScheme.onBackground
            )
        )

        // 分组卡片纵向铺开；卡片自带折叠，间距由 spacedBy 统一控制
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FormatsSection(settings = settings, vm = vm)
            FolderSection(settings = settings, vm = vm, onPickFolder = onPickFolder)
            DownloadSection(settings = settings, vm = vm)
            DohSection(settings = settings, doh = doh, vm = vm)
            TranslateSection(vm = vm)
            ReaderModeSection(settings = settings, vm = vm)
            BeautifySection(settings = settings, vm = vm)
            IconSection(icon = icon, vm = vm)
            AppearanceSection(settings = settings, vm = vm)
            AboutSection(icon = icon)
        }
    }
}

/* -------------------------------------------------------------- 下载格式 */

@Composable
private fun FormatsSection(settings: AppSettings, vm: AppViewModel) {
    GroupCard(
        title = stringResource(R.string.settings_formats_title),
        subtitle = stringResource(R.string.settings_formats_hint),
        summary = stringResource(
            R.string.group_summary_formats,
            settings.enabledFormats.size,
            DownloadFormat.entries.size
        ),
        stateKey = "formats",
        initiallyExpanded = true
    ) {
        DownloadFormat.entries.forEachIndexed { index, format ->
            SwitchRow(
                title = format.displayName,
                subtitle = ".${format.ext}",
                checked = format in settings.enabledFormats,
                onCheckedChange = { vm.toggleFormat(format, it) }
            )
            if (index != DownloadFormat.entries.lastIndex) {
                HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)
            }
        }
    }
}

/* ---------------------------------------------------------- 命名与下载优化 */

/**
 * 需求 1（自动命名）与需求 6（并行、重试、断点续传）的开关区。
 *
 * 滑杆用本地 state 承接拖动过程，只在整数档位真正变化时才回写，
 * 避免拖动途中反复触发 `setConcurrency` 把运行日志刷满。
 */
@Composable
private fun DownloadSection(settings: AppSettings, vm: AppViewModel) {
    val retrySummary = if (settings.retryCount == 0) {
        stringResource(R.string.settings_retry_none)
    } else {
        stringResource(R.string.settings_retry_value, settings.retryCount)
    }
    GroupCard(
        title = stringResource(R.string.settings_download_title),
        subtitle = stringResource(R.string.settings_download_hint),
        summary = stringResource(R.string.settings_concurrency_value, settings.concurrency) + " · " + retrySummary,
        stateKey = "download"
    ) {
        SwitchRow(
            title = stringResource(R.string.settings_auto_name),
            subtitle = stringResource(R.string.settings_auto_name_hint),
            checked = settings.autoName,
            onCheckedChange = vm::setAutoName
        )
        HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)
        SwitchRow(
            title = stringResource(R.string.settings_resume),
            subtitle = stringResource(R.string.settings_resume_hint),
            checked = settings.resumeEnabled,
            onCheckedChange = vm::setResumeEnabled
        )
        HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)

        var concurrency by remember(settings.concurrency) {
            mutableStateOf(settings.concurrency.toFloat())
        }
        SliderRow(
            label = stringResource(R.string.settings_concurrency),
            value = concurrency,
            valueRange = AppSettings.MIN_CONCURRENCY.toFloat()..AppSettings.MAX_CONCURRENCY.toFloat(),
            steps = AppSettings.MAX_CONCURRENCY - AppSettings.MIN_CONCURRENCY - 1,
            valueText = stringResource(R.string.settings_concurrency_value, concurrency.toInt()),
            onValueChange = { value ->
                concurrency = value
                val picked = value.toInt()
                    .coerceIn(AppSettings.MIN_CONCURRENCY, AppSettings.MAX_CONCURRENCY)
                if (picked != settings.concurrency) vm.setConcurrency(picked)
            }
        )
        Text(
            text = stringResource(R.string.settings_concurrency_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.ext.textSecondary
        )

        var retry by remember(settings.retryCount) { mutableStateOf(settings.retryCount.toFloat()) }
        SliderRow(
            label = stringResource(R.string.settings_retry),
            value = retry,
            valueRange = 0f..AppSettings.MAX_RETRY.toFloat(),
            steps = AppSettings.MAX_RETRY - 1,
            valueText = if (retry.toInt() == 0) {
                stringResource(R.string.settings_retry_none)
            } else {
                stringResource(R.string.settings_retry_value, retry.toInt())
            },
            onValueChange = { value ->
                retry = value
                val picked = value.toInt().coerceIn(0, AppSettings.MAX_RETRY)
                if (picked != settings.retryCount) vm.setRetryCount(picked)
            }
        )
        Text(
            text = stringResource(R.string.settings_retry_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.ext.textSecondary
        )
    }
}

/* -------------------------------------------------------------- 保存位置 */

@Composable
private fun FolderSection(
    settings: AppSettings,
    vm: AppViewModel,
    onPickFolder: (FolderTarget) -> Unit
) {
    val folderSummary = buildString {
        append(
            stringResource(
                if (settings.unifiedSave) R.string.settings_unified_save else R.string.group_summary_folder_split
            )
        )
        if (settings.authorClassify) {
            append(" · ")
            append(stringResource(R.string.settings_author_classify))
        }
    }
    GroupCard(
        title = stringResource(R.string.settings_folder_title),
        subtitle = stringResource(R.string.settings_folder_hint),
        summary = folderSummary,
        stateKey = "folder"
    ) {
        SwitchRow(
            title = stringResource(R.string.settings_unified_save),
            subtitle = stringResource(R.string.settings_unified_save_hint),
            checked = settings.unifiedSave,
            onCheckedChange = vm::setUnifiedSave
        )
        HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)
        SwitchRow(
            title = stringResource(R.string.settings_author_classify),
            subtitle = stringResource(R.string.settings_author_classify_hint),
            checked = settings.authorClassify,
            onCheckedChange = vm::setAuthorClassify
        )
        HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)
        Spacer(Modifier.height(4.dp))

        if (settings.authorClassify) {
            // 需求 2：明确两级目录的最终形态，避免用户误以为文件直接落在所选根目录。
            Text(
                text = stringResource(
                    R.string.settings_folder_classify_hint,
                    DownloadFormat.entries.joinToString(" / ") { it.displayName }
                ),
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.ext.textSecondary
            )
            Spacer(Modifier.height(8.dp))
        } else if (settings.unifiedSave) {
            // 关闭作者分类、但五种格式共用一个根目录时，仍会各建一层格式目录，
            // 否则五种格式会全部混在同一个文件夹里（v4.0 缺陷）。
            Text(
                text = stringResource(
                    R.string.settings_folder_format_hint,
                    DownloadFormat.entries.joinToString(" / ") { it.displayName }
                ),
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.ext.textSecondary
            )
            Spacer(Modifier.height(8.dp))
        }

        if (settings.unifiedSave) {
            FolderRow(
                title = stringResource(R.string.folder_unified),
                value = vm.folderLabel(FolderTarget.Unified),
                onPick = { onPickFolder(FolderTarget.Unified) },
                onClear = { vm.clearFolder(FolderTarget.Unified) }
            )
        } else {
            Text(
                text = stringResource(R.string.settings_per_format_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.ext.textSecondary
            )
            DownloadFormat.entries.forEach { format ->
                val target = FolderTarget.PerFormat(format)
                FolderRow(
                    title = format.displayName,
                    value = vm.folderLabel(target),
                    onPick = { onPickFolder(target) },
                    onClear = { vm.clearFolder(target) }
                )
            }
        }
    }
}

@Composable
private fun FolderRow(
    title: String,
    value: String,
    onPick: () -> Unit,
    onClear: () -> Unit
) {
    val unavailable = value == stringResource(R.string.folder_unavailable)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                color = if (unavailable) MaterialTheme.colorScheme.error else MaterialTheme.ext.textSecondary,
                maxLines = 2
            )
        }
        Spacer(Modifier.width(8.dp))
        SecondaryButton(text = stringResource(R.string.settings_pick_folder), onClick = onPick, icon = Icons.Filled.FolderOpen)
        Spacer(Modifier.width(4.dp))
        DangerTextButton(text = stringResource(R.string.settings_clear_folder), onClick = onClear)
    }
}

/* -------------------------------------------------------------- 安全 DNS */

@Composable
private fun DohSection(
    settings: AppSettings,
    doh: DohState,
    vm: AppViewModel
) {
    var customEndpoint by rememberSaveable(settings.dohEndpoint) { mutableStateOf(settings.dohEndpoint) }

    GroupCard(
        title = stringResource(R.string.settings_doh_title),
        subtitle = stringResource(R.string.settings_doh_subtitle),
        summary = dohStateLabel(doh.linkState),
        stateKey = "doh"
    ) {
        SwitchRow(
            title = stringResource(R.string.settings_doh_enable),
            subtitle = stringResource(R.string.settings_doh_enable_hint),
            checked = settings.dohEnabled,
            onCheckedChange = vm::setDohEnabled
        )
        HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)
        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = stringResource(R.string.settings_doh_state),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            StatusChip(text = dohStateLabel(doh.linkState), color = dohStateColor(doh.linkState))
        }
        if (doh.message.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = NekoText.catify(doh.message),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }

        Spacer(Modifier.height(12.dp))
        ValueRow(title = stringResource(R.string.settings_doh_endpoint), value = settings.dohEndpoint)
        ValueRow(
            title = stringResource(R.string.settings_doh_hosts),
            value = DohConfig.DEFAULT_DOH_HOSTS.joinToString(", ")
        )
        ValueRow(
            title = stringResource(R.string.settings_doh_active),
            value = doh.activeEndpoint ?: stringResource(R.string.settings_doh_none)
        )
        ValueRow(
            title = stringResource(R.string.settings_doh_ips),
            value = doh.resolvedIps.joinToString(", ").ifBlank { stringResource(R.string.settings_doh_none) },
            valueColor = MaterialTheme.colorScheme.primary
        )
        ValueRow(
            title = stringResource(R.string.settings_doh_latency),
            value = if (doh.latencyMs > 0) {
                stringResource(R.string.settings_doh_latency_value, doh.latencyMs.toInt())
            } else {
                stringResource(R.string.settings_doh_none)
            }
        )
        ValueRow(
            title = stringResource(R.string.settings_doh_queries),
            value = doh.queryCount.toString()
        )
        ValueRow(
            title = stringResource(R.string.settings_doh_sys_fallback),
            value = doh.systemFallbackCount.toString(),
            valueColor = if (doh.systemFallbackCount > 0) MaterialTheme.ext.warning else null
        )

        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.settings_doh_method),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = stringResource(R.string.settings_doh_method_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.ext.textSecondary
        )
        Spacer(Modifier.height(8.dp))
        SegmentedRow(
            options = DohMethod.entries.map { it.label to it },
            selected = settings.dohMethod,
            onSelect = vm::setDohMethod
        )

        Spacer(Modifier.height(6.dp))
        SwitchRow(
            title = stringResource(R.string.settings_doh_fallback),
            subtitle = stringResource(R.string.settings_doh_fallback_hint),
            checked = settings.dohFallbackEnabled,
            onCheckedChange = vm::setDohFallbackEnabled
        )

        HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)
        Spacer(Modifier.height(10.dp))

        SakuraTextField(
            value = customEndpoint,
            onValueChange = { customEndpoint = it },
            label = stringResource(R.string.settings_doh_custom),
            placeholder = AppSettings.DEFAULT_DOH_ENDPOINT,
            supportingText = stringResource(R.string.settings_doh_custom_hint),
            singleLine = false,
            imeAction = ImeAction.Done
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryButton(
                text = stringResource(R.string.settings_doh_apply),
                onClick = { vm.setDohEndpoint(customEndpoint) },
                modifier = Modifier.weight(1f)
            )
            SecondaryButton(
                text = stringResource(R.string.settings_doh_reset),
                onClick = {
                    vm.resetDohEndpoint()
                    customEndpoint = AppSettings.DEFAULT_DOH_ENDPOINT
                },
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(10.dp))
        GradientButton(
            text = stringResource(R.string.settings_doh_test),
            onClick = { vm.testDohConnection(quiet = false) },
            enabled = settings.dohEnabled,
            loading = doh.linkState == DohLinkState.TESTING,
            icon = Icons.Filled.NetworkCheck
        )

        HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)
        Spacer(Modifier.height(6.dp))
        // 需求 5：官网登录默认经安全 DNS 代理；网络未受污染时可切直连，省掉一层转发
        SwitchRow(
            title = stringResource(R.string.settings_web_direct),
            subtitle = stringResource(R.string.settings_web_direct_hint),
            checked = settings.webDirect,
            onCheckedChange = vm::setWebDirect
        )
    }
}

@Composable
private fun dohStateLabel(state: DohLinkState): String = when (state) {
    DohLinkState.CONNECTED -> stringResource(R.string.settings_doh_state_connected)
    DohLinkState.FAILED -> stringResource(R.string.settings_doh_state_failed)
    DohLinkState.TESTING -> stringResource(R.string.settings_doh_state_testing)
    DohLinkState.DISABLED -> stringResource(R.string.settings_doh_state_disabled)
    DohLinkState.UNKNOWN -> stringResource(R.string.settings_doh_state_unknown)
}

@Composable
private fun dohStateColor(state: DohLinkState): Color = when (state) {
    DohLinkState.CONNECTED -> MaterialTheme.ext.success
    DohLinkState.FAILED -> MaterialTheme.colorScheme.error
    DohLinkState.TESTING -> MaterialTheme.ext.warning
    DohLinkState.DISABLED, DohLinkState.UNKNOWN -> MaterialTheme.ext.textSecondary
}

/* ------------------------------------------------------------ 中文翻译 */

/**
 * 浏览页「译 中文」的模板与目标语言配置。
 *
 * 模板留空即恢复默认（Google 网页翻译代理，免密钥）；目标语言只替换模板里的
 * `{to}` 占位符，模板不含 `{to}` 时该输入不影响拼出的地址。
 */
@Composable
private fun TranslateSection(vm: AppViewModel) {
    var template by rememberSaveable { mutableStateOf(vm.translateTemplate()) }
    var target by rememberSaveable { mutableStateOf(vm.translateTarget()) }

    GroupCard(
        title = stringResource(R.string.settings_translate_title),
        subtitle = stringResource(R.string.settings_translate_hint),
        summary = target.ifBlank { TranslatePlan.DEFAULT_TARGET },
        stateKey = "translate"
    ) {
        SakuraTextField(
            value = template,
            onValueChange = { template = it },
            label = stringResource(R.string.settings_translate_template),
            placeholder = TranslatePlan.DEFAULT_TEMPLATE,
            supportingText = stringResource(R.string.settings_translate_template_hint),
            singleLine = false,
            imeAction = ImeAction.Done
        )
        Spacer(Modifier.height(10.dp))
        SakuraTextField(
            value = target,
            onValueChange = { target = it },
            label = stringResource(R.string.settings_translate_target),
            placeholder = TranslatePlan.DEFAULT_TARGET,
            supportingText = stringResource(R.string.settings_translate_target_hint),
            singleLine = true,
            imeAction = ImeAction.Done
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryButton(
                text = stringResource(R.string.settings_translate_apply),
                onClick = {
                    vm.setTranslateTemplate(template)
                    vm.setTranslateTarget(target)
                },
                modifier = Modifier.weight(1f)
            )
            SecondaryButton(
                text = stringResource(R.string.settings_translate_reset),
                onClick = {
                    vm.setTranslateTemplate("")
                    vm.setTranslateTarget(TranslatePlan.DEFAULT_TARGET)
                    template = ""
                    target = TranslatePlan.DEFAULT_TARGET
                },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

/* ---------------------------------------------------------- 默认阅读模式 */

/** 番茄式 / AO3 原站两种阅读模式的默认选择；阅读页内仍可随时切换。 */
@Composable
private fun ReaderModeSection(settings: AppSettings, vm: AppViewModel) {
    val modeLabel = if (settings.readerMode == ReaderMode.TOMATO) {
        stringResource(R.string.reader_mode_tomato)
    } else {
        stringResource(R.string.reader_mode_site)
    }
    GroupCard(
        title = stringResource(R.string.settings_reader_mode_title),
        subtitle = stringResource(R.string.settings_reader_mode_hint),
        summary = modeLabel,
        stateKey = "reader_mode"
    ) {
        SegmentedRow(
            options = listOf(
                stringResource(R.string.reader_mode_tomato) to ReaderMode.TOMATO,
                stringResource(R.string.reader_mode_site) to ReaderMode.SITE
            ),
            selected = settings.readerMode,
            onSelect = vm::setReaderMode
        )
    }
}

/* ------------------------------------------------------------ HTML 美化 */

@Composable
private fun BeautifySection(settings: AppSettings, vm: AppViewModel) {
    val beautify = settings.beautify

    var customFont by rememberSaveable(beautify.customFontFamily) { mutableStateOf(beautify.customFontFamily) }
    var customCss by rememberSaveable(beautify.customCss) { mutableStateOf(beautify.customCss) }

    val styleLabel = when (beautify.style) {
        BeautifyStyle.DOCUMENT -> stringResource(R.string.beautify_style_document)
        BeautifyStyle.CLASSIC -> stringResource(R.string.beautify_style_classic)
    }
    val beautifySummary = if (settings.autoBeautify) {
        styleLabel + " · " + stringResource(R.string.group_summary_beautify_auto)
    } else {
        styleLabel
    }
    GroupCard(
        title = stringResource(R.string.settings_beautify_title),
        subtitle = stringResource(R.string.settings_beautify_hint),
        summary = beautifySummary,
        stateKey = "beautify"
    ) {
        SwitchRow(
            title = stringResource(R.string.settings_beautify_auto),
            subtitle = stringResource(R.string.settings_beautify_auto_hint),
            checked = settings.autoBeautify,
            onCheckedChange = vm::setAutoBeautify
        )
        HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)

        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.settings_beautify_style), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        SegmentedRow(
            options = listOf(
                stringResource(R.string.beautify_style_document) to BeautifyStyle.DOCUMENT,
                stringResource(R.string.beautify_style_classic) to BeautifyStyle.CLASSIC
            ),
            selected = beautify.style,
            onSelect = vm::setBeautifyStyle
        )

        if (beautify.style == BeautifyStyle.DOCUMENT) {
            Spacer(Modifier.height(10.dp))
            Text(
                text = stringResource(R.string.settings_beautify_doc_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.ext.textSecondary
            )
        } else {
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.settings_beautify_font), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        SegmentedRow(
            options = listOf(
                stringResource(R.string.font_serif) to ReaderFont.SERIF,
                stringResource(R.string.font_sans) to ReaderFont.SANS,
                stringResource(R.string.font_mono) to ReaderFont.MONO
            ),
            selected = beautify.font,
            onSelect = vm::setBeautifyFont
        )

        Spacer(Modifier.height(12.dp))
        SakuraTextField(
            value = customFont,
            onValueChange = { customFont = it },
            label = stringResource(R.string.settings_beautify_custom_font),
            placeholder = beautify.font.cssFamily,
            singleLine = false,
            supportingText = stringResource(R.string.settings_beautify_custom_font_hint),
            trailing = {
                if (customFont != beautify.customFontFamily) {
                    Text(
                        text = stringResource(R.string.settings_doh_apply),
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clickable {
                                vm.updateBeautify { it.copy(customFontFamily = customFont.trim()) }
                            }
                    )
                }
            }
        )

        SliderRow(
            label = stringResource(R.string.settings_beautify_size),
            value = beautify.fontSizeSp.toFloat(),
            valueRange = 12f..30f,
            valueText = stringResource(R.string.settings_value_sp, beautify.fontSizeSp),
            steps = 17,
            onValueChange = { v -> vm.updateBeautify { it.copy(fontSizeSp = v.toInt()) } }
        )
        SliderRow(
            label = stringResource(R.string.settings_beautify_line),
            value = beautify.lineHeight,
            valueRange = 1.2f..2.8f,
            valueText = stringResource(R.string.settings_value_x, "%.2f".format(beautify.lineHeight)),
            onValueChange = { v -> vm.updateBeautify { it.copy(lineHeight = v) } }
        )
        SliderRow(
            label = stringResource(R.string.settings_beautify_margin),
            value = beautify.marginDp.toFloat(),
            valueRange = 0f..64f,
            valueText = stringResource(R.string.settings_value_dp, beautify.marginDp),
            steps = 15,
            onValueChange = { v -> vm.updateBeautify { it.copy(marginDp = v.toInt()) } }
        )
        SliderRow(
            label = stringResource(R.string.settings_beautify_para),
            value = beautify.paragraphSpacingEm,
            valueRange = 0f..3f,
            valueText = stringResource(R.string.settings_value_em, "%.2f".format(beautify.paragraphSpacingEm)),
            onValueChange = { v -> vm.updateBeautify { it.copy(paragraphSpacingEm = v) } }
        )

        SwitchRow(
            title = stringResource(R.string.settings_beautify_justify),
            checked = beautify.justify,
            onCheckedChange = { v -> vm.updateBeautify { it.copy(justify = v) } }
        )

        Spacer(Modifier.height(4.dp))
        Text(stringResource(R.string.settings_beautify_theme), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        SegmentedRow(
            options = listOf(
                stringResource(R.string.reader_theme_light) to ReaderTheme.LIGHT,
                stringResource(R.string.reader_theme_dark) to ReaderTheme.DARK,
                stringResource(R.string.reader_theme_follow) to ReaderTheme.FOLLOW_APP
            ),
            selected = beautify.theme,
            onSelect = vm::setBeautifyTheme
        )
        }

        Spacer(Modifier.height(14.dp))
        SakuraTextField(
            value = customCss,
            onValueChange = { customCss = it },
            label = stringResource(R.string.settings_beautify_custom_css),
            placeholder = "p { text-indent: 2em; }",
            singleLine = false,
            supportingText = stringResource(R.string.settings_beautify_custom_css_hint),
            imeAction = ImeAction.Done
        )
        if (customCss != beautify.customCss) {
            Spacer(Modifier.height(8.dp))
            SecondaryButton(
                text = stringResource(R.string.settings_doh_apply),
                onClick = { vm.updateBeautify { it.copy(customCss = customCss) } },
                modifier = Modifier.fillMaxWidth()
            )
        }

        SwitchRow(
            title = stringResource(R.string.settings_beautify_keep),
            checked = beautify.keepOriginal,
            onCheckedChange = { v -> vm.updateBeautify { it.copy(keepOriginal = v) } }
        )

        Spacer(Modifier.height(10.dp))
        GradientButton(
            text = stringResource(R.string.settings_beautify_preview),
            onClick = vm::previewSample,
            icon = Icons.Filled.Visibility
        )
    }
}

/* ---------------------------------------------------------- 外观与语言 */

@Composable
private fun AppearanceSection(settings: AppSettings, vm: AppViewModel) {
    val themeLabel = when (settings.theme) {
        ThemeMode.SAKURA_DARK -> stringResource(R.string.theme_sakura_dark)
        ThemeMode.MIDNIGHT -> stringResource(R.string.theme_midnight)
        ThemeMode.SAKURA_LIGHT -> stringResource(R.string.theme_sakura_light)
    }
    val langLabel = when (settings.language) {
        LanguageMode.SYSTEM -> stringResource(R.string.lang_system)
        LanguageMode.ZH -> stringResource(R.string.lang_zh)
        LanguageMode.EN -> stringResource(R.string.lang_en)
    }
    GroupCard(
        title = stringResource(R.string.settings_appearance_title),
        summary = "$themeLabel · $langLabel",
        stateKey = "appearance"
    ) {
        Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        SegmentedRow(
            options = listOf(
                stringResource(R.string.theme_sakura_dark) to ThemeMode.SAKURA_DARK,
                stringResource(R.string.theme_midnight) to ThemeMode.MIDNIGHT,
                stringResource(R.string.theme_sakura_light) to ThemeMode.SAKURA_LIGHT
            ),
            selected = settings.theme,
            onSelect = vm::setThemeMode
        )

        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.bodyMedium)
        Text(
            text = stringResource(R.string.settings_language_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.ext.textSecondary
        )
        Spacer(Modifier.height(8.dp))
        SegmentedRow(
            options = listOf(
                stringResource(R.string.lang_system) to LanguageMode.SYSTEM,
                stringResource(R.string.lang_zh) to LanguageMode.ZH,
                stringResource(R.string.lang_en) to LanguageMode.EN
            ),
            selected = settings.language,
            onSelect = vm::setLanguageMode
        )

        HorizontalDivider(
            color = MaterialTheme.ext.cardBorder,
            thickness = 0.5.dp,
            modifier = Modifier.padding(vertical = 10.dp)
        )
        SwitchRow(
            title = stringResource(R.string.settings_view_adult),
            subtitle = stringResource(R.string.settings_view_adult_hint),
            checked = settings.viewAdult,
            onCheckedChange = vm::setViewAdult
        )
    }
}

/* ------------------------------------------------------------ 应用图标 */

/**
 * 需求 4：应用图标。
 *
 * 四套内置图标各自对应 Manifest 里的一个 `activity-alias`，点选即通过
 * `PackageManager.setComponentEnabledSetting` 真实替换桌面图标；用户上传的图片
 * 存在应用私有目录、写不进 APK，所以只替换应用内的全部图标位（顶栏、底部 Tab、
 * 管理页、关于页），桌面则改用「创建快捷方式」把这张图钉上去——下方文案对此有明确说明。
 */
@Composable
private fun IconSection(icon: IconUiState, vm: AppViewModel) {
    // 图片选择 launcher 必须常驻组合，不能放进折叠卡片的正文里（收起时会被注销）
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        vm.importCustomIcon(uri)
    }
    var confirmDelete by remember { mutableStateOf(false) }

    GroupCard(
        title = stringResource(R.string.settings_icon_title),
        subtitle = stringResource(R.string.settings_icon_hint),
        summary = currentIconLabel(icon),
        stateKey = "icon"
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppLogo(icon = icon, size = 52.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.settings_icon_current),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.ext.textSecondary
                )
                Text(
                    text = currentIconLabel(icon),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = stringResource(R.string.settings_icon_alias, icon.activeIcon.aliasSimple),
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.ext.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        HorizontalDivider(
            color = MaterialTheme.ext.cardBorder,
            thickness = 0.5.dp,
            modifier = Modifier.padding(vertical = 12.dp)
        )

        Text(
            text = stringResource(R.string.settings_icon_builtin_group),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.height(8.dp))
        // weight 必须由 RowScope 的调用点传入，IconCell 内部拿不到 RowScope 接收者。
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AppIcon.entries.forEach { entry ->
                IconCell(
                    label = stringResource(entry.labelRes),
                    selected = icon.choice == entry.name,
                    onClick = { vm.setIconChoice(entry.name) },
                    modifier = Modifier.weight(1f)
                ) {
                    AppLogo(
                        icon = IconUiState(choice = entry.name, activeIcon = entry),
                        size = 42.dp
                    )
                }
            }
            IconCell(
                label = stringResource(R.string.icon_custom),
                selected = icon.useCustom,
                onClick = {
                    if (icon.hasCustom) {
                        vm.setIconChoice(AppIcon.CUSTOM_CHOICE)
                    } else {
                        picker.launch(arrayOf("image/*"))
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                if (icon.customBitmap != null) {
                    AppLogo(
                        icon = IconUiState(
                            choice = AppIcon.CUSTOM_CHOICE,
                            activeIcon = icon.activeIcon,
                            customBitmap = icon.customBitmap
                        ),
                        size = 42.dp
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.ext.cardBorder.copy(alpha = 0.3f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.PhotoLibrary,
                            contentDescription = null,
                            tint = MaterialTheme.ext.textSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        HorizontalDivider(
            color = MaterialTheme.ext.cardBorder,
            thickness = 0.5.dp,
            modifier = Modifier.padding(vertical = 12.dp)
        )

        Text(
            text = stringResource(R.string.settings_icon_custom_group),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        ClickableRow(
            title = if (icon.hasCustom) {
                stringResource(R.string.settings_icon_use_custom)
            } else {
                stringResource(R.string.settings_icon_pick)
            },
            subtitle = stringResource(R.string.settings_icon_pick_hint),
            icon = Icons.Filled.PhotoLibrary,
            enabled = !icon.importing,
            trailing = if (icon.useCustom) stringResource(R.string.settings_icon_in_use) else null,
            onClick = {
                if (icon.hasCustom) {
                    vm.setIconChoice(AppIcon.CUSTOM_CHOICE)
                } else {
                    picker.launch(arrayOf("image/*"))
                }
            }
        )
        if (icon.hasCustom) {
            ClickableRow(
                title = stringResource(R.string.settings_icon_repick),
                subtitle = stringResource(R.string.settings_icon_repick_hint),
                icon = Icons.Filled.AutoAwesome,
                enabled = !icon.importing,
                onClick = { picker.launch(arrayOf("image/*")) }
            )
            ClickableRow(
                title = stringResource(R.string.settings_icon_shortcut),
                subtitle = if (icon.shortcutSupported) {
                    stringResource(R.string.settings_icon_shortcut_hint)
                } else {
                    stringResource(R.string.settings_icon_shortcut_unsupported)
                },
                icon = Icons.Filled.AddToHomeScreen,
                enabled = icon.shortcutSupported && !icon.importing,
                onClick = vm::createDesktopShortcut
            )
            HorizontalDivider(color = MaterialTheme.ext.cardBorder, thickness = 0.5.dp)
            Spacer(Modifier.height(4.dp))
            DangerTextButton(
                text = stringResource(R.string.settings_icon_delete),
                onClick = { confirmDelete = true }
            )
        }
        if (icon.importing) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = stringResource(R.string.settings_icon_importing),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.ext.warning
            )
        }
    }

    if (confirmDelete) {
        IconConfirmDialog(
            title = stringResource(R.string.settings_icon_confirm_title),
            body = stringResource(R.string.settings_icon_confirm_body),
            onDismiss = { confirmDelete = false },
            onConfirm = {
                confirmDelete = false
                vm.clearCustomIcon()
            }
        )
    }
}

/**
 * 图标选择格。`modifier` 一律由调用方传入，因为 `Modifier.weight` 只能在
 * `RowScope` 作用域里调用；`preview` 是格子中间的方形图，内置图标与自定义图
 * 都走同一个 [AppLogo]，保证选中后应用内各处看到的形状一致。
 */
@Composable
private fun IconCell(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    preview: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    val borderColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.ext.cardBorder
    Column(
        modifier = modifier
            .clip(shape)
            .border(BorderStroke(if (selected) 2.dp else 1.dp, borderColor), shape)
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) { preview() }
        Spacer(Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.ext.textSecondary
        )
    }
}

/** 当前生效的图标名：自定义图片优先，否则是桌面 alias 正在用的那套内置图标。 */
@Composable
private fun currentIconLabel(icon: IconUiState): String =
    if (icon.useCustom) stringResource(R.string.icon_custom) else stringResource(icon.activeIcon.labelRes)

/**
 * 删除已上传图片的确认框。样式与 [ManageScreen] 里的清空确认保持一致；
 * 不复用同名 composable 是为了避免同包内出现两个同签名顶层函数造成解析歧义。
 */
@Composable
private fun IconConfirmDialog(
    title: String,
    body: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleMedium) },
        text = { Text(NekoText.catify(body), style = MaterialTheme.typography.bodyMedium) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(stringResource(R.string.confirm), color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel), color = MaterialTheme.ext.textSecondary)
            }
        },
        containerColor = MaterialTheme.ext.card,
        titleContentColor = MaterialTheme.colorScheme.onSurface,
        textContentColor = MaterialTheme.ext.textSecondary
    )
}

/* --------------------------------------------------------------- 关于 */

@Composable
private fun AboutSection(icon: IconUiState) {
    GroupCard(
        title = stringResource(R.string.settings_about_title),
        summary = "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
        stateKey = "about"
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppLogo(icon = icon, size = 46.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
        HorizontalDivider(
            color = MaterialTheme.ext.cardBorder,
            thickness = 0.5.dp,
            modifier = Modifier.padding(vertical = 10.dp)
        )
        ValueRow(
            title = stringResource(R.string.settings_version),
            value = "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
            valueColor = MaterialTheme.colorScheme.primary
        )
        // v5.1：产品定位由「下载器」改为「AO3 美化版客户端」
        ValueRow(
            title = stringResource(R.string.settings_tagline),
            value = stringResource(R.string.settings_tagline_value)
        )
        ValueRow(title = stringResource(R.string.settings_icon_current), value = currentIconLabel(icon))
        ValueRow(
            title = stringResource(R.string.settings_data_source),
            value = stringResource(R.string.settings_data_source_hint)
        )
        ValueRow(
            title = stringResource(R.string.settings_min_android),
            value = stringResource(R.string.settings_min_android_value)
        )
        ValueRow(title = "package", value = BuildConfig.APPLICATION_ID)
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Kotlin · Jetpack Compose · OkHttp · Jsoup · SAF",
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.ext.textSecondary
        )
    }
}
