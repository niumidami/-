package com.tabbit.aodl.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.tabbit.aodl.model.ThemeMode

/* ---------------------------------------------------- 暗樱花粉（默认主题） */

val SakuraBg = Color(0xFF1E1117)
val SakuraCard = Color(0xFF2A1A23)
val SakuraCardBorder = Color(0xFF3A2530)
val SakuraPrimary = Color(0xFFF48FB1)
val SakuraGradientStart = Color(0xFFB3446B)
val SakuraGradientEnd = Color(0xFFF48FB1)
val SakuraTextPrimary = Color(0xFFF8F0F3)
val SakuraTextSecondary = Color(0xFFA08090)
val SakuraLogBg = Color(0xFF170D12)
val ColorErrorRed = Color(0xFFEF5350)
val ColorSuccessGreen = Color(0xFF66BB6A)
val ColorWarnAmber = Color(0xFFFFB74D)

/* ------------------------------------------------------------ 午夜蓝备选 */

val MidnightBg = Color(0xFF10131A)
val MidnightCard = Color(0xFF1A1F2B)
val MidnightCardBorder = Color(0xFF262D3D)
val MidnightPrimary = Color(0xFF8AB4F8)
val MidnightGradientStart = Color(0xFF3D5A98)
val MidnightGradientEnd = Color(0xFF8AB4F8)
val MidnightTextPrimary = Color(0xFFE8ECF4)
val MidnightTextSecondary = Color(0xFF8A93A6)
val MidnightLogBg = Color(0xFF0B0E14)

/* ------------------------------------------------------------ 樱花亮色 */

val LightBg = Color(0xFFFDF7F9)
val LightCard = Color(0xFFFFFFFF)
val LightCardBorder = Color(0xFFEAD9E1)
val LightPrimary = Color(0xFFB3446B)
val LightTextPrimary = Color(0xFF2B2027)
val LightTextSecondary = Color(0xFF8A6E7C)
val LightLogBg = Color(0xFFF6ECF1)

/** Material3 之外的扩展色板：卡片、渐变、日志区、语义色。 */
@Immutable
data class ExtendedColors(
    val card: Color,
    val cardBorder: Color,
    val textSecondary: Color,
    val gradientStart: Color,
    val gradientEnd: Color,
    val logBackground: Color,
    val success: Color,
    val warning: Color,
    val isDark: Boolean
) {
    val buttonBrush: Brush get() = Brush.linearGradient(listOf(gradientStart, gradientEnd))
}

val LocalExtendedColors = staticCompositionLocalOf {
    ExtendedColors(
        card = SakuraCard,
        cardBorder = SakuraCardBorder,
        textSecondary = SakuraTextSecondary,
        gradientStart = SakuraGradientStart,
        gradientEnd = SakuraGradientEnd,
        logBackground = SakuraLogBg,
        success = ColorSuccessGreen,
        warning = ColorWarnAmber,
        isDark = true
    )
}

/** 通过 `MaterialTheme.ext` 读取扩展色板。 */
val MaterialTheme.ext: ExtendedColors
    @Composable
    @ReadOnlyComposable
    get() = LocalExtendedColors.current

private val SakuraDarkScheme = darkColorScheme(
    primary = SakuraPrimary,
    onPrimary = Color(0xFF2A0D1A),
    primaryContainer = Color(0xFF4A2136),
    onPrimaryContainer = SakuraTextPrimary,
    secondary = SakuraGradientStart,
    onSecondary = Color.White,
    background = SakuraBg,
    onBackground = SakuraTextPrimary,
    surface = SakuraBg,
    onSurface = SakuraTextPrimary,
    surfaceVariant = SakuraCard,
    onSurfaceVariant = SakuraTextSecondary,
    outline = SakuraCardBorder,
    error = ColorErrorRed,
    onError = Color.White
)

private val MidnightScheme = darkColorScheme(
    primary = MidnightPrimary,
    onPrimary = Color(0xFF0A1428),
    primaryContainer = Color(0xFF22355C),
    onPrimaryContainer = MidnightTextPrimary,
    secondary = MidnightGradientStart,
    onSecondary = Color.White,
    background = MidnightBg,
    onBackground = MidnightTextPrimary,
    surface = MidnightBg,
    onSurface = MidnightTextPrimary,
    surfaceVariant = MidnightCard,
    onSurfaceVariant = MidnightTextSecondary,
    outline = MidnightCardBorder,
    error = Color(0xFFFF6B6B),
    onError = Color.White
)

private val SakuraLightScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF7D7E3),
    onPrimaryContainer = Color(0xFF3D1425),
    secondary = SakuraPrimary,
    onSecondary = Color(0xFF3D1425),
    background = LightBg,
    onBackground = LightTextPrimary,
    surface = LightBg,
    onSurface = LightTextPrimary,
    surfaceVariant = LightCard,
    onSurfaceVariant = LightTextSecondary,
    outline = LightCardBorder,
    error = Color(0xFFC62828),
    onError = Color.White
)

private val Ao3Typography = Typography(
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 26.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 11.sp,
        lineHeight = 16.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 13.sp,
        lineHeight = 18.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Normal,
        fontSize = 10.sp,
        lineHeight = 14.sp
    )
)

/**
 * 应用主题入口。
 *
 * 默认「暗樱花粉」；`MIDNIGHT` 为深色备选，`SAKURA_LIGHT` 为亮色（便于白天阅读设置页）。
 * [appDark] 供 HTML 美化的"跟随 APP 主题"使用，由调用方按当前模式计算。
 */
@Composable
fun Ao3Theme(
    mode: ThemeMode = ThemeMode.SAKURA_DARK,
    content: @Composable () -> Unit
) {
    val scheme = when (mode) {
        ThemeMode.SAKURA_DARK -> SakuraDarkScheme
        ThemeMode.MIDNIGHT -> MidnightScheme
        ThemeMode.SAKURA_LIGHT -> SakuraLightScheme
    }
    val extended = when (mode) {
        ThemeMode.SAKURA_DARK -> ExtendedColors(
            card = SakuraCard,
            cardBorder = SakuraCardBorder,
            textSecondary = SakuraTextSecondary,
            gradientStart = SakuraGradientStart,
            gradientEnd = SakuraGradientEnd,
            logBackground = SakuraLogBg,
            success = ColorSuccessGreen,
            warning = ColorWarnAmber,
            isDark = true
        )
        ThemeMode.MIDNIGHT -> ExtendedColors(
            card = MidnightCard,
            cardBorder = MidnightCardBorder,
            textSecondary = MidnightTextSecondary,
            gradientStart = MidnightGradientStart,
            gradientEnd = MidnightGradientEnd,
            logBackground = MidnightLogBg,
            success = Color(0xFF5FD08A),
            warning = Color(0xFFFFC46B),
            isDark = true
        )
        ThemeMode.SAKURA_LIGHT -> ExtendedColors(
            card = LightCard,
            cardBorder = LightCardBorder,
            textSecondary = LightTextSecondary,
            gradientStart = SakuraGradientStart,
            gradientEnd = SakuraGradientEnd,
            logBackground = LightLogBg,
            success = Color(0xFF2E7D32),
            warning = Color(0xFFB26A00),
            isDark = false
        )
    }

    CompositionLocalProvider(LocalExtendedColors provides extended) {
        MaterialTheme(
            colorScheme = scheme,
            typography = Ao3Typography,
            content = content
        )
    }
}

/** 该主题模式是否为暗色（供 HTML 美化"跟随 APP 主题"与状态栏配色使用，非 Compose 上下文可调）。 */
fun ThemeMode.isDarkTheme(): Boolean = this != ThemeMode.SAKURA_LIGHT
