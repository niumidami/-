package com.tabbit.aodl.ui

import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.os.Build
import android.widget.ImageView
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** 加载动画素材文件名（放在 `app/src/main/assets/` 下）。 */
const val CAT_LOADING_ASSET = "oiiaioi_cat.gif"

/** 动画帧落盘用的缓存名：ImageDecoder 从文件读比从字节数组读兼容性更好。 */
private const val CAT_LOADING_CACHE = "cat_loading_cache.gif"

/**
 * 需求（v5.0 新增 2）：把界面上的「转圈」换成 oiiaioi cat 动图。
 *
 * 只替换**转圈动画本身**，外层的遮罩、文案与显示位置都由调用方保持原样，
 * 因此下载中、搜索中、登录提取中的语义完全不变。
 *
 * 兼容性：API 28 起用 [AnimatedImageDrawable] 播放动图；更低版本（本项目 minSdk 24）
 * 退化为静态首帧，尺寸占位一致，不会因为解码失败出现空洞。
 * 解码只做一次并缓存在内存里，重复显示不再读磁盘。
 */
@Composable
fun CatLoading(modifier: Modifier = Modifier, size: Dp = 48.dp) {
    val context = LocalContext.current
    var animated by remember { mutableStateOf<AnimatedImageDrawable?>(null) }
    var frame by remember { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(Unit) {
        val bytes = withContext(Dispatchers.IO) {
            runCatching { context.assets.open(CAT_LOADING_ASSET).use { it.readBytes() } }.getOrNull()
        } ?: return@LaunchedEffect

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val decoded = withContext(Dispatchers.IO) {
                runCatching {
                    val file = File(context.cacheDir, CAT_LOADING_CACHE)
                    file.writeBytes(bytes)
                    ImageDecoder.decodeDrawable(ImageDecoder.createSource(file))
                }.getOrNull()
            }
            animated = decoded as? AnimatedImageDrawable
        }
        if (animated == null) {
            frame = withContext(Dispatchers.IO) {
                runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }.getOrNull()
            }?.asImageBitmap()
        }
    }

    val drawable = animated
    when {
        drawable != null -> AndroidView(
            modifier = modifier.size(size),
            factory = { ctx ->
                ImageView(ctx).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setImageDrawable(drawable)
                }
            },
            update = { view ->
                view.scaleType = ImageView.ScaleType.FIT_CENTER
                if (view.drawable !== drawable) view.setImageDrawable(drawable)
                (view.drawable as? AnimatedImageDrawable)?.start()
            },
            onRelease = { view -> (view.drawable as? AnimatedImageDrawable)?.stop() }
        )

        frame != null -> Image(
            bitmap = frame!!,
            contentDescription = null,
            modifier = modifier.size(size),
            contentScale = ContentScale.Fit
        )

        // 素材还没解码完：先占住原尺寸，避免布局跳动
        else -> Box(modifier = modifier.size(size))
    }
}