package com.tabbit.aodl

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.LocaleList
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.data.Prefs
import com.tabbit.aodl.model.LanguageMode
import com.tabbit.aodl.ui.AppRoot
import com.tabbit.aodl.vm.AppViewModel
import java.util.Locale

/**
 * 应用唯一 Activity。
 *
 * 职责：
 * 1. 按用户在设置页选择的语言（跟随系统 / 中文 / English）包装 Context，
 *    使 Compose 之外的系统文案与资源也保持一致；
 * 2. 接收系统分享（ACTION_SEND）与作品深链（ACTION_VIEW）进来的链接或编号，
 *    交给 ViewModel 解析后填入下载页输入框；
 * 3. 监听语言版本号变化，切换语言后重建 Activity 让全部 string resource 生效。
 */
class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(applyLocale(newBase, Prefs(newBase).languageMode()))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)

        setContent {
            val localeVersion by vm.localeVersion.collectAsStateWithLifecycle()
            LaunchedEffect(localeVersion) {
                if (localeVersion != appliedLocaleVersion) {
                    appliedLocaleVersion = localeVersion
                    recreate()
                }
            }
            AppRoot(vm = vm)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** 解析分享 / 深链传入的文本。 */
    private fun handleIntent(intent: Intent?) {
        val raw = when (intent?.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> intent.data?.toString()
            else -> null
        }
        if (!raw.isNullOrBlank()) vm.handleSharedText(raw.trim())
    }

    private companion object {
        /**
         * 已生效的语言版本号（进程级）。
         * Activity 重建后 ViewModel 仍然存活，用进程级变量避免重建后重复触发 recreate。
         */
        var appliedLocaleVersion = 0
    }
}

/**
 * 按 [mode] 包装 Context 的 Locale。
 *
 * [LanguageMode.SYSTEM] 时原样返回，跟随系统语言；
 * 否则写入 Configuration 与 [LocaleList]，并同步 [Locale.setDefault]，
 * 保证 Compose 资源与系统对话框、日期格式都使用所选语言。
 */
private fun applyLocale(base: Context, mode: LanguageMode): Context {
    val locale = when (mode) {
        LanguageMode.SYSTEM -> return base
        LanguageMode.ZH -> Locale.SIMPLIFIED_CHINESE
        LanguageMode.EN -> Locale.ENGLISH
    }

    Locale.setDefault(locale)
    LocaleList.setDefault(LocaleList(locale))

    val config = Configuration(base.resources.configuration)
    config.setLocale(locale)
    config.setLayoutDirection(locale)
    return base.createConfigurationContext(config)
}
