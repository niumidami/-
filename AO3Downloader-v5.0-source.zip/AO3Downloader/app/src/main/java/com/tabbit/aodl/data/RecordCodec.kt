package com.tabbit.aodl.data

/**
 * 通用字段级编解码（v5.1：本地标签 / 本地订阅）。
 *
 * 记录用不可打印分隔符切分：字段 `\u001F`、行 `\u001E`、列表项 `\u001D`。
 * 字段正文里的分隔符、反斜杠与控制字符一律转义成可打印形式（`\\` / `\f` / `\n` / `\r` / `\xNN`），
 * 因此：
 * 1. 写进 SharedPreferences 的 XML 里不会出现非法控制字符；
 * 2. 正文里恰好出现分隔符也不会串行（先转义、再切分）；
 * 3. 不依赖 Android，可直接跑 JVM 单测。
 */
internal object RecordCodec {

    const val FIELD: Char = '\u001F'
    const val ROW: Char = '\u001E'
    const val LIST: Char = '\u001D'

    /** 一行记录里字段数不足时的容错阈值由调用方判断，这里只负责分合。 */
    fun encodeRow(fields: List<String>): String =
        fields.joinToString(FIELD.toString()) { escape(it) }

    /** 拆行；行内字段数由调用方校验，坏行返回 null。 */
    fun decodeRow(row: String): List<String>? {
        if (row.isEmpty()) return null
        return row.split(FIELD).map { unescape(it) }
    }

    fun encodeList(items: List<String>): String =
        items.filter { it.isNotBlank() }.joinToString(LIST.toString()) { escape(it) }

    fun decodeList(raw: String): List<String> =
        if (raw.isEmpty()) emptyList() else raw.split(LIST).map { unescape(it) }.filter { it.isNotBlank() }

    fun escape(text: String): String {
        if (text.isEmpty()) return text
        val sb = StringBuilder(text.length + 8)
        for (ch in text) {
            when {
                ch == '\\' -> sb.append("\\\\")
                ch == FIELD -> sb.append("\\f")
                ch == ROW -> sb.append("\\e")
                ch == LIST -> sb.append("\\d")
                ch == '\n' -> sb.append("\\n")
                ch == '\r' -> sb.append("\\r")
                ch < ' ' || ch == '\u007F' -> sb.append("\\x").append(hex(ch.code))
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun unescape(text: String): String {
        val slash = text.indexOf('\\')
        if (slash < 0) return text
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (ch != '\\' || i + 1 >= text.length) {
                sb.append(ch)
                i++
                continue
            }
            when (text[i + 1]) {
                '\\' -> { sb.append('\\'); i += 2 }
                'f' -> { sb.append(FIELD); i += 2 }
                'e' -> { sb.append(ROW); i += 2 }
                'd' -> { sb.append(LIST); i += 2 }
                'n' -> { sb.append('\n'); i += 2 }
                'r' -> { sb.append('\r'); i += 2 }
                'x' -> {
                    val hex = text.substring(i + 2, minOf(i + 4, text.length))
                    val code = hex.toIntOrNull(16)
                    if (hex.length == 2 && code != null) {
                        sb.append(code.toChar())
                        i += 4
                    } else {
                        sb.append(ch)
                        i++
                    }
                }
                else -> { sb.append(ch); i++ }
            }
        }
        return sb.toString()
    }

    private fun hex(code: Int): String = code.toString(16).padStart(2, '0')
}