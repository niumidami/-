package com.tabbit.aodl.data

/**
 * 同名歌词 / 封面文件的匹配规则（v5.2）。
 *
 * 纯对象：只根据「音频文件名 + 同目录兄弟文件名」推导候选，不碰 Android 与文件系统，
 * 可离线跑 JVM 单测。目录遍历与 URI 解析放在 ViewModel 侧。
 */
object LyricResolver {

    /** 外部歌词扩展名（小写，不含点）。 */
    private val LYRIC_EXTENSIONS = setOf("lrc")

    /** 可用作封面的图片扩展名（小写，不含点）。 */
    private val COVER_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp")

    /** 通用封面文件名（不含扩展名），按优先级排列。 */
    private val GENERIC_COVER_NAMES = listOf("cover", "folder", "front", "album")

    /**
     * 找同名歌词文件：与音频同主名（忽略大小写）且扩展名为 .lrc。
     * 找不到返回 null，由调用方退化到内嵌歌词。
     */
    fun findExternalLyric(trackFileName: String, siblings: Collection<String>): String? {
        val base = baseOf(trackFileName)
        return siblings.firstOrNull { sibling ->
            extensionOf(sibling) in LYRIC_EXTENSIONS && baseOf(sibling).equals(base, ignoreCase = true)
        }
    }

    /**
     * 找封面文件：与音频同主名的图片优先；其次 cover/folder/front/album 等通用名
     * （同优先级内按文件名排序取第一个，保证输出稳定）。找不到返回 null。
     */
    fun findExternalCover(trackFileName: String, siblings: Collection<String>): String? {
        val images = siblings.filter { extensionOf(it) in COVER_EXTENSIONS }
        if (images.isEmpty()) return null
        val base = baseOf(trackFileName)
        images.firstOrNull { baseOf(it).equals(base, ignoreCase = true) }?.let { return it }
        GENERIC_COVER_NAMES.forEach { wanted ->
            images.sorted().firstOrNull { baseOf(it).equals(wanted, ignoreCase = true) }?.let { return it }
        }
        return null
    }

    private fun extensionOf(name: String): String {
        val dot = name.lastIndexOf('.')
        return if (dot > 0 && dot < name.length - 1) name.substring(dot + 1).lowercase() else ""
    }

    private fun baseOf(name: String): String = MusicScanner.displayTitle(name)
}
