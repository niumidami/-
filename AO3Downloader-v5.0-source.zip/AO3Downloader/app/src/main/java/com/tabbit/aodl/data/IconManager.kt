package com.tabbit.aodl.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.tabbit.aodl.model.AppIcon
import java.io.File
import java.io.FileOutputStream

/** 导入用户上传的图标图片的结果。 */
sealed class IconImportResult {
    data class Ok(val sizePx: Int) : IconImportResult()
    data class Failed(val reason: IconImportError) : IconImportResult()
}

enum class IconImportError { NO_ACCESS, NOT_IMAGE, WRITE_FAILED }

/** 创建桌面快捷方式的结果。 */
enum class ShortcutResult { OK, UNSUPPORTED, FAILED }

/**
 * 图标能力（需求 4）的 Android 侧实现。纯判定逻辑在 [IconPlan]，本类只做系统调用。
 *
 * 三件事：
 * 1. **切换桌面图标** —— 对 Manifest 里的 4 个 `activity-alias` 逐个
 *    `setComponentEnabledSetting`，用 `DONT_KILL_APP` 避免切换时进程被杀；
 * 2. **管理用户上传的图片** —— SAF Uri 读流 -> 按目标边长采样解码 -> 居中裁成正方形 ->
 *    缩放到 [TARGET_PX] -> PNG 落到应用私有目录（先写临时文件再改名，避免半截文件），
 *    并在内存里缓存一份供 Compose 直接绘制；
 * 3. **创建桌面快捷方式** —— 走 `ShortcutManagerCompat.requestPinShortcut`，
 *    API 26+ 由系统弹窗确认，API 24/25 自动降级为 `ACTION_INSTALL_SHORTCUT` 广播。
 *
 * 安全约定：图片只存在 `filesDir` 下的应用私有目录，卸载即清除，不写入用户共享存储。
 */
class IconManager(context: Context) {

    private val appContext = context.applicationContext

    @Volatile
    private var cached: Bitmap? = null

    @Volatile
    private var cachedStamp: Long = -1L

    private val iconDir: File
        get() = File(appContext.filesDir, DIR_NAME).apply { if (!exists()) mkdirs() }

    private val customFile: File
        get() = File(iconDir, FILE_NAME)

    // ------------------------------------------------------------ 桌面 alias

    /**
     * 按当前选择同步 4 个 alias 的启用状态，切换后回读一次并返回系统认定的启用项，
     * 供运行日志留证据（正常应恰好一项）。
     */
    fun applyLauncherIcon(choice: String?, builtin: String?, hasCustomImage: Boolean): List<String> {
        val decision = IconPlan.decide(
            rawChoice = choice,
            rawBuiltin = builtin,
            known = AppIcon.knownNames(),
            fallback = AppIcon.DEFAULT.name,
            hasCustomImage = hasCustomImage
        )
        val pm = appContext.packageManager
        IconPlan.enabledStates(AppIcon.knownNames(), decision).forEach { (name, enabled) ->
            val component = componentOf(name)
            val state = if (enabled) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            }
            runCatching { pm.setComponentEnabledSetting(component, state, PackageManager.DONT_KILL_APP) }
        }
        return readEnabledAliases()
    }

    /** 回读 PackageManager，返回当前被标记为启用的 alias 简称。 */
    fun readEnabledAliases(): List<String> {
        val pm = appContext.packageManager
        return AppIcon.entries.mapNotNull { icon ->
            val state = runCatching {
                pm.getComponentEnabledSetting(componentOf(icon.name))
            }.getOrDefault(PackageManager.COMPONENT_ENABLED_STATE_DEFAULT)
            if (state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) icon.aliasSimple else null
        }
    }

    private fun componentOf(iconName: String): ComponentName =
        ComponentName(appContext.packageName, aliasClassOf(iconName))

    private fun aliasClassOf(iconName: String): String =
        "${appContext.packageName}.${AppIcon.fromName(iconName).aliasSimple}"

    // ---------------------------------------------------------- 自定义图片

    /** 私有目录里是否已经存着一张上传的图片。 */
    fun hasCustom(): Boolean = customFile.let { it.exists() && it.length() > 0L }

    /**
     * 读取用户上传的图片；文件未变化时直接返回内存缓存，
     * 避免每次重组都重新解码。文件不存在或解码失败返回 null。
     */
    fun customIcon(): Bitmap? {
        val file = customFile
        if (!file.exists() || file.length() <= 0L) {
            cached = null
            cachedStamp = -1L
            return null
        }
        val stamp = file.lastModified()
        cached?.let { if (stamp == cachedStamp) return it }
        val decoded = runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()
        cached = decoded
        cachedStamp = if (decoded == null) -1L else stamp
        return decoded
    }

    /** 删除已上传的图片并清空内存缓存。 */
    fun clearCustom() {
        cached = null
        cachedStamp = -1L
        runCatching { customFile.delete() }
    }

    /**
     * 从 SAF Uri 导入图片并落盘。
     *
     * 先用 `inJustDecodeBounds` 只读尺寸算采样率，再真正解码，
     * 这样几千万像素的照片也不会一次性撑爆内存。
     */
    fun importCustom(uri: Uri, targetPx: Int = TARGET_PX): IconImportResult {
        val resolver = appContext.contentResolver

        // inJustDecodeBounds 下 decodeStream 一定返回 null，只有尺寸被填进 bounds，
        // 因此这里只关心「能不能打开流」和「尺寸是否被解析出来」两件事。
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        var opened = false
        try {
            resolver.openInputStream(uri)?.use { input ->
                opened = true
                BitmapFactory.decodeStream(input, null, bounds)
            }
        } catch (t: Throwable) {
            return IconImportResult.Failed(IconImportError.NO_ACCESS)
        }
        if (!opened) return IconImportResult.Failed(IconImportError.NO_ACCESS)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            return IconImportResult.Failed(IconImportError.NOT_IMAGE)
        }

        val options = BitmapFactory.Options().apply {
            inSampleSize = IconPlan.sampleSize(bounds.outWidth, bounds.outHeight, targetPx)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = runCatching {
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        }.getOrNull() ?: return IconImportResult.Failed(IconImportError.NOT_IMAGE)

        val scaled = try {
            toSquare(decoded, targetPx)
        } catch (t: Throwable) {
            decoded.recycle()
            return IconImportResult.Failed(IconImportError.NOT_IMAGE)
        }

        val written = runCatching {
            val tmp = File(iconDir, "$FILE_NAME.tmp")
            FileOutputStream(tmp).use { out ->
                scaled.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
            }
            // 先写临时文件再改名，替换失败时保留旧图而不是留下半截文件
            if (!tmp.renameTo(customFile)) {
                tmp.copyTo(customFile, overwrite = true)
                tmp.delete()
            }
            customFile.exists() && customFile.length() > 0L
        }.getOrDefault(false)

        if (!written) {
            scaled.recycle()
            return IconImportResult.Failed(IconImportError.WRITE_FAILED)
        }

        cached = scaled
        cachedStamp = customFile.lastModified()
        return IconImportResult.Ok(scaled.width)
    }

    /** 居中裁成最大内接正方形后缩放到 [targetPx]，中间位图及时回收。 */
    private fun toSquare(source: Bitmap, targetPx: Int): Bitmap {
        val (x, y, size) = IconPlan.centerCrop(source.width, source.height)
            ?: throw IllegalArgumentException("bad bitmap size")
        val cropped = Bitmap.createBitmap(source, x, y, size, size)
        if (cropped !== source) source.recycle()
        val scaled = Bitmap.createScaledBitmap(cropped, targetPx, targetPx, true)
        if (scaled !== cropped) cropped.recycle()
        return scaled
    }

    // --------------------------------------------------------- 桌面快捷方式

    fun shortcutSupported(): Boolean =
        runCatching { ShortcutManagerCompat.isRequestPinShortcutSupported(appContext) }.getOrDefault(false)

    /**
     * 用指定图片请求固定一个桌面快捷方式。
     *
     * Intent 必须显式指向**当前启用的那个 alias**：alias 被禁用后系统不再解析它，
     * 快捷方式会变成点不动的死图标。[bitmap] 为空时退回默认内置图标。
     */
    fun createShortcut(label: String, bitmap: Bitmap?, aliasBuiltinName: String?): ShortcutResult {
        if (!shortcutSupported()) return ShortcutResult.UNSUPPORTED
        val pkg = appContext.packageName
        val aliasClass = aliasClassOf(aliasBuiltinName ?: AppIcon.DEFAULT.name)
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(pkg, aliasClass)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val icon = bitmap?.let { IconCompat.createWithBitmap(it) }
            ?: IconCompat.createWithResource(appContext, AppIcon.DEFAULT.logoRes)
        val info = ShortcutInfoCompat.Builder(appContext, SHORTCUT_ID)
            .setShortLabel(label)
            .setIntent(intent)
            .setIcon(icon)
            .build()
        val ok = runCatching {
            ShortcutManagerCompat.requestPinShortcut(appContext, info, null)
        }.getOrDefault(false)
        return if (ok) ShortcutResult.OK else ShortcutResult.FAILED
    }

    companion object {
        /** 落盘与绘制用的边长（像素）。256 足够顶栏/Tab/关于页各处清晰显示。 */
        const val TARGET_PX = 256

        private const val DIR_NAME = "icons"
        private const val FILE_NAME = "custom.png"
        private const val SHORTCUT_ID = "aodl_custom_icon"
    }
}
