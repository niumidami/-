package com.tabbit.aodl.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.model.FolderTarget
import com.tabbit.aodl.ui.theme.Ao3Theme
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel

/**
 * 底部导航的四格（v5.1 导航重构）。
 *
 * 顺序固定为 首页 → 书架 → 下载 → 我的：
 * - 首页：站点搜索（原「搜索作品」子页升为一级入口），冷启动默认停在这里；
 * - 书架：阅读历史 / 书签 / 书架；
 * - 下载：粘贴编号批量下载与「搜索作者」两区，页内用分段控件切换；
 * - 我的：账号，以及原「管理」页并入的下载管理（格式 / 保存位置 / 运行日志）。
 *
 * 原「管理」一级入口取消，原「浏览」子页整体删除。
 */
enum class MainTab { HOME, SHELF, DOWNLOAD, ACCOUNT }

@Composable
fun AppRoot(vm: AppViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val preview by vm.preview.collectAsStateWithLifecycle()
    val icon by vm.icon.collectAsStateWithLifecycle()
    val webLogin by vm.webLogin.collectAsStateWithLifecycle()
    val browser by vm.browser.collectAsStateWithLifecycle()
    val reader by vm.reader.collectAsStateWithLifecycle()
    val entryList by vm.entryList.collectAsStateWithLifecycle()
    val music by vm.music.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableStateOf(MainTab.HOME) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var pendingFolder by remember { mutableStateOf<FolderTarget?>(null) }

    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        val target = pendingFolder
        pendingFolder = null
        if (target != null) vm.onFolderPicked(target, uri)
    }

    Ao3Theme(mode = settings.theme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            if (showSettings) {
                SettingsScreen(
                    vm = vm,
                    onBack = { showSettings = false },
                    onPickFolder = { target ->
                        pendingFolder = target
                        folderPicker.launch(null)
                    }
                )
            } else {
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.ext.card,
                            tonalElevation = 0.dp
                        ) {
                            NavigationBarItem(
                                selected = tab == MainTab.HOME,
                                onClick = { tab = MainTab.HOME },
                                // 首页 Tab 的图标位跟随应用图标，上传的图片会一并生效
                                icon = { AppLogo(icon = icon, size = 24.dp) },
                                label = { Text(stringResource(R.string.tab_home)) },
                                colors = navColors()
                            )
                            NavigationBarItem(
                                selected = tab == MainTab.SHELF,
                                onClick = { tab = MainTab.SHELF },
                                icon = { Icon(Icons.Filled.CollectionsBookmark, contentDescription = null) },
                                label = { Text(stringResource(R.string.tab_shelf)) },
                                colors = navColors()
                            )
                            NavigationBarItem(
                                selected = tab == MainTab.DOWNLOAD,
                                onClick = { tab = MainTab.DOWNLOAD },
                                icon = { Icon(Icons.Filled.Download, contentDescription = null) },
                                label = { Text(stringResource(R.string.tab_download)) },
                                colors = navColors()
                            )
                            NavigationBarItem(
                                selected = tab == MainTab.ACCOUNT,
                                onClick = { tab = MainTab.ACCOUNT },
                                icon = { Icon(Icons.Filled.Person, contentDescription = null) },
                                label = { Text(stringResource(R.string.tab_account)) },
                                colors = navColors()
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (tab) {
                            MainTab.HOME -> HomeScreen(
                                vm = vm,
                                onOpenSettings = { showSettings = true }
                            )
                            MainTab.SHELF -> ShelfScreen(vm = vm)
                            MainTab.DOWNLOAD -> DownloadTabScreen(
                                vm = vm,
                                onOpenSettings = { showSettings = true },
                                onGoAccount = { tab = MainTab.ACCOUNT }
                            )
                            MainTab.ACCOUNT -> AccountScreen(
                                vm = vm,
                                onOpenSettings = { showSettings = true },
                                // 需求 5：跳转官网登录层，由用户自行登录后提取 Cookie
                                onOpenWebLogin = { vm.openWebLogin() }
                            )
                        }
                    }
                }
            }

            // 全屏预览层（WebView 渲染美化效果）
            if (preview.visible) {
                PreviewScreen(
                    state = preview,
                    onClose = { vm.closePreview() }
                )
            }

            // 内置浏览页：作品 / tag 的落地页（快捷入口与卡片点击后的通用 WebView 容器）
            if (browser.visible) {
                BrowserScreen(
                    vm = vm,
                    onClose = { vm.closeBrowser() }
                )
            }

            // 阅读页：番茄 / 原站两种模式（需求 v5.0 新增 3），盖在浏览页之上，关闭后回到浏览页
            if (reader.visible) {
                ReaderScreen(
                    vm = vm,
                    onClose = { vm.closeReader() }
                )
            }

            // v5.1：五类快捷入口的卡片列表页（全部作品 / tag / 作者 / 收藏夹 / 订阅名单）
            if (entryList.visible) {
                EntryListScreen(vm = vm)
            }

            // v5.1：本地音乐页（SAF 选文件夹 + 音频列表）
            if (music.visible) {
                LocalMusicScreen(
                    vm = vm,
                    onPickFolder = {
                        pendingFolder = FolderTarget.Music
                        folderPicker.launch(null)
                    }
                )
            }

            // v5.2：App 内桌面歌词条，悬浮在页面之上、可拖动，随播放进度高亮
            if (music.lyricBar && music.current != null) {
                DesktopLyricBar(vm = vm)
            }

            // 需求 5：官网登录层，盖在最上面，提取成功后自动关闭回到账号页
            if (webLogin.visible) {
                LoginWebScreen(
                    vm = vm,
                    onClose = { vm.closeWebLogin() }
                )
            }
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = MaterialTheme.colorScheme.primary,
    selectedTextColor = MaterialTheme.colorScheme.primary,
    unselectedIconColor = MaterialTheme.ext.textSecondary,
    unselectedTextColor = MaterialTheme.ext.textSecondary,
    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
)