package com.tabbit.aodl.data

import com.tabbit.aodl.model.DownloadFormat
import com.tabbit.aodl.model.WorkMeta

/**
 * 文件名生成器（需求 1）。
 *
 * 规则：
 * 1. 标题与作者都拿到 → `作品名 by 作者名.<后缀>`（多作者以 `, ` 连接）；
 * 2. 只拿到标题 → `作品名.<后缀>`；
 * 3. 两者都拿不到 → 回退为 **作品 ID** 命名 `<workId>.<后缀>`；
 * 4. 作品 ID 也为空 → 兜底常量 [FALLBACK_BASE]。
 *
 * 清洗：替换文件系统非法字符与控制字符、折叠连续空白、去首尾点与空格，
 * 标题段截断到 [MAX_TITLE]、作者段截断到 [MAX_AUTHOR]、
 * 完整文件名（含扩展名）截断到 [MAX_TOTAL]，保证在 FAT32/ext4/FUSE 上都可写。
 *
 * 本文件不依赖任何 Android 框架类，可在纯 JVM 下直接断言。
 */
object FileNameBuilder {

    /** 文件系统保留字符（Windows/Android/FUSE 通用）与 C0/C1 控制字符。 */
    private val ILLEGAL = Regex("[\\\\/:*?\"<>|\\u0000-\\u001F\\u007F]")

    private val WHITESPACE = Regex("\\s+")

    /** 断点续传用的临时文件后缀。 */
    const val PART_SUFFIX = ".part"

    const val FALLBACK_BASE = "AO3-work"

    /** 分隔符按用户要求使用 "by"。 */
    const val AUTHOR_SEPARATOR = " by "

    private const val MAX_TITLE = 80
    private const val MAX_AUTHOR = 40
    private const val MAX_TOTAL = 120

    /**
     * 生成最终文件名（含扩展名）。
     *
     * @param meta 作品页预解析结果；为 null 表示预解析失败，直接回退作品 ID
     * @param workId 作品编号，命名失败时的回退
     * @param serverSuggested 服务端 `Content-Disposition` 建议名，仅作最后兜底
     */
    fun build(
        meta: WorkMeta?,
        workId: String,
        format: DownloadFormat,
        serverSuggested: String? = null
    ): String {
        val base = baseName(meta, workId)
            .ifBlank { clean(serverSuggested.orEmpty().removeSuffix(".${format.ext}"), MAX_TOTAL) }
            .ifBlank { clean(workId, MAX_TOTAL) }
            .ifBlank { FALLBACK_BASE }
        return appendExt(base, format)
    }

    /** 不含扩展名的主干部分，供目录名与日志复用。 */
    fun baseName(meta: WorkMeta?, workId: String): String {
        val title = clean(meta?.title.orEmpty(), MAX_TITLE)
        val authors = clean(meta?.authorLabel.orEmpty(), MAX_AUTHOR)
        return when {
            title.isNotBlank() && authors.isNotBlank() -> "$title$AUTHOR_SEPARATOR$authors"
            title.isNotBlank() -> title
            authors.isNotBlank() -> authors
            else -> clean(workId, MAX_TOTAL)
        }
    }

    /**
     * 目录名清洗：作者名会作为一级目录名，必须比文件名更严格——
     * 不允许 `.` / `..`（会被当成相对路径），也不允许以空格或点结尾。
     */
    fun dirName(raw: String, fallback: String): String {
        val cleaned = clean(raw, MAX_TITLE)
            .trim('.', ' ')
        val normalized = cleaned.replace(Regex("^[.\\s]+"), "")
        return when {
            normalized.isEmpty() || normalized == "." || normalized == ".." -> fallback
            else -> normalized
        }
    }

    /** 断点续传的临时文件名。 */
    fun partName(finalName: String): String = "$finalName$PART_SUFFIX"

    /** 从临时文件名还原正式文件名。 */
    fun finalNameOf(partName: String): String = partName.removeSuffix(PART_SUFFIX)

    /**
     * 清洗单个片段：非法字符替换为 `_`，空白折叠为单空格，
     * 去首尾空白与点，超长时截断并再次去掉截断产生的尾部点/空格。
     */
    fun clean(raw: String, max: Int): String {
        if (raw.isBlank()) return ""
        val replaced = ILLEGAL.replace(raw, "_")
        val collapsed = WHITESPACE.replace(replaced, " ").trim()
        val stripped = collapsed.trim('.', ' ', '\u00A0')
        if (stripped.isEmpty()) return ""
        if (stripped.length <= max) return stripped
        // 截断后可能落在 "_"/空格/点上，需要再清理一次尾部
        return stripped.take(max).trimEnd('.', ' ', '_').ifEmpty { stripped.take(max) }
    }

    /** 拼接扩展名，并按 [MAX_TOTAL] 收紧主干长度。 */
    private fun appendExt(base: String, format: DownloadFormat): String {
        val ext = ".${format.ext}"
        val room = MAX_TOTAL - ext.length
        val trimmed = if (base.length > room) {
            base.take(room).trimEnd('.', ' ', '_').ifEmpty { base.take(room) }
        } else {
            base
        }
        val final = trimmed.ifBlank { FALLBACK_BASE }
        return if (final.endsWith(ext, ignoreCase = true)) final else "$final$ext"
    }
}
