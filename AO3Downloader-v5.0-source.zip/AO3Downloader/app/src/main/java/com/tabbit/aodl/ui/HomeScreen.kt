package com.tabbit.aodl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tabbit.aodl.R
import com.tabbit.aodl.data.CopyTarget
import com.tabbit.aodl.data.WorkSearchPaging
import com.tabbit.aodl.model.WorkItem
import com.tabbit.aodl.model.WorkSearchUiState
import com.tabbit.aodl.ui.theme.ext
import com.tabbit.aodl.vm.AppViewModel

/**
 * 首页（v5.1：按设计图重排 + 结果页筛选与分页）。
 *
 * **搜索前**是初始态：圆形 AO3 logo 居中靠上 → 其下一条搜索框（输入框 + 搜索按钮）
 * → 快捷入口区被 [Spacer] 配重推到页面下部（全部作品 / 我的订阅 / 我的标签 / 收藏夹 / 本地音乐）。
 * 五类入口统一落到 [EntryListScreen] 的卡片列表；「我的标签」「我的订阅」先出本地弹窗再进入。
 *
 * **搜索后**切换为结果态：顶部保留一条紧凑搜索行便于改词重搜，其下一行是结果工具条
 * （「筛选」入口 + 命中条数），列表复用统一的 [WorkCard]（`showDownload = false`，
 * 首页不出现任何下载控件），底部是仿 AO3 的分页条（每页 20 条）。
 *
 * 页内不再有子页切换控件——原「下载 / 搜索作者」两区已随底部「下载」格独立成页，
 * 原「浏览」页整体删除；顶栏只用于标注当前页并提供设置入口。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: AppViewModel,
    onOpenSettings: () -> Unit
) {
    val icon by vm.icon.collectAsStateWithLifecycle()
    val state by vm.workSearch.collectAsStateWithLifecycle()
    val myTags by vm.myTags.collectAsStateWithLifecycle()
    val subs by vm.subscriptions.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    val searched = state.query.isNotBlank()

    Column(modifier = Modifier.fillMaxSize()) {
        CenterAlignedTopAppBar(
            title = {
                ScreenTitle(icon = icon, text = stringResource(R.string.screen_home_title))
            },
            actions = {
                IconButton(onClick = onOpenSettings) {
                    Icon(
                        Icons.Filled.Settings,
                        contentDescription = stringResource(R.string.action_settings),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            },
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
                titleContentColor = MaterialTheme.colorScheme.onBackground
            )
        )

        if (!searched) {
            HomeLanding(vm = vm, state = state)
        } else {
            HomeResults(vm = vm, state = state, onCopy = { target, item ->
                copyWorkField(vm, clipboard, target, item)
            })
        }
    }

    // 「我的标签」弹窗：本地标签名单，单选进入该 tag 的作品列表
    if (myTags.visible) {
        MyTagsDialog(
            state = myTags,
            onDismiss = vm::closeMyTagsDialog,
            onInput = vm::onMyTagInput,
            onAdd = vm::addMyTag,
            onRemove = vm::removeMyTag,
            onOpen = vm::openMyTag
        )
    }

    // 「我的订阅」面板：订阅的作品 / 订阅的作者两栏，各自可进入
    if (subs.panelOpen) {
        SubscriptionsDialog(
            state = subs,
            onDismiss = vm::closeSubscriptionsPanel,
            onOpenWorks = vm::openSubscribedWorks,
            onOpenAuthors = vm::openSubscribedAuthors
        )
    }
}

/* ------------------------------------------------ 初始态：logo + 搜索 + 快捷入口 */

@Composable
private fun HomeLanding(vm: AppViewModel, state: WorkSearchUiState) {
    val icon by vm.icon.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 圆形 AO3 logo 居中靠上
        Spacer(Modifier.height(48.dp))
        AppLogo(icon = icon, size = 96.dp, cornerRatio = 0.5f)
        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.settings_tagline_value),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.ext.textSecondary,
            textAlign = TextAlign.Center
        )

        // 其下一条搜索框
        Spacer(Modifier.height(24.dp))
        SearchRow(vm = vm, state = state)
        Spacer(Modifier.height(6.dp))
        Text(
            text = stringResource(R.string.work_search_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.ext.textSecondary,
            modifier = Modifier.fillMaxWidth()
        )
        if (state.error.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            ErrorBanner(text = state.error, shape = RoundedCornerShape(14.dp))
        }

        // 快捷入口区落在页面下部（五类入口：全部作品 / 我的订阅 / 我的标签 / 收藏夹 / 本地音乐）
        Spacer(Modifier.weight(1f))
        Column(modifier = Modifier.fillMaxWidth()) {
            SectionTitle(text = stringResource(R.string.search_entries_title))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                EntryCard(
                    icon = Icons.Filled.Public,
                    label = stringResource(R.string.search_entry_all),
                    onClick = vm::openSiteWorksList,
                    modifier = Modifier.weight(1f)
                )
                EntryCard(
                    icon = Icons.Filled.Favorite,
                    label = stringResource(R.string.search_entry_subs),
                    onClick = vm::openSubscriptionsPanel,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                EntryCard(
                    icon = Icons.Filled.LocalOffer,
                    label = stringResource(R.string.search_entry_tags),
                    onClick = vm::openMyTagsDialog,
                    modifier = Modifier.weight(1f)
                )
                EntryCard(
                    icon = Icons.Filled.Bookmarks,
                    label = stringResource(R.string.search_entry_bookmarks),
                    onClick = vm::openBookmarksList,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                EntryCard(
                    icon = Icons.Filled.MusicNote,
                    label = stringResource(R.string.search_entry_music),
                    onClick = vm::openLocalMusic,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

/** 快捷入口卡片：图标 + 文案居中，点击进入对应浏览页。 */
@Composable
private fun EntryCard(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(MaterialTheme.ext.card)
            .border(1.dp, MaterialTheme.ext.cardBorder, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

/* ---------------------------------------------------- 结果态：搜索行 + 结果列表 */

@Composable
private fun HomeResults(
    vm: AppViewModel,
    state: WorkSearchUiState,
    onCopy: (CopyTarget, WorkItem) -> Unit
) {
    // 总页数：优先按命中条数算；解析不到条数时退回「已翻到第 N 页且还有下一页」的保守口径
    val pages = WorkSearchPaging.pageCount(state.totalCount).let { counted ->
        if (counted > 1) counted else if (state.hasMore) state.page + 1 else counted
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(4.dp))
            SearchRow(vm = vm, state = state)
            Spacer(Modifier.height(10.dp))
            ResultToolbar(vm = vm, state = state)
            if (state.error.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                ErrorBanner(text = state.error, shape = RoundedCornerShape(14.dp))
            }
        }

        when {
            state.loading && state.works.isEmpty() -> CenterLoading()

            state.works.isEmpty() -> EmptyHint(text = stringResource(R.string.work_search_no_result))

            else -> LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
            ) {
                items(state.works, key = { it.id + "|" + it.title }) { item ->
                    WorkCard(
                        item = item,
                        showDownload = false,
                        onCopy = { target -> onCopy(target, item) },
                        onOpenWork = { vm.openBrowserWork(item.id) },
                        onOpenAuthor = { vm.openBrowserAuthor(it) },
                        onOpenTag = { vm.openBrowserTag(it) },
                        onAddShelf = { vm.addToShelfFrom(item) }
                    )
                }
                if (pages > 1) {
                    item {
                        PagerBar(current = state.page, pages = pages, onGo = vm::goToSearchPage)
                    }
                }
            }
        }
    }

    if (state.filterPanelOpen) {
        SearchFilterSheet(
            options = state.filterOptions,
            initial = state.filters,
            loading = state.filterLoading,
            onDismiss = vm::closeSearchFilter,
            onApply = vm::applySearchFilters,
            onReset = vm::resetSearchFilters
        )
    }
}

/** 结果工具条：「筛选」入口（带生效项数）+ 命中条数。 */
@Composable
private fun ResultToolbar(vm: AppViewModel, state: WorkSearchUiState) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val active = state.filters.activeCount()
        SecondaryButton(
            text = if (active > 0) {
                stringResource(R.string.filter_button_active, active)
            } else {
                stringResource(R.string.filter_button)
            },
            onClick = vm::openSearchFilter,
            icon = Icons.Filled.FilterList
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = state.totalLabel.ifBlank {
                stringResource(R.string.work_search_count, state.works.size)
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.ext.textSecondary,
            maxLines = 1,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f)
        )
    }
}

/** 仿 AO3 分页条：上一页 / 页码窗口（跳段用省略号）/ 下一页。结果页与入口列表页共用。 */
@Composable
internal fun PagerBar(current: Int, pages: Int, onGo: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        PagerCell(
            label = stringResource(R.string.pager_prev),
            enabled = current > 1,
            active = false,
            onClick = { onGo(current - 1) }
        )
        WorkSearchPaging.pageWindow(current, pages).forEach { page ->
            if (page == null) {
                Text(
                    text = "…",
                    fontSize = 12.sp,
                    color = MaterialTheme.ext.textSecondary,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
            } else {
                PagerCell(
                    label = page.toString(),
                    enabled = true,
                    active = page == current,
                    onClick = { onGo(page) }
                )
            }
        }
        PagerCell(
            label = stringResource(R.string.pager_next),
            enabled = current < pages,
            active = false,
            onClick = { onGo(current + 1) }
        )
    }
}

@Composable
private fun PagerCell(label: String, enabled: Boolean, active: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = Modifier
            .padding(horizontal = 3.dp)
            .clip(shape)
            .background(
                if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.ext.logBackground
            )
            .border(
                1.dp,
                if (active) MaterialTheme.colorScheme.primary else MaterialTheme.ext.cardBorder,
                shape
            )
            .clickable(enabled = enabled && !active, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = when {
                active -> MaterialTheme.colorScheme.primary
                enabled -> MaterialTheme.colorScheme.onSurface
                else -> MaterialTheme.ext.textSecondary.copy(alpha = 0.5f)
            }
        )
    }
}

/** 搜索行：关键词输入框 + 搜索按钮，初始态与结果态共用。 */
@Composable
private fun SearchRow(vm: AppViewModel, state: WorkSearchUiState) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        SakuraTextField(
            value = state.queryInput,
            onValueChange = vm::onSearchQueryChange,
            label = stringResource(R.string.work_search_input_label),
            placeholder = stringResource(R.string.work_search_input_placeholder),
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(10.dp))
        GradientButton(
            text = stringResource(R.string.work_search_button),
            onClick = { vm.searchWorks() },
            enabled = state.queryInput.isNotBlank(),
            loading = state.loading && state.works.isEmpty(),
            icon = Icons.Filled.Search,
            modifier = Modifier.width(132.dp)
        )
    }
}