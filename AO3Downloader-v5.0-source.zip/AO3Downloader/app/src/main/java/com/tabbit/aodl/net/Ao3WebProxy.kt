package com.tabbit.aodl.net

import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import com.tabbit.aodl.data.WebLoginPlan
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

/**
 * 需求 5：把 WebView 对 AO3 的请求改道到「安全 DNS（DoH）+ OkHttp」。
 *
 * 为什么需要它：`WebView` 走的是系统 DNS，而本应用绕过污染靠的是自建 [DohDns]，
 * 两者不共用解析结果。不做代理的话，官网登录页在污染网络下根本打不开。
 *
 * 工作方式（在 `shouldInterceptRequest` 里同步执行，该回调本就在后台线程）：
 * 1. 非 AO3 主机名一律返回 null，交回 WebView 原生加载，代理面收窄；
 * 2. 发请求前把 `CookieManager` 里的 Cookie 塞进 `Cookie` 头，
 *    收响应后把每条 `Set-Cookie` 原文写回 `CookieManager`，双向同步；
 * 3. 3xx 由代理自己跟随（含主框架），因此登录 POST 的 302 不会漏掉中途下发的 Cookie；
 * 4. 带 [WebLoginPlan.POST_MARKER] 的地址还原成真实 POST，补上 `WebResourceRequest`
 *    拿不到的表单 body；拿不到标记的 POST 直接放行给 WebView（它自己有 body），
 *    并通过 [onPostFallback] 告知调用方，避免静默丢字段。
 *
 * 失败策略：任何异常都返回 null，让 WebView 自己再试一次原生加载。
 * 在 DNS 未被污染的网络里这反而能成功，比直接吐一个假错误页更有用。
 */
class Ao3WebProxy(
    private val dns: DohDns,
    /** 逃生开关关闭（= WebView 直连）时，代理整体不生效。 */
    @Volatile var enabled: Boolean = true,
    /** 拿不到 POST body、只能回退原生提交时的回调，仅用于提示，不含 URL。 */
    private val onPostFallback: () -> Unit = {}
) {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(dns)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            // 重定向必须自己跟随，否则拿不到 302 上的 Set-Cookie
            .followRedirects(false)
            .followSslRedirects(false)
            .retryOnConnectionFailure(true)
            .build()
    }

    /**
     * 最近一次主框架请求的最终地址（跟随完重定向之后的那个）。
     *
     * 登录 POST 之后 WebView 的地址栏仍停在带表单字段的假 GET 上，
     * 界面层要用它做 `history.replaceState`，把密码从历史条目里抹掉。
     * 主框架导航是串行的，单个字段足够；子资源请求不会覆盖它。
     */
    @Volatile
    var lastMainFrameUrl: String? = null
        private set

    /**
     * `shouldInterceptRequest` 的实现体。
     *
     * @return 代理得到的响应；返回 null 表示「交回 WebView 原生加载」。
     */
    fun intercept(request: WebResourceRequest?, cookies: CookieManager?): WebResourceResponse? {
        if (!enabled) return null
        val uri = request?.url ?: return null
        if (!WebLoginPlan.isAo3Host(uri.host)) return null
        val cookieJar = cookies ?: return null
        val url = uri.toString()
        val method = (request.method ?: "GET").trim().uppercase()

        // 拿不到 body 的原生 POST：让 WebView 自己提交，只提示一次
        if (method == "POST" && WebLoginPlan.splitPostRequest(url) == null) {
            onPostFallback()
            return null
        }

        return runCatching { exchange(url, method, request.requestHeaders, cookieJar, request.isForMainFrame) }
            .getOrNull()
    }

    private fun exchange(
        startUrl: String,
        startMethod: String,
        headers: Map<String, String>?,
        cookies: CookieManager,
        forMainFrame: Boolean
    ): WebResourceResponse? {
        val posted = WebLoginPlan.splitPostRequest(startUrl)
        var url = posted?.targetUrl ?: startUrl
        var method = if (posted != null) "POST" else startMethod
        var body: RequestBody? = posted?.let { buildFormBody(it.fields) }
        val cleanHeaders = WebLoginPlan.sanitizeRequestHeaders(headers)

        var hop = 0
        while (true) {
            val builder = Request.Builder().url(url)
            cleanHeaders.forEach { (name, value) -> builder.header(name, value) }
            builder.header("User-Agent", Ao3Client.USER_AGENT)
            builder.header("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
            cookies.getCookie(url)?.takeIf { it.isNotBlank() }?.let { builder.header("Cookie", it) }
            // GET / HEAD 不允许带 body，其余方法带上（重定向降级成 GET 时已在下面清空）
            if (body != null && method != "GET" && method != "HEAD") {
                builder.method(method, body)
            } else {
                builder.method(method, null)
            }

            val response = client.newCall(builder.build()).execute()
            syncCookies(response, url, cookies)
            if (forMainFrame) lastMainFrameUrl = url

            val location = response.header("Location")
            if (WebLoginPlan.isRedirect(response.code) &&
                !location.isNullOrBlank() &&
                hop < WebLoginPlan.MAX_REDIRECTS
            ) {
                val next = WebLoginPlan.resolveLocation(url, location)
                val nextMethod = WebLoginPlan.redirectMethod(response.code, method)
                response.close()
                if (next.isNullOrEmpty()) return null
                // 307/308 保留原方法与 body；降级成 GET 时必须丢掉 body
                body = if (nextMethod == method && method != "GET" && method != "HEAD") body else null
                method = nextMethod
                url = next
                hop++
                continue
            }
            return toWebResponse(response, url)
        }
    }

    /** 把响应的 Set-Cookie 原文写回 CookieManager；确有写入时才 flush，避免每个子资源都同步磁盘。 */
    private fun syncCookies(response: Response, url: String, cookies: CookieManager) {
        val setCookies = WebLoginPlan.extractSetCookies(response.headers.toMultimap())
        if (setCookies.isEmpty()) return
        setCookies.forEach { raw -> runCatching { cookies.setCookie(url, raw) } }
        runCatching { cookies.flush() }
    }

    /**
     * 把 OkHttp 响应包成 `WebResourceResponse`。
     *
     * 响应体以流的形式交出（不 `use{}`、不读进内存），由 WebView 负责关闭，
     * 关闭流即释放连接，因此大页面也不会整块驻留内存。
     */
    private fun toWebResponse(response: Response, url: String): WebResourceResponse {
        val contentType = response.header("Content-Type")
        val mime = WebLoginPlan.mimeOf(contentType) ?: guessMime(url)
        val charset = WebLoginPlan.charsetOf(contentType) ?: "UTF-8"
        val stream: InputStream = response.body?.byteStream() ?: ByteArrayInputStream(ByteArray(0))
        return WebResourceResponse(
            mime,
            charset,
            response.code,
            WebLoginPlan.reasonPhrase(response.code),
            WebLoginPlan.sanitizeResponseHeaders(response.headers.toMultimap()),
            stream
        )
    }

    private fun buildFormBody(fields: List<Pair<String, String>>): RequestBody {
        val builder = FormBody.Builder()
        fields.forEach { (name, value) -> builder.add(name, value) }
        return builder.build()
    }

    /** `Content-Type` 缺失时按扩展名兜底，保证 CSS/JS/图片不会被当成 HTML 解析。 */
    private fun guessMime(url: String): String {
        val path = url.substringBefore('?').substringBefore('#').lowercase()
        return when {
            path.endsWith(".css") -> "text/css"
            path.endsWith(".js") -> "application/javascript"
            path.endsWith(".json") -> "application/json"
            path.endsWith(".png") -> "image/png"
            path.endsWith(".jpg") || path.endsWith(".jpeg") -> "image/jpeg"
            path.endsWith(".gif") -> "image/gif"
            path.endsWith(".svg") -> "image/svg+xml"
            path.endsWith(".webp") -> "image/webp"
            path.endsWith(".ico") -> "image/x-icon"
            path.endsWith(".woff2") -> "font/woff2"
            path.endsWith(".woff") -> "font/woff"
            path.endsWith(".txt") -> "text/plain"
            path.endsWith(".xml") -> "application/xml"
            else -> "text/html"
        }
    }
}
